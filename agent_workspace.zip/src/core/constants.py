"""
Constantes del sistema OpenAI + MCP
"""

# Versión del sistema
SYSTEM_VERSION = "1.0.0"
SYSTEM_NAME = "OpenAI-MCP-Chat"

# Configuración de OpenAI
DEFAULT_OPENAI_MODEL = "gpt-4.1"
REASONING_MODEL = "o4-mini"
MAX_TOKENS_DEFAULT = 2048
TEMPERATURE_DEFAULT = 0.7
TIMEOUT_DEFAULT = 60

# Configuración de MCP
MCP_PROTOCOL_VERSION = "2024-11-05"
MCP_SERVER_LABEL = "chat-assistant-pro"
MCP_REQUIRE_APPROVAL = "never"
MAX_TOOLS_PER_REQUEST = 5

# Herramientas MCP disponibles
AVAILABLE_TOOLS = {
    # Búsqueda y análisis
    "buscar_informacion": {
        "name": "buscar_informacion",
        "description": "Buscar información usando SerpAPI",
        "category": "search",
        "parameters": ["query", "tipo", "region"]
    },
    "buscar_noticias": {
        "name": "buscar_noticias", 
        "description": "Buscar noticias actuales",
        "category": "search",
        "parameters": ["query", "region", "fecha"]
    },
    "buscar_academico": {
        "name": "buscar_academico",
        "description": "Buscar artículos académicos",
        "category": "search", 
        "parameters": ["query", "año", "autor"]
    },
    "analizar_tendencias": {
        "name": "analizar_tendencias",
        "description": "Analizar tendencias de búsqueda",
        "category": "analytics",
        "parameters": ["keywords", "periodo", "region"]
    },
    
    # Comunicación
    "gestionar_email": {
        "name": "gestionar_email",
        "description": "Gestionar operaciones de email",
        "category": "communication",
        "parameters": ["accion", "destinatario", "asunto", "contenido"]
    },
    "gestionar_calendario": {
        "name": "gestionar_calendario", 
        "description": "Gestionar operaciones de calendario",
        "category": "communication",
        "parameters": ["accion", "titulo", "fecha", "hora"]
    },
    
    # Análisis avanzado
    "analizar_sentimiento": {
        "name": "analizar_sentimiento",
        "description": "Analizar sentimiento de texto",
        "category": "analytics",
        "parameters": ["texto", "idioma"]
    },
    "generar_resumen": {
        "name": "generar_resumen",
        "description": "Generar resumen de contenido",
        "category": "analytics", 
        "parameters": ["contenido", "longitud", "estilo"]
    },
    "traducir_contenido": {
        "name": "traducir_contenido",
        "description": "Traducir contenido a otro idioma",
        "category": "analytics",
        "parameters": ["texto", "idioma_origen", "idioma_destino"]
    },
    
    # Flujos de trabajo
    "flujo_investigacion": {
        "name": "flujo_investigacion",
        "description": "Flujo completo de investigación",
        "category": "workflow",
        "parameters": ["tema", "profundidad", "formato_salida"]
    },
    "flujo_comunicacion": {
        "name": "flujo_comunicacion",
        "description": "Flujo de comunicación automatizada",
        "category": "workflow", 
        "parameters": ["destinatario", "tipo", "contenido"]
    },
    "flujo_analisis_competencia": {
        "name": "flujo_analisis_competencia",
        "description": "Análisis de competencia completo",
        "category": "workflow",
        "parameters": ["empresa", "sector", "metricas"]
    }
}

# Categorías de herramientas
TOOL_CATEGORIES = {
    "search": "Búsqueda e información",
    "communication": "Comunicación",
    "analytics": "Análisis y procesamiento",
    "workflow": "Flujos de trabajo"
}

# Patrones de selección de herramientas
TOOL_SELECTION_PATTERNS = {
    "research_intent": {
        "keywords": ["buscar", "investigar", "información", "datos", "estudiar"],
        "tools": ["buscar_informacion", "buscar_academico", "analizar_tendencias"]
    },
    "communication_intent": {
        "keywords": ["email", "correo", "enviar", "calendario", "cita", "reunión"],
        "tools": ["gestionar_email", "gestionar_calendario"]
    },
    "analysis_intent": {
        "keywords": ["analizar", "sentimiento", "resumen", "traducir", "procesar"],
        "tools": ["analizar_sentimiento", "generar_resumen", "traducir_contenido"]
    },
    "workflow_intent": {
        "keywords": ["flujo", "completo", "automatizar", "proceso", "competencia"],
        "tools": ["flujo_investigacion", "flujo_comunicacion", "flujo_analisis_competencia"]
    }
}

# Configuración de caché
CACHE_TTL = {
    "tool_list": 3600,      # 1 hora
    "responses": 1800,      # 30 minutos  
    "context": 7200,        # 2 horas
    "search_results": 3600, # 1 hora
    "user_preferences": 86400  # 24 horas
}

# Configuración de rate limiting
RATE_LIMITS = {
    "requests_per_minute": 60,
    "tokens_per_hour": 100000,
    "tools_per_request": 5,
    "max_conversation_length": 50
}

# URLs y endpoints
SERPAPI_BASE_URL = "https://serpapi.com/search"
OPENAI_BASE_URL = "https://api.openai.com/v1"
GOOGLE_OAUTH_SCOPES = [
    "https://mail.google.com/",
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/userinfo.email"
]

# Códigos de error
ERROR_CODES = {
    # Errores de sistema
    "SYSTEM_ERROR": "ERR_SYS_001",
    "CONFIG_ERROR": "ERR_CFG_001",
    "AUTH_ERROR": "ERR_AUTH_001",
    
    # Errores de OpenAI
    "OPENAI_API_ERROR": "ERR_OAI_001",
    "OPENAI_RATE_LIMIT": "ERR_OAI_002", 
    "OPENAI_TIMEOUT": "ERR_OAI_003",
    "OPENAI_TOKEN_ERROR": "ERR_OAI_004",
    
    # Errores de MCP
    "MCP_CONNECTION_ERROR": "ERR_MCP_001",
    "MCP_TOOL_NOT_FOUND": "ERR_MCP_002",
    "MCP_TOOL_EXECUTION_ERROR": "ERR_MCP_003",
    "MCP_SERVER_ERROR": "ERR_MCP_004",
    
    # Errores de servicios externos
    "SERPAPI_ERROR": "ERR_EXT_001",
    "GMAIL_ERROR": "ERR_EXT_002",
    "CALENDAR_ERROR": "ERR_EXT_003",
    
    # Errores de validación
    "VALIDATION_ERROR": "ERR_VAL_001",
    "DATA_PROCESSING_ERROR": "ERR_VAL_002",
    
    # Errores de red
    "NETWORK_ERROR": "ERR_NET_001",
    "TIMEOUT_ERROR": "ERR_NET_002",
    
    # Errores de recursos
    "RESOURCE_NOT_FOUND": "ERR_RES_001",
    "RESOURCE_UNAVAILABLE": "ERR_RES_002",
    
    # Errores de seguridad
    "SECURITY_ERROR": "ERR_SEC_001",
    "RATE_LIMIT_EXCEEDED": "ERR_SEC_002",
    "INVALID_TOKEN": "ERR_SEC_003"
}

# Mensajes de estado
STATUS_MESSAGES = {
    "initializing": "Inicializando sistema...",
    "ready": "Sistema listo",
    "processing": "Procesando solicitud...",
    "tool_execution": "Ejecutando herramienta...",
    "generating_response": "Generando respuesta...",
    "error": "Error en el sistema",
    "maintenance": "Sistema en mantenimiento"
}

# Configuración de modelos
MODEL_CONFIG = {
    "gpt-4.1": {
        "max_tokens": 4096,
        "temperature": 0.7,
        "use_cases": ["general", "analysis", "conversation"],
        "cost_per_1k_tokens": {"input": 0.03, "output": 0.06}
    },
    "o4-mini": {
        "max_tokens": 8192,
        "temperature": 0.3,
        "use_cases": ["reasoning", "complex_analysis"],
        "cost_per_1k_tokens": {"input": 0.15, "output": 0.60}
    }
}

# Configuración de optimización
OPTIMIZATION_CONFIG = {
    "token_optimization": {
        "max_context_length": 8000,
        "context_compression_threshold": 6000,
        "summary_when_over": 10000
    },
    "tool_selection": {
        "max_tools_per_intent": 3,
        "confidence_threshold": 0.7,
        "fallback_to_general": True
    },
    "caching": {
        "enable_response_cache": True,
        "enable_tool_cache": True,
        "cache_similarity_threshold": 0.9
    },
    "performance": {
        "concurrent_tool_execution": True,
        "max_concurrent_tools": 3,
        "tool_timeout": 30
    }
}

# Configuración de monitoreo
MONITORING_CONFIG = {
    "metrics_collection_interval": 60,
    "health_check_interval": 30,
    "log_retention_days": 30,
    "alert_thresholds": {
        "error_rate": 0.05,     # 5%
        "response_time": 5.0,   # 5 segundos
        "memory_usage": 0.85,   # 85%
        "cpu_usage": 0.80       # 80%
    }
}

# Configuración de seguridad
SECURITY_CONFIG = {
    "jwt_algorithm": "HS256",
    "access_token_expire_minutes": 30,
    "refresh_token_expire_days": 7,
    "password_min_length": 8,
    "max_login_attempts": 5,
    "lockout_duration_minutes": 15
}

# Configuración de la interfaz
UI_CONFIG = {
    "max_message_length": 4000,
    "conversation_history_limit": 100,
    "auto_save_interval": 30,
    "themes": ["light", "dark", "auto"],
    "default_theme": "auto",
    "supported_languages": ["es", "en", "fr", "de", "it", "pt"]
}

# Configuración de archivos
FILE_CONFIG = {
    "max_file_size_mb": 10,
    "allowed_extensions": [".txt", ".md", ".pdf", ".docx", ".csv", ".json"],
    "upload_directory": "uploads",
    "temp_directory": "temp",
    "log_directory": "logs"
}

# Patrones de intención para el procesamiento de mensajes
INTENT_PATTERNS = {
    "greeting": [
        "hola", "buenos días", "buenas tardes", "buenas noches", 
        "saludos", "hello", "hi", "hey"
    ],
    "help": [
        "ayuda", "help", "¿qué puedes hacer?", "comandos", 
        "instrucciones", "guía"
    ],
    "search": [
        "buscar", "busca", "encuentra", "search", "find", 
        "información sobre", "datos de"
    ],
    "email": [
        "email", "correo", "mail", "enviar email", "redactar",
        "bandeja de entrada", "gmail"
    ],
    "calendar": [
        "calendario", "calendar", "cita", "reunión", "evento",
        "agendar", "programar"
    ],
    "analysis": [
        "analizar", "análisis", "analyze", "estudiar", "examinar",
        "resumen", "sentimiento"
    ],
    "goodbye": [
        "adiós", "hasta luego", "bye", "goodbye", "nos vemos",
        "chao", "hasta pronto"
    ]
}

# Configuración de respuestas automáticas
AUTO_RESPONSES = {
    "greeting": [
        "¡Hola! Soy tu asistente de chat inteligente. ¿En qué puedo ayudarte hoy?",
        "¡Buenos días! Estoy aquí para ayudarte con búsquedas, emails, calendario y análisis.",
        "¡Saludos! ¿Qué te gustaría hacer hoy?"
    ],
    "help": [
        "Puedo ayudarte con:\n• Búsquedas web y académicas\n• Gestión de email y calendario\n• Análisis de texto y sentimientos\n• Flujos de trabajo automatizados\n\n¿Qué necesitas?",
        "Estas son mis capacidades principales:\n1. Búsqueda de información\n2. Gestión de Gmail\n3. Calendario de Google\n4. Análisis de contenido\n\n¿Por dónde empezamos?"
    ],
    "goodbye": [
        "¡Hasta luego! Ha sido un placer ayudarte.",
        "¡Nos vemos! No dudes en volver cuando necesites algo.",
        "¡Adiós! Que tengas un excelente día."
    ],
    "error": [
        "Lo siento, ha ocurrido un error. Por favor, intenta de nuevo.",
        "Disculpa, no pude procesar tu solicitud. ¿Puedes intentarlo otra vez?",
        "Ha habido un problema técnico. Estoy trabajando para solucionarlo."
    ]
}
