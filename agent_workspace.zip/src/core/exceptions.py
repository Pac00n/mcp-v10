"""
Excepciones personalizadas del sistema OpenAI + MCP
"""

from typing import Optional, Dict, Any


class MCPChatBaseException(Exception):
    """Excepción base del sistema"""
    
    def __init__(
        self, 
        message: str, 
        error_code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convertir excepción a diccionario"""
        return {
            "error": self.__class__.__name__,
            "message": self.message,
            "error_code": self.error_code,
            "details": self.details
        }


# Excepciones de configuración
class ConfigurationError(MCPChatBaseException):
    """Error de configuración del sistema"""
    pass


class AuthenticationError(MCPChatBaseException):
    """Error de autenticación"""
    pass


class AuthorizationError(MCPChatBaseException):
    """Error de autorización"""
    pass


# Excepciones de OpenAI
class OpenAIError(MCPChatBaseException):
    """Error general de OpenAI"""
    pass


class OpenAIAPIError(OpenAIError):
    """Error de API de OpenAI"""
    pass


class OpenAIRateLimitError(OpenAIError):
    """Error de límite de rate de OpenAI"""
    pass


class OpenAITimeoutError(OpenAIError):
    """Error de timeout de OpenAI"""
    pass


class OpenAITokenError(OpenAIError):
    """Error relacionado con tokens"""
    pass


# Excepciones de MCP
class MCPError(MCPChatBaseException):
    """Error general de MCP"""
    pass


class MCPServerError(MCPError):
    """Error del servidor MCP"""
    pass


class MCPToolError(MCPError):
    """Error de herramienta MCP"""
    pass


class MCPConnectionError(MCPError):
    """Error de conexión MCP"""
    pass


class MCPToolNotFoundError(MCPError):
    """Herramienta MCP no encontrada"""
    pass


class MCPToolExecutionError(MCPError):
    """Error de ejecución de herramienta MCP"""
    pass


# Excepciones de servicios externos
class ExternalServiceError(MCPChatBaseException):
    """Error de servicio externo"""
    pass


class SerpAPIError(ExternalServiceError):
    """Error de SerpAPI"""
    pass


class GoogleServiceError(ExternalServiceError):
    """Error de servicios Google"""
    pass


class GmailError(GoogleServiceError):
    """Error específico de Gmail"""
    pass


class CalendarError(GoogleServiceError):
    """Error específico de Google Calendar"""
    pass


# Excepciones de datos y validación
class ValidationError(MCPChatBaseException):
    """Error de validación de datos"""
    pass


class DataProcessingError(MCPChatBaseException):
    """Error de procesamiento de datos"""
    pass


class SerializationError(MCPChatBaseException):
    """Error de serialización"""
    pass


# Excepciones de caché y storage
class CacheError(MCPChatBaseException):
    """Error de caché"""
    pass


class StorageError(MCPChatBaseException):
    """Error de almacenamiento"""
    pass


# Excepciones de red
class NetworkError(MCPChatBaseException):
    """Error de red"""
    pass


class HTTPError(NetworkError):
    """Error HTTP"""
    pass


class TimeoutError(NetworkError):
    """Error de timeout"""
    pass


# Excepciones de recursos
class ResourceError(MCPChatBaseException):
    """Error de recursos"""
    pass


class ResourceNotFoundError(ResourceError):
    """Recurso no encontrado"""
    pass


class ResourceUnavailableError(ResourceError):
    """Recurso no disponible"""
    pass


# Excepciones de seguridad
class SecurityError(MCPChatBaseException):
    """Error de seguridad"""
    pass


class RateLimitError(SecurityError):
    """Error de límite de rate"""
    pass


class InvalidTokenError(SecurityError):
    """Token inválido"""
    pass


# Excepciones de contexto y flujo
class ContextError(MCPChatBaseException):
    """Error de contexto"""
    pass


class WorkflowError(MCPChatBaseException):
    """Error de flujo de trabajo"""
    pass


class OrchestrationError(MCPChatBaseException):
    """Error de orquestación"""
    pass


# Excepciones específicas del chat
class ChatError(MCPChatBaseException):
    """Error general de chat"""
    pass


class ConversationError(ChatError):
    """Error de conversación"""
    pass


class MessageProcessingError(ChatError):
    """Error de procesamiento de mensaje"""
    pass


class ResponseGenerationError(ChatError):
    """Error de generación de respuesta"""
    pass


# Funciones utilitarias para manejo de excepciones
def handle_openai_error(error: Exception) -> OpenAIError:
    """Convertir errores de OpenAI a nuestras excepciones"""
    error_message = str(error)
    
    if "rate limit" in error_message.lower():
        return OpenAIRateLimitError(
            message="Rate limit exceeded",
            error_code="OPENAI_RATE_LIMIT",
            details={"original_error": error_message}
        )
    elif "timeout" in error_message.lower():
        return OpenAITimeoutError(
            message="Request timeout",
            error_code="OPENAI_TIMEOUT", 
            details={"original_error": error_message}
        )
    elif "token" in error_message.lower():
        return OpenAITokenError(
            message="Token-related error",
            error_code="OPENAI_TOKEN_ERROR",
            details={"original_error": error_message}
        )
    else:
        return OpenAIAPIError(
            message=f"OpenAI API error: {error_message}",
            error_code="OPENAI_API_ERROR",
            details={"original_error": error_message}
        )


def handle_google_error(error: Exception, service: str = "google") -> GoogleServiceError:
    """Convertir errores de Google a nuestras excepciones"""
    error_message = str(error)
    
    if service.lower() == "gmail":
        return GmailError(
            message=f"Gmail error: {error_message}",
            error_code="GMAIL_ERROR",
            details={"original_error": error_message, "service": service}
        )
    elif service.lower() == "calendar":
        return CalendarError(
            message=f"Calendar error: {error_message}",
            error_code="CALENDAR_ERROR",
            details={"original_error": error_message, "service": service}
        )
    else:
        return GoogleServiceError(
            message=f"Google service error: {error_message}",
            error_code="GOOGLE_SERVICE_ERROR",
            details={"original_error": error_message, "service": service}
        )


def handle_mcp_error(error: Exception, tool_name: Optional[str] = None) -> MCPError:
    """Convertir errores de MCP a nuestras excepciones"""
    error_message = str(error)
    
    if "connection" in error_message.lower():
        return MCPConnectionError(
            message="MCP connection error",
            error_code="MCP_CONNECTION_ERROR",
            details={"original_error": error_message, "tool": tool_name}
        )
    elif "not found" in error_message.lower():
        return MCPToolNotFoundError(
            message=f"MCP tool not found: {tool_name}",
            error_code="MCP_TOOL_NOT_FOUND",
            details={"original_error": error_message, "tool": tool_name}
        )
    elif "execution" in error_message.lower():
        return MCPToolExecutionError(
            message=f"MCP tool execution failed: {tool_name}",
            error_code="MCP_TOOL_EXECUTION_ERROR",
            details={"original_error": error_message, "tool": tool_name}
        )
    else:
        return MCPError(
            message=f"MCP error: {error_message}",
            error_code="MCP_ERROR",
            details={"original_error": error_message, "tool": tool_name}
        )