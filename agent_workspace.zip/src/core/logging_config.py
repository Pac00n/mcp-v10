"""
Configuración de logging estructurado para el sistema
"""

import logging
import logging.handlers
import structlog
import sys
from pathlib import Path
from typing import Any, Dict
from .config import get_settings


def setup_logging() -> None:
    """Configurar logging estructurado"""
    settings = get_settings()
    
    # Crear directorio de logs si no existe
    log_path = Path(settings.logging.file_path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Configurar structlog
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer() if settings.logging.enable_structured 
            else structlog.dev.ConsoleRenderer()
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )
    
    # Configurar logging estándar
    logging.basicConfig(
        level=getattr(logging, settings.logging.level.upper()),
        format=settings.logging.format,
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.handlers.RotatingFileHandler(
                filename=settings.logging.file_path,
                maxBytes=settings.logging.max_bytes,
                backupCount=settings.logging.backup_count,
                encoding='utf-8'
            )
        ]
    )
    
    # Configurar niveles para librerías externas
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("google").setLevel(logging.INFO)
    logging.getLogger("openai").setLevel(logging.INFO)


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """Obtener logger estructurado"""
    return structlog.get_logger(name)


class LoggingMixin:
    """Mixin para agregar logging a cualquier clase"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.logger = get_logger(self.__class__.__name__)
    
    def log_info(self, message: str, **kwargs):
        """Log de información"""
        self.logger.info(message, **kwargs)
    
    def log_warning(self, message: str, **kwargs):
        """Log de advertencia"""
        self.logger.warning(message, **kwargs)
    
    def log_error(self, message: str, **kwargs):
        """Log de error"""
        self.logger.error(message, **kwargs)
    
    def log_debug(self, message: str, **kwargs):
        """Log de debug"""
        self.logger.debug(message, **kwargs)
    
    def log_exception(self, message: str, **kwargs):
        """Log de excepción"""
        self.logger.exception(message, **kwargs)


def log_function_call(func_name: str, args: tuple = (), kwargs: Dict[str, Any] = None):
    """Decorator para loggear llamadas a funciones"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            logger = get_logger(func.__module__)
            logger.debug(
                "Function called",
                function=func_name,
                args=args[:3],  # Solo primeros 3 args para evitar logs masivos
                kwargs_keys=list((kwargs or {}).keys())
            )
            try:
                result = func(*args, **kwargs)
                logger.debug("Function completed", function=func_name, success=True)
                return result
            except Exception as e:
                logger.error(
                    "Function failed",
                    function=func_name,
                    error=str(e),
                    error_type=type(e).__name__
                )
                raise
        return wrapper
    return decorator


def log_async_function_call(func_name: str):
    """Decorator para loggear llamadas a funciones async"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            logger = get_logger(func.__module__)
            logger.debug(
                "Async function called",
                function=func_name,
                args=args[:3],
                kwargs_keys=list((kwargs or {}).keys())
            )
            try:
                result = await func(*args, **kwargs)
                logger.debug("Async function completed", function=func_name, success=True)
                return result
            except Exception as e:
                logger.error(
                    "Async function failed",
                    function=func_name,
                    error=str(e),
                    error_type=type(e).__name__
                )
                raise
        return wrapper
    return decorator


class PerformanceLogger:
    """Logger específico para métricas de rendimiento"""
    
    def __init__(self):
        self.logger = get_logger("performance")
    
    def log_request_time(self, endpoint: str, duration: float, status: str = "success"):
        """Log de tiempo de request"""
        self.logger.info(
            "Request completed",
            endpoint=endpoint,
            duration_ms=round(duration * 1000, 2),
            status=status
        )
    
    def log_tool_execution(self, tool_name: str, duration: float, success: bool = True):
        """Log de ejecución de herramienta"""
        self.logger.info(
            "Tool execution",
            tool=tool_name,
            duration_ms=round(duration * 1000, 2),
            success=success
        )
    
    def log_token_usage(self, model: str, input_tokens: int, output_tokens: int, total_cost: float = None):
        """Log de uso de tokens"""
        self.logger.info(
            "Token usage",
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=input_tokens + output_tokens,
            estimated_cost=total_cost
        )
    
    def log_cache_hit(self, cache_key: str, hit: bool):
        """Log de hit/miss de caché"""
        self.logger.debug(
            "Cache access",
            key=cache_key,
            hit=hit,
            action="hit" if hit else "miss"
        )


class SecurityLogger:
    """Logger específico para eventos de seguridad"""
    
    def __init__(self):
        self.logger = get_logger("security")
    
    def log_authentication_attempt(self, user_id: str, success: bool, ip_address: str = None):
        """Log de intento de autenticación"""
        self.logger.info(
            "Authentication attempt",
            user_id=user_id,
            success=success,
            ip_address=ip_address,
            event_type="auth_attempt"
        )
    
    def log_rate_limit_exceeded(self, user_id: str, endpoint: str, ip_address: str = None):
        """Log de exceso de rate limit"""
        self.logger.warning(
            "Rate limit exceeded",
            user_id=user_id,
            endpoint=endpoint,
            ip_address=ip_address,
            event_type="rate_limit_exceeded"
        )
    
    def log_unauthorized_access(self, user_id: str, resource: str, ip_address: str = None):
        """Log de acceso no autorizado"""
        self.logger.warning(
            "Unauthorized access attempt",
            user_id=user_id,
            resource=resource,
            ip_address=ip_address,
            event_type="unauthorized_access"
        )


class ErrorLogger:
    """Logger específico para errores del sistema"""
    
    def __init__(self):
        self.logger = get_logger("errors")
    
    def log_system_error(self, error: Exception, context: Dict[str, Any] = None):
        """Log de error del sistema"""
        self.logger.error(
            "System error",
            error=str(error),
            error_type=type(error).__name__,
            context=context or {},
            event_type="system_error"
        )
    
    def log_external_service_error(self, service: str, error: str, request_id: str = None):
        """Log de error de servicio externo"""
        self.logger.error(
            "External service error",
            service=service,
            error=error,
            request_id=request_id,
            event_type="external_service_error"
        )
    
    def log_validation_error(self, data: Dict[str, Any], errors: list):
        """Log de error de validación"""
        self.logger.warning(
            "Validation error",
            data_keys=list(data.keys()),
            errors=errors,
            event_type="validation_error"
        )


# Instancias globales de loggers especializados
performance_logger = PerformanceLogger()
security_logger = SecurityLogger()
error_logger = ErrorLogger()


def initialize_logging():
    """Inicializar sistema de logging"""
    setup_logging()
    logger = get_logger("system")
    logger.info("Logging system initialized", version="1.0.0")


# Inicializar automáticamente
initialize_logging()