"""
Configuración centralizada del sistema OpenAI + MCP
"""

import os
from pathlib import Path
from typing import Dict, List, Optional, Any
from pydantic import Field, field_validator, ValidationInfo
from pydantic_settings import BaseSettings
import yaml


class GoogleConfig(BaseSettings):
    """Configuración de servicios Google"""
    
    oauth_file: str = Field(default=".gauth.json", description="Archivo de credenciales OAuth")
    credentials_dir: str = Field(default="./config/credentials", description="Directorio de credenciales")
    scopes: List[str] = Field(
        default_factory=lambda: [
            "https://mail.google.com/",
            "https://www.googleapis.com/auth/calendar",
            "https://www.googleapis.com/auth/userinfo.email"
        ],
        description="Scopes de Google API"
    )
    
    class Config:
        env_prefix = "GOOGLE_"


class SerpAPIConfig(BaseSettings):
    """Configuración de SerpAPI"""
    
    api_key: Optional[str] = Field(default=None, description="API Key de SerpAPI")
    base_url: str = Field(default="https://serpapi.com/search", description="URL base de SerpAPI")
    timeout: int = Field(default=30, description="Timeout en segundos")
    max_retries: int = Field(default=3, description="Máximo número de reintentos")
    
    class Config:
        env_prefix = "SERPAPI_"


class OpenAIConfig(BaseSettings):
    """Configuración de OpenAI"""
    
    api_key: Optional[str] = Field(default=None, description="API Key de OpenAI")
    base_url: str = Field(default="https://api.openai.com/v1", description="URL base de OpenAI")
    default_model: str = Field(default="gpt-4.1", description="Modelo por defecto")
    reasoning_model: str = Field(default="o4-mini", description="Modelo para tareas de razonamiento")
    max_tokens: int = Field(default=2048, description="Máximo de tokens por respuesta")
    temperature: float = Field(default=0.7, description="Temperatura del modelo")
    timeout: int = Field(default=60, description="Timeout en segundos")
    
    class Config:
        env_prefix = "OPENAI_"


class MCPConfig(BaseSettings):
    """Configuración del servidor MCP"""
    
    server_host: str = Field(default="0.0.0.0", description="Host del servidor MCP")
    server_port: int = Field(default=8000, description="Puerto del servidor MCP")
    server_url: str = Field(default="http://localhost:8000/mcp/v1", description="URL del servidor MCP")
    server_label: str = Field(default="chat-assistant-pro", description="Etiqueta del servidor")
    require_approval: str = Field(default="never", description="Política de aprobación")
    max_tools_per_request: int = Field(default=5, description="Máximo de herramientas por request")
    enable_streamable_http: bool = Field(default=True, description="Habilitar Streamable HTTP")
    
    class Config:
        env_prefix = "MCP_"


class CacheConfig(BaseSettings):
    """Configuración de caché"""
    
    redis_url: str = Field(default="redis://localhost:6379", description="URL de Redis")
    redis_db: int = Field(default=0, description="Base de datos Redis")
    tool_list_ttl: int = Field(default=3600, description="TTL para lista de herramientas (segundos)")
    response_ttl: int = Field(default=1800, description="TTL para respuestas (segundos)")
    context_ttl: int = Field(default=7200, description="TTL para contexto de usuario (segundos)")
    
    class Config:
        env_prefix = "CACHE_"


class LoggingConfig(BaseSettings):
    """Configuración de logging"""
    
    level: str = Field(default="INFO", description="Nivel de logging")
    format: str = Field(
        default="%(asctime)s | %(levelname)s | %(name)s | %(funcName)s:%(lineno)d | %(message)s",
        description="Formato de logging"
    )
    file_path: str = Field(default="logs/mcp_chat.log", description="Archivo de logs")
    max_bytes: int = Field(default=10485760, description="Tamaño máximo del archivo de log")
    backup_count: int = Field(default=5, description="Número de archivos de backup")
    enable_structured: bool = Field(default=True, description="Habilitar logging estructurado")
    
    class Config:
        env_prefix = "LOGGING_"


class MonitoringConfig(BaseSettings):
    """Configuración de monitoreo"""
    
    enable_prometheus: bool = Field(default=True, description="Habilitar métricas Prometheus")
    prometheus_port: int = Field(default=9090, description="Puerto de Prometheus")
    enable_health_checks: bool = Field(default=True, description="Habilitar health checks")
    metrics_collection_interval: int = Field(default=60, description="Intervalo de recolección de métricas")
    
    class Config:
        env_prefix = "MONITORING_"


class SecurityConfig(BaseSettings):
    """Configuración de seguridad"""
    
    secret_key: str = Field(default="changeme", description="Clave secreta para JWT")
    algorithm: str = Field(default="HS256", description="Algoritmo para JWT")
    access_token_expire_minutes: int = Field(default=30, description="Expiración del token de acceso")
    rate_limit_per_minute: int = Field(default=60, description="Límite de requests por minuto")
    
    class Config:
        env_prefix = "SECURITY_"


class Settings(BaseSettings):
    """Configuración principal del sistema"""
    
    # Configuración del entorno
    environment: str = Field(default="development", description="Entorno de ejecución")
    debug: bool = Field(default=True, description="Modo debug")
    
    # Configuraciones específicas
    google: GoogleConfig = Field(default_factory=GoogleConfig)
    serpapi: SerpAPIConfig = Field(default_factory=SerpAPIConfig)
    openai: OpenAIConfig = Field(default_factory=OpenAIConfig)
    mcp: MCPConfig = Field(default_factory=MCPConfig)
    cache: CacheConfig = Field(default_factory=CacheConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    monitoring: MonitoringConfig = Field(default_factory=MonitoringConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    
    # Configuración de herramientas
    enabled_tools: List[str] = Field(
        default_factory=lambda: [
            "buscar_informacion",
            "gestionar_email", 
            "gestionar_calendario",
            "analizar_sentimiento",
            "generar_resumen",
            "flujo_investigacion",
            "flujo_comunicacion"
        ],
        description="Herramientas MCP habilitadas"
    )
    
    # Optimizaciones
    optimization_config: Dict[str, Any] = Field(
        default_factory=lambda: {
            "tool_selection": {
                "dynamic_filtering": True,
                "context_aware": True,
                "max_tools_per_request": 5
            },
            "caching": {
                "enabled": True,
                "strategy": "intelligent"
            },
            "model_selection": {
                "adaptive": True,
                "performance_tracking": True
            }
        },
        description="Configuración de optimizaciones"
    )
    
    # TODO: Re-implement validators for Pydantic v2 when needed
    # @field_validator('environment')
    # @classmethod
    # def validate_environment(cls, v):
    #     valid_envs = ['development', 'staging', 'production']
    #     if v not in valid_envs:
    #         raise ValueError(f'Environment must be one of {valid_envs}')
    #     return v
    
    # @field_validator('secret_key')
    # @classmethod
    # def validate_secret_key(cls, v):
    #     # Note: In production, ensure secret_key is changed from default
    #     if v == 'changeme':
    #         import os
    #         if os.getenv('ENVIRONMENT') == 'production':
    #             raise ValueError('Secret key must be changed in production')
    #     return v
    
    def load_from_yaml(self, config_path: str) -> None:
        """Cargar configuración desde archivo YAML"""
        config_file = Path(config_path)
        if config_file.exists():
            with open(config_file, 'r', encoding='utf-8') as f:
                yaml_config = yaml.safe_load(f)
                for key, value in yaml_config.items():
                    if hasattr(self, key):
                        setattr(self, key, value)
    
    def get_mcp_tool_config(self, allowed_tools: Optional[List[str]] = None) -> Dict[str, Any]:
        """Generar configuración de herramientas MCP"""
        return {
            "type": "mcp",
            "server_url": self.mcp.server_url,
            "server_label": self.mcp.server_label,
            "allowed_tools": allowed_tools or self.enabled_tools,
            "require_approval": self.mcp.require_approval,
            "headers": {
                "Authorization": f"Bearer {self.get_mcp_api_key()}",
                "X-Client-Version": "1.0.0"
            }
        }
    
    def get_mcp_api_key(self) -> str:
        """Obtener API key para MCP (puede ser generado o configurado)"""
        return os.getenv("MCP_API_KEY", "mcp-internal-key")
    
    def is_production(self) -> bool:
        """Verificar si está en producción"""
        return self.environment == "production"
    
    def is_development(self) -> bool:
        """Verificar si está en desarrollo"""
        return self.environment == "development"
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
        extra = "allow"


# Instancia global de configuración
settings = Settings()

# Cargar configuración específica del entorno si existe
config_file = f"config/{settings.environment}.yaml"
if os.path.exists(config_file):
    settings.load_from_yaml(config_file)


def get_settings() -> Settings:
    """Obtener instancia de configuración"""
    return settings


def reload_settings() -> Settings:
    """Recargar configuración"""
    global settings
    settings = Settings()
    config_file = f"config/{settings.environment}.yaml"
    if os.path.exists(config_file):
        settings.load_from_yaml(config_file)
    return settings