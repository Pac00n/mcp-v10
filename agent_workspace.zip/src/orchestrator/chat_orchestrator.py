"""
Orquestador principal del chat MCP + OpenAI
Coordina la comunicación entre OpenAI y el servidor MCP
"""

import asyncio
import uuid
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import json

from ..core.config import get_settings
from ..core.logging_config import get_logger, performance_logger
from ..core.exceptions import OrchestrationError, ValidationError, ToolError
from ..openai_integration.openai_client import OpenAIClient, ConversationMessage, ChatResponse, MCPToolCall
from ..mcp.server import MCPServer
from ..utils.cache import CacheManager
from ..utils.validators import MasterValidator


@dataclass
class ChatSession:
    """Sesión de chat individual"""
    session_id: str
    user_id: str
    created_at: datetime
    last_activity: datetime
    message_count: int = 0
    tokens_used: int = 0
    conversation_history: List[ConversationMessage] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)
    preferences: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ChatRequest:
    """Solicitud de chat entrante"""
    message: str
    session_id: Optional[str] = None
    user_id: Optional[str] = None
    tools_enabled: bool = True
    stream_response: bool = False
    context: Optional[Dict[str, Any]] = None


@dataclass
class ChatResult:
    """Resultado completo de procesamiento de chat"""
    response: str
    session_id: str
    tool_calls_made: List[str]
    tokens_used: Dict[str, int]
    response_time: float
    cached: bool = False
    error: Optional[str] = None


class ChatOrchestrator:
    """Orquestador principal del sistema de chat"""
    
    def __init__(self):
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        # Componentes principales
        self.openai_client: Optional[OpenAIClient] = None
        self.mcp_server: Optional[MCPServer] = None
        self.cache_manager: Optional[CacheManager] = None
        self.validator: Optional[MasterValidator] = None
        
        # Sesiones activas
        self.active_sessions: Dict[str, ChatSession] = {}
        
        # Configuración del sistema
        self.system_prompts = {
            'default': self._get_default_system_prompt(),
            'tool_selection': self._get_tool_selection_prompt(),
            'error_handling': self._get_error_handling_prompt()
        }
        
        # Límites y configuración
        self.max_sessions = self.settings.orchestrator.max_active_sessions
        self.session_timeout = timedelta(hours=self.settings.orchestrator.session_timeout_hours)
        self.max_history_length = self.settings.orchestrator.max_history_messages
        
        # Estadísticas
        self.stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'tool_calls_made': 0,
            'sessions_created': 0,
            'cache_hits': 0,
            'errors': 0
        }
        
        self.is_initialized = False
    
    async def initialize(self) -> None:
        """Inicializar orquestador y todos sus componentes"""
        try:
            self.logger.info("Inicializando Chat Orchestrator...")
            
            # Inicializar componentes auxiliares
            self.cache_manager = CacheManager()
            await self.cache_manager.initialize()
            
            self.validator = MasterValidator()
            
            # Inicializar OpenAI Client
            self.openai_client = OpenAIClient()
            await self.openai_client.initialize()
            
            # Inicializar MCP Server
            self.mcp_server = MCPServer()
            await self.mcp_server.initialize()
            
            # Configurar task de limpieza de sesiones
            asyncio.create_task(self._session_cleanup_task())
            
            self.is_initialized = True
            self.logger.info("Chat Orchestrator inicializado correctamente")
            
        except Exception as e:
            self.logger.error(f"Error inicializando orquestador: {e}")
            raise OrchestrationError(f"Failed to initialize orchestrator: {e}")
    
    async def process_chat_request(self, request: ChatRequest) -> ChatResult:
        """
        Procesar solicitud de chat completa
        
        Args:
            request: Solicitud de chat
        
        Returns:
            Resultado completo del procesamiento
        """
        try:
            self._ensure_initialized()
            start_time = asyncio.get_event_loop().time()
            
            # Validar solicitud
            await self._validate_chat_request(request)
            
            # Obtener o crear sesión
            session = await self._get_or_create_session(request)
            
            # Procesar mensaje
            result = await self._process_message_with_tools(request, session)
            
            # Actualizar sesión
            await self._update_session(session, request, result)
            
            # Actualizar estadísticas
            execution_time = asyncio.get_event_loop().time() - start_time
            self._update_stats(result, execution_time)
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error procesando chat request: {e}")
            self.stats['errors'] += 1
            
            return ChatResult(
                response=f"Lo siento, ocurrió un error procesando tu mensaje: {e}",
                session_id=request.session_id or "error",
                tool_calls_made=[],
                tokens_used={'total_tokens': 0},
                response_time=0,
                error=str(e)
            )
    
    async def _process_message_with_tools(self, request: ChatRequest, session: ChatSession) -> ChatResult:
        """Procesar mensaje con herramientas MCP"""
        try:
            # Preparar historial de conversación
            conversation_history = self._prepare_conversation_history(session, request)
            
            # Obtener herramientas disponibles
            available_tools = []
            if request.tools_enabled and self.mcp_server:
                available_tools = await self.mcp_server.get_available_tools_for_openai()
            
            # Primera llamada a OpenAI
            chat_response = await self.openai_client.chat_completion(
                messages=conversation_history,
                tools=available_tools if available_tools else None,
                user_id=session.user_id,
                stream=request.stream_response
            )
            
            # Procesar tool calls si existen
            tool_calls_made = []
            if chat_response.tool_calls:
                tool_results = await self._execute_tool_calls(chat_response.tool_calls)
                tool_calls_made = [tc.function_name for tc in chat_response.tool_calls]
                
                # Si hay resultados de herramientas, hacer segunda llamada
                if tool_results:
                    updated_history = conversation_history.copy()
                    
                    # Agregar mensaje del asistente con tool calls
                    updated_history.append(ConversationMessage(
                        role="assistant",
                        content=chat_response.content,
                        tool_calls=chat_response.tool_calls
                    ))
                    
                    # Agregar resultados de herramientas
                    for tool_call, result in zip(chat_response.tool_calls, tool_results):
                        updated_history.append(ConversationMessage(
                            role="tool",
                            content=result,
                            tool_call_id=tool_call.call_id
                        ))
                    
                    # Segunda llamada para generar respuesta final
                    final_response = await self.openai_client.chat_completion(
                        messages=updated_history,
                        user_id=session.user_id
                    )
                    
                    # Usar respuesta final
                    chat_response.content = final_response.content
                    chat_response.tokens_used['total_tokens'] += final_response.tokens_used['total_tokens']
            
            return ChatResult(
                response=chat_response.content,
                session_id=session.session_id,
                tool_calls_made=tool_calls_made,
                tokens_used=chat_response.tokens_used,
                response_time=chat_response.response_time,
                cached=chat_response.cached
            )
            
        except Exception as e:
            self.logger.error(f"Error procesando mensaje con herramientas: {e}")
            raise OrchestrationError(f"Message processing failed: {e}")
    
    async def _execute_tool_calls(self, tool_calls: List[MCPToolCall]) -> List[str]:
        """Ejecutar llamadas a herramientas MCP"""
        try:
            if not self.mcp_server:
                raise ToolError("MCP Server not available")
            
            results = []
            
            for tool_call in tool_calls:
                try:
                    self.logger.info(f"Ejecutando herramienta: {tool_call.function_name}")
                    
                    # Ejecutar herramienta
                    result = await self.mcp_server.execute_tool(
                        tool_call.function_name,
                        tool_call.arguments
                    )
                    
                    results.append(result)
                    self.stats['tool_calls_made'] += 1
                    
                except Exception as e:
                    self.logger.error(f"Error ejecutando herramienta {tool_call.function_name}: {e}")
                    error_result = f"Error ejecutando {tool_call.function_name}: {e}"
                    results.append(error_result)
            
            return results
            
        except Exception as e:
            self.logger.error(f"Error en ejecución de herramientas: {e}")
            raise ToolError(f"Tool execution failed: {e}")
    
    async def _get_or_create_session(self, request: ChatRequest) -> ChatSession:
        """Obtener sesión existente o crear nueva"""
        try:
            # Si se proporciona session_id, intentar recuperar
            if request.session_id and request.session_id in self.active_sessions:
                session = self.active_sessions[request.session_id]
                session.last_activity = datetime.now()
                return session
            
            # Crear nueva sesión
            session_id = request.session_id or str(uuid.uuid4())
            user_id = request.user_id or "anonymous"
            
            session = ChatSession(
                session_id=session_id,
                user_id=user_id,
                created_at=datetime.now(),
                last_activity=datetime.now(),
                context=request.context or {}
            )
            
            # Limpiar sesiones si hay demasiadas
            if len(self.active_sessions) >= self.max_sessions:
                await self._cleanup_oldest_sessions()
            
            self.active_sessions[session_id] = session
            self.stats['sessions_created'] += 1
            
            self.logger.info(f"Nueva sesión creada: {session_id}")
            return session
            
        except Exception as e:
            self.logger.error(f"Error obteniendo/creando sesión: {e}")
            raise OrchestrationError(f"Session management failed: {e}")
    
    def _prepare_conversation_history(self, session: ChatSession, request: ChatRequest) -> List[ConversationMessage]:
        """Preparar historial de conversación para OpenAI"""
        try:
            conversation = []
            
            # Agregar prompt del sistema
            system_prompt = self._get_contextual_system_prompt(session, request)
            conversation.append(ConversationMessage(
                role="system",
                content=system_prompt,
                timestamp=datetime.now()
            ))
            
            # Agregar historial previo (limitado)
            if session.conversation_history:
                recent_history = session.conversation_history[-self.max_history_length:]
                conversation.extend(recent_history)
            
            # Agregar mensaje actual
            conversation.append(ConversationMessage(
                role="user",
                content=request.message,
                timestamp=datetime.now()
            ))
            
            return conversation
            
        except Exception as e:
            self.logger.error(f"Error preparando historial: {e}")
            # Fallback mínimo
            return [
                ConversationMessage(role="system", content=self.system_prompts['default']),
                ConversationMessage(role="user", content=request.message)
            ]
    
    def _get_contextual_system_prompt(self, session: ChatSession, request: ChatRequest) -> str:
        """Generar prompt del sistema contextual"""
        try:
            base_prompt = self.system_prompts['default']
            
            # Agregar información de herramientas disponibles
            if request.tools_enabled and self.mcp_server:
                tools_info = "\n\nHerramientas disponibles:"
                tools_info += "\n- Búsqueda web y académica (SerpAPI)"
                tools_info += "\n- Gestión de email (Gmail)"
                tools_info += "\n- Gestión de calendario (Google Calendar)"
                tools_info += "\n- Análisis de texto y sentimientos"
                tools_info += "\n- Flujos de trabajo automatizados"
                
                base_prompt += tools_info
            
            # Agregar contexto de sesión
            if session.context:
                context_info = f"\n\nContexto de la sesión: {json.dumps(session.context, indent=2)}"
                base_prompt += context_info
            
            return base_prompt
            
        except Exception as e:
            self.logger.error(f"Error generando prompt contextual: {e}")
            return self.system_prompts['default']
    
    async def _update_session(self, session: ChatSession, request: ChatRequest, result: ChatResult) -> None:
        """Actualizar sesión con nueva información"""
        try:
            # Agregar mensaje del usuario al historial
            session.conversation_history.append(ConversationMessage(
                role="user",
                content=request.message,
                timestamp=datetime.now()
            ))
            
            # Agregar respuesta del asistente
            session.conversation_history.append(ConversationMessage(
                role="assistant",
                content=result.response,
                timestamp=datetime.now(),
                tokens_used=result.tokens_used
            ))
            
            # Actualizar estadísticas de sesión
            session.message_count += 1
            session.tokens_used += result.tokens_used.get('total_tokens', 0)
            session.last_activity = datetime.now()
            
            # Mantener historial limitado
            if len(session.conversation_history) > self.max_history_length * 2:
                # Mantener siempre el primer mensaje (system prompt) y los más recientes
                system_messages = [msg for msg in session.conversation_history[:2] if msg.role == 'system']
                recent_messages = session.conversation_history[-self.max_history_length:]
                session.conversation_history = system_messages + recent_messages
            
        except Exception as e:
            self.logger.error(f"Error actualizando sesión: {e}")
    
    async def _validate_chat_request(self, request: ChatRequest) -> None:
        """Validar solicitud de chat"""
        try:
            if not request.message:
                raise ValidationError("Message cannot be empty")
            
            # Validar mensaje con el validator
            self.validator.message_validator.validate_message(request.message)
            
            # Validar longitud
            if len(request.message) > 4000:
                raise ValidationError("Message too long")
            
            # Validar session_id si se proporciona
            if request.session_id and not isinstance(request.session_id, str):
                raise ValidationError("Session ID must be string")
            
        except Exception as e:
            self.logger.error(f"Error validando chat request: {e}")
            raise ValidationError(f"Request validation failed: {e}")
    
    async def _cleanup_oldest_sessions(self) -> None:
        """Limpiar sesiones más antiguas"""
        try:
            if not self.active_sessions:
                return
            
            # Ordenar por última actividad
            sorted_sessions = sorted(
                self.active_sessions.items(),
                key=lambda x: x[1].last_activity
            )
            
            # Eliminar 20% de las sesiones más antiguas
            sessions_to_remove = max(1, len(sorted_sessions) // 5)
            
            for session_id, _ in sorted_sessions[:sessions_to_remove]:
                del self.active_sessions[session_id]
                self.logger.info(f"Sesión limpiada: {session_id}")
                
        except Exception as e:
            self.logger.error(f"Error limpiando sesiones: {e}")
    
    async def _session_cleanup_task(self) -> None:
        """Task de limpieza automática de sesiones"""
        while self.is_initialized:
            try:
                await asyncio.sleep(300)  # Cada 5 minutos
                
                current_time = datetime.now()
                expired_sessions = []
                
                for session_id, session in self.active_sessions.items():
                    if current_time - session.last_activity > self.session_timeout:
                        expired_sessions.append(session_id)
                
                for session_id in expired_sessions:
                    del self.active_sessions[session_id]
                    self.logger.info(f"Sesión expirada eliminada: {session_id}")
                
            except Exception as e:
                self.logger.error(f"Error en limpieza automática: {e}")
                await asyncio.sleep(60)  # Esperar 1 minuto antes de reintentar
    
    def _update_stats(self, result: ChatResult, execution_time: float) -> None:
        """Actualizar estadísticas del orquestador"""
        self.stats['total_requests'] += 1
        
        if not result.error:
            self.stats['successful_requests'] += 1
        
        if result.cached:
            self.stats['cache_hits'] += 1
        
        # Log de performance
        performance_logger.log_orchestrator_execution(
            execution_time,
            len(result.tool_calls_made),
            result.tokens_used.get('total_tokens', 0),
            not bool(result.error)
        )
    
    def _ensure_initialized(self) -> None:
        """Verificar que el orquestador esté inicializado"""
        if not self.is_initialized:
            raise OrchestrationError("Chat Orchestrator not initialized")
    
    def _get_default_system_prompt(self) -> str:
        """Prompt del sistema por defecto"""
        return """Eres un asistente inteligente con acceso a múltiples herramientas para ayudar a los usuarios.

Características principales:
- Puedes buscar información en internet y fuentes académicas
- Puedes gestionar emails y calendarios
- Puedes analizar texto y generar resúmenes
- Puedes crear flujos de trabajo automatizados

Instrucciones:
1. Responde de manera clara y útil
2. Usa las herramientas disponibles cuando sea apropiado
3. Siempre explica qué herramientas vas a usar y por qué
4. Si una herramienta falla, busca alternativas
5. Mantén un tono profesional pero amigable

Idioma: Responde siempre en español, el idioma preferido del usuario."""
    
    def _get_tool_selection_prompt(self) -> str:
        """Prompt para selección de herramientas"""
        return """Selecciona las herramientas más apropiadas para cada consulta:
- Búsquedas: SerpAPI
- Emails: Gmail
- Calendario: Google Calendar
- Análisis: Analytics Tools
- Flujos complejos: Workflow Tools"""
    
    def _get_error_handling_prompt(self) -> str:
        """Prompt para manejo de errores"""
        return """Si una herramienta falla:
1. Informa al usuario de manera clara
2. Sugiere alternativas
3. Continúa ayudando con otras herramientas"""
    
    async def get_session_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Obtener información de una sesión"""
        try:
            if session_id not in self.active_sessions:
                return None
            
            session = self.active_sessions[session_id]
            
            return {
                'session_id': session.session_id,
                'user_id': session.user_id,
                'created_at': session.created_at.isoformat(),
                'last_activity': session.last_activity.isoformat(),
                'message_count': session.message_count,
                'tokens_used': session.tokens_used,
                'history_length': len(session.conversation_history)
            }
            
        except Exception as e:
            self.logger.error(f"Error obteniendo info de sesión: {e}")
            return None
    
    async def get_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del orquestador"""
        try:
            stats = self.stats.copy()
            
            # Estadísticas adicionales
            stats['active_sessions'] = len(self.active_sessions)
            stats['avg_tokens_per_request'] = (
                stats['total_requests'] and 
                sum(s.tokens_used for s in self.active_sessions.values()) / stats['total_requests']
            ) or 0
            
            # Estadísticas de componentes
            if self.openai_client:
                stats['openai_stats'] = await self.openai_client.get_stats()
            
            if self.mcp_server:
                stats['mcp_stats'] = await self.mcp_server.get_stats()
            
            return stats
            
        except Exception as e:
            self.logger.error(f"Error obteniendo estadísticas: {e}")
            return {'error': str(e)}
    
    async def health_check(self) -> str:
        """Verificar salud del orquestador"""
        try:
            if not self.is_initialized:
                return "not_initialized"
            
            # Verificar componentes
            if self.openai_client:
                openai_status = await self.openai_client.health_check()
                if "error" in openai_status:
                    return f"openai_error: {openai_status}"
            
            if self.mcp_server:
                mcp_status = await self.mcp_server.health_check()
                if "error" in mcp_status:
                    return f"mcp_error: {mcp_status}"
            
            return "healthy"
            
        except Exception as e:
            return f"error: {str(e)}"
    
    async def close(self) -> None:
        """Cerrar orquestador y limpiar recursos"""
        try:
            self.is_initialized = False
            
            # Cerrar componentes
            if self.openai_client:
                await self.openai_client.close()
            
            if self.mcp_server:
                await self.mcp_server.close()
            
            if self.cache_manager:
                await self.cache_manager.close()
            
            # Limpiar sesiones
            self.active_sessions.clear()
            
            self.logger.info("Chat Orchestrator cerrado")
            
        except Exception as e:
            self.logger.error(f"Error cerrando orquestador: {e}")
