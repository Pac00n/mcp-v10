"""
Orquestador principal del sistema de chat OpenAI + MCP
"""

import asyncio
import time
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from uuid import uuid4

from ..core.config import get_settings
from ..core.exceptions import *
from ..core.logging_config import get_logger, performance_logger
from ..core.constants import TOOL_SELECTION_PATTERNS, AUTO_RESPONSES, INTENT_PATTERNS
from .tool_selector import ToolSelector
from .context_manager import ContextManager
from .optimization import OptimizationManager
from ..openai_integration.client import OpenAIClient
from ..mcp.server import MCPServerManager
from ..utils.cache import CacheManager
from ..utils.validators import MessageValidator


@dataclass
class ChatMessage:
    """Estructura de mensaje de chat"""
    id: str
    content: str
    role: str  # "user" | "assistant" | "system"
    timestamp: float
    metadata: Optional[Dict[str, Any]] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    tokens_used: Optional[Dict[str, int]] = None


@dataclass
class ChatResponse:
    """Estructura de respuesta de chat"""
    message: ChatMessage
    processing_time: float
    tools_used: List[str]
    tokens_consumed: Dict[str, int]
    cached: bool = False
    error: Optional[str] = None


class ChatOrchestrator:
    """
    Orquestador principal que coordina:
    - Selección inteligente de herramientas
    - Gestión de contexto y conversación
    - Optimización de rendimiento
    - Integración OpenAI + MCP
    """
    
    def __init__(self):
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        # Componentes del sistema
        self.tool_selector = ToolSelector()
        self.context_manager = ContextManager()
        self.optimization_manager = OptimizationManager()
        self.openai_client = OpenAIClient()
        self.mcp_server = MCPServerManager()
        self.cache_manager = CacheManager()
        self.message_validator = MessageValidator()
        
        # Estado del orquestador
        self.is_initialized = False
        self.active_conversations: Dict[str, Dict[str, Any]] = {}
        
        self.logger.info("ChatOrchestrator inicializado")
    
    async def initialize(self) -> None:
        """Inicializar todos los componentes"""
        try:
            self.logger.info("Inicializando ChatOrchestrator...")
            
            # Inicializar componentes
            await self.openai_client.initialize()
            await self.mcp_server.initialize()
            await self.cache_manager.initialize()
            
            self.is_initialized = True
            self.logger.info("ChatOrchestrator inicializado correctamente")
            
        except Exception as e:
            self.logger.error(f"Error inicializando ChatOrchestrator: {e}")
            raise OrchestrationError(f"Failed to initialize: {e}")
    
    async def process_message(
        self, 
        message: str, 
        conversation_id: Optional[str] = None,
        user_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> ChatResponse:
        """
        Procesar mensaje del usuario y generar respuesta
        
        Args:
            message: Mensaje del usuario
            conversation_id: ID de conversación (se genera si no se proporciona)
            user_id: ID del usuario
            context: Contexto adicional
            
        Returns:
            ChatResponse con la respuesta generada
        """
        start_time = time.time()
        
        try:
            # Validar entrada
            if not self.is_initialized:
                await self.initialize()
            
            # Generar IDs si es necesario
            conversation_id = conversation_id or str(uuid4())
            user_id = user_id or "anonymous"
            
            # Validar mensaje
            self.message_validator.validate_message(message)
            
            # Crear mensaje de usuario
            user_message = ChatMessage(
                id=str(uuid4()),
                content=message,
                role="user",
                timestamp=time.time(),
                metadata={"user_id": user_id, "conversation_id": conversation_id}
            )
            
            self.logger.info(
                "Procesando mensaje",
                conversation_id=conversation_id,
                user_id=user_id,
                message_length=len(message)
            )
            
            # Verificar caché
            cache_key = self.cache_manager.generate_cache_key(message, user_id)
            cached_response = await self.cache_manager.get_cached_response(cache_key)
            
            if cached_response:
                self.logger.info("Respuesta encontrada en caché", cache_key=cache_key)
                return self._create_cached_response(cached_response, start_time)
            
            # Gestionar contexto de conversación
            conversation_context = await self.context_manager.get_conversation_context(
                conversation_id, user_id
            )
            
            # Detectar intención del usuario
            intent = self._detect_intent(message)
            self.logger.debug(f"Intención detectada: {intent}")
            
            # Verificar respuesta automática
            auto_response = self._check_auto_response(intent, message)
            if auto_response:
                return await self._create_auto_response(
                    auto_response, user_message, start_time
                )
            
            # Seleccionar herramientas MCP
            selected_tools = await self.tool_selector.select_tools(
                message, intent, conversation_context
            )
            
            self.logger.info(f"Herramientas seleccionadas: {selected_tools}")
            
            # Optimizar configuración
            optimized_config = await self.optimization_manager.optimize_request(
                message, selected_tools, conversation_context
            )
            
            # Actualizar contexto de conversación
            await self.context_manager.add_message(conversation_id, user_message)
            
            # Generar respuesta con OpenAI + MCP
            response = await self._generate_response(
                message, 
                selected_tools, 
                conversation_context,
                optimized_config
            )
            
            # Crear mensaje de respuesta
            assistant_message = ChatMessage(
                id=str(uuid4()),
                content=response["content"],
                role="assistant",
                timestamp=time.time(),
                metadata={
                    "conversation_id": conversation_id,
                    "tools_used": selected_tools,
                    "model_used": optimized_config.get("model", self.settings.openai.default_model)
                },
                tool_calls=response.get("tool_calls", []),
                tokens_used=response.get("tokens_used", {})
            )
            
            # Actualizar contexto con respuesta
            await self.context_manager.add_message(conversation_id, assistant_message)
            
            # Guardar en caché
            await self.cache_manager.cache_response(
                cache_key, 
                assistant_message.content,
                selected_tools,
                assistant_message.tokens_used
            )
            
            # Crear respuesta final
            processing_time = time.time() - start_time
            chat_response = ChatResponse(
                message=assistant_message,
                processing_time=processing_time,
                tools_used=selected_tools,
                tokens_consumed=assistant_message.tokens_used or {},
                cached=False
            )
            
            # Log de rendimiento
            performance_logger.log_request_time(
                "chat_message", processing_time, "success"
            )
            
            if assistant_message.tokens_used:
                performance_logger.log_token_usage(
                    optimized_config.get("model", self.settings.openai.default_model),
                    assistant_message.tokens_used.get("input_tokens", 0),
                    assistant_message.tokens_used.get("output_tokens", 0)
                )
            
            self.logger.info(
                "Mensaje procesado exitosamente",
                conversation_id=conversation_id,
                processing_time=round(processing_time, 3),
                tools_used=len(selected_tools)
            )
            
            return chat_response
            
        except Exception as e:
            processing_time = time.time() - start_time
            self.logger.error(
                "Error procesando mensaje",
                error=str(e),
                error_type=type(e).__name__,
                processing_time=round(processing_time, 3)
            )
            
            # Crear respuesta de error
            error_message = ChatMessage(
                id=str(uuid4()),
                content=f"Lo siento, ha ocurrido un error: {str(e)}",
                role="assistant",
                timestamp=time.time(),
                metadata={"error": True}
            )
            
            return ChatResponse(
                message=error_message,
                processing_time=processing_time,
                tools_used=[],
                tokens_consumed={},
                error=str(e)
            )
    
    def _detect_intent(self, message: str) -> str:
        """Detectar intención del mensaje"""
        message_lower = message.lower()
        
        # Verificar patrones de intención
        for intent, keywords in INTENT_PATTERNS.items():
            if any(keyword in message_lower for keyword in keywords):
                return intent
        
        return "general"
    
    def _check_auto_response(self, intent: str, message: str) -> Optional[str]:
        """Verificar si se puede dar una respuesta automática"""
        if intent in AUTO_RESPONSES:
            # Para saludos, ayuda y despedidas, devolver respuesta automática
            if intent in ["greeting", "help", "goodbye"]:
                import random
                return random.choice(AUTO_RESPONSES[intent])
        
        return None
    
    async def _create_auto_response(
        self, 
        response_text: str, 
        user_message: ChatMessage, 
        start_time: float
    ) -> ChatResponse:
        """Crear respuesta automática"""
        assistant_message = ChatMessage(
            id=str(uuid4()),
            content=response_text,
            role="assistant", 
            timestamp=time.time(),
            metadata={"auto_response": True}
        )
        
        processing_time = time.time() - start_time
        
        return ChatResponse(
            message=assistant_message,
            processing_time=processing_time,
            tools_used=[],
            tokens_consumed={"input_tokens": 0, "output_tokens": 0},
            cached=False
        )
    
    def _create_cached_response(
        self, 
        cached_data: Dict[str, Any], 
        start_time: float
    ) -> ChatResponse:
        """Crear respuesta desde caché"""
        assistant_message = ChatMessage(
            id=str(uuid4()),
            content=cached_data["content"],
            role="assistant",
            timestamp=time.time(),
            metadata={"cached": True}
        )
        
        processing_time = time.time() - start_time
        
        return ChatResponse(
            message=assistant_message,
            processing_time=processing_time,
            tools_used=cached_data.get("tools_used", []),
            tokens_consumed=cached_data.get("tokens_used", {}),
            cached=True
        )
    
    async def _generate_response(
        self,
        message: str,
        selected_tools: List[str],
        conversation_context: Dict[str, Any],
        optimized_config: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Generar respuesta usando OpenAI + MCP"""
        
        # Preparar configuración de herramientas MCP
        mcp_tools_config = self.settings.get_mcp_tool_config(
            allowed_tools=selected_tools if selected_tools else None
        )
        
        # Preparar historial de conversación
        conversation_history = conversation_context.get("messages", [])
        
        # Agregar mensaje actual
        conversation_history.append({
            "role": "user",
            "content": message
        })
        
        # Generar respuesta con OpenAI
        response = await self.openai_client.generate_response(
            messages=conversation_history,
            tools_config=mcp_tools_config,
            model=optimized_config.get("model", self.settings.openai.default_model),
            temperature=optimized_config.get("temperature", self.settings.openai.temperature),
            max_tokens=optimized_config.get("max_tokens", self.settings.openai.max_tokens)
        )
        
        return response
    
    async def get_conversation_history(
        self, 
        conversation_id: str, 
        limit: int = 50
    ) -> List[ChatMessage]:
        """Obtener historial de conversación"""
        try:
            context = await self.context_manager.get_conversation_context(conversation_id)
            messages = context.get("messages", [])
            
            # Convertir a ChatMessage objects
            chat_messages = []
            for msg_data in messages[-limit:]:
                chat_message = ChatMessage(
                    id=msg_data.get("id", str(uuid4())),
                    content=msg_data["content"],
                    role=msg_data["role"],
                    timestamp=msg_data.get("timestamp", time.time()),
                    metadata=msg_data.get("metadata"),
                    tool_calls=msg_data.get("tool_calls"),
                    tokens_used=msg_data.get("tokens_used")
                )
                chat_messages.append(chat_message)
            
            return chat_messages
            
        except Exception as e:
            self.logger.error(f"Error obteniendo historial: {e}")
            return []
    
    async def clear_conversation(self, conversation_id: str) -> bool:
        """Limpiar conversación"""
        try:
            await self.context_manager.clear_conversation(conversation_id)
            self.logger.info(f"Conversación limpiada: {conversation_id}")
            return True
        except Exception as e:
            self.logger.error(f"Error limpiando conversación: {e}")
            return False
    
    async def get_system_status(self) -> Dict[str, Any]:
        """Obtener estado del sistema"""
        try:
            openai_status = await self.openai_client.health_check()
            mcp_status = await self.mcp_server.health_check()
            cache_status = await self.cache_manager.health_check()
            
            return {
                "orchestrator": {
                    "initialized": self.is_initialized,
                    "active_conversations": len(self.active_conversations)
                },
                "openai": openai_status,
                "mcp": mcp_status,
                "cache": cache_status,
                "timestamp": time.time()
            }
            
        except Exception as e:
            self.logger.error(f"Error obteniendo estado del sistema: {e}")
            return {
                "error": str(e),
                "timestamp": time.time()
            }
    
    async def shutdown(self) -> None:
        """Apagar el orquestador"""
        try:
            self.logger.info("Apagando ChatOrchestrator...")
            
            # Cerrar componentes
            await self.openai_client.close()
            await self.mcp_server.shutdown()
            await self.cache_manager.close()
            
            self.is_initialized = False
            self.logger.info("ChatOrchestrator apagado correctamente")
            
        except Exception as e:
            self.logger.error(f"Error apagando ChatOrchestrator: {e}")
            raise