"""
Orquestador optimizado para OpenAI Responses API + MCP
Coordina la comunicación usando la nueva sintaxis nativa de MCP
"""

import asyncio
import uuid
import json
from typing import Dict, List, Optional, Any, Tuple, AsyncGenerator
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum

from ..core.config import get_settings
from ..core.logging_config import get_logger, performance_logger
from ..core.exceptions import OrchestrationError, ValidationError, OpenAIError, MCPError
from ..openai_integration.responses_client import (
    OpenAIResponsesClient, 
    ChatMessage, 
    ResponseResult,
    StreamChunk
)
from ..utils.cache import CacheManager
from ..utils.validators import MasterValidator


class SessionStatus(Enum):
    """Estados de sesión"""
    ACTIVE = "active"
    IDLE = "idle"
    TERMINATED = "terminated"
    ERROR = "error"


@dataclass
class ChatSession:
    """Sesión de chat mejorada"""
    session_id: str
    user_id: str
    created_at: datetime
    last_activity: datetime
    status: SessionStatus = SessionStatus.ACTIVE
    message_count: int = 0
    tokens_used: int = 0
    tool_calls_made: int = 0
    conversation_history: List[Dict[str, Any]] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)
    preferences: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class OrchestrationRequest:
    """Request de orquestación completa"""
    message: str
    session_id: Optional[str] = None
    user_id: Optional[str] = None
    model: Optional[str] = None
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    use_reasoning: bool = False
    reasoning_effort: str = "medium"
    stream_response: bool = False
    context: Optional[Dict[str, Any]] = None
    preferences: Optional[Dict[str, Any]] = None


@dataclass
class OrchestrationResult:
    """Resultado de orquestación"""
    response: str
    session_id: str
    model_used: str
    tokens_used: Dict[str, int]
    tool_calls: List[Dict[str, Any]]
    response_time: float
    reasoning: Optional[str] = None
    cached: bool = False
    error: Optional[str] = None
    session_status: SessionStatus = SessionStatus.ACTIVE


class ResponsesOrchestrator:
    """
    Orquestador principal optimizado para Responses API
    """
    
    def __init__(self):
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        # Componentes principales
        self.openai_client: Optional[OpenAIResponsesClient] = None
        self.cache_manager: Optional[CacheManager] = None
        self.validator: Optional[MasterValidator] = None
        
        # Gestión de sesiones
        self.active_sessions: Dict[str, ChatSession] = {}
        self.session_cleanup_interval = 300  # 5 minutos
        
        # Configuración del sistema
        self.system_prompts = {
            'default': self._get_default_system_prompt(),
            'tool_selection': self._get_tool_selection_prompt(),
            'reasoning': self._get_reasoning_prompt()
        }
        
        # Límites y configuración
        self.max_sessions = self.settings.orchestrator.max_active_sessions
        self.session_timeout = timedelta(hours=self.settings.orchestrator.session_timeout_hours)
        self.max_history_length = self.settings.orchestrator.max_history_messages
        
        # Estadísticas globales
        self.stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'streaming_requests': 0,
            'reasoning_requests': 0,
            'tool_calls_made': 0,
            'tokens_used': 0,
            'sessions_created': 0,
            'sessions_terminated': 0,
            'cache_hits': 0,
            'average_response_time': 0.0,
            'start_time': datetime.now()
        }
        
        # Tareas de fondo
        self._cleanup_task: Optional[asyncio.Task] = None
        
        self.is_initialized = False
    
    async def initialize(self) -> None:
        """Inicializar orquestador y componentes"""
        try:
            self.logger.info("Inicializando Responses Orchestrator...")
            
            # Inicializar cliente OpenAI
            self.openai_client = OpenAIResponsesClient()
            self.openai_client.configure_default_mcp_server()
            
            # Inicializar componentes auxiliares
            self.cache_manager = CacheManager()
            await self.cache_manager.initialize()
            
            self.validator = MasterValidator()
            
            # Iniciar tareas de fondo
            self._cleanup_task = asyncio.create_task(self._session_cleanup_loop())
            
            # Verificar conectividad
            health = await self.openai_client.health_check()
            if health.get("status") != "healthy":
                raise OrchestrationError(f"OpenAI client unhealthy: {health.get('error')}")
            
            self.is_initialized = True
            self.logger.info("✅ Responses Orchestrator inicializado correctamente")
            
        except Exception as e:
            self.logger.error(f"❌ Error inicializando Responses Orchestrator: {e}")
            raise OrchestrationError(f"Failed to initialize orchestrator: {e}")
    
    async def process_chat_request(
        self, 
        request: OrchestrationRequest
    ) -> OrchestrationResult:
        """
        Procesar request de chat completo
        
        Args:
            request: Request de orquestación
            
        Returns:
            Resultado de orquestración
        """
        try:
            self._ensure_initialized()
            start_time = datetime.now()
            
            # Actualizar estadísticas
            self.stats['total_requests'] += 1
            
            if request.stream_response:
                self.stats['streaming_requests'] += 1
            
            if request.use_reasoning:
                self.stats['reasoning_requests'] += 1
            
            # Validar request
            self._validate_request(request)
            
            # Obtener o crear sesión
            session = await self._get_or_create_session(
                request.session_id, 
                request.user_id,
                request.context,
                request.preferences
            )
            
            # Preparar mensajes con contexto
            messages = await self._prepare_messages(session, request.message)
            
            # Realizar chat completion
            if request.stream_response:
                # Para streaming, devolvemos un generador especial
                return await self._handle_streaming_request(session, messages, request, start_time)
            else:
                return await self._handle_standard_request(session, messages, request, start_time)
                
        except Exception as e:
            self.stats['failed_requests'] += 1
            self.logger.error(f"Error procesando chat request: {e}")
            
            return OrchestrationResult(
                response=f"Error procesando solicitud: {str(e)}",
                session_id=request.session_id or "unknown",
                model_used="unknown",
                tokens_used={},
                tool_calls=[],
                response_time=(datetime.now() - start_time).total_seconds() if 'start_time' in locals() else 0.0,
                error=str(e),
                session_status=SessionStatus.ERROR
            )
    
    async def process_streaming_chat(
        self, 
        request: OrchestrationRequest
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Procesar chat con streaming de respuesta
        
        Args:
            request: Request de orquestación
            
        Yields:
            Chunks de respuesta en streaming
        """
        try:
            self._ensure_initialized()
            start_time = datetime.now()
            
            # Actualizar estadísticas
            self.stats['total_requests'] += 1
            self.stats['streaming_requests'] += 1
            
            # Validar request
            self._validate_request(request)
            
            # Obtener o crear sesión
            session = await self._get_or_create_session(
                request.session_id, 
                request.user_id,
                request.context,
                request.preferences
            )
            
            # Preparar mensajes
            messages = await self._prepare_messages(session, request.message)
            
            # Variables para acumular respuesta
            full_response = ""
            tool_calls = []
            tokens_used = {}
            
            # Streaming de OpenAI
            async for chunk in await self.openai_client.chat_completion(
                messages=messages,
                model=request.model,
                max_tokens=request.max_tokens,
                temperature=request.temperature,
                stream=True,
                use_reasoning=request.use_reasoning,
                reasoning_effort=request.reasoning_effort
            ):
                # Acumular contenido
                if chunk.content:
                    full_response += chunk.content
                
                if chunk.tool_calls:
                    tool_calls.extend(chunk.tool_calls)
                
                if chunk.tokens_used:
                    tokens_used = chunk.tokens_used
                
                # Yield del chunk
                yield {
                    "type": "chunk",
                    "content": chunk.content,
                    "is_complete": chunk.is_complete,
                    "tool_calls": chunk.tool_calls,
                    "session_id": session.session_id
                }
                
                if chunk.is_complete:
                    break
            
            # Actualizar sesión con respuesta completa
            await self._update_session_after_response(
                session, 
                request.message, 
                full_response,
                tool_calls,
                tokens_used
            )
            
            # Yield final con resumen
            response_time = (datetime.now() - start_time).total_seconds()
            
            yield {
                "type": "complete",
                "session_id": session.session_id,
                "total_tokens": tokens_used.get('total_tokens', 0),
                "tool_calls_count": len(tool_calls),
                "response_time": response_time
            }
            
            # Actualizar estadísticas
            self.stats['successful_requests'] += 1
            self.stats['tool_calls_made'] += len(tool_calls)
            self.stats['tokens_used'] += tokens_used.get('total_tokens', 0)
            self._update_average_response_time(response_time)
            
        except Exception as e:
            self.stats['failed_requests'] += 1
            self.logger.error(f"Error en streaming chat: {e}")
            
            yield {
                "type": "error",
                "error": str(e),
                "session_id": request.session_id or "unknown"
            }
    
    async def _handle_standard_request(
        self,
        session: ChatSession,
        messages: List[ChatMessage],
        request: OrchestrationRequest,
        start_time: datetime
    ) -> OrchestrationResult:
        """Manejar request estándar (no streaming)"""
        
        try:
            # Realizar chat completion
            result = await self.openai_client.chat_completion(
                messages=messages,
                model=request.model,
                max_tokens=request.max_tokens,
                temperature=request.temperature,
                stream=False,
                use_reasoning=request.use_reasoning,
                reasoning_effort=request.reasoning_effort
            )
            
            # Actualizar sesión
            await self._update_session_after_response(
                session,
                request.message,
                result.content,
                result.tool_calls,
                result.tokens_used
            )
            
            # Calcular tiempo de respuesta
            response_time = (datetime.now() - start_time).total_seconds()
            
            # Actualizar estadísticas
            self.stats['successful_requests'] += 1
            self.stats['tool_calls_made'] += len(result.tool_calls)
            self.stats['tokens_used'] += result.tokens_used.get('total_tokens', 0)
            self._update_average_response_time(response_time)
            
            return OrchestrationResult(
                response=result.content,
                session_id=session.session_id,
                model_used=result.model_used,
                tokens_used=result.tokens_used,
                tool_calls=result.tool_calls,
                response_time=response_time,
                reasoning=result.reasoning,
                cached=False,  # TODO: Implementar cache
                session_status=session.status
            )
            
        except Exception as e:
            self.logger.error(f"Error en request estándar: {e}")
            raise
    
    async def _get_or_create_session(
        self,
        session_id: Optional[str],
        user_id: Optional[str],
        context: Optional[Dict[str, Any]],
        preferences: Optional[Dict[str, Any]]
    ) -> ChatSession:
        """Obtener sesión existente o crear nueva"""
        
        # Si no hay session_id, crear uno nuevo
        if not session_id:
            session_id = f"session_{uuid.uuid4().hex[:12]}"
        
        # Si no hay user_id, usar uno por defecto
        if not user_id:
            user_id = f"user_{uuid.uuid4().hex[:8]}"
        
        # Verificar si la sesión existe
        if session_id in self.active_sessions:
            session = self.active_sessions[session_id]
            session.last_activity = datetime.now()
            
            # Actualizar contexto y preferencias si se proporcionan
            if context:
                session.context.update(context)
            if preferences:
                session.preferences.update(preferences)
            
            return session
        
        # Crear nueva sesión
        if len(self.active_sessions) >= self.max_sessions:
            await self._cleanup_old_sessions()
        
        session = ChatSession(
            session_id=session_id,
            user_id=user_id,
            created_at=datetime.now(),
            last_activity=datetime.now(),
            context=context or {},
            preferences=preferences or {}
        )
        
        self.active_sessions[session_id] = session
        self.stats['sessions_created'] += 1
        
        self.logger.info(f"Nueva sesión creada: {session_id} para usuario {user_id}")
        
        return session
    
    async def _prepare_messages(
        self, 
        session: ChatSession, 
        user_message: str
    ) -> List[ChatMessage]:
        """Preparar mensajes con contexto de sesión"""
        
        messages = []
        
        # Mensaje de sistema
        system_prompt = self._build_system_prompt(session)
        if system_prompt:
            messages.append(ChatMessage(role="system", content=system_prompt))
        
        # Historial de conversación (limitado)
        history_limit = min(len(session.conversation_history), self.max_history_length)
        recent_history = session.conversation_history[-history_limit:] if history_limit > 0 else []
        
        for msg in recent_history:
            messages.append(ChatMessage(
                role=msg.get('role', 'user'),
                content=msg.get('content', '')
            ))
        
        # Mensaje actual del usuario
        messages.append(ChatMessage(role="user", content=user_message))
        
        return messages
    
    async def _update_session_after_response(
        self,
        session: ChatSession,
        user_message: str,
        assistant_response: str,
        tool_calls: List[Dict[str, Any]],
        tokens_used: Dict[str, int]
    ) -> None:
        """Actualizar sesión después de recibir respuesta"""
        
        # Agregar mensajes al historial
        session.conversation_history.append({
            'role': 'user',
            'content': user_message,
            'timestamp': datetime.now().isoformat()
        })
        
        session.conversation_history.append({
            'role': 'assistant',
            'content': assistant_response,
            'tool_calls': tool_calls,
            'timestamp': datetime.now().isoformat()
        })
        
        # Actualizar estadísticas de sesión
        session.message_count += 2  # user + assistant
        session.tokens_used += tokens_used.get('total_tokens', 0)
        session.tool_calls_made += len(tool_calls)
        session.last_activity = datetime.now()
    
    def _build_system_prompt(self, session: ChatSession) -> str:
        """Construir prompt de sistema personalizado"""
        
        base_prompt = self.system_prompts['default']
        
        # Agregar contexto de sesión si existe
        if session.context:
            context_info = "\n\nContexto de la sesión:\n"
            for key, value in session.context.items():
                context_info += f"- {key}: {value}\n"
            base_prompt += context_info
        
        # Agregar preferencias si existen
        if session.preferences:
            prefs_info = "\n\nPreferencias del usuario:\n"
            for key, value in session.preferences.items():
                prefs_info += f"- {key}: {value}\n"
            base_prompt += prefs_info
        
        return base_prompt
    
    def _validate_request(self, request: OrchestrationRequest) -> None:
        """Validar request de orquestación"""
        
        if not request.message or not request.message.strip():
            raise ValidationError("Mensaje vacío")
        
        if len(request.message) > 50000:  # Límite de caracteres
            raise ValidationError("Mensaje demasiado largo")
        
        if request.temperature is not None and not (0.0 <= request.temperature <= 2.0):
            raise ValidationError("Temperatura debe estar entre 0.0 y 2.0")
        
        if request.max_tokens is not None and not (1 <= request.max_tokens <= 4000):
            raise ValidationError("max_tokens debe estar entre 1 y 4000")
    
    async def _session_cleanup_loop(self) -> None:
        """Loop de limpieza de sesiones inactivas"""
        
        while True:
            try:
                await asyncio.sleep(self.session_cleanup_interval)
                await self._cleanup_old_sessions()
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error en cleanup de sesiones: {e}")
    
    async def _cleanup_old_sessions(self) -> None:
        """Limpiar sesiones inactivas"""
        
        current_time = datetime.now()
        sessions_to_remove = []
        
        for session_id, session in self.active_sessions.items():
            if current_time - session.last_activity > self.session_timeout:
                sessions_to_remove.append(session_id)
        
        for session_id in sessions_to_remove:
            del self.active_sessions[session_id]
            self.stats['sessions_terminated'] += 1
            self.logger.info(f"Sesión limpiada por inactividad: {session_id}")
    
    def _update_average_response_time(self, response_time: float) -> None:
        """Actualizar tiempo de respuesta promedio"""
        
        current_avg = self.stats['average_response_time']
        total_requests = self.stats['successful_requests']
        
        if total_requests == 1:
            self.stats['average_response_time'] = response_time
        else:
            # Promedio móvil simple
            self.stats['average_response_time'] = (
                (current_avg * (total_requests - 1) + response_time) / total_requests
            )
    
    def _ensure_initialized(self) -> None:
        """Verificar que el orquestador esté inicializado"""
        if not self.is_initialized:
            raise OrchestrationError("Orchestrator not initialized")
    
    def _get_default_system_prompt(self) -> str:
        """Obtener prompt de sistema por defecto"""
        return """Eres un asistente inteligente con acceso a herramientas especializadas para:

🔍 Búsqueda de información (web y noticias)
📧 Gestión de correo electrónico 
📅 Gestión de calendario
📊 Análisis de texto y sentimientos
📝 Generación de resúmenes
🔄 Flujos de trabajo complejos

Instrucciones:
- Usa las herramientas apropiadas según la solicitud del usuario
- Proporciona respuestas informativas y útiles
- Si necesitas más información, pregunta claramente
- Mantén un tono profesional pero amigable
- Indica qué herramientas estás usando cuando sea relevante"""
    
    def _get_tool_selection_prompt(self) -> str:
        """Prompt para selección de herramientas"""
        return """
Analiza la solicitud del usuario y determina qué herramientas usar:

- Para búsquedas: buscar_informacion o buscar_noticias
- Para emails: gestionar_email  
- Para calendario: gestionar_calendario
- Para análisis: analizar_sentimiento o generar_resumen
- Para tareas complejas: flujo_investigacion_completo
- Para diagnóstico: estado_sistema
"""
    
    def _get_reasoning_prompt(self) -> str:
        """Prompt para modelos de razonamiento"""
        return """
Piensa paso a paso para resolver la solicitud del usuario:

1. Analiza qué información necesitas
2. Determina qué herramientas usar
3. Planifica la secuencia de acciones
4. Ejecuta y verifica los resultados
5. Proporciona una respuesta completa
"""
    
    # Métodos públicos de gestión
    
    async def get_session_info(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Obtener información de una sesión"""
        
        if session_id not in self.active_sessions:
            return None
        
        session = self.active_sessions[session_id]
        
        return {
            "session_id": session.session_id,
            "user_id": session.user_id,
            "status": session.status.value,
            "created_at": session.created_at.isoformat(),
            "last_activity": session.last_activity.isoformat(),
            "message_count": session.message_count,
            "tokens_used": session.tokens_used,
            "tool_calls_made": session.tool_calls_made,
            "context": session.context,
            "preferences": session.preferences
        }
    
    async def terminate_session(self, session_id: str) -> bool:
        """Terminar sesión específica"""
        
        if session_id in self.active_sessions:
            session = self.active_sessions[session_id]
            session.status = SessionStatus.TERMINATED
            del self.active_sessions[session_id]
            
            self.stats['sessions_terminated'] += 1
            self.logger.info(f"Sesión terminada: {session_id}")
            return True
        
        return False
    
    def get_orchestrator_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del orquestrador"""
        
        uptime = (datetime.now() - self.stats['start_time']).total_seconds()
        
        return {
            **self.stats,
            'active_sessions': len(self.active_sessions),
            'uptime_seconds': uptime,
            'requests_per_minute': (self.stats['total_requests'] / max(uptime / 60, 1)),
            'success_rate': (
                self.stats['successful_requests'] / max(self.stats['total_requests'], 1) * 100
            )
        }
    
    async def shutdown(self) -> None:
        """Cerrar orquestrador limpiamente"""
        
        self.logger.info("Cerrando Responses Orchestrator...")
        
        # Cancelar tareas de fondo
        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass
        
        # Cerrar componentes
        if self.cache_manager:
            await self.cache_manager.close()
        
        # Marcar todas las sesiones como terminadas
        for session in self.active_sessions.values():
            session.status = SessionStatus.TERMINATED
        
        self.active_sessions.clear()
        
        self.logger.info("✅ Responses Orchestrator cerrado correctamente")
