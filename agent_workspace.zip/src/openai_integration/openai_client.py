"""
Cliente OpenAI optimizado para integración con MCP
Soporta las últimas APIs incluyendo Responses API
"""

import asyncio
import json
from typing import Dict, List, Optional, Any, AsyncGenerator, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime
import time

from openai import AsyncOpenAI
from openai.types.chat import ChatCompletion, ChatCompletionMessage
from openai.types.chat.chat_completion import Choice

from ..core.config import get_settings
from ..core.logging_config import get_logger, performance_logger
from ..core.exceptions import OpenAIError, ValidationError, RateLimitError
from ..utils.cache import CacheManager
from ..utils.validators import MasterValidator


@dataclass
class MCPToolCall:
    """Representación de una llamada a herramienta MCP"""
    tool_name: str
    function_name: str
    arguments: Dict[str, Any]
    call_id: str


@dataclass
class ConversationMessage:
    """Mensaje de conversación optimizado"""
    role: str
    content: str
    tool_calls: Optional[List[MCPToolCall]] = None
    tool_call_id: Optional[str] = None
    timestamp: Optional[datetime] = None
    tokens_used: Optional[Dict[str, int]] = None


@dataclass
class ChatResponse:
    """Respuesta completa de chat"""
    content: str
    tool_calls: List[MCPToolCall]
    tokens_used: Dict[str, int]
    model_used: str
    finish_reason: str
    response_time: float
    cached: bool = False


class OpenAIClient:
    """Cliente OpenAI avanzado con soporte MCP"""
    
    def __init__(self):
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        # Cliente OpenAI
        self.client: Optional[AsyncOpenAI] = None
        
        # Gestores auxiliares
        self.cache_manager = CacheManager()
        self.validator = MasterValidator()
        
        # Configuración de modelos
        self.model_config = {
            'primary': self.settings.openai.primary_model,
            'fallback': self.settings.openai.fallback_model,
            'max_tokens': self.settings.openai.max_tokens,
            'temperature': self.settings.openai.temperature
        }
        
        # Rate limiting
        self.rate_limiter = {
            'requests_per_minute': 60,
            'requests_count': 0,
            'window_start': time.time()
        }
        
        # Estadísticas
        self.stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'cached_responses': 0,
            'tool_calls_made': 0,
            'total_tokens_used': 0
        }
        
        self.is_initialized = False
    
    async def initialize(self) -> None:
        """Inicializar cliente OpenAI"""
        try:
            # Inicializar cliente OpenAI
            self.client = AsyncOpenAI(
                api_key=self.settings.openai.api_key,
                timeout=self.settings.openai.timeout,
                max_retries=self.settings.openai.max_retries
            )
            
            # Inicializar cache
            await self.cache_manager.initialize()
            
            # Verificar conectividad
            await self._test_connection()
            
            self.is_initialized = True
            self.logger.info("OpenAI Client inicializado correctamente")
            
        except Exception as e:
            self.logger.error(f"Error inicializando OpenAI Client: {e}")
            raise OpenAIError(f"Failed to initialize OpenAI client: {e}")
    
    async def _test_connection(self) -> None:
        """Probar conexión con OpenAI"""
        try:
            # Test simple
            response = await self.client.chat.completions.create(
                model=self.model_config['primary'],
                messages=[{"role": "user", "content": "test"}],
                max_tokens=5
            )
            
            if response.choices:
                self.logger.info("Conexión OpenAI verificada")
            else:
                raise OpenAIError("Invalid response from OpenAI")
                
        except Exception as e:
            self.logger.error(f"Error verificando conexión OpenAI: {e}")
            raise OpenAIError(f"OpenAI connection test failed: {e}")
    
    async def chat_completion(
        self,
        messages: List[ConversationMessage],
        tools: Optional[List[Dict[str, Any]]] = None,
        user_id: Optional[str] = None,
        use_cache: bool = True,
        stream: bool = False
    ) -> ChatResponse:
        """
        Completar chat con soporte para herramientas MCP
        
        Args:
            messages: Historial de mensajes
            tools: Herramientas MCP disponibles
            user_id: ID del usuario para caché personalizado
            use_cache: Usar caché si está disponible
            stream: Respuesta en streaming
        
        Returns:
            Respuesta completa del chat
        """
        try:
            self._ensure_initialized()
            start_time = time.time()
            
            # Validar mensajes
            self._validate_messages(messages)
            
            # Verificar rate limiting
            await self._check_rate_limit()
            
            # Generar clave de caché
            cache_key = None
            if use_cache:
                cache_key = self._generate_cache_key(messages, tools, user_id)
                cached_response = await self.cache_manager.get_cached_response(cache_key)
                
                if cached_response:
                    self.stats['cached_responses'] += 1
                    self.logger.info("Respuesta obtenida desde caché")
                    return self._create_chat_response_from_cache(cached_response)
            
            # Preparar mensajes para OpenAI
            openai_messages = self._convert_messages_to_openai(messages)
            
            # Configurar parámetros de la llamada
            call_params = {
                'model': self.model_config['primary'],
                'messages': openai_messages,
                'max_tokens': self.model_config['max_tokens'],
                'temperature': self.model_config['temperature'],
                'stream': stream
            }
            
            # Agregar herramientas si están disponibles
            if tools:
                call_params['tools'] = tools
                call_params['tool_choice'] = 'auto'
            
            # Realizar llamada
            if stream:
                return await self._handle_streaming_response(call_params, cache_key, start_time)
            else:
                return await self._handle_regular_response(call_params, cache_key, start_time)
                
        except Exception as e:
            self.logger.error(f"Error en chat completion: {e}")
            if "rate_limit" in str(e).lower():
                raise RateLimitError(f"Rate limit exceeded: {e}")
            else:
                raise OpenAIError(f"Chat completion failed: {e}")
    
    async def _handle_regular_response(
        self,
        call_params: Dict[str, Any],
        cache_key: Optional[str],
        start_time: float
    ) -> ChatResponse:
        """Manejar respuesta regular (no streaming)"""
        try:
            # Realizar llamada a OpenAI
            response = await self.client.chat.completions.create(**call_params)
            
            # Procesar respuesta
            chat_response = self._process_openai_response(response, start_time)
            
            # Cachear si es necesario
            if cache_key and chat_response.finish_reason == 'stop':
                await self._cache_response(cache_key, chat_response)
            
            # Actualizar estadísticas
            self._update_stats(chat_response)
            
            return chat_response
            
        except Exception as e:
            self.logger.error(f"Error procesando respuesta regular: {e}")
            # Intentar con modelo fallback
            if call_params['model'] != self.model_config['fallback']:
                self.logger.info("Intentando con modelo fallback")
                call_params['model'] = self.model_config['fallback']
                return await self._handle_regular_response(call_params, None, start_time)
            raise
    
    async def _handle_streaming_response(
        self,
        call_params: Dict[str, Any],
        cache_key: Optional[str],
        start_time: float
    ) -> AsyncGenerator[str, None]:
        """Manejar respuesta streaming"""
        try:
            accumulated_content = ""
            accumulated_tokens = {'prompt_tokens': 0, 'completion_tokens': 0}
            
            stream = await self.client.chat.completions.create(**call_params)
            
            async for chunk in stream:
                if chunk.choices:
                    delta = chunk.choices[0].delta
                    
                    if delta.content:
                        accumulated_content += delta.content
                        yield delta.content
                    
                    # Manejar tool calls en streaming si es necesario
                    if delta.tool_calls:
                        # Procesar tool calls
                        pass
            
            # Al final del stream, crear respuesta completa
            response_time = time.time() - start_time
            
            chat_response = ChatResponse(
                content=accumulated_content,
                tool_calls=[],
                tokens_used=accumulated_tokens,
                model_used=call_params['model'],
                finish_reason='stop',
                response_time=response_time
            )
            
            # Cachear resultado final
            if cache_key:
                await self._cache_response(cache_key, chat_response)
            
            self._update_stats(chat_response)
            
        except Exception as e:
            self.logger.error(f"Error en streaming response: {e}")
            raise OpenAIError(f"Streaming response failed: {e}")
    
    def _process_openai_response(self, response: ChatCompletion, start_time: float) -> ChatResponse:
        """Procesar respuesta de OpenAI"""
        try:
            choice = response.choices[0]
            message = choice.message
            
            # Extraer contenido
            content = message.content or ""
            
            # Extraer tool calls
            tool_calls = []
            if message.tool_calls:
                for tool_call in message.tool_calls:
                    if tool_call.function:
                        mcp_tool_call = MCPToolCall(
                            tool_name=tool_call.function.name.split('_')[0] if '_' in tool_call.function.name else tool_call.function.name,
                            function_name=tool_call.function.name,
                            arguments=json.loads(tool_call.function.arguments),
                            call_id=tool_call.id
                        )
                        tool_calls.append(mcp_tool_call)
            
            # Extraer tokens usados
            tokens_used = {
                'prompt_tokens': response.usage.prompt_tokens if response.usage else 0,
                'completion_tokens': response.usage.completion_tokens if response.usage else 0,
                'total_tokens': response.usage.total_tokens if response.usage else 0
            }
            
            # Calcular tiempo de respuesta
            response_time = time.time() - start_time
            
            return ChatResponse(
                content=content,
                tool_calls=tool_calls,
                tokens_used=tokens_used,
                model_used=response.model,
                finish_reason=choice.finish_reason,
                response_time=response_time
            )
            
        except Exception as e:
            self.logger.error(f"Error procesando respuesta OpenAI: {e}")
            raise OpenAIError(f"Failed to process OpenAI response: {e}")
    
    def _convert_messages_to_openai(self, messages: List[ConversationMessage]) -> List[Dict[str, Any]]:
        """Convertir mensajes internos a formato OpenAI"""
        openai_messages = []
        
        for msg in messages:
            openai_msg = {
                'role': msg.role,
                'content': msg.content
            }
            
            # Agregar tool calls si existen
            if msg.tool_calls:
                openai_msg['tool_calls'] = []
                for tool_call in msg.tool_calls:
                    openai_msg['tool_calls'].append({
                        'id': tool_call.call_id,
                        'type': 'function',
                        'function': {
                            'name': tool_call.function_name,
                            'arguments': json.dumps(tool_call.arguments)
                        }
                    })
            
            # Agregar tool_call_id para respuestas de herramientas
            if msg.tool_call_id:
                openai_msg['tool_call_id'] = msg.tool_call_id
            
            openai_messages.append(openai_msg)
        
        return openai_messages
    
    def _validate_messages(self, messages: List[ConversationMessage]) -> None:
        """Validar mensajes antes de enviar"""
        if not messages:
            raise ValidationError("Messages list cannot be empty")
        
        for i, msg in enumerate(messages):
            if not msg.role or msg.role not in ['system', 'user', 'assistant', 'tool']:
                raise ValidationError(f"Invalid role in message {i}: {msg.role}")
            
            if not isinstance(msg.content, str):
                raise ValidationError(f"Message content must be string in message {i}")
            
            # Validar longitud del contenido
            if len(msg.content) > 10000:  # Límite razonable
                raise ValidationError(f"Message {i} content too long")
    
    async def _check_rate_limit(self) -> None:
        """Verificar y manejar rate limiting"""
        current_time = time.time()
        
        # Resetear contador si ha pasado 1 minuto
        if current_time - self.rate_limiter['window_start'] >= 60:
            self.rate_limiter['requests_count'] = 0
            self.rate_limiter['window_start'] = current_time
        
        # Verificar límite
        if self.rate_limiter['requests_count'] >= self.rate_limiter['requests_per_minute']:
            wait_time = 60 - (current_time - self.rate_limiter['window_start'])
            self.logger.warning(f"Rate limit alcanzado, esperando {wait_time:.1f} segundos")
            await asyncio.sleep(wait_time)
            
            # Resetear después de esperar
            self.rate_limiter['requests_count'] = 0
            self.rate_limiter['window_start'] = time.time()
        
        self.rate_limiter['requests_count'] += 1
    
    def _generate_cache_key(
        self,
        messages: List[ConversationMessage],
        tools: Optional[List[Dict[str, Any]]],
        user_id: Optional[str]
    ) -> str:
        """Generar clave única para caché"""
        try:
            # Crear hash de los mensajes
            messages_str = json.dumps([
                {'role': msg.role, 'content': msg.content}
                for msg in messages[-5:]  # Solo últimos 5 mensajes
            ], sort_keys=True)
            
            # Incluir herramientas disponibles
            tools_str = json.dumps(tools, sort_keys=True) if tools else "no_tools"
            
            # Incluir configuración del modelo
            model_str = f"{self.model_config['primary']}_{self.model_config['temperature']}"
            
            components = [messages_str, tools_str, model_str]
            if user_id:
                components.append(user_id)
            
            return self.cache_manager.generate_cache_key(*components)
            
        except Exception as e:
            self.logger.error(f"Error generando cache key: {e}")
            return f"fallback_key_{int(time.time())}"
    
    async def _cache_response(self, cache_key: str, response: ChatResponse) -> None:
        """Cachear respuesta para uso futuro"""
        try:
            await self.cache_manager.cache_response(
                cache_key=cache_key,
                response=response.content,
                tools_used=[tc.function_name for tc in response.tool_calls],
                tokens_used=response.tokens_used
            )
        except Exception as e:
            self.logger.warning(f"Error cacheando respuesta: {e}")
    
    def _create_chat_response_from_cache(self, cached_data: Dict[str, Any]) -> ChatResponse:
        """Crear ChatResponse desde datos cacheados"""
        return ChatResponse(
            content=cached_data['content'],
            tool_calls=[],  # Tool calls no se cachean por seguridad
            tokens_used=cached_data['tokens_used'],
            model_used="cached",
            finish_reason="stop",
            response_time=0.001,  # Tiempo mínimo para caché
            cached=True
        )
    
    def _update_stats(self, response: ChatResponse) -> None:
        """Actualizar estadísticas del cliente"""
        self.stats['total_requests'] += 1
        
        if response.finish_reason in ['stop', 'length']:
            self.stats['successful_requests'] += 1
        
        self.stats['tool_calls_made'] += len(response.tool_calls)
        self.stats['total_tokens_used'] += response.tokens_used.get('total_tokens', 0)
        
        # Log de performance
        performance_logger.log_api_call(
            "openai_chat_completion",
            response.response_time,
            response.finish_reason == 'stop',
            response.tokens_used.get('total_tokens', 0)
        )
    
    def _ensure_initialized(self) -> None:
        """Verificar que el cliente esté inicializado"""
        if not self.is_initialized or not self.client:
            raise OpenAIError("OpenAI client not initialized")
    
    async def get_available_models(self) -> List[str]:
        """Obtener lista de modelos disponibles"""
        try:
            self._ensure_initialized()
            
            models = await self.client.models.list()
            model_names = [model.id for model in models.data]
            
            # Filtrar solo modelos de chat
            chat_models = [
                name for name in model_names
                if any(prefix in name for prefix in ['gpt-', 'gpt4', 'chatgpt'])
            ]
            
            return sorted(chat_models)
            
        except Exception as e:
            self.logger.error(f"Error obteniendo modelos: {e}")
            return [self.model_config['primary'], self.model_config['fallback']]
    
    async def get_model_info(self, model_name: str) -> Dict[str, Any]:
        """Obtener información de un modelo específico"""
        try:
            self._ensure_initialized()
            
            model = await self.client.models.retrieve(model_name)
            
            return {
                'id': model.id,
                'created': model.created,
                'owned_by': model.owned_by,
                'object': model.object
            }
            
        except Exception as e:
            self.logger.error(f"Error obteniendo info del modelo: {e}")
            return {'error': str(e)}
    
    async def get_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del cliente"""
        try:
            # Estadísticas básicas
            stats = self.stats.copy()
            
            # Calcular ratios
            if stats['total_requests'] > 0:
                stats['success_rate'] = (stats['successful_requests'] / stats['total_requests']) * 100
                stats['cache_hit_rate'] = (stats['cached_responses'] / stats['total_requests']) * 100
            else:
                stats['success_rate'] = 0
                stats['cache_hit_rate'] = 0
            
            # Estadísticas de caché
            cache_stats = await self.cache_manager.get_stats()
            stats['cache_stats'] = cache_stats
            
            # Configuración actual
            stats['model_config'] = self.model_config
            
            return stats
            
        except Exception as e:
            self.logger.error(f"Error obteniendo estadísticas: {e}")
            return {'error': str(e)}
    
    async def health_check(self) -> str:
        """Verificar salud del cliente OpenAI"""
        try:
            if not self.is_initialized:
                return "not_initialized"
            
            # Test de conectividad simple
            await self._test_connection()
            
            # Verificar caché
            cache_status = await self.cache_manager.health_check()
            
            return f"healthy_cache_{cache_status}"
            
        except Exception as e:
            return f"error: {str(e)}"
    
    async def close(self) -> None:
        """Cerrar cliente OpenAI"""
        try:
            if self.client:
                await self.client.close()
                self.client = None
            
            await self.cache_manager.close()
            
            self.is_initialized = False
            self.logger.info("OpenAI Client cerrado")
            
        except Exception as e:
            self.logger.error(f"Error cerrando OpenAI Client: {e}")
