"""
Cliente OpenAI para Responses API con integración MCP nativa
Implementa la nueva sintaxis de OpenAI con herramientas MCP directas
"""

import asyncio
import json
import time
from typing import Dict, List, Optional, Any, AsyncGenerator, Union
from dataclasses import dataclass, asdict
from datetime import datetime
import aiohttp
from urllib.parse import urljoin

from ..core.config import get_settings
from ..core.logging_config import get_logger, performance_logger
from ..core.exceptions import OpenAIError, MCPError, RateLimitError
from ..core.constants import SYSTEM_NAME, SYSTEM_VERSION


@dataclass
class MCPServerConfig:
    """Configuración de servidor MCP para OpenAI"""
    server_label: str
    server_url: str
    allowed_tools: Optional[List[str]] = None
    require_approval: str = "never"
    headers: Optional[Dict[str, str]] = None
    
    def to_openai_tool(self) -> Dict[str, Any]:
        """Convertir a formato de herramienta OpenAI"""
        tool_config = {
            "type": "mcp",
            "server_label": self.server_label,
            "server_url": self.server_url,
            "require_approval": self.require_approval
        }
        
        if self.allowed_tools:
            tool_config["allowed_tools"] = self.allowed_tools
        
        if self.headers:
            tool_config["headers"] = self.headers
            
        return tool_config


@dataclass
class ChatMessage:
    """Mensaje de chat para Responses API"""
    role: str  # "system", "user", "assistant"
    content: Union[str, List[Dict[str, Any]]]
    
    def to_openai_format(self) -> Dict[str, Any]:
        """Convertir a formato OpenAI"""
        if isinstance(self.content, str):
            return {
                "role": self.role,
                "content": [
                    {
                        "type": "input_text",
                        "text": self.content
                    }
                ]
            }
        else:
            return {
                "role": self.role,
                "content": self.content
            }


@dataclass
class ResponseResult:
    """Resultado de la Responses API"""
    content: str
    model_used: str
    finish_reason: str
    tokens_used: Dict[str, int]
    tool_calls: List[Dict[str, Any]]
    response_time: float
    response_id: Optional[str] = None
    reasoning: Optional[str] = None


@dataclass
class StreamChunk:
    """Chunk de streaming"""
    content: str
    is_complete: bool
    tool_calls: List[Dict[str, Any]]
    tokens_used: Optional[Dict[str, int]] = None


class OpenAIResponsesClient:
    """
    Cliente para OpenAI Responses API con integración MCP nativa
    """
    
    def __init__(self):
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        # Configuración de API
        self.api_key = self.settings.openai.api_key
        self.base_url = self.settings.openai.base_url
        self.timeout = self.settings.openai.timeout
        self.max_retries = self.settings.openai.max_retries
        
        # Endpoint específico para Responses API
        self.responses_endpoint = urljoin(self.base_url, "responses")
        
        # Configuración de modelos
        self.default_model = self.settings.openai.default_model
        self.reasoning_model = self.settings.openai.reasoning_model
        self.max_tokens = self.settings.openai.max_tokens
        self.temperature = self.settings.openai.temperature
        
        # Configuración MCP
        self.mcp_servers: List[MCPServerConfig] = []
        
        # Rate limiting
        self.rate_limiter = {
            'requests_per_minute': 50,  # Conservador para Responses API
            'requests_count': 0,
            'window_start': time.time()
        }
        
        # Estadísticas
        self.stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'total_tokens_used': 0,
            'tool_calls_made': 0,
            'streaming_requests': 0,
            'cached_requests': 0
        }
        
        self.logger.info("OpenAI Responses Client inicializado")
    
    def configure_mcp_server(
        self,
        server_label: str,
        server_url: str,
        allowed_tools: Optional[List[str]] = None,
        require_approval: str = "never",
        headers: Optional[Dict[str, str]] = None
    ) -> None:
        """
        Configurar servidor MCP para usar con OpenAI
        
        Args:
            server_label: Etiqueta del servidor (ej: 'chat_assistant')
            server_url: URL del servidor MCP
            allowed_tools: Lista de herramientas permitidas (opcional)
            require_approval: Política de aprobación ('never', 'always')
            headers: Headers adicionales (API keys, etc.)
        """
        mcp_config = MCPServerConfig(
            server_label=server_label,
            server_url=server_url,
            allowed_tools=allowed_tools,
            require_approval=require_approval,
            headers=headers
        )
        
        # Reemplazar si ya existe
        self.mcp_servers = [s for s in self.mcp_servers if s.server_label != server_label]
        self.mcp_servers.append(mcp_config)
        
        self.logger.info(f"Servidor MCP configurado: {server_label} -> {server_url}")
    
    def configure_default_mcp_server(self) -> None:
        """Configurar servidor MCP por defecto basado en configuración"""
        mcp_url = self.settings.mcp.server_url
        mcp_label = self.settings.mcp.server_label
        
        # Headers con API key si está configurada
        headers = {}
        if self.settings.mcp.api_key:
            headers["X-API-KEY"] = self.settings.mcp.api_key
        
        # Lista de herramientas del servidor
        allowed_tools = [
            "buscar_informacion",
            "buscar_noticias", 
            "gestionar_email",
            "gestionar_calendario",
            "analizar_sentimiento",
            "generar_resumen",
            "flujo_investigacion_completo",
            "estado_sistema"
        ]
        
        self.configure_mcp_server(
            server_label=mcp_label,
            server_url=mcp_url,
            allowed_tools=allowed_tools,
            require_approval="never",
            headers=headers if headers else None
        )
    
    async def chat_completion(
        self,
        messages: List[ChatMessage],
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        stream: bool = False,
        use_reasoning: bool = False,
        reasoning_effort: str = "medium",
        previous_response_id: Optional[str] = None,
        additional_tools: Optional[List[Dict[str, Any]]] = None
    ) -> Union[ResponseResult, AsyncGenerator[StreamChunk, None]]:
        """
        Crear chat completion usando Responses API
        
        Args:
            messages: Lista de mensajes de chat
            model: Modelo a usar (por defecto del config)
            max_tokens: Máximo de tokens
            temperature: Temperatura del modelo
            stream: Si hacer streaming de la respuesta
            use_reasoning: Si usar modelo de razonamiento
            reasoning_effort: Esfuerzo de razonamiento (low, medium, high)
            previous_response_id: ID de respuesta anterior para caché
            additional_tools: Herramientas adicionales de OpenAI
        
        Returns:
            ResponseResult o AsyncGenerator para streaming
        """
        try:
            await self._check_rate_limit()
            start_time = time.time()
            
            # Preparar parámetros de la request
            request_data = await self._prepare_request_data(
                messages=messages,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                use_reasoning=use_reasoning,
                reasoning_effort=reasoning_effort,
                previous_response_id=previous_response_id,
                additional_tools=additional_tools
            )
            
            # Realizar request
            if stream:
                return self._handle_streaming_request(request_data, start_time)
            else:
                return await self._handle_standard_request(request_data, start_time)
                
        except Exception as e:
            self.logger.error(f"Error en chat completion: {e}")
            self.stats['total_requests'] += 1
            raise OpenAIError(f"Chat completion failed: {e}")
    
    async def _prepare_request_data(
        self,
        messages: List[ChatMessage],
        model: Optional[str],
        max_tokens: Optional[int],
        temperature: Optional[float],
        use_reasoning: bool,
        reasoning_effort: str,
        previous_response_id: Optional[str],
        additional_tools: Optional[List[Dict[str, Any]]]
    ) -> Dict[str, Any]:
        """Preparar datos de la request"""
        
        # Modelo a usar
        if use_reasoning:
            selected_model = model or self.reasoning_model
        else:
            selected_model = model or self.default_model
        
        # Construir datos base
        request_data = {
            "model": selected_model,
            "input": [msg.to_openai_format() for msg in messages],
            "max_output_tokens": max_tokens or self.max_tokens,
            "temperature": temperature or self.temperature
        }
        
        # Configuración de razonamiento
        if use_reasoning:
            request_data["reasoning"] = {
                "effort": reasoning_effort,
                "summary": "auto"
            }
        
        # ID de respuesta anterior para caché
        if previous_response_id:
            request_data["previous_response_id"] = previous_response_id
        
        # Configurar herramientas
        tools = []
        
        # Agregar servidores MCP
        for mcp_server in self.mcp_servers:
            tools.append(mcp_server.to_openai_tool())
        
        # Agregar herramientas adicionales de OpenAI
        if additional_tools:
            tools.extend(additional_tools)
        
        if tools:
            request_data["tools"] = tools
        
        return request_data
    
    async def _handle_standard_request(
        self, 
        request_data: Dict[str, Any], 
        start_time: float
    ) -> ResponseResult:
        """Manejar request estándar (no streaming)"""
        
        timeout = aiohttp.ClientTimeout(total=self.timeout)
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
            "User-Agent": f"{SYSTEM_NAME}/{SYSTEM_VERSION}"
        }
        
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(
                self.responses_endpoint,
                json=request_data,
                headers=headers
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    return self._parse_response(result, start_time)
                
                elif response.status == 429:
                    raise RateLimitError("Rate limit exceeded")
                
                else:
                    error_text = await response.text()
                    raise OpenAIError(f"API error {response.status}: {error_text}")
    
    async def _handle_streaming_request(
        self, 
        request_data: Dict[str, Any], 
        start_time: float
    ) -> AsyncGenerator[StreamChunk, None]:
        """Manejar request con streaming"""
        
        # Agregar streaming a los datos
        request_data["stream"] = True
        
        timeout = aiohttp.ClientTimeout(total=self.timeout * 2)  # Más tiempo para streaming
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
            "User-Agent": f"{SYSTEM_NAME}/{SYSTEM_VERSION}",
            "Accept": "text/event-stream"
        }
        
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(
                self.responses_endpoint,
                json=request_data,
                headers=headers
            ) as response:
                
                if response.status != 200:
                    error_text = await response.text()
                    raise OpenAIError(f"Streaming error {response.status}: {error_text}")
                
                self.stats['streaming_requests'] += 1
                
                async for chunk in self._parse_streaming_response(response):
                    yield chunk
    
    def _parse_response(self, result: Dict[str, Any], start_time: float) -> ResponseResult:
        """Parsear respuesta estándar"""
        
        # Extraer información básica
        content = ""
        tool_calls = []
        reasoning = None
        
        # Procesar choices
        if "choices" in result and result["choices"]:
            choice = result["choices"][0]
            
            if "message" in choice:
                message = choice["message"]
                if "content" in message:
                    content = message["content"]
                if "tool_calls" in message:
                    tool_calls = message["tool_calls"]
            
            if "reasoning" in choice:
                reasoning = choice["reasoning"]
        
        # Información de uso de tokens
        tokens_used = result.get("usage", {})
        
        # Estadísticas
        response_time = time.time() - start_time
        self.stats['total_requests'] += 1
        self.stats['successful_requests'] += 1
        self.stats['total_tokens_used'] += tokens_used.get('total_tokens', 0)
        
        if tool_calls:
            self.stats['tool_calls_made'] += len(tool_calls)
        
        # Log de rendimiento
        performance_logger.log_api_call(
            "openai_responses",
            response_time,
            True,
            {"tokens": tokens_used.get('total_tokens', 0)}
        )
        
        return ResponseResult(
            content=content,
            model_used=result.get("model", "unknown"),
            finish_reason=result.get("choices", [{}])[0].get("finish_reason", "unknown"),
            tokens_used=tokens_used,
            tool_calls=tool_calls,
            response_time=response_time,
            response_id=result.get("id"),
            reasoning=reasoning
        )
    
    async def _parse_streaming_response(
        self, 
        response: aiohttp.ClientResponse
    ) -> AsyncGenerator[StreamChunk, None]:
        """Parsear respuesta de streaming"""
        
        buffer = ""
        
        async for line in response.content:
            line_text = line.decode('utf-8').strip()
            
            if line_text.startswith("data: "):
                data_text = line_text[6:]  # Remover "data: "
                
                if data_text == "[DONE]":
                    break
                
                try:
                    chunk_data = json.loads(data_text)
                    chunk = self._parse_stream_chunk(chunk_data)
                    if chunk:
                        yield chunk
                        
                except json.JSONDecodeError:
                    continue
    
    def _parse_stream_chunk(self, chunk_data: Dict[str, Any]) -> Optional[StreamChunk]:
        """Parsear chunk individual de streaming"""
        
        if "choices" not in chunk_data or not chunk_data["choices"]:
            return None
        
        choice = chunk_data["choices"][0]
        
        # Extraer contenido delta
        content = ""
        if "delta" in choice and "content" in choice["delta"]:
            content = choice["delta"]["content"]
        
        # Determinar si está completo
        is_complete = choice.get("finish_reason") is not None
        
        # Tool calls (si existen)
        tool_calls = []
        if "delta" in choice and "tool_calls" in choice["delta"]:
            tool_calls = choice["delta"]["tool_calls"]
        
        # Tokens (solo en el último chunk)
        tokens_used = None
        if is_complete and "usage" in chunk_data:
            tokens_used = chunk_data["usage"]
        
        return StreamChunk(
            content=content,
            is_complete=is_complete,
            tool_calls=tool_calls,
            tokens_used=tokens_used
        )
    
    async def _check_rate_limit(self) -> None:
        """Verificar y manejar rate limiting"""
        current_time = time.time()
        
        # Reset ventana si ha pasado 1 minuto
        if current_time - self.rate_limiter['window_start'] >= 60:
            self.rate_limiter['requests_count'] = 0
            self.rate_limiter['window_start'] = current_time
        
        # Verificar límite
        if self.rate_limiter['requests_count'] >= self.rate_limiter['requests_per_minute']:
            wait_time = 60 - (current_time - self.rate_limiter['window_start'])
            self.logger.warning(f"Rate limit alcanzado, esperando {wait_time:.1f}s")
            await asyncio.sleep(wait_time)
            
            # Reset después de esperar
            self.rate_limiter['requests_count'] = 0
            self.rate_limiter['window_start'] = time.time()
        
        self.rate_limiter['requests_count'] += 1
    
    def add_openai_tools(self, model: str = None) -> List[Dict[str, Any]]:
        """
        Agregar herramientas adicionales de OpenAI
        
        Args:
            model: Modelo para determinar herramientas compatibles
            
        Returns:
            Lista de configuraciones de herramientas OpenAI
        """
        tools = []
        
        # Web search (disponible para todos los modelos)
        tools.append({
            "type": "web_search_preview",
            "user_location": {
                "type": "approximate",
                "country": "ES"
            },
            "search_context_size": "medium"
        })
        
        # Code interpreter (si el modelo lo soporta)
        if model and ("gpt-4" in model or "o1" in model):
            tools.append({
                "type": "code_interpreter",
                "container": {
                    "type": "auto"
                }
            })
        
        return tools
    
    def get_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del cliente"""
        return self.stats.copy()
    
    async def health_check(self) -> Dict[str, Any]:
        """Verificar estado del cliente"""
        try:
            # Test simple
            messages = [ChatMessage(role="user", content="test")]
            
            # Request mínima
            request_data = {
                "model": self.default_model,
                "input": [msg.to_openai_format() for msg in messages],
                "max_output_tokens": 5
            }
            
            timeout = aiohttp.ClientTimeout(total=10)
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}"
            }
            
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(
                    self.responses_endpoint,
                    json=request_data,
                    headers=headers
                ) as response:
                    
                    if response.status == 200:
                        return {
                            "status": "healthy",
                            "endpoint": self.responses_endpoint,
                            "mcp_servers": len(self.mcp_servers),
                            "stats": self.get_stats()
                        }
                    else:
                        return {
                            "status": "error",
                            "error": f"HTTP {response.status}",
                            "endpoint": self.responses_endpoint
                        }
                        
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "endpoint": self.responses_endpoint
            }
