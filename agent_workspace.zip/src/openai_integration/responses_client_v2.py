"""
Cliente OpenAI Responses API con integración MCP nativa - PASO 4
Implementa la sintaxis MCP exacta según documentación OpenAI
"""

import asyncio
import json
import time
from typing import Dict, List, Optional, Any, AsyncGenerator, Union
from dataclasses import dataclass, asdict
from datetime import datetime
import aiohttp
from urllib.parse import urljoin

# Importar el SDK oficial de OpenAI
import openai
from openai import AsyncOpenAI

from ..core.config import get_settings
from ..core.logging_config import get_logger, performance_logger
from ..core.exceptions import OpenAIError, MCPError, RateLimitError
from ..core.constants import SYSTEM_NAME, SYSTEM_VERSION


@dataclass
class MCPToolConfig:
    """Configuración exacta de herramienta MCP según documentación OpenAI"""
    type: str = "mcp"
    server_url: str = ""
    server_label: str = ""
    allowed_tools: Optional[List[str]] = None
    require_approval: str = "never"
    headers: Optional[Dict[str, str]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convertir a diccionario para OpenAI API"""
        tool_dict = {
            "type": "mcp",  # Sintaxis MCP exacta según documentación
            "server_url": self.server_url,
            "server_label": self.server_label,
            "require_approval": self.require_approval
        }
        
        if self.allowed_tools:
            tool_dict["allowed_tools"] = self.allowed_tools
        
        if self.headers:
            tool_dict["headers"] = self.headers
            
        return tool_dict


@dataclass
class ChatMessageV2:
    """Mensaje de chat para Responses API v2"""
    role: str  # 'user', 'assistant', 'system'
    content: str
    name: Optional[str] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    
    def to_openai_format(self) -> Dict[str, Any]:
        """Convertir a formato OpenAI"""
        message = {
            "role": self.role,
            "content": self.content
        }
        
        if self.name:
            message["name"] = self.name
            
        if self.tool_calls:
            message["tool_calls"] = self.tool_calls
            
        return message


@dataclass 
class ResponseResultV2:
    """Resultado de response de OpenAI"""
    content: str
    usage: Dict[str, int]
    model: str
    finish_reason: str
    tool_calls: List[Dict[str, Any]]
    response_time: float
    response_id: Optional[str] = None
    reasoning: Optional[str] = None


@dataclass
class StreamChunkV2:
    """Chunk de streaming v2"""
    content: str
    is_complete: bool
    tool_calls: List[Dict[str, Any]]
    tokens_used: Optional[Dict[str, int]] = None


class OpenAIResponsesClientV2:
    """
    Cliente OpenAI Responses API v2 con sintaxis MCP exacta
    Usa el SDK oficial de OpenAI con herramientas MCP nativas
    """
    
    def __init__(self):
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        # Configurar cliente OpenAI oficial
        self.client = AsyncOpenAI(
            api_key=self.settings.openai.api_key,
            base_url=self.settings.openai.base_url,
            timeout=self.settings.openai.timeout,
            max_retries=self.settings.openai.max_retries
        )
        
        # Configuración de modelos
        self.default_model = self.settings.openai.default_model
        self.reasoning_model = self.settings.openai.reasoning_model
        self.max_tokens = self.settings.openai.max_tokens
        self.temperature = self.settings.openai.temperature
        
        # Configuración MCP
        self.mcp_tools: List[MCPToolConfig] = []
        
        # Rate limiting
        self.rate_limiter = {
            'requests_per_minute': 50,
            'requests_count': 0,
            'window_start': time.time()
        }
        
        # Estadísticas
        self.stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'total_tokens_used': 0,
            'tool_calls_made': 0,
            'streaming_requests': 0,
            'cached_requests': 0
        }
        
        self.logger.info("OpenAI Responses Client V2 inicializado con SDK oficial")
    
    def configure_mcp_tool(
        self,
        server_url: str,
        server_label: str,
        allowed_tools: Optional[List[str]] = None,
        require_approval: str = "never",
        headers: Optional[Dict[str, str]] = None
    ) -> None:
        """
        Configurar herramienta MCP exacta según documentación OpenAI
        
        Ejemplo de uso:
        client.configure_mcp_tool(
            server_url="http://localhost:8080/mcp",
            server_label="chat_assistant",
            allowed_tools=["buscar_web", "enviar_email"],
            require_approval="never",
            headers={"X-API-KEY": "mi_clave_secreta"}
        )
        """
        mcp_tool = MCPToolConfig(
            server_url=server_url,
            server_label=server_label,
            allowed_tools=allowed_tools,
            require_approval=require_approval,
            headers=headers
        )
        
        # Reemplazar si ya existe
        self.mcp_tools = [t for t in self.mcp_tools if t.server_label != server_label]
        self.mcp_tools.append(mcp_tool)
        
        self.logger.info(f"Herramienta MCP configurada: {server_label} -> {server_url}")
        if allowed_tools:
            self.logger.info(f"Herramientas permitidas: {allowed_tools}")
    
    def configure_default_mcp_tool(self) -> None:
        """Configurar herramienta MCP por defecto según configuración del sistema"""
        mcp_url = self.settings.mcp.server_url
        mcp_label = self.settings.mcp.server_label
        
        # Headers con API key si está configurada
        headers = {}
        if self.settings.mcp.api_key:
            headers["X-API-KEY"] = self.settings.mcp.api_key
        
        # Herramientas disponibles en nuestro servidor MCP
        allowed_tools = [
            "buscar_informacion",     # SerpAPI web search
            "buscar_noticias",        # SerpAPI news search  
            "gestionar_email",        # Gmail tools
            "gestionar_calendario",   # Google Calendar tools
            "analizar_sentimiento",   # Analytics tools
            "generar_resumen",        # Analytics tools
            "flujo_investigacion_completo",  # Workflow tools
            "estado_sistema"          # System status
        ]
        
        self.configure_mcp_tool(
            server_url=mcp_url,
            server_label=mcp_label,
            allowed_tools=allowed_tools,
            require_approval="never",
            headers=headers if headers else None
        )
    
    async def chat_completion(
        self,
        messages: List[ChatMessageV2],
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        stream: bool = False,
        use_reasoning: bool = False,
        reasoning_effort: str = "medium",
        previous_response_id: Optional[str] = None,
        additional_tools: Optional[List[Dict[str, Any]]] = None
    ) -> Union[ResponseResultV2, AsyncGenerator[StreamChunkV2, None]]:
        """
        Crear chat completion usando Responses API con herramientas MCP
        
        Args:
            messages: Lista de mensajes de chat
            model: Modelo a usar (por defecto del config)  
            max_tokens: Máximo de tokens
            temperature: Temperatura del modelo
            stream: Si hacer streaming de la respuesta
            use_reasoning: Si usar modelo de razonamiento
            reasoning_effort: Esfuerzo de razonamiento (low, medium, high)
            previous_response_id: ID de respuesta anterior para caché
            additional_tools: Herramientas adicionales de OpenAI
        
        Returns:
            ResponseResultV2 o AsyncGenerator para streaming
        """
        try:
            await self._check_rate_limit()
            start_time = time.time()
            
            # Preparar parámetros de la request usando sintaxis exacta
            request_params = await self._prepare_request_params(
                messages=messages,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                use_reasoning=use_reasoning,
                reasoning_effort=reasoning_effort,
                previous_response_id=previous_response_id,
                additional_tools=additional_tools
            )
            
            # Hacer la request usando el SDK oficial
            if stream:
                return self._handle_streaming_request(request_params, start_time)
            else:
                return await self._handle_standard_request(request_params, start_time)
                
        except Exception as e:
            self.logger.error(f"Error en chat completion: {e}")
            raise OpenAIError(f"Chat completion failed: {str(e)}")
    
    async def _prepare_request_params(
        self,
        messages: List[ChatMessageV2],
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        use_reasoning: bool = False,
        reasoning_effort: str = "medium",
        previous_response_id: Optional[str] = None,
        additional_tools: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """Preparar parámetros de request con sintaxis MCP exacta"""
        
        # Configuración base
        request_params = {
            "model": model or (self.reasoning_model if use_reasoning else self.default_model),
            "messages": [msg.to_openai_format() for msg in messages],
            "max_tokens": max_tokens or self.max_tokens,
            "temperature": temperature or self.temperature
        }
        
        # Agregar previous_response_id para caché si está disponible
        if previous_response_id:
            request_params["previous_response_id"] = previous_response_id
        
        # Configurar razonamiento si se solicita
        if use_reasoning:
            request_params["reasoning"] = {
                "effort": reasoning_effort,
                "summary": "auto"
            }
        
        # Preparar herramientas usando sintaxis MCP exacta
        tools = []
        
        # Agregar herramientas MCP con sintaxis exacta según documentación
        for mcp_tool in self.mcp_tools:
            tools.append(mcp_tool.to_dict())
        
        # Agregar herramientas adicionales de OpenAI (web_search, code_interpreter, etc.)
        if additional_tools:
            tools.extend(additional_tools)
        
        if tools:
            request_params["tools"] = tools
        
        return request_params
    
    async def _handle_standard_request(
        self, 
        request_params: Dict[str, Any], 
        start_time: float
    ) -> ResponseResultV2:
        """Manejar request estándar usando SDK oficial"""
        
        try:
            # Usar el endpoint de responses del SDK oficial
            response = await self.client.chat.completions.create(**request_params)
            
            # Procesar respuesta
            return self._parse_response(response, start_time)
            
        except openai.RateLimitError as e:
            raise RateLimitError(f"Rate limit exceeded: {str(e)}")
        except openai.APIError as e:
            raise OpenAIError(f"OpenAI API error: {str(e)}")
        except Exception as e:
            raise OpenAIError(f"Unexpected error: {str(e)}")
    
    async def _handle_streaming_request(
        self, 
        request_params: Dict[str, Any], 
        start_time: float
    ) -> AsyncGenerator[StreamChunkV2, None]:
        """Manejar request con streaming usando SDK oficial"""
        
        # Activar streaming
        request_params["stream"] = True
        
        try:
            stream = await self.client.chat.completions.create(**request_params)
            
            content_chunks = []
            tool_calls = []
            
            async for chunk in stream:
                if chunk.choices and len(chunk.choices) > 0:
                    choice = chunk.choices[0]
                    delta = choice.delta
                    
                    # Contenido de texto
                    content = ""
                    if delta.content:
                        content = delta.content
                        content_chunks.append(content)
                    
                    # Tool calls
                    if delta.tool_calls:
                        tool_calls.extend(delta.tool_calls)
                    
                    # Determinar si es el chunk final
                    is_complete = choice.finish_reason is not None
                    
                    # Crear chunk de respuesta
                    stream_chunk = StreamChunkV2(
                        content=content,
                        is_complete=is_complete,
                        tool_calls=tool_calls if tool_calls else [],
                        tokens_used=None  # Los tokens se reportan al final
                    )
                    
                    yield stream_chunk
                    
                    if is_complete:
                        break
            
        except openai.RateLimitError as e:
            raise RateLimitError(f"Rate limit exceeded: {str(e)}")
        except openai.APIError as e:
            raise OpenAIError(f"OpenAI API error: {str(e)}")
        except Exception as e:
            raise OpenAIError(f"Streaming error: {str(e)}")
    
    def _parse_response(self, response: Any, start_time: float) -> ResponseResultV2:
        """Parsear respuesta de OpenAI"""
        
        response_time = time.time() - start_time
        
        choice = response.choices[0]
        message = choice.message
        
        # Extraer contenido
        content = message.content or ""
        
        # Extraer tool calls
        tool_calls = []
        if message.tool_calls:
            tool_calls = [tool_call.dict() for tool_call in message.tool_calls]
        
        # Extraer usage
        usage = {}
        if response.usage:
            usage = {
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens
            }
        
        # Extraer reasoning si está disponible
        reasoning = None
        if hasattr(response, 'reasoning') and response.reasoning:
            reasoning = response.reasoning
        
        # Actualizar estadísticas
        self.stats['total_requests'] += 1
        self.stats['successful_requests'] += 1
        if usage.get('total_tokens'):
            self.stats['total_tokens_used'] += usage['total_tokens']
        if tool_calls:
            self.stats['tool_calls_made'] += len(tool_calls)
        
        return ResponseResultV2(
            content=content,
            usage=usage,
            model=response.model,
            finish_reason=choice.finish_reason,
            tool_calls=tool_calls,
            response_time=response_time,
            response_id=getattr(response, 'id', None),
            reasoning=reasoning
        )
    
    async def _check_rate_limit(self) -> None:
        """Verificar rate limiting"""
        current_time = time.time()
        
        # Reset ventana si ha pasado un minuto
        if current_time - self.rate_limiter['window_start'] >= 60:
            self.rate_limiter['requests_count'] = 0
            self.rate_limiter['window_start'] = current_time
        
        # Verificar límite
        if self.rate_limiter['requests_count'] >= self.rate_limiter['requests_per_minute']:
            wait_time = 60 - (current_time - self.rate_limiter['window_start'])
            self.logger.warning(f"Rate limit alcanzado, esperando {wait_time:.2f}s")
            await asyncio.sleep(wait_time)
            self.rate_limiter['requests_count'] = 0
            self.rate_limiter['window_start'] = time.time()
        
        self.rate_limiter['requests_count'] += 1
    
    def get_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del cliente"""
        return self.stats.copy()
    
    def reset_stats(self) -> None:
        """Resetear estadísticas"""
        self.stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'total_tokens_used': 0,
            'tool_calls_made': 0,
            'streaming_requests': 0,
            'cached_requests': 0
        }
        self.logger.info("Estadísticas del cliente reseteadas")


# Función de conveniencia para crear cliente con configuración por defecto
async def create_mcp_client() -> OpenAIResponsesClientV2:
    """
    Crear cliente OpenAI con configuración MCP por defecto
    
    Returns:
        Cliente configurado listo para usar
    """
    client = OpenAIResponsesClientV2()
    client.configure_default_mcp_tool()
    return client


# Ejemplo de uso según especificaciones del PASO 4
async def example_usage():
    """
    Ejemplo de uso con sintaxis MCP exacta según documentación
    """
    # Crear cliente
    client = OpenAIResponsesClientV2()
    
    # Configurar herramienta MCP con sintaxis exacta
    client.configure_mcp_tool(
        server_url="http://localhost:8080/mcp",
        server_label="chat_assistant",
        allowed_tools=["buscar_informacion", "gestionar_email"],
        require_approval="never",
        headers={"X-API-KEY": "mi_clave_secreta"}
    )
    
    # Crear mensajes
    messages = [
        ChatMessageV2(role="user", content="Busca información sobre OpenAI MCP")
    ]
    
    # Chat completion estándar
    result = await client.chat_completion(messages=messages)
    print(f"Respuesta: {result.content}")
    print(f"Tokens usados: {result.usage}")
    print(f"Tool calls: {result.tool_calls}")
    
    # Chat completion con streaming
    async for chunk in await client.chat_completion(messages=messages, stream=True):
        print(f"Chunk: {chunk.content}", end="")
        if chunk.is_complete:
            print("\n[Streaming completado]")
            break


if __name__ == "__main__":
    # Ejecutar ejemplo
    asyncio.run(example_usage())
