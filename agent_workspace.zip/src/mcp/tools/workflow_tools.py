"""
Herramientas de flujo de trabajo que combinan múltiples operaciones
"""

import asyncio
from typing import Dict, List, Optional, Any
from datetime import datetime

from ...core.config import get_settings
from ...core.logging_config import get_logger, performance_logger
from ...core.exceptions import WorkflowError
from .base_tool import BaseTool


class WorkflowTools(BaseTool):
    """
    Herramientas de flujo de trabajo que combinan múltiples operaciones
    """
    
    def __init__(self):
        super().__init__("Workflow")
        self.settings = get_settings()
        
        # Referencias a otras herramientas (se configurarán desde el servidor)
        self.serpapi_tools = None
        self.gmail_tools = None
        self.calendar_tools = None
        self.analytics_tools = None
        
        self.logger.info("WorkflowTools inicializado")
    
    def set_tools(self, serpapi_tools, gmail_tools, calendar_tools, analytics_tools):
        """
        Configurar referencias a otras herramientas
        
        Args:
            serpapi_tools: Herramientas de SerpAPI
            gmail_tools: Herramientas de Gmail
            calendar_tools: Herramientas de Calendar
            analytics_tools: Herramientas de Analytics
        """
        self.serpapi_tools = serpapi_tools
        self.gmail_tools = gmail_tools
        self.calendar_tools = calendar_tools
        self.analytics_tools = analytics_tools
        self.logger.info("Herramientas de workflow configuradas")
    
    async def research_workflow(
        self,
        topic: str,
        depth: str = "normal",
        include_news: bool = True,
        include_academic: bool = False,
        email_report: bool = False,
        recipient_email: str = None
    ) -> str:
        """
        Flujo completo de investigación sobre un tema
        
        Args:
            topic: Tema a investigar
            depth: Nivel de profundidad (basico, normal, detallado)
            include_news: Si incluir noticias actuales
            include_academic: Si incluir búsqueda académica
            email_report: Si enviar resultado por email
            recipient_email: Email del destinatario
            
        Returns:
            Informe completo de investigación
        """
        start_time = asyncio.get_event_loop().time()
        
        try:
            if not topic or not topic.strip():
                raise WorkflowError("Tema de investigación es requerido")
            
            self.logger.info(f"Iniciando flujo de investigación para: {topic}")
            
            # Inicializar reporte
            report_sections = []
            
            # 1. Búsqueda web general
            report_sections.append("# 🔍 Investigación Completa: " + topic)
            report_sections.append(f"*Generado el {datetime.now().strftime('%d/%m/%Y %H:%M')}*\n")
            
            try:
                web_results = await self.serpapi_tools.search(
                    query=topic,
                    search_type="web",
                    num_results=5 if depth == "basico" else 8 if depth == "normal" else 10,
                    region="es"
                )
                report_sections.append("## 📝 Información General")
                report_sections.append(web_results)
            except Exception as e:
                self.logger.error(f"Error en búsqueda web: {e}")
                report_sections.append("## 📝 Información General")
                report_sections.append(f"❌ Error obteniendo información general: {str(e)}")
            
            # 2. Noticias actuales si se solicita
            if include_news:
                try:
                    news_results = await self.serpapi_tools.search_news(
                        query=topic,
                        region="es",
                        num_results=3 if depth == "basico" else 5 if depth == "normal" else 7,
                        time_period="7d"
                    )
                    report_sections.append("## 📰 Noticias Actuales")
                    report_sections.append(news_results)
                except Exception as e:
                    self.logger.error(f"Error en búsqueda de noticias: {e}")
                    report_sections.append("## 📰 Noticias Actuales")
                    report_sections.append(f"❌ Error obteniendo noticias: {str(e)}")
            
            # 3. Búsqueda académica si se solicita
            if include_academic:
                try:
                    academic_results = await self.serpapi_tools.search_academic(
                        query=topic,
                        num_results=3 if depth == "basico" else 5
                    )
                    report_sections.append("## 🎓 Investigación Académica")
                    report_sections.append(academic_results)
                except Exception as e:
                    self.logger.error(f"Error en búsqueda académica: {e}")
                    report_sections.append("## 🎓 Investigación Académica")
                    report_sections.append(f"❌ Error obteniendo investigación académica: {str(e)}")
            
            # 4. Generar resumen si el nivel es detallado
            if depth == "detallado":
                try:
                    # Combinar todo el contenido para el resumen
                    full_content = "\n\n".join(report_sections)
                    summary = await self.analytics_tools.generate_summary(
                        content=full_content,
                        length="medio",
                        style="formal",
                        language="es"
                    )
                    report_sections.insert(2, "## 📊 Resumen Ejecutivo")
                    report_sections.insert(3, summary)
                except Exception as e:
                    self.logger.error(f"Error generando resumen: {e}")
            
            # 5. Compilar reporte final
            final_report = "\n\n".join(report_sections)
            
            # Agregar conclusión
            final_report += f"\n\n## ✅ Investigación Completada"
            final_report += f"\n\n*Investigación realizada con {len(report_sections)} secciones.*"
            final_report += f"\n*Profundidad: {depth.title()}*"
            final_report += f"\n*Noticias incluidas: {'Sí' if include_news else 'No'}*"
            final_report += f"\n*Investigación académica: {'Sí' if include_academic else 'No'}*"
            
            # 6. Enviar por email si se solicita
            if email_report and recipient_email:
                try:
                    email_subject = f"Investigación: {topic}"
                    await self.gmail_tools.execute_action(
                        action="enviar",
                        recipient=recipient_email,
                        subject=email_subject,
                        body=final_report
                    )
                    final_report += f"\n\n📧 **Reporte enviado por email a:** {recipient_email}"
                except Exception as e:
                    self.logger.error(f"Error enviando email: {e}")
                    final_report += f"\n\n❌ **Error enviando email:** {str(e)}"
            
            # Log de rendimiento
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("research_workflow", duration, True)
            
            self._record_call(success=True)
            return final_report
            
        except Exception as e:
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("research_workflow", duration, False)
            
            self._record_call(success=False)
            self.logger.error(f"Error en flujo de investigación: {e}")
            raise WorkflowError(f"Research workflow failed: {e}")
    
    async def daily_briefing_workflow(
        self,
        topics: List[str],
        email_recipient: str = None,
        create_calendar_event: bool = False
    ) -> str:
        """
        Flujo de briefing diario con múltiples temas
        
        Args:
            topics: Lista de temas para el briefing
            email_recipient: Email para enviar el briefing
            create_calendar_event: Si crear evento en calendario
            
        Returns:
            Briefing diario completo
        """
        start_time = asyncio.get_event_loop().time()
        
        try:
            if not topics:
                raise WorkflowError("Lista de temas es requerida")
            
            self.logger.info(f"Iniciando briefing diario para {len(topics)} temas")
            
            # Inicializar briefing
            briefing_sections = []
            briefing_sections.append("# 📰 Briefing Diario")
            briefing_sections.append(f"*{datetime.now().strftime('%A, %d de %B de %Y')}*\n")
            
            # Procesar cada tema
            for i, topic in enumerate(topics, 1):
                self.logger.info(f"Procesando tema {i}/{len(topics)}: {topic}")
                
                try:
                    # Buscar noticias del tema
                    news_results = await self.serpapi_tools.search_news(
                        query=topic,
                        region="es",
                        num_results=3,
                        time_period="24h"
                    )
                    
                    briefing_sections.append(f"## {i}. {topic.title()}")
                    briefing_sections.append(news_results)
                    
                except Exception as e:
                    self.logger.error(f"Error procesando tema {topic}: {e}")
                    briefing_sections.append(f"## {i}. {topic.title()}")
                    briefing_sections.append(f"❌ Error obteniendo información: {str(e)}")
            
            # Compilar briefing
            final_briefing = "\n\n".join(briefing_sections)
            
            # Agregar resumen del briefing
            final_briefing += f"\n\n## 📊 Resumen del Briefing"
            final_briefing += f"\n\n✅ Briefing completado con {len(topics)} temas"
            final_briefing += f"\n📅 Fecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}"
            
            # Enviar por email si se solicita
            if email_recipient:
                try:
                    email_subject = f"Briefing Diario - {datetime.now().strftime('%d/%m/%Y')}"
                    await self.gmail_tools.execute_action(
                        action="enviar",
                        recipient=email_recipient,
                        subject=email_subject,
                        body=final_briefing
                    )
                    final_briefing += f"\n\n📧 **Briefing enviado por email a:** {email_recipient}"
                except Exception as e:
                    self.logger.error(f"Error enviando briefing por email: {e}")
                    final_briefing += f"\n\n❌ **Error enviando email:** {str(e)}"
            
            # Crear evento en calendario si se solicita
            if create_calendar_event:
                try:
                    tomorrow = datetime.now().replace(hour=9, minute=0, second=0, microsecond=0)
                    tomorrow = tomorrow.replace(day=tomorrow.day + 1)
                    
                    await self.calendar_tools.execute_action(
                        action="crear",
                        title="Revisar Briefing Diario",
                        start_datetime=tomorrow.strftime("%Y-%m-%d %H:%M"),
                        end_datetime=tomorrow.replace(hour=9, minute=30).strftime("%Y-%m-%d %H:%M"),
                        description=f"Revisar briefing diario con {len(topics)} temas"
                    )
                    final_briefing += f"\n\n📅 **Recordatorio creado en calendario para mañana a las 9:00**"
                except Exception as e:
                    self.logger.error(f"Error creando evento en calendario: {e}")
                    final_briefing += f"\n\n❌ **Error creando recordatorio:** {str(e)}"
            
            # Log de rendimiento
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("daily_briefing_workflow", duration, True)
            
            self._record_call(success=True)
            return final_briefing
            
        except Exception as e:
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("daily_briefing_workflow", duration, False)
            
            self._record_call(success=False)
            self.logger.error(f"Error en briefing diario: {e}")
            raise WorkflowError(f"Daily briefing workflow failed: {e}")
    
    async def email_analysis_workflow(
        self,
        search_query: str = "is:unread",
        analyze_sentiment: bool = True,
        create_summary: bool = True,
        max_emails: int = 10
    ) -> str:
        """
        Flujo de análisis de emails
        
        Args:
            search_query: Query para buscar emails
            analyze_sentiment: Si analizar sentimiento
            create_summary: Si crear resumen
            max_emails: Máximo número de emails a analizar
            
        Returns:
            Análisis completo de emails
        """
        start_time = asyncio.get_event_loop().time()
        
        try:
            self.logger.info(f"Iniciando análisis de emails: {search_query}")
            
            # Buscar emails
            email_results = await self.gmail_tools.execute_action(
                action="buscar",
                search_query=search_query,
                max_results=max_emails
            )
            
            analysis_sections = []
            analysis_sections.append("# 📧 Análisis de Emails")
            analysis_sections.append(f"*Análisis realizado el {datetime.now().strftime('%d/%m/%Y %H:%M')}*\n")
            
            analysis_sections.append("## 📥 Emails Encontrados")
            analysis_sections.append(email_results)
            
            # Análisis adicional si se solicita
            if analyze_sentiment or create_summary:
                analysis_sections.append("## 📊 Análisis Adicional")
                
                if analyze_sentiment:
                    try:
                        sentiment_analysis = await self.analytics_tools.analyze_sentiment(
                            text=email_results,
                            language="es",
                            include_entities=True
                        )
                        analysis_sections.append("### Análisis de Sentimiento")
                        analysis_sections.append(sentiment_analysis)
                    except Exception as e:
                        self.logger.error(f"Error en análisis de sentimiento: {e}")
                        analysis_sections.append("### Análisis de Sentimiento")
                        analysis_sections.append(f"❌ Error: {str(e)}")
                
                if create_summary:
                    try:
                        summary = await self.analytics_tools.generate_summary(
                            content=email_results,
                            length="medio",
                            style="formal",
                            language="es"
                        )
                        analysis_sections.append("### Resumen de Emails")
                        analysis_sections.append(summary)
                    except Exception as e:
                        self.logger.error(f"Error generando resumen: {e}")
                        analysis_sections.append("### Resumen de Emails")
                        analysis_sections.append(f"❌ Error: {str(e)}")
            
            # Compilar análisis final
            final_analysis = "\n\n".join(analysis_sections)
            
            # Log de rendimiento
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("email_analysis_workflow", duration, True)
            
            self._record_call(success=True)
            return final_analysis
            
        except Exception as e:
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("email_analysis_workflow", duration, False)
            
            self._record_call(success=False)
            self.logger.error(f"Error en análisis de emails: {e}")
            raise WorkflowError(f"Email analysis workflow failed: {e}")
    
    async def health_check(self) -> Dict[str, Any]:
        """
        Verificar estado de salud de Workflow
        
        Returns:
            Estado de salud
        """
        try:
            tools_status = {
                "serpapi": self.serpapi_tools is not None,
                "gmail": self.gmail_tools is not None,
                "calendar": self.calendar_tools is not None,
                "analytics": self.analytics_tools is not None
            }
            
            return {
                "status": "healthy" if all(tools_status.values()) else "partial",
                "message": "Workflow tools status",
                "tools_configured": tools_status,
                "available_workflows": [
                    "research_workflow",
                    "daily_briefing_workflow", 
                    "email_analysis_workflow"
                ]
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Workflow health check failed: {str(e)}"
            }