"""
Herramientas de Gmail para gestión de email
"""

import base64
import asyncio
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

from ...core.config import get_settings
from ...core.logging_config import get_logger
from ...core.exceptions import GmailError, ValidationError
from .base_tool import BaseTool
from ..auth.oauth_manager import OAuthManager


class GmailTools(BaseTool):
    """Herramientas de gestión de Gmail"""
    
    def __init__(self):
        super().__init__()
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        self.oauth_manager = OAuthManager()
        self.service = None
        self.user_email = None
    
    async def initialize(self) -> None:
        """Inicializar cliente Gmail"""
        try:
            # Autenticar con Google OAuth
            credentials = await self.oauth_manager.get_credentials()
            
            if not credentials:
                self.logger.warning("No hay credenciales de Gmail disponibles")
                return
            
            # Crear servicio Gmail
            self.service = build('gmail', 'v1', credentials=credentials)
            
            # Obtener información del usuario
            try:
                profile = self.service.users().getProfile(userId='me').execute()
                self.user_email = profile.get('emailAddress')
                self.logger.info(f"Gmail inicializado para: {self.user_email}")
            except Exception as e:
                self.logger.warning(f"No se pudo obtener perfil de Gmail: {e}")
            
            self.is_initialized = True
            self.logger.info("Gmail Tools inicializadas")
            
        except Exception as e:
            self.logger.error(f"Error inicializando Gmail: {e}")
            raise GmailError(f"Failed to initialize Gmail: {e}")
    
    async def send_email(
        self,
        to: str,
        subject: str,
        body: str,
        cc: Optional[str] = None,
        bcc: Optional[str] = None,
        is_html: bool = False
    ) -> str:
        """
        Enviar email
        
        Args:
            to: Destinatario principal
            subject: Asunto del email
            body: Contenido del mensaje
            cc: Destinatarios en copia
            bcc: Destinatarios en copia oculta
            is_html: Si el contenido es HTML
        
        Returns:
            Resultado del envío
        """
        try:
            self._ensure_initialized()
            
            # Validar parámetros
            self._validate_params({"to": to, "subject": subject, "body": body}, ["to", "subject", "body"])
            
            # Crear mensaje
            message = MIMEMultipart()
            message['to'] = to
            message['subject'] = subject
            
            if cc:
                message['cc'] = cc
            if bcc:
                message['bcc'] = bcc
            
            # Agregar contenido
            content_type = 'html' if is_html else 'plain'
            message.attach(MIMEText(body, content_type, 'utf-8'))
            
            # Codificar mensaje
            raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode('utf-8')
            
            # Enviar
            result = self.service.users().messages().send(
                userId='me',
                body={'raw': raw_message}
            ).execute()
            
            message_id = result.get('id')
            
            self.logger.info(f"Email enviado exitosamente: {message_id}")
            
            return self.format_success_response(
                f"📧 Email enviado exitosamente\n\n"
                f"**Para:** {to}\n"
                f"**Asunto:** {subject}\n"
                f"**ID del mensaje:** {message_id}\n"
                f"**Enviado desde:** {self.user_email}",
                "✅ Email enviado"
            )
            
        except Exception as e:
            self.logger.error(f"Error enviando email: {e}")
            return self.format_error_response(e, "envío de email")
    
    async def search_emails(
        self,
        query: str,
        limit: int = 10,
        include_spam_trash: bool = False
    ) -> str:
        """
        Buscar emails
        
        Args:
            query: Query de búsqueda (Gmail query format)
            limit: Número máximo de emails
            include_spam_trash: Incluir spam y papelera
        
        Returns:
            Lista de emails encontrados
        """
        try:
            self._ensure_initialized()
            
            if not query.strip():
                query = "in:inbox"  # Por defecto buscar en inbox
            
            # Buscar mensajes
            results = self.service.users().messages().list(
                userId='me',
                q=query,
                maxResults=limit,
                includeSpamTrash=include_spam_trash
            ).execute()
            
            messages = results.get('messages', [])
            
            if not messages:
                return "📭 No se encontraron emails que coincidan con la búsqueda."
            
            # Obtener detalles de los mensajes
            email_details = []
            for msg in messages[:limit]:
                try:
                    message = self.service.users().messages().get(
                        userId='me',
                        id=msg['id'],
                        format='metadata',
                        metadataHeaders=['Subject', 'From', 'Date', 'To']
                    ).execute()
                    
                    email_details.append(self._format_email_summary(message))
                    
                except Exception as e:
                    self.logger.warning(f"Error obteniendo email {msg['id']}: {e}")
                    continue
            
            result = f"📬 **Emails encontrados ({len(email_details)}):**\n\n"
            result += "\n---\n".join(email_details)
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error buscando emails: {e}")
            return self.format_error_response(e, "búsqueda de emails")
    
    async def read_email(
        self,
        message_id: Optional[str] = None,
        subject_filter: Optional[str] = None,
        from_filter: Optional[str] = None,
        latest: bool = True
    ) -> str:
        """
        Leer email específico o el más reciente
        
        Args:
            message_id: ID específico del mensaje
            subject_filter: Filtrar por asunto
            from_filter: Filtrar por remitente
            latest: Si obtener el más reciente
        
        Returns:
            Contenido del email
        """
        try:
            self._ensure_initialized()
            
            if message_id:
                # Leer mensaje específico
                message = self.service.users().messages().get(
                    userId='me',
                    id=message_id,
                    format='full'
                ).execute()
                
                return self._format_email_full(message)
            
            else:
                # Buscar mensaje basado en filtros
                query_parts = ["in:inbox"]
                
                if subject_filter:
                    query_parts.append(f'subject:"{subject_filter}"')
                if from_filter:
                    query_parts.append(f'from:"{from_filter}"')
                
                query = " ".join(query_parts)
                
                # Buscar mensajes
                results = self.service.users().messages().list(
                    userId='me',
                    q=query,
                    maxResults=1 if latest else 5
                ).execute()
                
                messages = results.get('messages', [])
                
                if not messages:
                    return "📭 No se encontraron emails que coincidan con los filtros."
                
                # Leer el primer (más reciente) mensaje
                message = self.service.users().messages().get(
                    userId='me',
                    id=messages[0]['id'],
                    format='full'
                ).execute()
                
                return self._format_email_full(message)
                
        except Exception as e:
            self.logger.error(f"Error leyendo email: {e}")
            return self.format_error_response(e, "lectura de email")
    
    async def list_emails(
        self,
        label: str = "INBOX",
        limit: int = 10,
        unread_only: bool = False
    ) -> str:
        """
        Listar emails de una etiqueta específica
        
        Args:
            label: Etiqueta de Gmail (INBOX, SENT, DRAFT, etc.)
            limit: Número de emails
            unread_only: Solo emails no leídos
        
        Returns:
            Lista de emails
        """
        try:
            self._ensure_initialized()
            
            query = f"in:{label.lower()}"
            if unread_only:
                query += " is:unread"
            
            return await self.search_emails(query, limit)
            
        except Exception as e:
            self.logger.error(f"Error listando emails: {e}")
            return self.format_error_response(e, "listado de emails")
    
    async def mark_as_read(self, message_id: str) -> str:
        """Marcar email como leído"""
        try:
            self._ensure_initialized()
            
            self.service.users().messages().modify(
                userId='me',
                id=message_id,
                body={'removeLabelIds': ['UNREAD']}
            ).execute()
            
            return f"✅ Email {message_id} marcado como leído"
            
        except Exception as e:
            self.logger.error(f"Error marcando como leído: {e}")
            return self.format_error_response(e, "marcar como leído")
    
    async def delete_email(self, message_id: str) -> str:
        """Eliminar email"""
        try:
            self._ensure_initialized()
            
            self.service.users().messages().delete(
                userId='me',
                id=message_id
            ).execute()
            
            return f"🗑️ Email {message_id} eliminado"
            
        except Exception as e:
            self.logger.error(f"Error eliminando email: {e}")
            return self.format_error_response(e, "eliminar email")
    
    def _format_email_summary(self, message: Dict) -> str:
        """Formatear resumen de email"""
        try:
            headers = {h['name']: h['value'] for h in message['payload'].get('headers', [])}
            
            subject = headers.get('Subject', 'Sin asunto')
            from_addr = headers.get('From', 'Desconocido')
            date = headers.get('Date', 'Fecha desconocida')
            to_addr = headers.get('To', 'Desconocido')
            
            # Formatear fecha
            try:
                from email.utils import parsedate_to_datetime
                date_obj = parsedate_to_datetime(date)
                formatted_date = date_obj.strftime("%d/%m/%Y %H:%M")
            except:
                formatted_date = date
            
            # Verificar si está leído
            labels = message.get('labelIds', [])
            status = "📬" if "UNREAD" in labels else "📭"
            
            result = f"{status} **{subject}**\n"
            result += f"**De:** {from_addr}\n"
            result += f"**Para:** {to_addr}\n"
            result += f"**Fecha:** {formatted_date}\n"
            result += f"**ID:** {message['id']}"
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error formateando email: {e}")
            return f"Error formateando email: {e}"
    
    def _format_email_full(self, message: Dict) -> str:
        """Formatear email completo"""
        try:
            headers = {h['name']: h['value'] for h in message['payload'].get('headers', [])}
            
            subject = headers.get('Subject', 'Sin asunto')
            from_addr = headers.get('From', 'Desconocido')
            date = headers.get('Date', 'Fecha desconocida')
            to_addr = headers.get('To', 'Desconocido')
            
            # Formatear fecha
            try:
                from email.utils import parsedate_to_datetime
                date_obj = parsedate_to_datetime(date)
                formatted_date = date_obj.strftime("%d/%m/%Y %H:%M")
            except:
                formatted_date = date
            
            # Extraer contenido
            body = self._extract_email_body(message['payload'])
            
            result = f"📧 **Email completo**\n\n"
            result += f"**Asunto:** {subject}\n"
            result += f"**De:** {from_addr}\n"
            result += f"**Para:** {to_addr}\n"
            result += f"**Fecha:** {formatted_date}\n"
            result += f"**ID:** {message['id']}\n\n"
            result += "**Contenido:**\n"
            result += "---\n"
            result += body or "Sin contenido de texto disponible"
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error formateando email completo: {e}")
            return self.format_error_response(e, "formato de email")
    
    def _extract_email_body(self, payload: Dict) -> str:
        """Extraer el cuerpo del email"""
        try:
            # Si tiene partes múltiples
            if 'parts' in payload:
                for part in payload['parts']:
                    if part['mimeType'] == 'text/plain':
                        data = part['body'].get('data')
                        if data:
                            return base64.urlsafe_b64decode(data).decode('utf-8')
                    elif part['mimeType'] == 'text/html':
                        # Como fallback, usar HTML si no hay texto plano
                        data = part['body'].get('data')
                        if data:
                            import html
                            html_content = base64.urlsafe_b64decode(data).decode('utf-8')
                            # Limpiar HTML básico
                            text_content = html.unescape(html_content)
                            # Remover tags HTML básicos
                            import re
                            text_content = re.sub('<[^<]+?>', '', text_content)
                            return text_content
            
            # Si es un mensaje simple
            elif payload['mimeType'] == 'text/plain':
                data = payload['body'].get('data')
                if data:
                    return base64.urlsafe_b64decode(data).decode('utf-8')
            
            return "No se pudo extraer el contenido del mensaje"
            
        except Exception as e:
            self.logger.error(f"Error extrayendo cuerpo del email: {e}")
            return f"Error extrayendo contenido: {e}"
    
    async def health_check(self) -> str:
        """Verificar estado de Gmail"""
        try:
            if not self.is_initialized:
                return "not_initialized"
            
            if not self.service:
                return "no_service"
            
            # Test simple
            profile = self.service.users().getProfile(userId='me').execute()
            return "healthy"
            
        except Exception as e:
            return f"error: {str(e)}"
    
    async def close(self) -> None:
        """Cerrar recursos de Gmail"""
        try:
            self.service = None
            await super().close()
            self.logger.info("Gmail Tools cerradas")
        except Exception as e:
            self.logger.error(f"Error cerrando Gmail: {e}")
