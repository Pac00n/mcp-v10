"""
Herramientas de SerpAPI para búsqueda web
"""

import asyncio
import aiohttp
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

from ...core.config import get_settings
from ...core.logging_config import get_logger, performance_logger
from ...core.exceptions import SerpAPIError
from .base_tool import BaseTool


class SerpAPITools(BaseTool):
    """
    Herramientas de búsqueda web usando SerpAPI
    """
    
    def __init__(self):
        super().__init__("SerpAPI")
        self.settings = get_settings()
        self.api_key = self.settings.serpapi.api_key
        self.base_url = self.settings.serpapi.base_url
        self.timeout = self.settings.serpapi.timeout
        self.max_retries = self.settings.serpapi.max_retries
        
        # Mapeo de tipos de búsqueda a engines de SerpAPI
        self.engine_mapping = {
            "web": "google",
            "news": "google_news",
            "scholar": "google_scholar",
            "images": "google_images",
            "videos": "google_videos",
            "shopping": "google_shopping",
            "maps": "google_maps"
        }
        
        self.logger.info("SerpAPITools inicializado")
    
    async def search(
        self,
        query: str,
        search_type: str = "web",
        num_results: int = 5,
        region: str = "es",
        **kwargs
    ) -> str:
        """
        Realizar búsqueda web usando SerpAPI
        
        Args:
            query: Términos de búsqueda
            search_type: Tipo de búsqueda (web, news, scholar, images, videos)
            num_results: Número de resultados
            region: Región de búsqueda
            **kwargs: Parámetros adicionales
        
        Returns:
            Resultados formateados como string
        """
        start_time = asyncio.get_event_loop().time()
        
        try:
            if not self.api_key:
                raise SerpAPIError("SERPAPI_API_KEY no configurada")
            
            # Seleccionar engine apropiado
            engine = self.engine_mapping.get(search_type, "google")
            
            # Preparar parámetros
            params = {
                "api_key": self.api_key,
                "q": query,
                "engine": engine,
                "num": min(num_results, 10),  # Máximo 10 resultados
                "gl": region,
                "hl": "es" if region == "es" else "en"
            }
            
            # Parámetros específicos por tipo
            if search_type == "news":
                params.update({
                    "tbm": "nws",
                    "tbs": kwargs.get("time_period", "qdr:d")  # Por defecto último día
                })
            elif search_type == "scholar":
                params.update({
                    "as_ylo": kwargs.get("year_from", ""),
                    "as_yhi": kwargs.get("year_to", "")
                })
            elif search_type == "images":
                params.update({
                    "tbm": "isch",
                    "safe": "active"
                })
            
            # Agregar parámetros adicionales
            params.update(kwargs)
            
            # Realizar búsqueda
            result = await self._make_request(params)
            
            # Formatear resultados
            formatted_result = await self._format_results(result, search_type, query)
            
            # Log de rendimiento
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("serpapi_search", duration, True)
            
            return formatted_result
            
        except Exception as e:
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("serpapi_search", duration, False)
            self.logger.error(f"Error en búsqueda SerpAPI: {e}")
            raise SerpAPIError(f"Search failed: {e}")
    
    async def search_news(
        self,
        query: str,
        region: str = "es",
        num_results: int = 5,
        time_period: str = "24h"
    ) -> str:
        """
        Búsqueda específica de noticias
        
        Args:
            query: Términos de búsqueda
            region: Región
            num_results: Número de noticias
            time_period: Periodo (24h, 7d, 30d)
        
        Returns:
            Noticias formateadas
        """
        # Convertir periodo a formato SerpAPI
        time_mapping = {
            "24h": "qdr:d",    # Último día
            "7d": "qdr:w",     # Última semana
            "30d": "qdr:m",    # Último mes
            "1y": "qdr:y"      # Último año
        }
        
        tbs_param = time_mapping.get(time_period, "qdr:d")
        
        return await self.search(
            query=query,
            search_type="news",
            num_results=num_results,
            region=region,
            tbs=tbs_param
        )
    
    async def search_academic(
        self,
        query: str,
        year_from: Optional[int] = None,
        year_to: Optional[int] = None,
        author: Optional[str] = None,
        num_results: int = 5
    ) -> str:
        """
        Búsqueda académica en Google Scholar
        
        Args:
            query: Términos de búsqueda
            year_from: Año desde
            year_to: Año hasta
            author: Autor específico
            num_results: Número de resultados
        
        Returns:
            Artículos académicos formateados
        """
        params = {}
        
        if year_from:
            params["as_ylo"] = str(year_from)
        if year_to:
            params["as_yhi"] = str(year_to)
        if author:
            query = f'author:"{author}" {query}'
        
        return await self.search(
            query=query,
            search_type="scholar",
            num_results=num_results,
            **params
        )
    
    async def _make_request(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Realizar request HTTP a SerpAPI con reintentos
        
        Args:
            params: Parámetros de la request
        
        Returns:
            Respuesta JSON de SerpAPI
        """
        last_exception = None
        
        for attempt in range(self.max_retries):
            try:
                timeout = aiohttp.ClientTimeout(total=self.timeout)
                
                async with aiohttp.ClientSession(timeout=timeout) as session:
                    async with session.get(self.base_url, params=params) as response:
                        if response.status == 200:
                            return await response.json()
                        elif response.status == 429:
                            # Rate limit - esperar y reintentar
                            wait_time = 2 ** attempt
                            self.logger.warning(f"Rate limit hit, waiting {wait_time}s")
                            await asyncio.sleep(wait_time)
                            continue
                        else:
                            error_text = await response.text()
                            raise SerpAPIError(f"HTTP {response.status}: {error_text}")
                            
            except asyncio.TimeoutError as e:
                last_exception = e
                wait_time = 1 * (attempt + 1)
                self.logger.warning(f"Timeout en intento {attempt + 1}, esperando {wait_time}s")
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(wait_time)
                continue
                
            except Exception as e:
                last_exception = e
                if attempt < self.max_retries - 1:
                    wait_time = 1 * (attempt + 1)
                    self.logger.warning(f"Error en intento {attempt + 1}: {e}, esperando {wait_time}s")
                    await asyncio.sleep(wait_time)
                    continue
                else:
                    break
        
        # Si llegamos aquí, todos los intentos fallaron
        raise SerpAPIError(f"All {self.max_retries} attempts failed. Last error: {last_exception}")
    
    async def _format_results(
        self, 
        result: Dict[str, Any], 
        search_type: str, 
        query: str
    ) -> str:
        """
        Formatear resultados según el tipo de búsqueda
        
        Args:
            result: Respuesta de SerpAPI
            search_type: Tipo de búsqueda
            query: Query original
        
        Returns:
            Resultados formateados como string
        """
        try:
            if search_type == "web":
                return await self._format_web_results(result, query)
            elif search_type == "news":
                return await self._format_news_results(result, query)
            elif search_type == "scholar":
                return await self._format_scholar_results(result, query)
            elif search_type == "images":
                return await self._format_images_results(result, query)
            else:
                return await self._format_web_results(result, query)
                
        except Exception as e:
            self.logger.error(f"Error formateando resultados: {e}")
            return f"❌ Error formateando resultados para '{query}': {str(e)}"
    
    async def _format_web_results(self, result: Dict[str, Any], query: str) -> str:
        """Formatear resultados de búsqueda web"""
        if "organic_results" not in result:
            return f"🔍 No se encontraron resultados para '{query}'"
        
        results = result["organic_results"]
        if not results:
            return f"🔍 No se encontraron resultados para '{query}'"
        
        formatted = f"🔍 **Resultados para '{query}'**:\n\n"
        
        for i, item in enumerate(results[:5], 1):
            title = item.get("title", "Sin título")
            snippet = item.get("snippet", "Sin descripción")
            link = item.get("link", "")
            
            # Limpiar snippet
            snippet = snippet.replace("\n", " ").strip()
            if len(snippet) > 150:
                snippet = snippet[:147] + "..."
            
            formatted += f"**{i}. {title}**\n"
            formatted += f"📝 {snippet}\n"
            formatted += f"🔗 {link}\n\n"
        
        return formatted
    
    async def _format_news_results(self, result: Dict[str, Any], query: str) -> str:
        """Formatear resultados de noticias"""
        if "news_results" not in result:
            return f"📰 No se encontraron noticias para '{query}'"
        
        results = result["news_results"]
        if not results:
            return f"📰 No se encontraron noticias para '{query}'"
        
        formatted = f"📰 **Noticias sobre '{query}'**:\n\n"
        
        for i, item in enumerate(results[:5], 1):
            title = item.get("title", "Sin título")
            snippet = item.get("snippet", "Sin descripción")
            source = item.get("source", "Fuente desconocida")
            date = item.get("date", "")
            link = item.get("link", "")
            
            # Limpiar snippet
            snippet = snippet.replace("\n", " ").strip()
            if len(snippet) > 120:
                snippet = snippet[:117] + "..."
            
            formatted += f"**{i}. {title}**\n"
            formatted += f"📰 {source}"
            if date:
                formatted += f" - {date}"
            formatted += f"\n📝 {snippet}\n"
            formatted += f"🔗 {link}\n\n"
        
        return formatted
    
    async def _format_scholar_results(self, result: Dict[str, Any], query: str) -> str:
        """Formatear resultados académicos"""
        if "organic_results" not in result:
            return f"🎓 No se encontraron artículos académicos para '{query}'"
        
        results = result["organic_results"]
        if not results:
            return f"🎓 No se encontraron artículos académicos para '{query}'"
        
        formatted = f"🎓 **Artículos académicos sobre '{query}'**:\n\n"
        
        for i, item in enumerate(results[:5], 1):
            title = item.get("title", "Sin título")
            snippet = item.get("snippet", "Sin resumen")
            link = item.get("link", "")
            
            # Información adicional específica de Scholar
            publication_info = item.get("publication_info", {})
            authors = publication_info.get("authors", [])
            year = publication_info.get("year", "")
            
            formatted += f"**{i}. {title}**\n"
            
            if authors:
                authors_str = ", ".join(authors[:3])  # Máximo 3 autores
                if len(authors) > 3:
                    authors_str += " et al."
                formatted += f"👥 Autores: {authors_str}\n"
            
            if year:
                formatted += f"📅 Año: {year}\n"
            
            # Limpiar snippet
            snippet = snippet.replace("\n", " ").strip()
            if len(snippet) > 150:
                snippet = snippet[:147] + "..."
            
            formatted += f"📝 {snippet}\n"
            formatted += f"🔗 {link}\n\n"
        
        return formatted
    
    async def _format_images_results(self, result: Dict[str, Any], query: str) -> str:
        """Formatear resultados de imágenes"""
        if "images_results" not in result:
            return f"🖼️ No se encontraron imágenes para '{query}'"
        
        results = result["images_results"]
        if not results:
            return f"🖼️ No se encontraron imágenes para '{query}'"
        
        formatted = f"🖼️ **Imágenes de '{query}'**:\n\n"
        
        for i, item in enumerate(results[:5], 1):
            title = item.get("title", "Sin título")
            source = item.get("source", "Fuente desconocida")
            original = item.get("original", "")
            thumbnail = item.get("thumbnail", "")
            
            formatted += f"**{i}. {title}**\n"
            formatted += f"📱 Fuente: {source}\n"
            formatted += f"🔗 Original: {original}\n"
            if thumbnail:
                formatted += f"🖼️ Preview: {thumbnail}\n"
            formatted += "\n"
        
        return formatted
    
    async def health_check(self) -> Dict[str, Any]:
        """
        Verificar estado de SerpAPI
        
        Returns:
            Estado del servicio
        """
        try:
            if not self.api_key:
                return {
                    "status": "error",
                    "message": "API key not configured"
                }
            
            # Test simple con búsqueda básica
            params = {
                "api_key": self.api_key,
                "q": "test",
                "engine": "google",
                "num": 1
            }
            
            timeout = aiohttp.ClientTimeout(total=5)  # Timeout corto para health check
            
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(self.base_url, params=params) as response:
                    if response.status == 200:
                        return {
                            "status": "healthy",
                            "message": "SerpAPI responding correctly"
                        }
                    else:
                        return {
                            "status": "error",
                            "message": f"HTTP {response.status}"
                        }
                        
        except Exception as e:
            return {
                "status": "error",
                "message": f"Health check failed: {str(e)}"
            }