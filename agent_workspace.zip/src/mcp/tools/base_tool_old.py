"""
Clase base para todas las herramientas MCP
"""

import asyncio
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional

from ...core.logging_config import get_logger
from ...core.exceptions import MCPToolError


class BaseTool(ABC):
    """Clase base abstracta para herramientas MCP"""
    
    def __init__(self):
        self.logger = get_logger(self.__class__.__name__)
        self.is_initialized = False
        self._name = self.__class__.__name__
        
        self.logger.debug(f"Inicializando {self._name}")
    
    @abstractmethod
    async def initialize(self) -> None:
        """Inicializar la herramienta"""
        pass
    
    @abstractmethod
    async def health_check(self) -> str:
        """Verificar estado de la herramienta"""
        pass
    
    async def close(self) -> None:
        """Cerrar recursos de la herramienta"""
        self.is_initialized = False
        self.logger.debug(f"Cerrando {self._name}")
    
    def _ensure_initialized(self) -> None:
        """Verificar que la herramienta esté inicializada"""
        if not self.is_initialized:
            raise MCPToolError(f"Tool {self._name} not initialized")
    
    def _validate_params(self, params: Dict[str, Any], required: list) -> None:
        """Validar parámetros requeridos"""
        missing = [param for param in required if param not in params or params[param] is None]
        if missing:
            raise MCPToolError(f"Missing required parameters: {missing}")
    
    async def execute_with_retry(
        self, 
        func, 
        max_retries: int = 3, 
        delay: float = 1.0,
        *args, 
        **kwargs
    ):
        """Ejecutar función con reintentos"""
        last_exception = None
        
        for attempt in range(max_retries):
            try:
                return await func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                if attempt < max_retries - 1:
                    wait_time = delay * (2 ** attempt)  # Backoff exponencial
                    self.logger.warning(
                        f"Intento {attempt + 1} falló, reintentando en {wait_time}s: {e}"
                    )
                    await asyncio.sleep(wait_time)
                else:
                    self.logger.error(f"Todos los intentos fallaron: {e}")
        
        raise last_exception
    
    def format_error_response(self, error: Exception, context: str = "") -> str:
        """Formatear respuesta de error para el usuario"""
        error_msg = f"❌ Error en {self._name}"
        if context:
            error_msg += f" ({context})"
        error_msg += f": {str(error)}"
        
        # Log detallado para debugging
        self.logger.error(f"Error en {self._name}: {error}", exc_info=True)
        
        return error_msg
    
    def format_success_response(self, data: Any, title: str = "") -> str:
        """Formatear respuesta exitosa"""
        if not title:
            title = f"✅ Resultado de {self._name}"
        
        if isinstance(data, str):
            return f"{title}\n\n{data}"
        elif isinstance(data, dict):
            return f"{title}\n\n{self._dict_to_string(data)}"
        elif isinstance(data, list):
            return f"{title}\n\n{self._list_to_string(data)}"
        else:
            return f"{title}\n\n{str(data)}"
    
    def _dict_to_string(self, data: dict, indent: int = 0) -> str:
        """Convertir diccionario a string formateado"""
        lines = []
        prefix = "  " * indent
        
        for key, value in data.items():
            if isinstance(value, dict):
                lines.append(f"{prefix}**{key}:**")
                lines.append(self._dict_to_string(value, indent + 1))
            elif isinstance(value, list):
                lines.append(f"{prefix}**{key}:**")
                lines.append(self._list_to_string(value, indent + 1))
            else:
                lines.append(f"{prefix}**{key}:** {value}")
        
        return "\n".join(lines)
    
    def _list_to_string(self, data: list, indent: int = 0) -> str:
        """Convertir lista a string formateado"""
        lines = []
        prefix = "  " * indent
        
        for i, item in enumerate(data, 1):
            if isinstance(item, dict):
                lines.append(f"{prefix}{i}. {self._dict_to_string(item, indent + 1)}")
            elif isinstance(item, list):
                lines.append(f"{prefix}{i}. {self._list_to_string(item, indent + 1)}")
            else:
                lines.append(f"{prefix}{i}. {item}")
        
        return "\n".join(lines)
    
    def truncate_text(self, text: str, max_length: int = 500) -> str:
        """Truncar texto si es muy largo"""
        if len(text) <= max_length:
            return text
        
        return text[:max_length - 3] + "..."
    
    @property
    def name(self) -> str:
        """Nombre de la herramienta"""
        return self._name
    
    @property
    def status(self) -> Dict[str, Any]:
        """Estado actual de la herramienta"""
        return {
            "name": self._name,
            "initialized": self.is_initialized,
            "class": self.__class__.__name__
        }
