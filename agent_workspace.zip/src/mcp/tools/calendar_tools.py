"""
Herramientas de Google Calendar para gestión de eventos
"""

import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import pytz
from dateutil import parser

from ...core.config import get_settings
from ...core.logging_config import get_logger, performance_logger
from ...core.exceptions import CalendarError
from .base_tool import BaseTool


class CalendarTools(BaseTool):
    """
    Herramientas para gestión de Google Calendar
    """
    
    def __init__(self):
        super().__init__("Calendar")
        self.settings = get_settings()
        
        # El servicio se obtendrá a través del OAuthManager
        self.service = None
        self.default_timezone = 'Europe/Madrid'
        
        self.logger.info("CalendarTools inicializado")
    
    async def execute_action(
        self,
        action: str,
        title: str = None,
        start_datetime: str = None,
        end_datetime: str = None,
        description: str = None,
        attendees: List[str] = None,
        event_id: str = None,
        calendar_id: str = "primary",
        days_ahead: int = 30,
        **kwargs
    ) -> str:
        """
        Ejecutar acción de Calendar
        
        Args:
            action: Acción a realizar (crear, listar, eliminar, actualizar, buscar)
            title: Título del evento
            start_datetime: Fecha/hora inicio
            end_datetime: Fecha/hora fin
            description: Descripción del evento
            attendees: Lista de emails para invitar
            event_id: ID del evento
            calendar_id: ID del calendario
            days_ahead: Días hacia adelante para listar
            
        Returns:
            Resultado de la acción
        """
        start_time = asyncio.get_event_loop().time()
        
        try:
            if not self.service:
                raise CalendarError("Calendar service not available. Check OAuth authentication.")
            
            result = ""
            
            if action == "crear":
                result = await self._create_event(
                    title, start_datetime, end_datetime, description, 
                    attendees or [], calendar_id
                )
            elif action == "listar":
                result = await self._list_events(calendar_id, days_ahead)
            elif action == "eliminar":
                result = await self._delete_event(event_id, calendar_id)
            elif action == "actualizar":
                result = await self._update_event(
                    event_id, title, start_datetime, end_datetime, 
                    description, attendees, calendar_id
                )
            elif action == "buscar":
                result = await self._search_events(title, calendar_id, days_ahead)
            else:
                raise CalendarError(f"Acción no soportada: {action}")
            
            # Log de rendimiento
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("calendar_action", duration, True)
            
            self._record_call(success=True)
            return result
            
        except Exception as e:
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("calendar_action", duration, False)
            
            self._record_call(success=False)
            self.logger.error(f"Error en acción Calendar {action}: {e}")
            raise CalendarError(f"Calendar action '{action}' failed: {e}")
    
    async def _create_event(
        self,
        title: str,
        start_datetime: str,
        end_datetime: str,
        description: str = None,
        attendees: List[str] = None,
        calendar_id: str = "primary"
    ) -> str:
        """
        Crear evento en el calendario
        
        Args:
            title: Título del evento
            start_datetime: Fecha/hora inicio
            end_datetime: Fecha/hora fin
            description: Descripción
            attendees: Lista de invitados
            calendar_id: ID del calendario
            
        Returns:
            Confirmación de creación
        """
        try:
            if not all([title, start_datetime, end_datetime]):
                raise CalendarError("Título, fecha de inicio y fin son requeridos")
            
            # Parsear fechas
            start_dt = self._parse_datetime(start_datetime)
            end_dt = self._parse_datetime(end_datetime)
            
            # Verificar que la fecha de fin sea posterior al inicio
            if end_dt <= start_dt:
                raise CalendarError("La fecha de fin debe ser posterior a la de inicio")
            
            # Crear evento
            event = {
                'summary': title,
                'start': {
                    'dateTime': start_dt.isoformat(),
                    'timeZone': self.default_timezone,
                },
                'end': {
                    'dateTime': end_dt.isoformat(),
                    'timeZone': self.default_timezone,
                },
            }
            
            if description:
                event['description'] = description
            
            if attendees:
                event['attendees'] = [{'email': email} for email in attendees]
            
            # Crear evento en Google Calendar
            created_event = self.service.events().insert(
                calendarId=calendar_id,
                body=event
            ).execute()
            
            # Formatear respuesta
            event_link = created_event.get('htmlLink', '')
            
            result = f"✅ **Evento creado correctamente**\n\n"
            result += f"📅 **{title}**\n"
            result += f"🕐 Inicio: {self._format_datetime(start_dt)}\n"
            result += f"🕐 Fin: {self._format_datetime(end_dt)}\n"
            
            if description:
                result += f"📝 Descripción: {description}\n"
            
            if attendees:
                result += f"👥 Invitados: {', '.join(attendees)}\n"
            
            result += f"🆔 ID: {created_event['id']}\n"
            
            if event_link:
                result += f"🔗 Link: {event_link}"
            
            return result
            
        except Exception as e:
            raise CalendarError(f"Error creando evento: {e}")
    
    async def _list_events(self, calendar_id: str = "primary", days_ahead: int = 30) -> str:
        """
        Listar eventos próximos
        
        Args:
            calendar_id: ID del calendario
            days_ahead: Días hacia adelante
            
        Returns:
            Lista de eventos
        """
        try:
            # Calcular rango de fechas
            now = datetime.now(pytz.timezone(self.default_timezone))
            end_date = now + timedelta(days=days_ahead)
            
            # Obtener eventos
            events_result = self.service.events().list(
                calendarId=calendar_id,
                timeMin=now.isoformat(),
                timeMax=end_date.isoformat(),
                maxResults=20,
                singleEvents=True,
                orderBy='startTime'
            ).execute()
            
            events = events_result.get('items', [])
            
            if not events:
                return f"📅 No hay eventos en los próximos {days_ahead} días"
            
            formatted = f"📅 **Eventos próximos ({len(events)}) - Próximos {days_ahead} días:**\n\n"
            
            for i, event in enumerate(events, 1):
                title = event.get('summary', 'Sin título')
                start = event['start'].get('dateTime', event['start'].get('date'))
                end = event['end'].get('dateTime', event['end'].get('date'))
                description = event.get('description', '')
                location = event.get('location', '')
                event_id = event['id']
                
                # Parsear fechas
                start_dt = parser.parse(start)
                end_dt = parser.parse(end)
                
                formatted += f"**{i}. {title}**\n"
                formatted += f"🕐 {self._format_datetime(start_dt)} - {self._format_datetime(end_dt)}\n"
                
                if location:
                    formatted += f"📍 Ubicación: {location}\n"
                
                if description:
                    desc_preview = description[:100] + "..." if len(description) > 100 else description
                    formatted += f"📝 {desc_preview}\n"
                
                formatted += f"🆔 ID: {event_id}\n\n"
            
            return formatted
            
        except Exception as e:
            raise CalendarError(f"Error listando eventos: {e}")
    
    async def _delete_event(self, event_id: str, calendar_id: str = "primary") -> str:
        """
        Eliminar evento
        
        Args:
            event_id: ID del evento
            calendar_id: ID del calendario
            
        Returns:
            Confirmación de eliminación
        """
        try:
            if not event_id:
                raise CalendarError("ID del evento es requerido")
            
            # Obtener información del evento antes de eliminarlo
            event = self.service.events().get(
                calendarId=calendar_id,
                eventId=event_id
            ).execute()
            
            title = event.get('summary', 'Sin título')
            
            # Eliminar evento
            self.service.events().delete(
                calendarId=calendar_id,
                eventId=event_id
            ).execute()
            
            return f"✅ Evento '{title}' eliminado correctamente (ID: {event_id})"
            
        except Exception as e:
            raise CalendarError(f"Error eliminando evento: {e}")
    
    async def _update_event(
        self,
        event_id: str,
        title: str = None,
        start_datetime: str = None,
        end_datetime: str = None,
        description: str = None,
        attendees: List[str] = None,
        calendar_id: str = "primary"
    ) -> str:
        """
        Actualizar evento existente
        
        Args:
            event_id: ID del evento
            title: Nuevo título
            start_datetime: Nueva fecha/hora inicio
            end_datetime: Nueva fecha/hora fin
            description: Nueva descripción
            attendees: Nueva lista de invitados
            calendar_id: ID del calendario
            
        Returns:
            Confirmación de actualización
        """
        try:
            if not event_id:
                raise CalendarError("ID del evento es requerido")
            
            # Obtener evento existente
            event = self.service.events().get(
                calendarId=calendar_id,
                eventId=event_id
            ).execute()
            
            # Actualizar campos proporcionados
            if title:
                event['summary'] = title
            
            if start_datetime:
                start_dt = self._parse_datetime(start_datetime)
                event['start'] = {
                    'dateTime': start_dt.isoformat(),
                    'timeZone': self.default_timezone,
                }
            
            if end_datetime:
                end_dt = self._parse_datetime(end_datetime)
                event['end'] = {
                    'dateTime': end_dt.isoformat(),
                    'timeZone': self.default_timezone,
                }
            
            if description is not None:  # Permitir descripción vacía
                event['description'] = description
            
            if attendees is not None:  # Permitir lista vacía
                event['attendees'] = [{'email': email} for email in attendees]
            
            # Actualizar evento
            updated_event = self.service.events().update(
                calendarId=calendar_id,
                eventId=event_id,
                body=event
            ).execute()
            
            return f"✅ Evento actualizado correctamente\n📅 {updated_event.get('summary', 'Sin título')}\n🆔 ID: {event_id}"
            
        except Exception as e:
            raise CalendarError(f"Error actualizando evento: {e}")
    
    async def _search_events(self, query: str, calendar_id: str = "primary", days_ahead: int = 30) -> str:
        """
        Buscar eventos por texto
        
        Args:
            query: Texto a buscar
            calendar_id: ID del calendario
            days_ahead: Días hacia adelante para buscar
            
        Returns:
            Eventos encontrados
        """
        try:
            if not query:
                raise CalendarError("Query de búsqueda es requerida")
            
            # Calcular rango de fechas
            now = datetime.now(pytz.timezone(self.default_timezone))
            end_date = now + timedelta(days=days_ahead)
            
            # Buscar eventos
            events_result = self.service.events().list(
                calendarId=calendar_id,
                timeMin=now.isoformat(),
                timeMax=end_date.isoformat(),
                q=query,
                maxResults=20,
                singleEvents=True,
                orderBy='startTime'
            ).execute()
            
            events = events_result.get('items', [])
            
            if not events:
                return f"🔍 No se encontraron eventos que contengan '{query}'"
            
            formatted = f"🔍 **Eventos encontrados ({len(events)}) para '{query}':**\n\n"
            
            for i, event in enumerate(events, 1):
                title = event.get('summary', 'Sin título')
                start = event['start'].get('dateTime', event['start'].get('date'))
                description = event.get('description', '')
                event_id = event['id']
                
                # Parsear fecha
                start_dt = parser.parse(start)
                
                formatted += f"**{i}. {title}**\n"
                formatted += f"🕐 {self._format_datetime(start_dt)}\n"
                
                if description:
                    desc_preview = description[:100] + "..." if len(description) > 100 else description
                    formatted += f"📝 {desc_preview}\n"
                
                formatted += f"🆔 ID: {event_id}\n\n"
            
            return formatted
            
        except Exception as e:
            raise CalendarError(f"Error buscando eventos: {e}")
    
    def _parse_datetime(self, datetime_str: str) -> datetime:
        """
        Parsear string de fecha/hora a objeto datetime
        
        Args:
            datetime_str: String de fecha/hora
            
        Returns:
            Objeto datetime
        """
        try:
            # Intentar varios formatos
            formats = [
                "%Y-%m-%d %H:%M",
                "%Y-%m-%d %H:%M:%S",
                "%d/%m/%Y %H:%M",
                "%d-%m-%Y %H:%M",
                "%Y-%m-%dT%H:%M:%S",
                "%Y-%m-%d"
            ]
            
            for fmt in formats:
                try:
                    dt = datetime.strptime(datetime_str, fmt)
                    # Asignar timezone si no tiene
                    if dt.tzinfo is None:
                        dt = pytz.timezone(self.default_timezone).localize(dt)
                    return dt
                except ValueError:
                    continue
            
            # Si ningún formato funciona, usar dateutil
            dt = parser.parse(datetime_str)
            if dt.tzinfo is None:
                dt = pytz.timezone(self.default_timezone).localize(dt)
            return dt
            
        except Exception as e:
            raise CalendarError(f"No se pudo parsear la fecha '{datetime_str}': {e}")
    
    def _format_datetime(self, dt: datetime) -> str:
        """
        Formatear datetime para mostrar
        
        Args:
            dt: Objeto datetime
            
        Returns:
            Fecha formateada
        """
        return dt.strftime("%d/%m/%Y %H:%M")
    
    def set_service(self, service) -> None:
        """
        Establecer servicio Calendar (llamado por el servidor MCP)
        
        Args:
            service: Servicio Calendar autenticado
        """
        self.service = service
        self.logger.info("Servicio Calendar configurado")
    
    async def health_check(self) -> Dict[str, Any]:
        """
        Verificar estado de salud de Calendar
        
        Returns:
            Estado de salud
        """
        try:
            if not self.service:
                return {
                    "status": "error",
                    "message": "Calendar service not configured"
                }
            
            # Test simple: obtener información del calendario principal
            calendar_info = self.service.calendars().get(calendarId='primary').execute()
            
            return {
                "status": "healthy",
                "message": "Calendar service responding",
                "calendar_name": calendar_info.get('summary', 'Principal'),
                "timezone": calendar_info.get('timeZone', 'unknown')
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Calendar health check failed: {str(e)}"
            }