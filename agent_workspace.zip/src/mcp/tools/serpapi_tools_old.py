"""
Herramientas de SerpAPI para búsqueda web, noticias y académica
"""

import asyncio
import aiohttp
import json
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

from ...core.config import get_settings
from ...core.logging_config import get_logger
from ...core.exceptions import SerpAPIError, ValidationError
from .base_tool import BaseTool


class SerpAPITools(BaseTool):
    """Herramientas de búsqueda usando SerpAPI"""
    
    def __init__(self):
        super().__init__()
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        self.api_key = self.settings.serpapi.api_key
        self.base_url = self.settings.serpapi.base_url
        self.timeout = self.settings.serpapi.timeout
        
        if not self.api_key:
            self.logger.warning("SerpAPI key no configurada")
        
        # Sesión HTTP
        self.session: Optional[aiohttp.ClientSession] = None
    
    async def initialize(self) -> None:
        """Inicializar cliente SerpAPI"""
        try:
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            self.session = aiohttp.ClientSession(timeout=timeout)
            
            # Verificar API key con una búsqueda simple
            if self.api_key:
                await self._test_connection()
            
            self.is_initialized = True
            self.logger.info("SerpAPI Tools inicializadas")
            
        except Exception as e:
            self.logger.error(f"Error inicializando SerpAPI: {e}")
            raise SerpAPIError(f"Failed to initialize SerpAPI: {e}")
    
    async def _test_connection(self) -> None:
        """Probar conexión con SerpAPI"""
        try:
            params = {
                "api_key": self.api_key,
                "engine": "google",
                "q": "test",
                "num": 1
            }
            
            async with self.session.get(self.base_url, params=params) as response:
                if response.status == 200:
                    self.logger.info("Conexión SerpAPI verificada")
                else:
                    raise SerpAPIError(f"SerpAPI connection test failed: {response.status}")
                    
        except Exception as e:
            self.logger.warning(f"No se pudo verificar SerpAPI: {e}")
    
    async def search(
        self,
        query: str,
        search_type: str = "web",
        region: str = "es",
        limit: int = 10
    ) -> str:
        """
        Realizar búsqueda general
        
        Args:
            query: Términos de búsqueda
            search_type: Tipo de búsqueda (web, news, scholar, images)
            region: Región para la búsqueda
            limit: Número máximo de resultados
        
        Returns:
            Resultados formateados
        """
        try:
            if not self.is_initialized:
                await self.initialize()
            
            if not query.strip():
                raise ValidationError("Query cannot be empty")
            
            # Mapear tipos de búsqueda
            engine_map = {
                "web": "google",
                "news": "google_news",
                "scholar": "google_scholar",
                "images": "google_images"
            }
            
            engine = engine_map.get(search_type, "google")
            
            # Realizar búsqueda específica
            if search_type == "news":
                return await self.search_news(query, region, "ultima_semana", limit)
            elif search_type == "scholar":
                return await self.search_scholar(query, limit=limit)
            elif search_type == "images":
                return await self.search_images(query, limit=limit)
            else:
                return await self.search_web(query, region, limit)
                
        except Exception as e:
            self.logger.error(f"Error en búsqueda general: {e}")
            raise SerpAPIError(f"Search failed: {e}")
    
    async def search_web(
        self,
        query: str,
        region: str = "es",
        limit: int = 10
    ) -> str:
        """Búsqueda web general"""
        try:
            params = {
                "api_key": self.api_key,
                "engine": "google",
                "q": query,
                "gl": region,
                "hl": "es" if region == "es" else "en",
                "num": min(limit, 20)  # SerpAPI limit
            }
            
            async with self.session.get(self.base_url, params=params) as response:
                if response.status != 200:
                    raise SerpAPIError(f"API request failed: {response.status}")
                
                data = await response.json()
                
                if "error" in data:
                    raise SerpAPIError(f"SerpAPI error: {data['error']}")
                
                return self._format_web_results(data, query)
                
        except Exception as e:
            self.logger.error(f"Error búsqueda web: {e}")
            raise SerpAPIError(f"Web search failed: {e}")
    
    async def search_news(
        self,
        query: str,
        region: str = "es",
        time_period: str = "ultima_semana",
        limit: int = 10
    ) -> str:
        """Búsqueda de noticias"""
        try:
            # Mapear períodos de tiempo
            time_map = {
                "ultima_hora": "h",
                "ultimo_dia": "d",
                "ultima_semana": "w",
                "ultimo_mes": "m",
                "ultimo_año": "y"
            }
            
            params = {
                "api_key": self.api_key,
                "engine": "google_news",
                "q": query,
                "gl": region,
                "hl": "es" if region == "es" else "en"
            }
            
            # Agregar filtro de tiempo si está disponible
            if time_period in time_map:
                params["tbs"] = f"qdr:{time_map[time_period]}"
            
            async with self.session.get(self.base_url, params=params) as response:
                if response.status != 200:
                    raise SerpAPIError(f"News API request failed: {response.status}")
                
                data = await response.json()
                
                if "error" in data:
                    raise SerpAPIError(f"SerpAPI error: {data['error']}")
                
                return self._format_news_results(data, query, limit)
                
        except Exception as e:
            self.logger.error(f"Error búsqueda noticias: {e}")
            raise SerpAPIError(f"News search failed: {e}")
    
    async def search_scholar(
        self,
        query: str,
        year_from: Optional[int] = None,
        author: Optional[str] = None,
        limit: int = 10
    ) -> str:
        """Búsqueda académica en Google Scholar"""
        try:
            params = {
                "api_key": self.api_key,
                "engine": "google_scholar",
                "q": query,
                "hl": "es"
            }
            
            # Filtros adicionales
            if year_from:
                params["as_ylo"] = year_from
            
            if author:
                params["as_sdt"] = "1,5"  # Include patents and citations
                params["as_vis"] = "1"    # Include citations
                params["q"] = f'author:"{author}" {query}'
            
            async with self.session.get(self.base_url, params=params) as response:
                if response.status != 200:
                    raise SerpAPIError(f"Scholar API request failed: {response.status}")
                
                data = await response.json()
                
                if "error" in data:
                    raise SerpAPIError(f"SerpAPI error: {data['error']}")
                
                return self._format_scholar_results(data, query, limit)
                
        except Exception as e:
            self.logger.error(f"Error búsqueda académica: {e}")
            raise SerpAPIError(f"Scholar search failed: {e}")
    
    async def search_images(
        self,
        query: str,
        limit: int = 10
    ) -> str:
        """Búsqueda de imágenes"""
        try:
            params = {
                "api_key": self.api_key,
                "engine": "google_images",
                "q": query,
                "hl": "es"
            }
            
            async with self.session.get(self.base_url, params=params) as response:
                if response.status != 200:
                    raise SerpAPIError(f"Images API request failed: {response.status}")
                
                data = await response.json()
                
                if "error" in data:
                    raise SerpAPIError(f"SerpAPI error: {data['error']}")
                
                return self._format_image_results(data, query, limit)
                
        except Exception as e:
            self.logger.error(f"Error búsqueda imágenes: {e}")
            raise SerpAPIError(f"Image search failed: {e}")
    
    def _format_web_results(self, data: Dict, query: str) -> str:
        """Formatear resultados de búsqueda web"""
        try:
            results = []
            results.append(f"🔍 **Resultados de búsqueda para: '{query}'**\n")
            
            # Información general
            if "search_information" in data:
                search_info = data["search_information"]
                if "total_results" in search_info:
                    results.append(f"📊 Total de resultados: {search_info['total_results']}")
                if "time_taken_displayed" in search_info:
                    results.append(f"⏱️ Tiempo: {search_info['time_taken_displayed']}\n")
            
            # Resultados orgánicos
            if "organic_results" in data:
                results.append("## 📋 Resultados principales:")
                
                for i, result in enumerate(data["organic_results"][:10], 1):
                    title = result.get("title", "Sin título")
                    link = result.get("link", "")
                    snippet = result.get("snippet", "Sin descripción")
                    
                    results.append(f"\n**{i}. {title}**")
                    results.append(f"🔗 {link}")
                    results.append(f"📝 {snippet}")
            
            # Respuesta directa si existe
            if "answer_box" in data:
                answer = data["answer_box"]
                if "answer" in answer:
                    results.insert(1, f"💡 **Respuesta directa:** {answer['answer']}\n")
            
            # Knowledge graph
            if "knowledge_graph" in data:
                kg = data["knowledge_graph"]
                if "description" in kg:
                    results.insert(1, f"📚 **Información:** {kg['description']}\n")
            
            return "\n".join(results)
            
        except Exception as e:
            self.logger.error(f"Error formateando resultados web: {e}")
            return f"Error formateando resultados: {e}"
    
    def _format_news_results(self, data: Dict, query: str, limit: int) -> str:
        """Formatear resultados de noticias"""
        try:
            results = []
            results.append(f"📰 **Noticias sobre: '{query}'**\n")
            
            if "news_results" in data:
                results.append("## 🗞️ Noticias recientes:")
                
                for i, news in enumerate(data["news_results"][:limit], 1):
                    title = news.get("title", "Sin título")
                    source = news.get("source", "Fuente desconocida")
                    date = news.get("date", "Fecha no disponible")
                    link = news.get("link", "")
                    snippet = news.get("snippet", "")
                    
                    results.append(f"\n**{i}. {title}**")
                    results.append(f"📅 {date} | 📰 {source}")
                    if link:
                        results.append(f"🔗 {link}")
                    if snippet:
                        results.append(f"📝 {snippet}")
            
            return "\n".join(results)
            
        except Exception as e:
            self.logger.error(f"Error formateando noticias: {e}")
            return f"Error formateando noticias: {e}"
    
    def _format_scholar_results(self, data: Dict, query: str, limit: int) -> str:
        """Formatear resultados académicos"""
        try:
            results = []
            results.append(f"🎓 **Artículos académicos sobre: '{query}'**\n")
            
            if "organic_results" in data:
                results.append("## 📚 Publicaciones académicas:")
                
                for i, paper in enumerate(data["organic_results"][:limit], 1):
                    title = paper.get("title", "Sin título")
                    authors = ", ".join(paper.get("publication_info", {}).get("authors", []))
                    year = paper.get("publication_info", {}).get("year", "")
                    cited_by = paper.get("inline_links", {}).get("cited_by", {}).get("total", 0)
                    link = paper.get("link", "")
                    snippet = paper.get("snippet", "")
                    
                    results.append(f"\n**{i}. {title}**")
                    if authors:
                        results.append(f"👥 Autores: {authors}")
                    if year:
                        results.append(f"📅 Año: {year}")
                    if cited_by:
                        results.append(f"📊 Citado por: {cited_by}")
                    if link:
                        results.append(f"🔗 {link}")
                    if snippet:
                        results.append(f"📝 {snippet}")
            
            return "\n".join(results)
            
        except Exception as e:
            self.logger.error(f"Error formateando resultados académicos: {e}")
            return f"Error formateando resultados académicos: {e}"
    
    def _format_image_results(self, data: Dict, query: str, limit: int) -> str:
        """Formatear resultados de imágenes"""
        try:
            results = []
            results.append(f"🖼️ **Imágenes para: '{query}'**\n")
            
            if "images_results" in data:
                results.append("## 🎨 Imágenes encontradas:")
                
                for i, image in enumerate(data["images_results"][:limit], 1):
                    title = image.get("title", f"Imagen {i}")
                    source = image.get("source", "Fuente desconocida")
                    original = image.get("original", "")
                    thumbnail = image.get("thumbnail", "")
                    
                    results.append(f"\n**{i}. {title}**")
                    results.append(f"📷 Fuente: {source}")
                    if original:
                        results.append(f"🔗 Original: {original}")
                    if thumbnail:
                        results.append(f"🖼️ Miniatura: {thumbnail}")
            
            return "\n".join(results)
            
        except Exception as e:
            self.logger.error(f"Error formateando imágenes: {e}")
            return f"Error formateando imágenes: {e}"
    
    async def health_check(self) -> str:
        """Verificar estado de SerpAPI"""
        try:
            if not self.api_key:
                return "no_api_key"
            
            if not self.session:
                return "not_initialized"
            
            # Test simple
            await self._test_connection()
            return "healthy"
            
        except Exception as e:
            return f"error: {str(e)}"
    
    async def close(self) -> None:
        """Cerrar sesión HTTP"""
        try:
            if self.session and not self.session.closed:
                await self.session.close()
            self.logger.info("SerpAPI Tools cerradas")
        except Exception as e:
            self.logger.error(f"Error cerrando SerpAPI: {e}")
