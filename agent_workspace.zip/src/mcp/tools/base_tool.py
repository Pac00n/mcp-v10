"""
Clase base para todas las herramientas MCP
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any

from ...core.logging_config import get_logger


class BaseTool(ABC):
    """
    Clase base abstracta para todas las herramientas MCP
    """
    
    def __init__(self, tool_name: str):
        self.tool_name = tool_name
        self.logger = get_logger(f"{__name__}.{tool_name}")
        self.is_initialized = False
        self._stats = {
            "calls": 0,
            "successes": 0,
            "errors": 0
        }
    
    async def initialize(self) -> None:
        """
        Inicializar la herramienta (opcional de implementar)
        """
        self.is_initialized = True
        self.logger.info(f"{self.tool_name} tool initialized")
    
    def _record_call(self, success: bool = True) -> None:
        """
        Registrar estadísticas de llamada
        
        Args:
            success: Si la llamada fue exitosa
        """
        self._stats["calls"] += 1
        if success:
            self._stats["successes"] += 1
        else:
            self._stats["errors"] += 1
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Obtener estadísticas de la herramienta
        
        Returns:
            Diccionario con estadísticas
        """
        success_rate = 0
        if self._stats["calls"] > 0:
            success_rate = (self._stats["successes"] / self._stats["calls"]) * 100
        
        return {
            "tool_name": self.tool_name,
            "total_calls": self._stats["calls"],
            "successes": self._stats["successes"],
            "errors": self._stats["errors"],
            "success_rate": round(success_rate, 2),
            "is_initialized": self.is_initialized
        }
    
    async def health_check(self) -> Dict[str, Any]:
        """
        Verificar estado de salud de la herramienta
        
        Returns:
            Estado de salud
        """
        return {
            "status": "healthy" if self.is_initialized else "not_initialized",
            "tool_name": self.tool_name,
            "stats": self.get_stats()
        }
    
    def __str__(self) -> str:
        return f"{self.tool_name}Tool(initialized={self.is_initialized})"
    
    def __repr__(self) -> str:
        return self.__str__()