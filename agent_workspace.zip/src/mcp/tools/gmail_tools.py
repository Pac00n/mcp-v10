"""
Herramientas de Gmail para gestión de email
"""

import asyncio
import base64
import json
from typing import Dict, List, Optional, Any
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

from ...core.config import get_settings
from ...core.logging_config import get_logger, performance_logger
from ...core.exceptions import GmailError
from .base_tool import BaseTool


class GmailTools(BaseTool):
    """
    Herramientas para gestión de Gmail
    """
    
    def __init__(self):
        super().__init__("Gmail")
        self.settings = get_settings()
        
        # El servicio se obtendrá a través del OAuthManager
        self.service = None
        
        self.logger.info("GmailTools inicializado")
    
    async def execute_action(
        self,
        action: str,
        recipient: str = None,
        subject: str = None,
        body: str = None,
        search_query: str = None,
        email_id: str = None,
        max_results: int = 10,
        **kwargs
    ) -> str:
        """
        Ejecutar acción de Gmail
        
        Args:
            action: Acción a realizar (enviar, buscar, leer, listar, marcar_leido)
            recipient: Destinatario del email
            subject: Asunto del email
            body: Cuerpo del email
            search_query: Query para buscar emails
            email_id: ID del email
            max_results: Máximo número de resultados
            
        Returns:
            Resultado de la acción
        """
        start_time = asyncio.get_event_loop().time()
        
        try:
            # El servicio debe ser pasado por el servidor MCP
            if not self.service:
                raise GmailError("Gmail service not available. Check OAuth authentication.")
            
            result = ""
            
            if action == "enviar":
                result = await self._send_email(recipient, subject, body)
            elif action == "buscar":
                result = await self._search_emails(search_query, max_results)
            elif action == "leer":
                result = await self._read_email(email_id)
            elif action == "listar":
                result = await self._list_emails(max_results)
            elif action == "marcar_leido":
                result = await self._mark_as_read(email_id)
            else:
                raise GmailError(f"Acción no soportada: {action}")
            
            # Log de rendimiento
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("gmail_action", duration, True)
            
            self._record_call(success=True)
            return result
            
        except Exception as e:
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("gmail_action", duration, False)
            
            self._record_call(success=False)
            self.logger.error(f"Error en acción Gmail {action}: {e}")
            raise GmailError(f"Gmail action '{action}' failed: {e}")
    
    async def _send_email(self, recipient: str, subject: str, body: str) -> str:
        """
        Enviar email
        
        Args:
            recipient: Destinatario
            subject: Asunto
            body: Cuerpo del mensaje
            
        Returns:
            Confirmación del envío
        """
        try:
            if not all([recipient, subject, body]):
                raise GmailError("Destinatario, asunto y cuerpo son requeridos para enviar email")
            
            # Crear mensaje
            message = MIMEText(body)
            message['to'] = recipient
            message['subject'] = subject
            
            # Codificar mensaje
            raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
            
            # Enviar
            result = self.service.users().messages().send(
                userId='me',
                body={'raw': raw_message}
            ).execute()
            
            return f"✅ Email enviado correctamente a {recipient}\n📧 ID del mensaje: {result['id']}"
            
        except Exception as e:
            raise GmailError(f"Error enviando email: {e}")
    
    async def _search_emails(self, query: str, max_results: int) -> str:
        """
        Buscar emails
        
        Args:
            query: Query de búsqueda
            max_results: Máximo de resultados
            
        Returns:
            Lista de emails encontrados
        """
        try:
            if not query:
                raise GmailError("Query de búsqueda es requerida")
            
            # Buscar emails
            result = self.service.users().messages().list(
                userId='me',
                q=query,
                maxResults=min(max_results, 50)  # Máximo 50
            ).execute()
            
            if 'messages' not in result:
                return f"📭 No se encontraron emails para: '{query}'"
            
            messages = result['messages']
            formatted = f"📧 **Emails encontrados ({len(messages)}) para '{query}':**\n\n"
            
            for i, msg in enumerate(messages, 1):
                # Obtener detalles del mensaje
                msg_detail = self.service.users().messages().get(
                    userId='me',
                    id=msg['id'],
                    format='metadata',
                    metadataHeaders=['Subject', 'From', 'Date']
                ).execute()
                
                headers = msg_detail['payload']['headers']
                subject = self._get_header_value(headers, 'Subject') or 'Sin asunto'
                sender = self._get_header_value(headers, 'From') or 'Desconocido'
                date = self._get_header_value(headers, 'Date') or 'Sin fecha'
                
                # Formatear fecha si es posible
                formatted_date = self._format_date(date)
                
                formatted += f"**{i}. {subject}**\n"
                formatted += f"👤 De: {sender}\n"
                formatted += f"📅 Fecha: {formatted_date}\n"
                formatted += f"🆔 ID: {msg['id']}\n\n"
            
            return formatted
            
        except Exception as e:
            raise GmailError(f"Error buscando emails: {e}")
    
    async def _read_email(self, email_id: str) -> str:
        """
        Leer email completo
        
        Args:
            email_id: ID del email
            
        Returns:
            Contenido completo del email
        """
        try:
            if not email_id:
                raise GmailError("ID del email es requerido")
            
            # Obtener email completo
            message = self.service.users().messages().get(
                userId='me',
                id=email_id,
                format='full'
            ).execute()
            
            # Extraer headers
            headers = message['payload']['headers']
            subject = self._get_header_value(headers, 'Subject') or 'Sin asunto'
            sender = self._get_header_value(headers, 'From') or 'Desconocido'
            date = self._get_header_value(headers, 'Date') or 'Sin fecha'
            to = self._get_header_value(headers, 'To') or 'Desconocido'
            
            # Extraer cuerpo del mensaje
            body = self._extract_message_body(message['payload'])
            
            # Formatear respuesta
            formatted = f"📧 **Email Completo**\n\n"
            formatted += f"**Asunto:** {subject}\n"
            formatted += f"**De:** {sender}\n"
            formatted += f"**Para:** {to}\n"
            formatted += f"**Fecha:** {self._format_date(date)}\n"
            formatted += f"**ID:** {email_id}\n\n"
            formatted += "**Contenido:**\n"
            formatted += "─" * 50 + "\n"
            formatted += body
            formatted += "\n" + "─" * 50
            
            return formatted
            
        except Exception as e:
            raise GmailError(f"Error leyendo email: {e}")
    
    async def _list_emails(self, max_results: int) -> str:
        """
        Listar emails recientes
        
        Args:
            max_results: Máximo de emails a listar
            
        Returns:
            Lista de emails recientes
        """
        try:
            # Listar emails recientes
            result = self.service.users().messages().list(
                userId='me',
                maxResults=min(max_results, 20),  # Máximo 20 para listar
                labelIds=['INBOX']
            ).execute()
            
            if 'messages' not in result:
                return "📭 No hay emails en la bandeja de entrada"
            
            messages = result['messages']
            formatted = f"📥 **Emails recientes en bandeja de entrada ({len(messages)}):**\n\n"
            
            for i, msg in enumerate(messages, 1):
                # Obtener detalles del mensaje
                msg_detail = self.service.users().messages().get(
                    userId='me',
                    id=msg['id'],
                    format='metadata',
                    metadataHeaders=['Subject', 'From', 'Date']
                ).execute()
                
                headers = msg_detail['payload']['headers']
                subject = self._get_header_value(headers, 'Subject') or 'Sin asunto'
                sender = self._get_header_value(headers, 'From') or 'Desconocido'
                date = self._get_header_value(headers, 'Date') or 'Sin fecha'
                
                # Verificar si está leído
                labels = msg_detail.get('labelIds', [])
                is_unread = 'UNREAD' in labels
                status_icon = "🆕" if is_unread else "📖"
                
                formatted += f"{status_icon} **{i}. {subject}**\n"
                formatted += f"👤 De: {sender}\n"
                formatted += f"📅 {self._format_date(date)}\n"
                formatted += f"🆔 ID: {msg['id']}\n\n"
            
            return formatted
            
        except Exception as e:
            raise GmailError(f"Error listando emails: {e}")
    
    async def _mark_as_read(self, email_id: str) -> str:
        """
        Marcar email como leído
        
        Args:
            email_id: ID del email
            
        Returns:
            Confirmación
        """
        try:
            if not email_id:
                raise GmailError("ID del email es requerido")
            
            # Marcar como leído (remover etiqueta UNREAD)
            self.service.users().messages().modify(
                userId='me',
                id=email_id,
                body={'removeLabelIds': ['UNREAD']}
            ).execute()
            
            return f"✅ Email {email_id} marcado como leído"
            
        except Exception as e:
            raise GmailError(f"Error marcando email como leído: {e}")
    
    def _get_header_value(self, headers: List[Dict], name: str) -> Optional[str]:
        """
        Obtener valor de header por nombre
        
        Args:
            headers: Lista de headers
            name: Nombre del header
            
        Returns:
            Valor del header o None
        """
        for header in headers:
            if header['name'].lower() == name.lower():
                return header['value']
        return None
    
    def _extract_message_body(self, payload: Dict) -> str:
        """
        Extraer cuerpo del mensaje desde payload
        
        Args:
            payload: Payload del mensaje
            
        Returns:
            Cuerpo del mensaje
        """
        try:
            # Si es un mensaje simple
            if payload.get('body', {}).get('data'):
                return base64.urlsafe_b64decode(
                    payload['body']['data']
                ).decode('utf-8')
            
            # Si es un mensaje con partes múltiples
            if 'parts' in payload:
                for part in payload['parts']:
                    if part.get('mimeType') == 'text/plain':
                        if part.get('body', {}).get('data'):
                            return base64.urlsafe_b64decode(
                                part['body']['data']
                            ).decode('utf-8')
                    
                    # Recursivo para partes anidadas
                    if 'parts' in part:
                        body = self._extract_message_body(part)
                        if body:
                            return body
            
            return "No se pudo extraer el contenido del mensaje"
            
        except Exception as e:
            return f"Error extrayendo contenido: {str(e)}"
    
    def _format_date(self, date_str: str) -> str:
        """
        Formatear fecha para mejor legibilidad
        
        Args:
            date_str: Fecha como string
            
        Returns:
            Fecha formateada
        """
        try:
            # Intentar parsear la fecha
            from email.utils import parsedate_to_datetime
            dt = parsedate_to_datetime(date_str)
            
            # Formatear a español
            return dt.strftime("%d/%m/%Y %H:%M")
            
        except:
            # Si no se puede parsear, devolver original
            return date_str
    
    def set_service(self, service) -> None:
        """
        Establecer servicio Gmail (llamado por el servidor MCP)
        
        Args:
            service: Servicio Gmail autenticado
        """
        self.service = service
        self.logger.info("Servicio Gmail configurado")
    
    async def health_check(self) -> Dict[str, Any]:
        """
        Verificar estado de salud de Gmail
        
        Returns:
            Estado de salud
        """
        try:
            if not self.service:
                return {
                    "status": "error",
                    "message": "Gmail service not configured"
                }
            
            # Test simple: obtener perfil del usuario
            profile = self.service.users().getProfile(userId='me').execute()
            
            return {
                "status": "healthy",
                "message": "Gmail service responding",
                "email_address": profile.get('emailAddress', 'unknown'),
                "total_messages": profile.get('messagesTotal', 0)
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Gmail health check failed: {str(e)}"
            }