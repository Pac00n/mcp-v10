"""
Herramientas de análisis de texto y datos
"""

import asyncio
import re
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from enum import Enum

from ...core.config import get_settings
from ...core.logging_config import get_logger, performance_logger
from ...core.exceptions import AnalyticsError
from .base_tool import BaseTool


class SentimentLevel(Enum):
    """Niveles de sentimiento"""
    VERY_POSITIVE = "muy_positivo"
    POSITIVE = "positivo"
    NEUTRAL = "neutral"
    NEGATIVE = "negativo"
    VERY_NEGATIVE = "muy_negativo"


@dataclass
class SentimentResult:
    """Resultado de análisis de sentimiento"""
    sentiment: SentimentLevel
    confidence: float
    positive_score: float
    negative_score: float
    neutral_score: float


@dataclass
class Entity:
    """Entidad detectada en el texto"""
    text: str
    entity_type: str
    confidence: float


class AnalyticsTools(BaseTool):
    """
    Herramientas de análisis de texto y sentimiento
    """
    
    def __init__(self):
        super().__init__("Analytics")
        self.settings = get_settings()
        
        # Palabras clave para análisis de sentimiento
        self.positive_words = {
            "español": [
                "excelente", "bueno", "genial", "fantástico", "perfecto", "maravilloso",
                "increíble", "fabuloso", "estupendo", "magnífico", "extraordinario",
                "éxito", "triunfo", "victoria", "logro", "alegría", "felicidad",
                "amor", "paz", "esperanza", "satisfacción", "gratitud", "optimista",
                "positivo", "brillante", "glorioso", "hermoso", "encantador"
            ],
            "english": [
                "excellent", "good", "great", "fantastic", "perfect", "wonderful",
                "amazing", "fabulous", "awesome", "magnificent", "extraordinary",
                "success", "triumph", "victory", "achievement", "joy", "happiness",
                "love", "peace", "hope", "satisfaction", "gratitude", "optimistic",
                "positive", "brilliant", "glorious", "beautiful", "charming"
            ]
        }
        
        self.negative_words = {
            "español": [
                "horrible", "malo", "terrible", "pésimo", "desastroso", "espantoso",
                "desesperante", "frustrante", "irritante", "molesto", "fastidioso",
                "fracaso", "derrota", "pérdida", "tristeza", "depresión", "ansiedad",
                "odio", "ira", "miedo", "preocupación", "estrés", "pesimista",
                "negativo", "oscuro", "sombrío", "feo", "repugnante"
            ],
            "english": [
                "horrible", "bad", "terrible", "awful", "disastrous", "dreadful",
                "hopeless", "frustrating", "irritating", "annoying", "bothersome",
                "failure", "defeat", "loss", "sadness", "depression", "anxiety",
                "hate", "anger", "fear", "worry", "stress", "pessimistic",
                "negative", "dark", "gloomy", "ugly", "disgusting"
            ]
        }
        
        # Tipos de entidades reconocibles
        self.entity_patterns = {
            "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            "url": r'https?://(?:[-\w.])+(?:[:\d]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:\w*))?)?',
            "teléfono": r'(\+?[\d\s\-\(\)]{9,15})',
            "fecha": r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b',
            "dinero": r'[\$€£¥]\s?\d+(?:\.\d{2})?|\d+(?:\.\d{2})?\s?(?:euros?|dólares?|libras?)'
        }
        
        self.logger.info("AnalyticsTools inicializado")
    
    async def analyze_sentiment(
        self,
        text: str,
        language: str = "es",
        include_entities: bool = False
    ) -> str:
        """
        Analizar sentimiento de un texto
        
        Args:
            text: Texto a analizar
            language: Idioma del texto
            include_entities: Si incluir análisis de entidades
            
        Returns:
            Análisis de sentimiento formateado
        """
        start_time = asyncio.get_event_loop().time()
        
        try:
            if not text or not text.strip():
                raise AnalyticsError("Texto vacío o no válido")
            
            # Análisis de sentimiento
            sentiment_result = await self._analyze_text_sentiment(text, language)
            
            # Análisis de entidades si se solicita
            entities = []
            if include_entities:
                entities = await self._extract_entities(text)
            
            # Formatear resultado
            result = await self._format_sentiment_result(text, sentiment_result, entities, language)
            
            # Log de rendimiento
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("sentiment_analysis", duration, True)
            
            self._record_call(success=True)
            return result
            
        except Exception as e:
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("sentiment_analysis", duration, False)
            
            self._record_call(success=False)
            self.logger.error(f"Error en análisis de sentimiento: {e}")
            raise AnalyticsError(f"Sentiment analysis failed: {e}")
    
    async def generate_summary(
        self,
        content: str,
        length: str = "medio",
        style: str = "neutro",
        language: str = "es"
    ) -> str:
        """
        Generar resumen del contenido
        
        Args:
            content: Contenido a resumir
            length: Longitud del resumen (corto, medio, largo)
            style: Estilo del resumen (neutro, formal, casual)
            language: Idioma de salida
            
        Returns:
            Resumen generado
        """
        start_time = asyncio.get_event_loop().time()
        
        try:
            if not content or not content.strip():
                raise AnalyticsError("Contenido vacío o no válido")
            
            # Generar resumen basado en reglas simples
            summary = await self._generate_extractive_summary(content, length, style, language)
            
            # Log de rendimiento
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("summary_generation", duration, True)
            
            self._record_call(success=True)
            return summary
            
        except Exception as e:
            duration = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("summary_generation", duration, False)
            
            self._record_call(success=False)
            self.logger.error(f"Error generando resumen: {e}")
            raise AnalyticsError(f"Summary generation failed: {e}")
    
    async def _analyze_text_sentiment(self, text: str, language: str) -> SentimentResult:
        """
        Analizar sentimiento del texto usando reglas simples
        
        Args:
            text: Texto a analizar
            language: Idioma del texto
            
        Returns:
            Resultado del análisis
        """
        # Normalizar texto
        text_lower = text.lower()
        words = re.findall(r'\b\w+\b', text_lower)
        
        # Seleccionar diccionarios según idioma
        lang_key = "español" if language == "es" else "english"
        positive_words = self.positive_words.get(lang_key, self.positive_words["español"])
        negative_words = self.negative_words.get(lang_key, self.negative_words["español"])
        
        # Contar palabras positivas y negativas
        positive_count = sum(1 for word in words if word in positive_words)
        negative_count = sum(1 for word in words if word in negative_words)
        
        total_sentiment_words = positive_count + negative_count
        total_words = len(words)
        
        if total_sentiment_words == 0:
            # Texto neutral
            return SentimentResult(
                sentiment=SentimentLevel.NEUTRAL,
                confidence=0.5,
                positive_score=0.0,
                negative_score=0.0,
                neutral_score=1.0
            )
        
        # Calcular scores
        positive_score = positive_count / total_words
        negative_score = negative_count / total_words
        neutral_score = max(0, 1.0 - positive_score - negative_score)
        
        # Determinar sentimiento
        if positive_score > negative_score:
            if positive_score > 0.1:
                sentiment = SentimentLevel.VERY_POSITIVE
            else:
                sentiment = SentimentLevel.POSITIVE
            confidence = min(0.9, positive_score * 5)
        elif negative_score > positive_score:
            if negative_score > 0.1:
                sentiment = SentimentLevel.VERY_NEGATIVE
            else:
                sentiment = SentimentLevel.NEGATIVE
            confidence = min(0.9, negative_score * 5)
        else:
            sentiment = SentimentLevel.NEUTRAL
            confidence = 0.5
        
        return SentimentResult(
            sentiment=sentiment,
            confidence=confidence,
            positive_score=positive_score,
            negative_score=negative_score,
            neutral_score=neutral_score
        )
    
    async def _extract_entities(self, text: str) -> List[Entity]:
        """
        Extraer entidades del texto usando regex
        
        Args:
            text: Texto a analizar
            
        Returns:
            Lista de entidades encontradas
        """
        entities = []
        
        for entity_type, pattern in self.entity_patterns.items():
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                entities.append(Entity(
                    text=match.group(),
                    entity_type=entity_type,
                    confidence=0.8  # Confianza fija para regex
                ))
        
        return entities
    
    async def _format_sentiment_result(
        self,
        text: str,
        sentiment: SentimentResult,
        entities: List[Entity],
        language: str
    ) -> str:
        """
        Formatear resultado del análisis de sentimiento
        
        Args:
            text: Texto original
            sentiment: Resultado del sentimiento
            entities: Entidades encontradas
            language: Idioma
            
        Returns:
            Resultado formateado
        """
        # Mapeo de sentimientos a emoji y texto
        sentiment_mapping = {
            SentimentLevel.VERY_POSITIVE: ("😍", "Muy Positivo"),
            SentimentLevel.POSITIVE: ("😊", "Positivo"),
            SentimentLevel.NEUTRAL: ("😐", "Neutral"),
            SentimentLevel.NEGATIVE: ("😞", "Negativo"),
            SentimentLevel.VERY_NEGATIVE: ("😡", "Muy Negativo"),
        }
        
        emoji, sentiment_text = sentiment_mapping[sentiment.sentiment]
        
        # Crear resultado formateado
        result = f"📊 **Análisis de Sentimiento**\n\n"
        result += f"**Texto analizado:** {text[:100]}{'...' if len(text) > 100 else ''}\n\n"
        result += f"**Resultado:** {emoji} {sentiment_text}\n"
        result += f"**Confianza:** {sentiment.confidence:.1%}\n\n"
        
        result += "**Puntuaciones detalladas:**\n"
        result += f"• Positivo: {sentiment.positive_score:.1%}\n"
        result += f"• Negativo: {sentiment.negative_score:.1%}\n"
        result += f"• Neutral: {sentiment.neutral_score:.1%}\n"
        
        if entities:
            result += f"\n**Entidades detectadas ({len(entities)}):**\n"
            entity_groups = {}
            for entity in entities:
                if entity.entity_type not in entity_groups:
                    entity_groups[entity.entity_type] = []
                entity_groups[entity.entity_type].append(entity.text)
            
            for entity_type, texts in entity_groups.items():
                result += f"• {entity_type.title()}: {', '.join(set(texts))}\n"
        
        return result
    
    async def _generate_extractive_summary(
        self,
        content: str,
        length: str,
        style: str,
        language: str
    ) -> str:
        """
        Generar resumen extractivo simple
        
        Args:
            content: Contenido a resumir
            length: Longitud deseada
            style: Estilo del resumen
            language: Idioma
            
        Returns:
            Resumen generado
        """
        # Dividir en oraciones
        sentences = re.split(r'[.!?]+', content)
        sentences = [s.strip() for s in sentences if s.strip()]
        
        if not sentences:
            return "No se pudo generar resumen: contenido no válido"
        
        # Determinar número de oraciones según longitud
        length_mapping = {
            "corto": min(2, len(sentences)),
            "medio": min(4, len(sentences)),
            "largo": min(6, len(sentences))
        }
        
        num_sentences = length_mapping.get(length, length_mapping["medio"])
        
        # Seleccionar oraciones (simple: primeras N oraciones)
        selected_sentences = sentences[:num_sentences]
        
        # Formatear según estilo
        if style == "formal":
            summary = ". ".join(selected_sentences) + "."
            prefix = "**Resumen ejecutivo:**\n\n"
        elif style == "casual":
            summary = ". ".join(selected_sentences) + "."
            prefix = "**En resumen:**\n\n"
        else:  # neutro
            summary = ". ".join(selected_sentences) + "."
            prefix = "**Resumen:**\n\n"
        
        # Estadísticas
        word_count_original = len(content.split())
        word_count_summary = len(summary.split())
        compression_ratio = (1 - word_count_summary / word_count_original) * 100
        
        result = f"📄 **Generación de Resumen**\n\n"
        result += prefix + summary + "\n\n"
        result += f"**Estadísticas:**\n"
        result += f"• Texto original: {word_count_original} palabras\n"
        result += f"• Resumen: {word_count_summary} palabras\n"
        result += f"• Compresión: {compression_ratio:.1f}%\n"
        result += f"• Oraciones seleccionadas: {len(selected_sentences)}/{len(sentences)}"
        
        return result
    
    async def analyze_text_stats(self, text: str) -> str:
        """
        Generar estadísticas básicas del texto
        
        Args:
            text: Texto a analizar
            
        Returns:
            Estadísticas formateadas
        """
        try:
            if not text or not text.strip():
                return "❌ Texto vacío o no válido"
            
            # Estadísticas básicas
            char_count = len(text)
            char_count_no_spaces = len(text.replace(" ", ""))
            word_count = len(text.split())
            sentence_count = len(re.split(r'[.!?]+', text))
            paragraph_count = len([p for p in text.split('\n\n') if p.strip()])
            
            # Palabras únicas
            words = re.findall(r'\b\w+\b', text.lower())
            unique_words = len(set(words))
            
            # Longitud promedio de palabras
            avg_word_length = sum(len(word) for word in words) / len(words) if words else 0
            
            # Formatear resultado
            result = f"📈 **Estadísticas del Texto**\n\n"
            result += f"**Conteo:**\n"
            result += f"• Caracteres: {char_count:,}\n"
            result += f"• Caracteres (sin espacios): {char_count_no_spaces:,}\n"
            result += f"• Palabras: {word_count:,}\n"
            result += f"• Palabras únicas: {unique_words:,}\n"
            result += f"• Oraciones: {sentence_count:,}\n"
            result += f"• Párrafos: {paragraph_count:,}\n\n"
            
            result += f"**Métricas:**\n"
            result += f"• Longitud promedio de palabra: {avg_word_length:.1f} caracteres\n"
            result += f"• Palabras por oración: {word_count/max(sentence_count, 1):.1f}\n"
            result += f"• Diversidad léxica: {unique_words/max(word_count, 1):.1%}\n"
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error analizando estadísticas: {e}")
            return f"❌ Error analizando estadísticas: {str(e)}"
    
    async def health_check(self) -> Dict[str, Any]:
        """
        Verificar estado de salud de Analytics
        
        Returns:
            Estado de salud
        """
        try:
            # Test simple de análisis
            test_text = "Este es un texto de prueba para verificar el funcionamiento."
            sentiment = await self._analyze_text_sentiment(test_text, "es")
            
            return {
                "status": "healthy",
                "message": "Analytics tools responding correctly",
                "test_sentiment": sentiment.sentiment.value,
                "supported_languages": ["es", "en"]
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Analytics health check failed: {str(e)}"
            }