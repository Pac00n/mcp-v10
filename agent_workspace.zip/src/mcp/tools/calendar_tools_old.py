"""
Herramientas de Google Calendar para gestión de eventos
"""

import asyncio
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Any
import pytz

from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

from ...core.config import get_settings
from ...core.logging_config import get_logger
from ...core.exceptions import CalendarError, ValidationError
from .base_tool import BaseTool
from ..auth.oauth_manager import OAuthManager


class CalendarTools(BaseTool):
    """Herramientas de gestión de Google Calendar"""
    
    def __init__(self):
        super().__init__()
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        self.oauth_manager = OAuthManager()
        self.service = None
        self.primary_calendar_id = 'primary'
        self.timezone = 'Europe/Madrid'  # Timezone por defecto
    
    async def initialize(self) -> None:
        """Inicializar cliente Google Calendar"""
        try:
            # Autenticar con Google OAuth
            credentials = await self.oauth_manager.get_credentials()
            
            if not credentials:
                self.logger.warning("No hay credenciales de Calendar disponibles")
                return
            
            # Crear servicio Calendar
            self.service = build('calendar', 'v3', credentials=credentials)
            
            # Verificar acceso obteniendo información del calendario
            try:
                calendar_info = self.service.calendars().get(calendarId=self.primary_calendar_id).execute()
                self.logger.info(f"Calendar inicializado: {calendar_info.get('summary', 'Principal')}")
            except Exception as e:
                self.logger.warning(f"No se pudo obtener info del calendario: {e}")
            
            self.is_initialized = True
            self.logger.info("Calendar Tools inicializadas")
            
        except Exception as e:
            self.logger.error(f"Error inicializando Calendar: {e}")
            raise CalendarError(f"Failed to initialize Calendar: {e}")
    
    async def create_event(
        self,
        title: str,
        date: str,
        time: str,
        duration_minutes: int = 60,
        description: Optional[str] = None,
        location: Optional[str] = None,
        attendees: Optional[List[str]] = None,
        calendar_id: str = 'primary'
    ) -> str:
        """
        Crear evento en calendario
        
        Args:
            title: Título del evento
            date: Fecha del evento (YYYY-MM-DD)
            time: Hora del evento (HH:MM)
            duration_minutes: Duración en minutos
            description: Descripción del evento
            location: Ubicación del evento
            attendees: Lista de emails de asistentes
            calendar_id: ID del calendario
        
        Returns:
            Resultado de la creación
        """
        try:
            self._ensure_initialized()
            
            # Validar parámetros
            self._validate_params({"title": title, "date": date, "time": time}, ["title", "date", "time"])
            
            # Parsear fecha y hora
            start_datetime = self._parse_datetime(date, time)
            end_datetime = start_datetime + timedelta(minutes=duration_minutes)
            
            # Crear evento
            event = {
                'summary': title,
                'start': {
                    'dateTime': start_datetime.isoformat(),
                    'timeZone': self.timezone,
                },
                'end': {
                    'dateTime': end_datetime.isoformat(),
                    'timeZone': self.timezone,
                },
            }
            
            # Agregar campos opcionales
            if description:
                event['description'] = description
            
            if location:
                event['location'] = location
            
            if attendees:
                event['attendees'] = [{'email': email} for email in attendees]
                event['sendUpdates'] = 'all'  # Enviar invitaciones
            
            # Crear evento en Calendar
            created_event = self.service.events().insert(
                calendarId=calendar_id, 
                body=event
            ).execute()
            
            event_id = created_event.get('id')
            event_link = created_event.get('htmlLink')
            
            self.logger.info(f"Evento creado exitosamente: {event_id}")
            
            result = f"📅 **Evento creado exitosamente**\n\n"
            result += f"**Título:** {title}\n"
            result += f"**Fecha:** {date}\n"
            result += f"**Hora:** {time}\n"
            result += f"**Duración:** {duration_minutes} minutos\n"
            result += f"**ID del evento:** {event_id}\n"
            
            if description:
                result += f"**Descripción:** {description}\n"
            if location:
                result += f"**Ubicación:** {location}\n"
            if attendees:
                result += f"**Asistentes:** {', '.join(attendees)}\n"
            if event_link:
                result += f"**Enlace:** {event_link}\n"
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error creando evento: {e}")
            return self.format_error_response(e, "creación de evento")
    
    async def list_events(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 10,
        calendar_id: str = 'primary'
    ) -> str:
        """
        Listar eventos del calendario
        
        Args:
            start_date: Fecha de inicio (YYYY-MM-DD)
            end_date: Fecha de fin (YYYY-MM-DD)
            limit: Número máximo de eventos
            calendar_id: ID del calendario
        
        Returns:
            Lista de eventos
        """
        try:
            self._ensure_initialized()
            
            # Configurar fechas
            if start_date:
                time_min = datetime.fromisoformat(f"{start_date}T00:00:00").replace(tzinfo=pytz.timezone(self.timezone)).isoformat()
            else:
                time_min = datetime.now(pytz.timezone(self.timezone)).isoformat()
            
            if end_date:
                time_max = datetime.fromisoformat(f"{end_date}T23:59:59").replace(tzinfo=pytz.timezone(self.timezone)).isoformat()
            else:
                time_max = (datetime.now(pytz.timezone(self.timezone)) + timedelta(days=30)).isoformat()
            
            # Obtener eventos
            events_result = self.service.events().list(
                calendarId=calendar_id,
                timeMin=time_min,
                timeMax=time_max,
                maxResults=limit,
                singleEvents=True,
                orderBy='startTime'
            ).execute()
            
            events = events_result.get('items', [])
            
            if not events:
                return "📅 No se encontraron eventos en el período especificado."
            
            result = f"📅 **Eventos del calendario ({len(events)}):**\n\n"
            
            for i, event in enumerate(events, 1):
                event_summary = self._format_event_summary(event, i)
                result += event_summary + "\n---\n"
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error listando eventos: {e}")
            return self.format_error_response(e, "listado de eventos")
    
    async def search_events(
        self,
        query: str,
        start_date: Optional[str] = None,
        limit: int = 10,
        calendar_id: str = 'primary'
    ) -> str:
        """
        Buscar eventos en el calendario
        
        Args:
            query: Términos de búsqueda
            start_date: Fecha de inicio para la búsqueda
            limit: Número máximo de eventos
            calendar_id: ID del calendario
        
        Returns:
            Eventos encontrados
        """
        try:
            self._ensure_initialized()
            
            if not query.strip():
                return "❌ La búsqueda requiere términos específicos."
            
            # Configurar fecha de inicio
            if start_date:
                time_min = datetime.fromisoformat(f"{start_date}T00:00:00").replace(tzinfo=pytz.timezone(self.timezone)).isoformat()
            else:
                time_min = (datetime.now(pytz.timezone(self.timezone)) - timedelta(days=30)).isoformat()
            
            # Buscar eventos
            events_result = self.service.events().list(
                calendarId=calendar_id,
                q=query,
                timeMin=time_min,
                maxResults=limit,
                singleEvents=True,
                orderBy='startTime'
            ).execute()
            
            events = events_result.get('items', [])
            
            if not events:
                return f"🔍 No se encontraron eventos que coincidan con '{query}'."
            
            result = f"🔍 **Eventos encontrados para '{query}' ({len(events)}):**\n\n"
            
            for i, event in enumerate(events, 1):
                event_summary = self._format_event_summary(event, i)
                result += event_summary + "\n---\n"
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error buscando eventos: {e}")
            return self.format_error_response(e, "búsqueda de eventos")
    
    async def get_event(
        self,
        event_id: str,
        calendar_id: str = 'primary'
    ) -> str:
        """
        Obtener detalles de un evento específico
        
        Args:
            event_id: ID del evento
            calendar_id: ID del calendario
        
        Returns:
            Detalles del evento
        """
        try:
            self._ensure_initialized()
            
            event = self.service.events().get(
                calendarId=calendar_id,
                eventId=event_id
            ).execute()
            
            return self._format_event_details(event)
            
        except Exception as e:
            self.logger.error(f"Error obteniendo evento: {e}")
            return self.format_error_response(e, "obtención de evento")
    
    async def update_event(
        self,
        event_id: str,
        title: Optional[str] = None,
        date: Optional[str] = None,
        time: Optional[str] = None,
        duration_minutes: Optional[int] = None,
        description: Optional[str] = None,
        location: Optional[str] = None,
        calendar_id: str = 'primary'
    ) -> str:
        """
        Actualizar evento existente
        
        Args:
            event_id: ID del evento
            title: Nuevo título
            date: Nueva fecha (YYYY-MM-DD)
            time: Nueva hora (HH:MM)
            duration_minutes: Nueva duración
            description: Nueva descripción
            location: Nueva ubicación
            calendar_id: ID del calendario
        
        Returns:
            Resultado de la actualización
        """
        try:
            self._ensure_initialized()
            
            # Obtener evento actual
            event = self.service.events().get(
                calendarId=calendar_id,
                eventId=event_id
            ).execute()
            
            # Actualizar campos modificados
            if title:
                event['summary'] = title
            
            if description is not None:
                event['description'] = description
            
            if location is not None:
                event['location'] = location
            
            if date and time:
                start_datetime = self._parse_datetime(date, time)
                
                if duration_minutes:
                    end_datetime = start_datetime + timedelta(minutes=duration_minutes)
                else:
                    # Mantener duración original
                    original_start = datetime.fromisoformat(event['start']['dateTime'].replace('Z', '+00:00'))
                    original_end = datetime.fromisoformat(event['end']['dateTime'].replace('Z', '+00:00'))
                    duration = original_end - original_start
                    end_datetime = start_datetime + duration
                
                event['start'] = {
                    'dateTime': start_datetime.isoformat(),
                    'timeZone': self.timezone,
                }
                event['end'] = {
                    'dateTime': end_datetime.isoformat(),
                    'timeZone': self.timezone,
                }
            
            # Actualizar evento
            updated_event = self.service.events().update(
                calendarId=calendar_id,
                eventId=event_id,
                body=event
            ).execute()
            
            self.logger.info(f"Evento actualizado: {event_id}")
            
            return f"✅ **Evento actualizado exitosamente**\n\n{self._format_event_details(updated_event)}"
            
        except Exception as e:
            self.logger.error(f"Error actualizando evento: {e}")
            return self.format_error_response(e, "actualización de evento")
    
    async def delete_event(
        self,
        event_id: str,
        calendar_id: str = 'primary',
        send_updates: bool = True
    ) -> str:
        """
        Eliminar evento del calendario
        
        Args:
            event_id: ID del evento
            calendar_id: ID del calendario
            send_updates: Enviar notificaciones de cancelación
        
        Returns:
            Resultado de la eliminación
        """
        try:
            self._ensure_initialized()
            
            # Obtener info del evento antes de eliminar
            try:
                event = self.service.events().get(
                    calendarId=calendar_id,
                    eventId=event_id
                ).execute()
                
                event_title = event.get('summary', 'Sin título')
            except:
                event_title = event_id
            
            # Eliminar evento
            self.service.events().delete(
                calendarId=calendar_id,
                eventId=event_id,
                sendUpdates='all' if send_updates else 'none'
            ).execute()
            
            self.logger.info(f"Evento eliminado: {event_id}")
            
            return f"🗑️ **Evento eliminado exitosamente**\n\n**Evento:** {event_title}\n**ID:** {event_id}"
            
        except Exception as e:
            self.logger.error(f"Error eliminando evento: {e}")
            return self.format_error_response(e, "eliminación de evento")
    
    async def get_free_busy(
        self,
        start_date: str,
        end_date: str,
        calendar_id: str = 'primary'
    ) -> str:
        """
        Obtener información de disponibilidad
        
        Args:
            start_date: Fecha de inicio (YYYY-MM-DD)
            end_date: Fecha de fin (YYYY-MM-DD)
            calendar_id: ID del calendario
        
        Returns:
            Información de disponibilidad
        """
        try:
            self._ensure_initialized()
            
            time_min = datetime.fromisoformat(f"{start_date}T00:00:00").replace(tzinfo=pytz.timezone(self.timezone)).isoformat()
            time_max = datetime.fromisoformat(f"{end_date}T23:59:59").replace(tzinfo=pytz.timezone(self.timezone)).isoformat()
            
            body = {
                'timeMin': time_min,
                'timeMax': time_max,
                'items': [{'id': calendar_id}]
            }
            
            freebusy = self.service.freebusy().query(body=body).execute()
            
            busy_times = freebusy['calendars'][calendar_id].get('busy', [])
            
            if not busy_times:
                return f"✅ **Completamente libre del {start_date} al {end_date}**"
            
            result = f"📅 **Disponibilidad del {start_date} al {end_date}:**\n\n"
            result += "**Períodos ocupados:**\n"
            
            for i, busy_period in enumerate(busy_times, 1):
                start = datetime.fromisoformat(busy_period['start'].replace('Z', '+00:00'))
                end = datetime.fromisoformat(busy_period['end'].replace('Z', '+00:00'))
                
                result += f"{i}. {start.strftime('%d/%m/%Y %H:%M')} - {end.strftime('%d/%m/%Y %H:%M')}\n"
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error obteniendo disponibilidad: {e}")
            return self.format_error_response(e, "consulta de disponibilidad")
    
    def _parse_datetime(self, date: str, time: str) -> datetime:
        """Parsear fecha y hora a objeto datetime"""
        try:
            datetime_str = f"{date}T{time}:00"
            dt = datetime.fromisoformat(datetime_str)
            return dt.replace(tzinfo=pytz.timezone(self.timezone))
        except Exception as e:
            raise ValidationError(f"Invalid date/time format: {date} {time}")
    
    def _format_event_summary(self, event: Dict, index: int = None) -> str:
        """Formatear resumen de evento"""
        try:
            title = event.get('summary', 'Sin título')
            
            # Manejar eventos de todo el día vs eventos con hora
            start = event['start']
            end = event['end']
            
            if 'date' in start:  # Evento de todo el día
                date_str = start['date']
                time_info = "Todo el día"
            else:  # Evento con hora específica
                start_dt = datetime.fromisoformat(start['dateTime'].replace('Z', '+00:00'))
                end_dt = datetime.fromisoformat(end['dateTime'].replace('Z', '+00:00'))
                
                date_str = start_dt.strftime('%d/%m/%Y')
                time_info = f"{start_dt.strftime('%H:%M')} - {end_dt.strftime('%H:%M')}"
            
            result = ""
            if index:
                result += f"**{index}. {title}**\n"
            else:
                result += f"**{title}**\n"
            
            result += f"📅 {date_str}\n"
            result += f"🕐 {time_info}\n"
            
            if 'location' in event:
                result += f"📍 {event['location']}\n"
            
            if 'description' in event:
                description = self.truncate_text(event['description'], 100)
                result += f"📝 {description}\n"
            
            result += f"🆔 {event['id']}"
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error formateando evento: {e}")
            return f"Error formateando evento: {e}"
    
    def _format_event_details(self, event: Dict) -> str:
        """Formatear detalles completos del evento"""
        try:
            title = event.get('summary', 'Sin título')
            
            result = f"📅 **Detalles del evento**\n\n"
            result += f"**Título:** {title}\n"
            
            # Fecha y hora
            start = event['start']
            end = event['end']
            
            if 'date' in start:
                result += f"**Fecha:** {start['date']}\n"
                result += f"**Tipo:** Todo el día\n"
            else:
                start_dt = datetime.fromisoformat(start['dateTime'].replace('Z', '+00:00'))
                end_dt = datetime.fromisoformat(end['dateTime'].replace('Z', '+00:00'))
                
                result += f"**Fecha:** {start_dt.strftime('%d/%m/%Y')}\n"
                result += f"**Hora:** {start_dt.strftime('%H:%M')} - {end_dt.strftime('%H:%M')}\n"
                
                duration = end_dt - start_dt
                duration_hours = duration.total_seconds() / 3600
                result += f"**Duración:** {duration_hours:.1f} horas\n"
            
            # Información adicional
            if 'location' in event:
                result += f"**Ubicación:** {event['location']}\n"
            
            if 'description' in event:
                result += f"**Descripción:** {event['description']}\n"
            
            if 'attendees' in event:
                attendees = [att.get('email', 'Sin email') for att in event['attendees']]
                result += f"**Asistentes:** {', '.join(attendees)}\n"
            
            if 'hangoutLink' in event:
                result += f"**Enlace Meet:** {event['hangoutLink']}\n"
            
            if 'htmlLink' in event:
                result += f"**Enlace Calendar:** {event['htmlLink']}\n"
            
            result += f"**ID:** {event['id']}\n"
            
            if 'created' in event:
                created_dt = datetime.fromisoformat(event['created'].replace('Z', '+00:00'))
                result += f"**Creado:** {created_dt.strftime('%d/%m/%Y %H:%M')}\n"
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error formateando detalles: {e}")
            return f"Error formateando detalles del evento: {e}"
    
    async def health_check(self) -> str:
        """Verificar estado de Calendar"""
        try:
            if not self.is_initialized:
                return "not_initialized"
            
            if not self.service:
                return "no_service"
            
            # Test simple
            calendar_info = self.service.calendars().get(calendarId=self.primary_calendar_id).execute()
            return "healthy"
            
        except Exception as e:
            return f"error: {str(e)}"
    
    async def close(self) -> None:
        """Cerrar recursos de Calendar"""
        try:
            self.service = None
            await super().close()
            self.logger.info("Calendar Tools cerradas")
        except Exception as e:
            self.logger.error(f"Error cerrando Calendar: {e}")
