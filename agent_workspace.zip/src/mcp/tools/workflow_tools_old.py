"""
Herramientas de flujos de trabajo automatizados
Combinan múltiples herramientas para crear procesos complejos
"""

import asyncio
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

from ...core.config import get_settings
from ...core.logging_config import get_logger, performance_logger
from ...core.exceptions import WorkflowError, ValidationError
from .base_tool import BaseTool


@dataclass
class WorkflowStep:
    """Paso individual de un flujo de trabajo"""
    name: str
    tool: str
    action: str
    params: Dict[str, Any]
    completed: bool = False
    result: Optional[str] = None
    error: Optional[str] = None


@dataclass
class WorkflowResult:
    """Resultado de un flujo de trabajo"""
    workflow_name: str
    steps: List[WorkflowStep]
    success: bool
    total_time: float
    final_result: str


class WorkflowTools(BaseTool):
    """Herramientas de flujos de trabajo automatizados"""
    
    def __init__(self):
        super().__init__()
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        # Referencias a otras herramientas (se inyectarán desde el servidor)
        self.serpapi_tools = None
        self.gmail_tools = None
        self.calendar_tools = None
        self.analytics_tools = None
        
        # Plantillas de flujos predefinidos
        self.workflow_templates = {
            "research": self._get_research_workflow_template,
            "communication": self._get_communication_workflow_template,
            "analysis": self._get_analysis_workflow_template,
            "competitive_analysis": self._get_competitive_analysis_template
        }
    
    async def initialize(self) -> None:
        """Inicializar herramientas de workflow"""
        try:
            # Las herramientas específicas se inyectarán después
            self.is_initialized = True
            self.logger.info("Workflow Tools inicializadas")
            
        except Exception as e:
            self.logger.error(f"Error inicializando Workflow: {e}")
            raise WorkflowError(f"Failed to initialize Workflow: {e}")
    
    def inject_tools(
        self,
        serpapi_tools,
        gmail_tools,
        calendar_tools,
        analytics_tools
    ):
        """Inyectar referencias a otras herramientas"""
        self.serpapi_tools = serpapi_tools
        self.gmail_tools = gmail_tools
        self.calendar_tools = calendar_tools
        self.analytics_tools = analytics_tools
        
        self.logger.info("Herramientas inyectadas en Workflow Tools")
    
    async def research_workflow(
        self,
        topic: str,
        depth: str = "medio",
        include_academic: bool = True,
        include_news: bool = True,
        output_format: str = "completo"
    ) -> str:
        """
        Flujo completo de investigación automatizada
        
        Args:
            topic: Tema a investigar
            depth: Nivel de profundidad (básico, medio, avanzado)
            include_academic: Incluir búsqueda académica
            include_news: Incluir noticias actuales
            output_format: Formato del reporte (completo, resumen, puntos)
        
        Returns:
            Reporte completo de investigación
        """
        try:
            self._ensure_initialized()
            start_time = asyncio.get_event_loop().time()
            
            # Validar parámetros
            self._validate_params({"topic": topic}, ["topic"])
            
            if not self.serpapi_tools:
                raise WorkflowError("SerpAPI tools not available for research workflow")
            
            # Crear pasos del workflow
            steps = self._create_research_steps(topic, depth, include_academic, include_news)
            
            self.logger.info(f"Iniciando workflow de investigación para: {topic}")
            
            # Ejecutar workflow
            result = await self._execute_workflow(
                workflow_name="Investigación",
                steps=steps,
                topic=topic
            )
            
            # Generar reporte final
            final_report = await self._generate_research_report(
                result, topic, output_format
            )
            
            execution_time = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("research_workflow", execution_time, result.success)
            
            return final_report
            
        except Exception as e:
            self.logger.error(f"Error en workflow de investigación: {e}")
            return self.format_error_response(e, "workflow de investigación")
    
    async def communication_workflow(
        self,
        communication_type: str,
        recipient: str,
        content: str,
        schedule: bool = False,
        scheduled_time: Optional[str] = None
    ) -> str:
        """
        Flujo de comunicación automatizada
        
        Args:
            communication_type: Tipo de comunicación (email, reunion)
            recipient: Destinatario de la comunicación
            content: Contenido o tema de la comunicación
            schedule: Si se debe programar para después
            scheduled_time: Fecha para programar (YYYY-MM-DD HH:MM)
        
        Returns:
            Resultado del flujo de comunicación
        """
        try:
            self._ensure_initialized()
            start_time = asyncio.get_event_loop().time()
            
            # Validar parámetros
            self._validate_params({
                "communication_type": communication_type,
                "recipient": recipient,
                "content": content
            }, ["communication_type", "recipient", "content"])
            
            # Crear pasos del workflow
            steps = self._create_communication_steps(
                communication_type, recipient, content, schedule, scheduled_time
            )
            
            self.logger.info(f"Iniciando workflow de comunicación: {communication_type}")
            
            # Ejecutar workflow
            result = await self._execute_workflow(
                workflow_name="Comunicación",
                steps=steps,
                communication_type=communication_type
            )
            
            # Generar reporte final
            final_report = self._generate_communication_report(result, communication_type)
            
            execution_time = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("communication_workflow", execution_time, result.success)
            
            return final_report
            
        except Exception as e:
            self.logger.error(f"Error en workflow de comunicación: {e}")
            return self.format_error_response(e, "workflow de comunicación")
    
    async def competitive_analysis_workflow(
        self,
        company: str,
        industry: str,
        metrics: List[str] = None
    ) -> str:
        """
        Flujo de análisis de competencia completo
        
        Args:
            company: Empresa a analizar
            industry: Sector/industria
            metrics: Métricas específicas a analizar
        
        Returns:
            Análisis completo de competencia
        """
        try:
            self._ensure_initialized()
            start_time = asyncio.get_event_loop().time()
            
            # Validar parámetros
            self._validate_params({"company": company, "industry": industry}, ["company", "industry"])
            
            if metrics is None:
                metrics = ["market_share", "products", "pricing", "news"]
            
            # Crear pasos del workflow
            steps = self._create_competitive_analysis_steps(company, industry, metrics)
            
            self.logger.info(f"Iniciando análisis de competencia para: {company}")
            
            # Ejecutar workflow
            result = await self._execute_workflow(
                workflow_name="Análisis de Competencia",
                steps=steps,
                company=company
            )
            
            # Generar reporte final
            final_report = await self._generate_competitive_analysis_report(
                result, company, industry
            )
            
            execution_time = asyncio.get_event_loop().time() - start_time
            performance_logger.log_tool_execution("competitive_analysis_workflow", execution_time, result.success)
            
            return final_report
            
        except Exception as e:
            self.logger.error(f"Error en workflow de análisis de competencia: {e}")
            return self.format_error_response(e, "workflow de análisis de competencia")
    
    def _create_research_steps(
        self,
        topic: str,
        depth: str,
        include_academic: bool,
        include_news: bool
    ) -> List[WorkflowStep]:
        """Crear pasos para workflow de investigación"""
        steps = []
        
        # Búsqueda web general
        steps.append(WorkflowStep(
            name="Búsqueda Web General",
            tool="serpapi",
            action="search_web",
            params={
                "query": topic,
                "limit": 15 if depth == "avanzado" else 10
            }
        ))
        
        # Búsqueda académica si se requiere
        if include_academic:
            steps.append(WorkflowStep(
                name="Búsqueda Académica",
                tool="serpapi",
                action="search_scholar",
                params={
                    "query": topic,
                    "limit": 10 if depth == "avanzado" else 5
                }
            ))
        
        # Búsqueda de noticias si se requiere
        if include_news:
            steps.append(WorkflowStep(
                name="Búsqueda de Noticias",
                tool="serpapi",
                action="search_news",
                params={
                    "query": topic,
                    "time_period": "ultimo_mes",
                    "limit": 10 if depth == "avanzado" else 5
                }
            ))
        
        # Búsquedas específicas según profundidad
        if depth == "avanzado":
            # Búsqueda de tendencias
            steps.append(WorkflowStep(
                name="Análisis de Tendencias",
                tool="serpapi",
                action="search_web",
                params={
                    "query": f"{topic} tendencias 2024 2025",
                    "limit": 5
                }
            ))
            
            # Búsqueda de competidores/alternativas
            steps.append(WorkflowStep(
                name="Competidores y Alternativas",
                tool="serpapi",
                action="search_web",
                params={
                    "query": f"{topic} competidores alternativas comparación",
                    "limit": 5
                }
            ))
        
        return steps
    
    def _create_communication_steps(
        self,
        communication_type: str,
        recipient: str,
        content: str,
        schedule: bool,
        scheduled_time: Optional[str]
    ) -> List[WorkflowStep]:
        """Crear pasos para workflow de comunicación"""
        steps = []
        
        if communication_type.lower() == "email":
            if schedule and scheduled_time:
                # Email programado (nota: Gmail API no soporta programación nativa)
                steps.append(WorkflowStep(
                    name="Programar Email",
                    tool="calendar",
                    action="create_event",
                    params={
                        "title": f"Enviar email a {recipient}",
                        "date": scheduled_time.split()[0],
                        "time": scheduled_time.split()[1] if len(scheduled_time.split()) > 1 else "09:00",
                        "description": f"Recordatorio: Enviar email con contenido: {content[:100]}..."
                    }
                ))
            else:
                # Email inmediato
                steps.append(WorkflowStep(
                    name="Enviar Email",
                    tool="gmail",
                    action="send_email",
                    params={
                        "to": recipient,
                        "subject": f"Comunicación sobre: {content[:50]}...",
                        "body": content
                    }
                ))
        
        elif communication_type.lower() == "reunion":
            if not scheduled_time:
                # Si no se especifica tiempo, programar para mañana
                tomorrow = datetime.now() + timedelta(days=1)
                scheduled_time = tomorrow.strftime("%Y-%m-%d 10:00")
            
            steps.append(WorkflowStep(
                name="Programar Reunión",
                tool="calendar",
                action="create_event",
                params={
                    "title": f"Reunión: {content[:50]}...",
                    "date": scheduled_time.split()[0],
                    "time": scheduled_time.split()[1] if len(scheduled_time.split()) > 1 else "10:00",
                    "duration_minutes": 60,
                    "description": content,
                    "attendees": [recipient] if "@" in recipient else None
                }
            ))
            
            # Enviar email de confirmación
            steps.append(WorkflowStep(
                name="Email de Confirmación",
                tool="gmail",
                action="send_email",
                params={
                    "to": recipient,
                    "subject": f"Reunión programada: {content[:50]}...",
                    "body": f"Hola,\n\nSe ha programado una reunión para {scheduled_time}.\n\nTema: {content}\n\nSaludos"
                }
            ))
        
        return steps
    
    def _create_competitive_analysis_steps(
        self,
        company: str,
        industry: str,
        metrics: List[str]
    ) -> List[WorkflowStep]:
        """Crear pasos para análisis de competencia"""
        steps = []
        
        # Información general de la empresa
        steps.append(WorkflowStep(
            name="Información General",
            tool="serpapi",
            action="search_web",
            params={
                "query": f"{company} empresa información general",
                "limit": 10
            }
        ))
        
        # Análisis de productos/servicios
        if "products" in metrics:
            steps.append(WorkflowStep(
                name="Productos y Servicios",
                tool="serpapi",
                action="search_web",
                params={
                    "query": f"{company} productos servicios catálogo",
                    "limit": 8
                }
            ))
        
        # Análisis de precios
        if "pricing" in metrics:
            steps.append(WorkflowStep(
                name="Análisis de Precios",
                tool="serpapi",
                action="search_web",
                params={
                    "query": f"{company} precios tarifas costos",
                    "limit": 5
                }
            ))
        
        # Noticias recientes
        if "news" in metrics:
            steps.append(WorkflowStep(
                name="Noticias Recientes",
                tool="serpapi",
                action="search_news",
                params={
                    "query": company,
                    "time_period": "ultimo_mes",
                    "limit": 8
                }
            ))
        
        # Competidores directos
        steps.append(WorkflowStep(
            name="Competidores Directos",
            tool="serpapi",
            action="search_web",
            params={
                "query": f"{company} competidores {industry} alternativas",
                "limit": 8
            }
        ))
        
        return steps
    
    async def _execute_workflow(
        self,
        workflow_name: str,
        steps: List[WorkflowStep],
        **context
    ) -> WorkflowResult:
        """Ejecutar workflow paso a paso"""
        try:
            start_time = asyncio.get_event_loop().time()
            
            self.logger.info(f"Ejecutando workflow '{workflow_name}' con {len(steps)} pasos")
            
            successful_steps = 0
            
            for i, step in enumerate(steps, 1):
                try:
                    self.logger.info(f"Ejecutando paso {i}/{len(steps)}: {step.name}")
                    
                    # Ejecutar paso individual
                    result = await self._execute_workflow_step(step)
                    
                    step.completed = True
                    step.result = result
                    successful_steps += 1
                    
                    self.logger.info(f"Paso {i} completado exitosamente")
                    
                    # Pausa breve entre pasos para evitar rate limiting
                    await asyncio.sleep(0.5)
                    
                except Exception as e:
                    self.logger.error(f"Error en paso {i} ({step.name}): {e}")
                    step.error = str(e)
                    # Continuar con el siguiente paso en lugar de fallar completamente
            
            total_time = asyncio.get_event_loop().time() - start_time
            success = successful_steps > 0  # Exitoso si al menos un paso funcionó
            
            # Generar resultado consolidado
            final_result = self._consolidate_workflow_results(steps, workflow_name)
            
            return WorkflowResult(
                workflow_name=workflow_name,
                steps=steps,
                success=success,
                total_time=total_time,
                final_result=final_result
            )
            
        except Exception as e:
            self.logger.error(f"Error ejecutando workflow: {e}")
            raise WorkflowError(f"Workflow execution failed: {e}")
    
    async def _execute_workflow_step(self, step: WorkflowStep) -> str:
        """Ejecutar un paso individual del workflow"""
        try:
            if step.tool == "serpapi":
                if not self.serpapi_tools:
                    raise WorkflowError("SerpAPI tools not available")
                
                if step.action == "search_web":
                    return await self.serpapi_tools.search_web(**step.params)
                elif step.action == "search_news":
                    return await self.serpapi_tools.search_news(**step.params)
                elif step.action == "search_scholar":
                    return await self.serpapi_tools.search_scholar(**step.params)
                else:
                    return await self.serpapi_tools.search(**step.params)
            
            elif step.tool == "gmail":
                if not self.gmail_tools:
                    raise WorkflowError("Gmail tools not available")
                
                if step.action == "send_email":
                    return await self.gmail_tools.send_email(**step.params)
                else:
                    raise WorkflowError(f"Unknown Gmail action: {step.action}")
            
            elif step.tool == "calendar":
                if not self.calendar_tools:
                    raise WorkflowError("Calendar tools not available")
                
                if step.action == "create_event":
                    return await self.calendar_tools.create_event(**step.params)
                else:
                    raise WorkflowError(f"Unknown Calendar action: {step.action}")
            
            elif step.tool == "analytics":
                if not self.analytics_tools:
                    raise WorkflowError("Analytics tools not available")
                
                if step.action == "analyze_sentiment":
                    return await self.analytics_tools.analyze_sentiment(**step.params)
                elif step.action == "generate_summary":
                    return await self.analytics_tools.generate_summary(**step.params)
                else:
                    raise WorkflowError(f"Unknown Analytics action: {step.action}")
            
            else:
                raise WorkflowError(f"Unknown tool: {step.tool}")
                
        except Exception as e:
            self.logger.error(f"Error ejecutando paso {step.name}: {e}")
            raise WorkflowError(f"Step execution failed: {e}")
    
    def _consolidate_workflow_results(self, steps: List[WorkflowStep], workflow_name: str) -> str:
        """Consolidar resultados de todos los pasos"""
        try:
            consolidated = f"# Resultados del Workflow: {workflow_name}\n\n"
            
            # Resumen ejecutivo
            completed_steps = [step for step in steps if step.completed]
            failed_steps = [step for step in steps if step.error]
            
            consolidated += f"## 📊 Resumen Ejecutivo\n"
            consolidated += f"• Pasos completados: {len(completed_steps)}/{len(steps)}\n"
            consolidated += f"• Pasos fallidos: {len(failed_steps)}\n"
            consolidated += f"• Tasa de éxito: {(len(completed_steps) / len(steps)) * 100:.1f}%\n\n"
            
            # Resultados por paso
            for i, step in enumerate(steps, 1):
                consolidated += f"## {i}. {step.name}\n"
                
                if step.completed and step.result:
                    # Truncar resultados muy largos
                    result_preview = self.truncate_text(step.result, 800)
                    consolidated += f"✅ **Completado**\n{result_preview}\n\n"
                elif step.error:
                    consolidated += f"❌ **Error:** {step.error}\n\n"
                else:
                    consolidated += f"⏸️ **No ejecutado**\n\n"
                
                consolidated += "---\n\n"
            
            return consolidated
            
        except Exception as e:
            self.logger.error(f"Error consolidando resultados: {e}")
            return f"Error consolidando resultados del workflow: {e}"
    
    async def _generate_research_report(
        self,
        workflow_result: WorkflowResult,
        topic: str,
        output_format: str
    ) -> str:
        """Generar reporte final de investigación"""
        try:
            report = f"# 🔍 Reporte de Investigación: {topic}\n\n"
            report += f"**Fecha:** {datetime.now().strftime('%d/%m/%Y %H:%M')}\n"
            report += f"**Tiempo total:** {workflow_result.total_time:.1f} segundos\n\n"
            
            if output_format == "resumen":
                # Versión resumida
                completed_steps = [step for step in workflow_result.steps if step.completed]
                report += f"## 📋 Resumen\n"
                report += f"Se completaron {len(completed_steps)} búsquedas sobre '{topic}'.\n\n"
                
                for step in completed_steps:
                    if step.result:
                        # Extraer solo los primeros resultados
                        preview = self.truncate_text(step.result, 200)
                        report += f"**{step.name}:** {preview}\n\n"
            
            elif output_format == "puntos":
                # Versión de puntos clave
                report += f"## 🔑 Puntos Clave sobre {topic}\n\n"
                
                point_number = 1
                for step in workflow_result.steps:
                    if step.completed and step.result:
                        # Extraer información clave
                        lines = step.result.split('\n')[:5]  # Primeras 5 líneas
                        for line in lines:
                            if line.strip() and ('**' in line or '•' in line):
                                report += f"{point_number}. {line.strip()}\n"
                                point_number += 1
                                if point_number > 10:  # Máximo 10 puntos
                                    break
                        if point_number > 10:
                            break
            
            else:
                # Versión completa
                report += workflow_result.final_result
            
            # Agregar conclusiones si tenemos analytics tools
            if self.analytics_tools and workflow_result.success:
                try:
                    # Analizar el contenido consolidado para generar insights
                    all_content = "\n".join([
                        step.result for step in workflow_result.steps 
                        if step.completed and step.result
                    ])
                    
                    if len(all_content) > 500:  # Solo si hay suficiente contenido
                        summary = await self.analytics_tools.generate_summary(
                            all_content, "corto", "profesional"
                        )
                        report += f"\n## 💡 Conclusiones Automáticas\n{summary}\n"
                        
                except Exception as e:
                    self.logger.warning(f"No se pudieron generar conclusiones automáticas: {e}")
            
            return report
            
        except Exception as e:
            self.logger.error(f"Error generando reporte de investigación: {e}")
            return f"Error generando reporte: {e}"
    
    def _generate_communication_report(
        self,
        workflow_result: WorkflowResult,
        communication_type: str
    ) -> str:
        """Generar reporte de comunicación"""
        try:
            report = f"# 💬 Reporte de Comunicación\n\n"
            report += f"**Tipo:** {communication_type}\n"
            report += f"**Fecha:** {datetime.now().strftime('%d/%m/%Y %H:%M')}\n"
            report += f"**Estado:** {'✅ Exitoso' if workflow_result.success else '❌ Con errores'}\n\n"
            
            # Resumen de acciones realizadas
            report += f"## 📋 Acciones Realizadas\n\n"
            
            for step in workflow_result.steps:
                if step.completed:
                    report += f"✅ **{step.name}:** Completado exitosamente\n"
                    if step.result:
                        preview = self.truncate_text(step.result, 200)
                        report += f"   {preview}\n\n"
                elif step.error:
                    report += f"❌ **{step.name}:** {step.error}\n\n"
            
            return report
            
        except Exception as e:
            self.logger.error(f"Error generando reporte de comunicación: {e}")
            return f"Error generando reporte: {e}"
    
    async def _generate_competitive_analysis_report(
        self,
        workflow_result: WorkflowResult,
        company: str,
        industry: str
    ) -> str:
        """Generar reporte de análisis de competencia"""
        try:
            report = f"# 🏢 Análisis de Competencia: {company}\n\n"
            report += f"**Industria:** {industry}\n"
            report += f"**Fecha:** {datetime.now().strftime('%d/%m/%Y %H:%M')}\n"
            report += f"**Tiempo de análisis:** {workflow_result.total_time:.1f} segundos\n\n"
            
            # Organizar resultados por categoría
            categories = {
                "Información General": [],
                "Productos y Servicios": [],
                "Precios": [],
                "Noticias": [],
                "Competidores": []
            }
            
            for step in workflow_result.steps:
                if step.completed and step.result:
                    if "información general" in step.name.lower():
                        categories["Información General"].append(step.result)
                    elif "productos" in step.name.lower():
                        categories["Productos y Servicios"].append(step.result)
                    elif "precios" in step.name.lower():
                        categories["Precios"].append(step.result)
                    elif "noticias" in step.name.lower():
                        categories["Noticias"].append(step.result)
                    elif "competidores" in step.name.lower():
                        categories["Competidores"].append(step.result)
            
            # Generar secciones del reporte
            for category, results in categories.items():
                if results:
                    report += f"## 📊 {category}\n\n"
                    for result in results:
                        preview = self.truncate_text(result, 600)
                        report += f"{preview}\n\n"
                    report += "---\n\n"
            
            return report
            
        except Exception as e:
            self.logger.error(f"Error generando reporte de análisis: {e}")
            return f"Error generando reporte: {e}"
    
    # Métodos de plantillas de workflow (para futuras expansiones)
    def _get_research_workflow_template(self) -> Dict[str, Any]:
        """Plantilla para workflow de investigación"""
        return {
            "name": "Research Workflow",
            "description": "Flujo completo de investigación con múltiples fuentes",
            "steps": ["web_search", "academic_search", "news_search", "analysis"]
        }
    
    def _get_communication_workflow_template(self) -> Dict[str, Any]:
        """Plantilla para workflow de comunicación"""
        return {
            "name": "Communication Workflow", 
            "description": "Flujo de comunicación automatizada",
            "steps": ["prepare_content", "send_communication", "schedule_followup"]
        }
    
    def _get_analysis_workflow_template(self) -> Dict[str, Any]:
        """Plantilla para workflow de análisis"""
        return {
            "name": "Analysis Workflow",
            "description": "Flujo de análisis de contenido",
            "steps": ["collect_data", "analyze_sentiment", "generate_summary", "create_report"]
        }
    
    def _get_competitive_analysis_template(self) -> Dict[str, Any]:
        """Plantilla para análisis de competencia"""
        return {
            "name": "Competitive Analysis Workflow",
            "description": "Análisis completo de competencia",
            "steps": ["company_info", "products_analysis", "pricing_analysis", "news_analysis", "competitors_analysis"]
        }
    
    async def health_check(self) -> str:
        """Verificar estado de Workflow Tools"""
        try:
            if not self.is_initialized:
                return "not_initialized"
            
            # Verificar disponibilidad de herramientas
            available_tools = []
            if self.serpapi_tools:
                available_tools.append("serpapi")
            if self.gmail_tools:
                available_tools.append("gmail")
            if self.calendar_tools:
                available_tools.append("calendar")
            if self.analytics_tools:
                available_tools.append("analytics")
            
            if not available_tools:
                return "no_tools_available"
            
            return f"healthy_with_tools: {','.join(available_tools)}"
            
        except Exception as e:
            return f"error: {str(e)}"
    
    async def close(self) -> None:
        """Cerrar Workflow Tools"""
        try:
            # Limpiar referencias
            self.serpapi_tools = None
            self.gmail_tools = None
            self.calendar_tools = None
            self.analytics_tools = None
            
            await super().close()
            self.logger.info("Workflow Tools cerradas")
        except Exception as e:
            self.logger.error(f"Error cerrando Workflow: {e}")
