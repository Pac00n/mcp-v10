"""
Herramientas de análisis de texto y contenido
"""

import asyncio
import re
import statistics
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from collections import Counter

from ...core.config import get_settings
from ...core.logging_config import get_logger
from ...core.exceptions import DataProcessingError, ValidationError
from .base_tool import BaseTool


@dataclass
class SentimentResult:
    """Resultado de análisis de sentimiento"""
    score: float  # -1 a 1
    label: str   # positive, negative, neutral
    confidence: float  # 0 a 1
    details: Dict[str, Any]


@dataclass
class SummaryResult:
    """Resultado de generación de resumen"""
    summary: str
    original_length: int
    summary_length: int
    compression_ratio: float
    key_points: List[str]


class AnalyticsTools(BaseTool):
    """Herramientas de análisis de texto y contenido"""
    
    def __init__(self):
        super().__init__()
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        # Diccionarios de palabras para análisis de sentimiento en español
        self.positive_words = {
            "excelente", "bueno", "fantástico", "increíble", "genial", "perfecto",
            "maravilloso", "espectacular", "extraordinario", "fabuloso", "magnífico",
            "brillante", "sobresaliente", "exitoso", "favorable", "positivo",
            "satisfactorio", "agradable", "placentero", "hermoso", "alegre",
            "feliz", "contento", "entusiasmado", "emocionado", "motivado",
            "inspirado", "confiado", "optimista", "esperanzado", "radiante"
        }
        
        self.negative_words = {
            "terrible", "malo", "horrible", "pésimo", "awful", "desastroso",
            "lamentable", "deplorable", "inaceptable", "decepcionante", "frustrante",
            "molesto", "irritante", "preocupante", "problemático", "difícil",
            "complicado", "negativo", "desfavorable", "triste", "deprimido",
            "enojado", "furioso", "disgustado", "aburrido", "cansado",
            "estresado", "ansioso", "nervioso", "confundido", "perdido"
        }
        
        # Palabras de intensificación
        self.intensifiers = {
            "muy": 1.5, "bastante": 1.3, "algo": 0.8, "poco": 0.6,
            "extremadamente": 2.0, "súper": 1.8, "realmente": 1.4,
            "totalmente": 1.6, "completamente": 1.7, "absolutamente": 1.9
        }
    
    async def initialize(self) -> None:
        """Inicializar herramientas de análisis"""
        try:
            # No requiere inicialización especial
            self.is_initialized = True
            self.logger.info("Analytics Tools inicializadas")
            
        except Exception as e:
            self.logger.error(f"Error inicializando Analytics: {e}")
            raise DataProcessingError(f"Failed to initialize Analytics: {e}")
    
    async def analyze_sentiment(
        self,
        text: str,
        language: str = "es"
    ) -> str:
        """
        Analizar sentimiento de texto
        
        Args:
            text: Texto a analizar
            language: Idioma del texto
        
        Returns:
            Análisis de sentimiento formateado
        """
        try:
            self._ensure_initialized()
            
            if not text.strip():
                raise ValidationError("Text cannot be empty")
            
            # Realizar análisis
            result = self._analyze_sentiment_basic(text, language)
            
            # Formatear resultado
            return self._format_sentiment_result(result, text)
            
        except Exception as e:
            self.logger.error(f"Error en análisis de sentimiento: {e}")
            return self.format_error_response(e, "análisis de sentimiento")
    
    def _analyze_sentiment_basic(self, text: str, language: str) -> SentimentResult:
        """Análisis básico de sentimiento usando diccionarios"""
        try:
            # Limpiar y normalizar texto
            clean_text = self._clean_text(text)
            words = clean_text.lower().split()
            
            # Contadores
            positive_score = 0
            negative_score = 0
            word_count = len(words)
            
            # Análisis palabra por palabra
            for i, word in enumerate(words):
                intensity = 1.0
                
                # Verificar intensificadores previos
                if i > 0 and words[i-1] in self.intensifiers:
                    intensity = self.intensifiers[words[i-1]]
                
                # Evaluar sentimiento
                if word in self.positive_words:
                    positive_score += intensity
                elif word in self.negative_words:
                    negative_score += intensity
            
            # Calcular puntuaciones
            total_sentiment_words = positive_score + negative_score
            
            if total_sentiment_words == 0:
                score = 0.0
                label = "neutral"
                confidence = 0.5
            else:
                # Score normalizado (-1 a 1)
                score = (positive_score - negative_score) / max(total_sentiment_words, 1)
                
                # Clasificación
                if score > 0.1:
                    label = "positive"
                elif score < -0.1:
                    label = "negative"
                else:
                    label = "neutral"
                
                # Confianza basada en cantidad de palabras de sentimiento vs total
                confidence = min(total_sentiment_words / max(word_count, 1), 1.0)
            
            # Detalles adicionales
            details = {
                "positive_words_found": positive_score,
                "negative_words_found": negative_score,
                "total_words": word_count,
                "sentiment_words": total_sentiment_words,
                "language": language
            }
            
            return SentimentResult(
                score=round(score, 3),
                label=label,
                confidence=round(confidence, 3),
                details=details
            )
            
        except Exception as e:
            self.logger.error(f"Error en análisis básico: {e}")
            raise DataProcessingError(f"Sentiment analysis failed: {e}")
    
    async def generate_summary(
        self,
        content: str,
        length: str = "medio",
        style: str = "profesional"
    ) -> str:
        """
        Generar resumen inteligente
        
        Args:
            content: Contenido a resumir
            length: Longitud del resumen (corto, medio, largo)
            style: Estilo del resumen
        
        Returns:
            Resumen formateado
        """
        try:
            self._ensure_initialized()
            
            if not content.strip():
                raise ValidationError("Content cannot be empty")
            
            # Configurar parámetros de resumen
            length_config = {
                "corto": 0.2,    # 20% del original
                "medio": 0.4,    # 40% del original
                "largo": 0.6     # 60% del original
            }
            
            compression_ratio = length_config.get(length, 0.4)
            
            # Generar resumen
            result = self._generate_extractive_summary(content, compression_ratio, style)
            
            # Formatear resultado
            return self._format_summary_result(result, content)
            
        except Exception as e:
            self.logger.error(f"Error generando resumen: {e}")
            return self.format_error_response(e, "generación de resumen")
    
    def _generate_extractive_summary(
        self, 
        content: str, 
        compression_ratio: float, 
        style: str
    ) -> SummaryResult:
        """Generar resumen extractivo básico"""
        try:
            # Dividir en oraciones
            sentences = self._split_sentences(content)
            
            if len(sentences) <= 3:
                # Contenido muy corto, devolver tal como está
                return SummaryResult(
                    summary=content,
                    original_length=len(content),
                    summary_length=len(content),
                    compression_ratio=1.0,
                    key_points=sentences[:3]
                )
            
            # Calcular número de oraciones para el resumen
            target_sentences = max(1, int(len(sentences) * compression_ratio))
            
            # Puntuar oraciones
            sentence_scores = self._score_sentences(sentences, style)
            
            # Seleccionar mejores oraciones
            top_sentences = sorted(
                sentence_scores, 
                key=lambda x: x[1], 
                reverse=True
            )[:target_sentences]
            
            # Ordenar por posición original
            selected_sentences = sorted(top_sentences, key=lambda x: x[2])
            
            # Crear resumen
            summary_text = " ".join([sent[0] for sent in selected_sentences])
            
            # Extraer puntos clave
            key_points = [sent[0] for sent in top_sentences[:min(5, len(top_sentences))]]
            
            return SummaryResult(
                summary=summary_text,
                original_length=len(content),
                summary_length=len(summary_text),
                compression_ratio=len(summary_text) / len(content),
                key_points=key_points
            )
            
        except Exception as e:
            self.logger.error(f"Error en resumen extractivo: {e}")
            raise DataProcessingError(f"Summary generation failed: {e}")
    
    def _split_sentences(self, text: str) -> List[str]:
        """Dividir texto en oraciones"""
        try:
            # Limpiar texto
            clean_text = self._clean_text(text)
            
            # Expresión regular para dividir oraciones
            sentence_pattern = r'[.!?]+\s+'
            sentences = re.split(sentence_pattern, clean_text)
            
            # Filtrar oraciones muy cortas
            valid_sentences = [
                sent.strip() for sent in sentences 
                if len(sent.strip()) > 10
            ]
            
            return valid_sentences
            
        except Exception as e:
            self.logger.error(f"Error dividiendo oraciones: {e}")
            return [text]  # Fallback
    
    def _score_sentences(self, sentences: List[str], style: str) -> List[Tuple[str, float, int]]:
        """Puntuar oraciones para resumen"""
        try:
            scored_sentences = []
            
            # Calcular frecuencia de palabras
            all_words = []
            for sentence in sentences:
                words = self._clean_text(sentence).lower().split()
                all_words.extend(words)
            
            word_freq = Counter(all_words)
            
            for i, sentence in enumerate(sentences):
                score = self._calculate_sentence_score(sentence, word_freq, style, i, len(sentences))
                scored_sentences.append((sentence, score, i))
            
            return scored_sentences
            
        except Exception as e:
            self.logger.error(f"Error puntuando oraciones: {e}")
            return [(sent, 1.0, i) for i, sent in enumerate(sentences)]
    
    def _calculate_sentence_score(
        self, 
        sentence: str, 
        word_freq: Counter, 
        style: str, 
        position: int, 
        total_sentences: int
    ) -> float:
        """Calcular puntuación de una oración"""
        try:
            words = self._clean_text(sentence).lower().split()
            
            if not words:
                return 0.0
            
            # Score base: frecuencia de palabras
            word_score = sum(word_freq[word] for word in words) / len(words)
            
            # Normalizar por longitud de oración
            length_factor = min(len(words) / 15, 1.0)  # Preferir oraciones de ~15 palabras
            
            # Factor de posición
            position_factor = 1.0
            if position < total_sentences * 0.2:  # Primeras 20%
                position_factor = 1.2
            elif position > total_sentences * 0.8:  # Últimas 20%
                position_factor = 1.1
            
            # Factores según estilo
            style_factor = 1.0
            if style == "académico":
                # Preferir oraciones con términos técnicos
                technical_words = ["análisis", "estudio", "investigación", "resultado", "conclusión"]
                if any(word in sentence.lower() for word in technical_words):
                    style_factor = 1.3
            elif style == "ejecutivo":
                # Preferir oraciones con términos de negocio
                business_words = ["estrategia", "objetivo", "meta", "resultado", "beneficio", "impacto"]
                if any(word in sentence.lower() for word in business_words):
                    style_factor = 1.3
            
            # Score final
            final_score = word_score * length_factor * position_factor * style_factor
            
            return round(final_score, 3)
            
        except Exception as e:
            self.logger.error(f"Error calculando score de oración: {e}")
            return 1.0
    
    def _clean_text(self, text: str) -> str:
        """Limpiar y normalizar texto"""
        try:
            # Remover caracteres especiales pero mantener puntuación básica
            cleaned = re.sub(r'[^\w\s.!?¿¡,;:]', ' ', text)
            
            # Normalizar espacios
            cleaned = re.sub(r'\s+', ' ', cleaned)
            
            return cleaned.strip()
            
        except Exception as e:
            self.logger.error(f"Error limpiando texto: {e}")
            return text
    
    def _format_sentiment_result(self, result: SentimentResult, original_text: str) -> str:
        """Formatear resultado de análisis de sentimiento"""
        try:
            # Emoji según sentimiento
            emoji_map = {
                "positive": "😊",
                "negative": "😞", 
                "neutral": "😐"
            }
            
            emoji = emoji_map.get(result.label, "🤔")
            
            # Color del score
            if result.score > 0.5:
                score_description = "Muy positivo"
            elif result.score > 0.1:
                score_description = "Positivo"
            elif result.score > -0.1:
                score_description = "Neutral"
            elif result.score > -0.5:
                score_description = "Negativo"
            else:
                score_description = "Muy negativo"
            
            formatted_result = f"🧠 **Análisis de Sentimiento**\n\n"
            formatted_result += f"{emoji} **Resultado:** {score_description}\n"
            formatted_result += f"📊 **Puntuación:** {result.score} (rango: -1 a 1)\n"
            formatted_result += f"🎯 **Confianza:** {result.confidence * 100:.1f}%\n\n"
            
            formatted_result += "📈 **Detalles del análisis:**\n"
            formatted_result += f"• Palabras positivas detectadas: {result.details['positive_words_found']}\n"
            formatted_result += f"• Palabras negativas detectadas: {result.details['negative_words_found']}\n"
            formatted_result += f"• Total de palabras analizadas: {result.details['total_words']}\n"
            formatted_result += f"• Palabras con carga emocional: {result.details['sentiment_words']}\n"
            
            # Mostrar muestra del texto si es muy largo
            if len(original_text) > 200:
                sample_text = original_text[:200] + "..."
                formatted_result += f"\n📝 **Texto analizado (muestra):** {sample_text}"
            else:
                formatted_result += f"\n📝 **Texto analizado:** {original_text}"
            
            return formatted_result
            
        except Exception as e:
            self.logger.error(f"Error formateando resultado de sentimiento: {e}")
            return f"Error formateando resultado: {e}"
    
    def _format_summary_result(self, result: SummaryResult, original_content: str) -> str:
        """Formatear resultado de resumen"""
        try:
            formatted_result = f"📄 **Resumen Inteligente**\n\n"
            
            formatted_result += f"📊 **Estadísticas:**\n"
            formatted_result += f"• Longitud original: {result.original_length:,} caracteres\n"
            formatted_result += f"• Longitud del resumen: {result.summary_length:,} caracteres\n"
            formatted_result += f"• Reducción: {(1 - result.compression_ratio) * 100:.1f}%\n\n"
            
            formatted_result += f"✨ **Resumen:**\n{result.summary}\n\n"
            
            if result.key_points:
                formatted_result += f"🔑 **Puntos clave:**\n"
                for i, point in enumerate(result.key_points[:5], 1):
                    # Truncar puntos muy largos
                    truncated_point = self.truncate_text(point, 150)
                    formatted_result += f"{i}. {truncated_point}\n"
            
            return formatted_result
            
        except Exception as e:
            self.logger.error(f"Error formateando resultado de resumen: {e}")
            return f"Error formateando resultado: {e}"
    
    async def analyze_text_statistics(self, text: str) -> str:
        """Analizar estadísticas básicas del texto"""
        try:
            self._ensure_initialized()
            
            if not text.strip():
                raise ValidationError("Text cannot be empty")
            
            # Calcular estadísticas
            stats = self._calculate_text_stats(text)
            
            # Formatear resultado
            result = f"📊 **Estadísticas del Texto**\n\n"
            result += f"📝 **Contenido:**\n"
            result += f"• Caracteres totales: {stats['total_chars']:,}\n"
            result += f"• Caracteres sin espacios: {stats['chars_no_spaces']:,}\n"
            result += f"• Palabras: {stats['total_words']:,}\n"
            result += f"• Oraciones: {stats['sentences']:,}\n"
            result += f"• Párrafos: {stats['paragraphs']:,}\n\n"
            
            result += f"📈 **Promedios:**\n"
            result += f"• Palabras por oración: {stats['avg_words_per_sentence']:.1f}\n"
            result += f"• Caracteres por palabra: {stats['avg_chars_per_word']:.1f}\n"
            result += f"• Oraciones por párrafo: {stats['avg_sentences_per_paragraph']:.1f}\n\n"
            
            result += f"🕐 **Tiempo de lectura estimado:** {stats['reading_time']} minutos\n"
            
            if stats['most_common_words']:
                result += f"\n🔤 **Palabras más frecuentes:**\n"
                for word, count in stats['most_common_words'][:10]:
                    result += f"• {word}: {count} veces\n"
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error en estadísticas de texto: {e}")
            return self.format_error_response(e, "análisis de estadísticas")
    
    def _calculate_text_stats(self, text: str) -> Dict[str, Any]:
        """Calcular estadísticas básicas del texto"""
        try:
            # Limpiar texto para análisis
            clean_text = self._clean_text(text)
            
            # Conteos básicos
            total_chars = len(text)
            chars_no_spaces = len(text.replace(' ', ''))
            
            # Palabras
            words = clean_text.split()
            total_words = len(words)
            
            # Oraciones
            sentences = self._split_sentences(text)
            sentence_count = len(sentences)
            
            # Párrafos
            paragraphs = [p.strip() for p in text.split('\n\n') if p.strip()]
            paragraph_count = len(paragraphs)
            
            # Promedios
            avg_words_per_sentence = total_words / max(sentence_count, 1)
            avg_chars_per_word = chars_no_spaces / max(total_words, 1)
            avg_sentences_per_paragraph = sentence_count / max(paragraph_count, 1)
            
            # Tiempo de lectura (250 palabras por minuto promedio)
            reading_time = max(1, total_words // 250)
            
            # Palabras más comunes (excluyendo palabras muy cortas)
            meaningful_words = [word.lower() for word in words if len(word) > 3]
            most_common_words = Counter(meaningful_words).most_common(10)
            
            return {
                'total_chars': total_chars,
                'chars_no_spaces': chars_no_spaces,
                'total_words': total_words,
                'sentences': sentence_count,
                'paragraphs': paragraph_count,
                'avg_words_per_sentence': avg_words_per_sentence,
                'avg_chars_per_word': avg_chars_per_word,
                'avg_sentences_per_paragraph': avg_sentences_per_paragraph,
                'reading_time': reading_time,
                'most_common_words': most_common_words
            }
            
        except Exception as e:
            self.logger.error(f"Error calculando estadísticas: {e}")
            return {}
    
    async def health_check(self) -> str:
        """Verificar estado de Analytics Tools"""
        try:
            if not self.is_initialized:
                return "not_initialized"
            
            # Test básico de funcionalidad
            test_result = self._analyze_sentiment_basic("texto de prueba positivo", "es")
            
            return "healthy"
            
        except Exception as e:
            return f"error: {str(e)}"
    
    async def close(self) -> None:
        """Cerrar Analytics Tools"""
        try:
            await super().close()
            self.logger.info("Analytics Tools cerradas")
        except Exception as e:
            self.logger.error(f"Error cerrando Analytics: {e}")
