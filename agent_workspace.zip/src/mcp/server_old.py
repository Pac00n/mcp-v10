#!/usr/bin/env python3
"""
Servidor MCP Principal con Herramientas Múltiples
Integra SerpAPI, Gmail, Google Calendar con selección automática de herramientas
"""

import asyncio
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional, Any, Union
import uvicorn

# Agregar el directorio raíz al path para importaciones
sys.path.append(str(Path(__file__).parent.parent.parent))

from mcp import FastMCP
from mcp.types import Resource, Tool, Prompt

from src.core.config import get_settings
from src.core.logging_config import get_logger, performance_logger
from src.core.exceptions import *
from src.core.constants import AVAILABLE_TOOLS
from .tools.serpapi_tools import SerpAPITools
from .tools.gmail_tools import GmailTools
from .tools.calendar_tools import CalendarTools
from .tools.analytics_tools import AnalyticsTools
from .tools.workflow_tools import WorkflowTools
from .auth.oauth_manager import OAuthManager
from ..utils.cache import CacheManager


class MCPServerManager:
    """
    Gestor del servidor MCP que integra todas las herramientas
    y proporciona selección automática basada en contexto
    """
    
    def __init__(self):
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        # Crear servidor FastMCP
        self.mcp = FastMCP("chat-assistant-pro")
        
        # Componentes
        self.oauth_manager = OAuthManager()
        self.cache_manager = CacheManager()
        
        # Herramientas
        self.serpapi_tools = SerpAPITools()
        self.gmail_tools = GmailTools()
        self.calendar_tools = CalendarTools()
        self.analytics_tools = AnalyticsTools()
        self.workflow_tools = WorkflowTools()
        
        # Estado del servidor
        self.is_initialized = False
        self.available_tools: Dict[str, Any] = {}
        
        self.logger.info("MCPServerManager inicializado")
    
    async def initialize(self) -> None:
        """Inicializar servidor y todos los componentes"""
        try:
            self.logger.info("Inicializando servidor MCP...")
            
            # Inicializar componentes
            await self.cache_manager.initialize()
            await self.oauth_manager.initialize()
            
            # Inicializar herramientas
            await self._initialize_tools()
            
            # Registrar herramientas en el servidor MCP
            await self._register_tools()
            
            # Registrar recursos y prompts
            await self._register_resources()
            await self._register_prompts()
            
            self.is_initialized = True
            self.logger.info("Servidor MCP inicializado correctamente")
            
        except Exception as e:
            self.logger.error(f"Error inicializando servidor MCP: {e}")
            raise MCPServerError(f"Failed to initialize MCP server: {e}")
    
    async def _initialize_tools(self) -> None:
        """Inicializar todas las herramientas"""
        tools_to_init = [
            ("SerpAPI", self.serpapi_tools),
            ("Gmail", self.gmail_tools),
            ("Calendar", self.calendar_tools),
            ("Analytics", self.analytics_tools),
            ("Workflow", self.workflow_tools)
        ]
        
        for tool_name, tool_instance in tools_to_init:
            try:
                await tool_instance.initialize()
                self.logger.info(f"Herramienta {tool_name} inicializada")
            except Exception as e:
                self.logger.warning(f"Error inicializando {tool_name}: {e}")
    
    async def _register_tools(self) -> None:
        """Registrar todas las herramientas en el servidor MCP"""
        
        # ========== HERRAMIENTAS DE BÚSQUEDA ==========
        
        @self.mcp.tool()
        async def buscar_informacion(
            query: str,
            tipo: str = "web",
            region: str = "es",
            limite: int = 10
        ) -> str:
            """
            Buscar información usando SerpAPI
            
            Args:
                query: Términos de búsqueda
                tipo: Tipo de búsqueda (web, news, scholar, images)
                region: Región para la búsqueda (es, us, uk, etc.)
                limite: Número máximo de resultados
            
            Returns:
                Resultados de búsqueda formateados
            """
            try:
                start_time = asyncio.get_event_loop().time()
                
                result = await self.serpapi_tools.search(
                    query=query,
                    search_type=tipo,
                    region=region,
                    limit=limite
                )
                
                duration = asyncio.get_event_loop().time() - start_time
                performance_logger.log_tool_execution("buscar_informacion", duration, True)
                
                return result
                
            except Exception as e:
                self.logger.error(f"Error en búsqueda: {e}")
                raise MCPToolExecutionError(f"Search failed: {e}")
        
        @self.mcp.tool()
        async def buscar_noticias(
            query: str,
            region: str = "es",
            fecha: str = "ultima_semana",
            limite: int = 10
        ) -> str:
            """
            Buscar noticias actuales
            
            Args:
                query: Términos de búsqueda para noticias
                region: Región para las noticias
                fecha: Período de tiempo (ultima_semana, ultimo_mes, etc.)
                limite: Número de noticias
            
            Returns:
                Noticias formateadas con títulos, fuentes y fechas
            """
            try:
                result = await self.serpapi_tools.search_news(
                    query=query,
                    region=region,
                    time_period=fecha,
                    limit=limite
                )
                return result
            except Exception as e:
                self.logger.error(f"Error buscando noticias: {e}")
                raise MCPToolExecutionError(f"News search failed: {e}")
        
        @self.mcp.tool()
        async def buscar_academico(
            query: str,
            año_desde: Optional[int] = None,
            autor: Optional[str] = None,
            limite: int = 10
        ) -> str:
            """
            Buscar artículos académicos en Google Scholar
            
            Args:
                query: Términos de búsqueda académicos
                año_desde: Año mínimo de publicación
                autor: Filtrar por autor específico
                limite: Número de artículos
            
            Returns:
                Artículos académicos con autores, citas y enlaces
            """
            try:
                result = await self.serpapi_tools.search_scholar(
                    query=query,
                    year_from=año_desde,
                    author=autor,
                    limit=limite
                )
                return result
            except Exception as e:
                self.logger.error(f"Error búsqueda académica: {e}")
                raise MCPToolExecutionError(f"Academic search failed: {e}")
        
        # ========== HERRAMIENTAS DE EMAIL ==========
        
        @self.mcp.tool()
        async def gestionar_email(
            accion: str,
            destinatario: Optional[str] = None,
            asunto: Optional[str] = None,
            contenido: Optional[str] = None,
            filtro_busqueda: Optional[str] = None,
            limite: int = 10
        ) -> str:
            """
            Gestionar operaciones de email con Gmail
            
            Args:
                accion: Tipo de acción (enviar, buscar, leer, listar)
                destinatario: Email del destinatario (para enviar)
                asunto: Asunto del email
                contenido: Contenido del mensaje
                filtro_busqueda: Filtro para buscar emails
                limite: Número máximo de emails a procesar
            
            Returns:
                Resultado de la operación de email
            """
            try:
                if accion == "enviar":
                    if not all([destinatario, asunto, contenido]):
                        raise ValidationError("Para enviar email se requiere destinatario, asunto y contenido")
                    
                    result = await self.gmail_tools.send_email(
                        to=destinatario,
                        subject=asunto,
                        body=contenido
                    )
                
                elif accion == "buscar":
                    result = await self.gmail_tools.search_emails(
                        query=filtro_busqueda or "",
                        limit=limite
                    )
                
                elif accion == "leer":
                    result = await self.gmail_tools.read_email(
                        subject_filter=asunto or filtro_busqueda
                    )
                
                elif accion == "listar":
                    result = await self.gmail_tools.list_emails(limit=limite)
                
                else:
                    raise ValidationError(f"Acción no válida: {accion}")
                
                return result
                
            except Exception as e:
                self.logger.error(f"Error gestionando email: {e}")
                raise MCPToolExecutionError(f"Email operation failed: {e}")
        
        # ========== HERRAMIENTAS DE CALENDARIO ==========
        
        @self.mcp.tool()
        async def gestionar_calendario(
            accion: str,
            titulo: Optional[str] = None,
            fecha: Optional[str] = None,
            hora: Optional[str] = None,
            duracion: int = 60,
            descripcion: Optional[str] = None,
            evento_id: Optional[str] = None
        ) -> str:
            """
            Gestionar operaciones de Google Calendar
            
            Args:
                accion: Tipo de acción (crear, listar, eliminar, buscar)
                titulo: Título del evento
                fecha: Fecha del evento (YYYY-MM-DD)
                hora: Hora del evento (HH:MM)
                duracion: Duración en minutos
                descripcion: Descripción del evento
                evento_id: ID del evento (para eliminar)
            
            Returns:
                Resultado de la operación de calendario
            """
            try:
                if accion == "crear":
                    if not all([titulo, fecha, hora]):
                        raise ValidationError("Para crear evento se requiere título, fecha y hora")
                    
                    result = await self.calendar_tools.create_event(
                        title=titulo,
                        date=fecha,
                        time=hora,
                        duration_minutes=duracion,
                        description=descripcion
                    )
                
                elif accion == "listar":
                    result = await self.calendar_tools.list_events(
                        start_date=fecha,
                        limit=10
                    )
                
                elif accion == "eliminar":
                    if not evento_id:
                        raise ValidationError("Para eliminar evento se requiere evento_id")
                    
                    result = await self.calendar_tools.delete_event(event_id=evento_id)
                
                elif accion == "buscar":
                    result = await self.calendar_tools.search_events(
                        query=titulo or "",
                        start_date=fecha
                    )
                
                else:
                    raise ValidationError(f"Acción no válida: {accion}")
                
                return result
                
            except Exception as e:
                self.logger.error(f"Error gestionando calendario: {e}")
                raise MCPToolExecutionError(f"Calendar operation failed: {e}")
        
        # ========== HERRAMIENTAS DE ANÁLISIS ==========
        
        @self.mcp.tool()
        async def analizar_sentimiento(
            texto: str,
            idioma: str = "es"
        ) -> str:
            """
            Analizar el sentimiento de un texto
            
            Args:
                texto: Texto a analizar
                idioma: Idioma del texto
            
            Returns:
                Análisis de sentimiento con score y clasificación
            """
            try:
                result = await self.analytics_tools.analyze_sentiment(
                    text=texto,
                    language=idioma
                )
                return result
            except Exception as e:
                self.logger.error(f"Error analizando sentimiento: {e}")
                raise MCPToolExecutionError(f"Sentiment analysis failed: {e}")
        
        @self.mcp.tool()
        async def generar_resumen(
            contenido: str,
            longitud: str = "medio",
            estilo: str = "profesional"
        ) -> str:
            """
            Generar resumen inteligente de contenido
            
            Args:
                contenido: Contenido a resumir
                longitud: Longitud del resumen (corto, medio, largo)
                estilo: Estilo del resumen (profesional, casual, académico)
            
            Returns:
                Resumen del contenido
            """
            try:
                result = await self.analytics_tools.generate_summary(
                    content=contenido,
                    length=longitud,
                    style=estilo
                )
                return result
            except Exception as e:
                self.logger.error(f"Error generando resumen: {e}")
                raise MCPToolExecutionError(f"Summary generation failed: {e}")
        
        # ========== FLUJOS DE TRABAJO ==========
        
        @self.mcp.tool()
        async def flujo_investigacion(
            tema: str,
            profundidad: str = "medio",
            incluir_academico: bool = True,
            incluir_noticias: bool = True,
            formato_salida: str = "completo"
        ) -> str:
            """
            Flujo completo de investigación automatizada
            
            Args:
                tema: Tema a investigar
                profundidad: Nivel de profundidad (básico, medio, avanzado)
                incluir_academico: Incluir búsqueda académica
                incluir_noticias: Incluir noticias actuales
                formato_salida: Formato del reporte (completo, resumen, puntos)
            
            Returns:
                Reporte completo de investigación
            """
            try:
                result = await self.workflow_tools.research_workflow(
                    topic=tema,
                    depth=profundidad,
                    include_academic=incluir_academico,
                    include_news=incluir_noticias,
                    output_format=formato_salida
                )
                return result
            except Exception as e:
                self.logger.error(f"Error en flujo de investigación: {e}")
                raise MCPToolExecutionError(f"Research workflow failed: {e}")
        
        @self.mcp.tool()
        async def flujo_comunicacion(
            tipo: str,
            destinatario: str,
            contenido: str,
            programar: bool = False,
            fecha_programada: Optional[str] = None
        ) -> str:
            """
            Flujo de comunicación automatizada
            
            Args:
                tipo: Tipo de comunicación (email, reunion)
                destinatario: Destinatario de la comunicación
                contenido: Contenido o tema de la comunicación
                programar: Si se debe programar para después
                fecha_programada: Fecha para programar (YYYY-MM-DD HH:MM)
            
            Returns:
                Resultado del flujo de comunicación
            """
            try:
                result = await self.workflow_tools.communication_workflow(
                    communication_type=tipo,
                    recipient=destinatario,
                    content=contenido,
                    schedule=programar,
                    scheduled_time=fecha_programada
                )
                return result
            except Exception as e:
                self.logger.error(f"Error en flujo de comunicación: {e}")
                raise MCPToolExecutionError(f"Communication workflow failed: {e}")
        
        # Actualizar herramientas disponibles
        self.available_tools = {
            "buscar_informacion": buscar_informacion,
            "buscar_noticias": buscar_noticias,
            "buscar_academico": buscar_academico,
            "gestionar_email": gestionar_email,
            "gestionar_calendario": gestionar_calendario,
            "analizar_sentimiento": analizar_sentimiento,
            "generar_resumen": generar_resumen,
            "flujo_investigacion": flujo_investigacion,
            "flujo_comunicacion": flujo_comunicacion
        }
        
        self.logger.info(f"Registradas {len(self.available_tools)} herramientas MCP")
    
    async def _register_resources(self) -> None:
        """Registrar recursos MCP"""
        
        @self.mcp.resource("system://status")
        async def system_status() -> str:
            """Estado del sistema MCP"""
            status = await self.health_check()
            return f"Sistema MCP Status: {status}"
        
        @self.mcp.resource("tools://list")
        async def tools_list() -> str:
            """Lista de herramientas disponibles"""
            tools_info = []
            for tool_name, tool_config in AVAILABLE_TOOLS.items():
                tools_info.append(f"• {tool_name}: {tool_config['description']}")
            
            return "Herramientas disponibles:\n" + "\n".join(tools_info)
        
        @self.mcp.resource("config://current")
        async def current_config() -> str:
            """Configuración actual del sistema"""
            return f"Configuración MCP:\n- Entorno: {self.settings.environment}\n- Herramientas: {len(self.available_tools)}"
    
    async def _register_prompts(self) -> None:
        """Registrar prompts MCP"""
        
        @self.mcp.prompt("ayuda_herramientas")
        async def help_tools_prompt() -> str:
            """Prompt de ayuda para herramientas"""
            return """
            Herramientas disponibles en el sistema MCP:
            
            🔍 BÚSQUEDA:
            - buscar_informacion: Búsqueda web general
            - buscar_noticias: Noticias actuales
            - buscar_academico: Artículos académicos
            
            📧 COMUNICACIÓN:
            - gestionar_email: Operaciones de Gmail
            - gestionar_calendario: Gestión de Google Calendar
            
            🧠 ANÁLISIS:
            - analizar_sentimiento: Análisis de sentimientos
            - generar_resumen: Resúmenes inteligentes
            
            🔄 FLUJOS:
            - flujo_investigacion: Investigación completa
            - flujo_comunicacion: Comunicación automatizada
            
            Usa estas herramientas para resolver tareas complejas de manera eficiente.
            """
    
    async def select_tools_for_query(self, query: str, context: Optional[Dict] = None) -> List[str]:
        """
        Seleccionar herramientas apropiadas basadas en la consulta
        
        Args:
            query: Consulta del usuario
            context: Contexto adicional
        
        Returns:
            Lista de nombres de herramientas recomendadas
        """
        try:
            # Análisis básico de intención
            query_lower = query.lower()
            selected_tools = []
            
            # Patrones de búsqueda
            search_keywords = ["buscar", "busca", "encuentra", "información", "datos", "qué es", "definición"]
            if any(keyword in query_lower for keyword in search_keywords):
                if "noticias" in query_lower or "actualidad" in query_lower:
                    selected_tools.append("buscar_noticias")
                elif "académico" in query_lower or "paper" in query_lower or "estudio" in query_lower:
                    selected_tools.append("buscar_academico")
                else:
                    selected_tools.append("buscar_informacion")
            
            # Patrones de email
            email_keywords = ["email", "correo", "mail", "enviar", "mensaje", "escribir email"]
            if any(keyword in query_lower for keyword in email_keywords):
                selected_tools.append("gestionar_email")
            
            # Patrones de calendario
            calendar_keywords = ["calendario", "cita", "reunión", "evento", "agendar", "programar"]
            if any(keyword in query_lower for keyword in calendar_keywords):
                selected_tools.append("gestionar_calendario")
            
            # Patrones de análisis
            analysis_keywords = ["analizar", "sentimiento", "resumen", "resumir"]
            if any(keyword in query_lower for keyword in analysis_keywords):
                if "sentimiento" in query_lower:
                    selected_tools.append("analizar_sentimiento")
                elif "resumen" in query_lower or "resumir" in query_lower:
                    selected_tools.append("generar_resumen")
            
            # Patrones de flujos complejos
            if "investigar" in query_lower or "investigación" in query_lower:
                selected_tools.append("flujo_investigacion")
            
            if "comunicar" in query_lower and ("reunión" in query_lower or "email" in query_lower):
                selected_tools.append("flujo_comunicacion")
            
            # Si no se detecta patrón específico, usar búsqueda general
            if not selected_tools:
                selected_tools.append("buscar_informacion")
            
            self.logger.info(f"Herramientas seleccionadas para '{query[:50]}...': {selected_tools}")
            return selected_tools
            
        except Exception as e:
            self.logger.error(f"Error seleccionando herramientas: {e}")
            return ["buscar_informacion"]  # Fallback
    
    async def health_check(self) -> Dict[str, Any]:
        """Verificar estado del servidor MCP"""
        try:
            status = {
                "server": "healthy" if self.is_initialized else "initializing",
                "tools_count": len(self.available_tools),
                "components": {}
            }
            
            # Verificar componentes
            components = [
                ("serpapi", self.serpapi_tools),
                ("gmail", self.gmail_tools),
                ("calendar", self.calendar_tools),
                ("cache", self.cache_manager)
            ]
            
            for name, component in components:
                try:
                    if hasattr(component, 'health_check'):
                        component_status = await component.health_check()
                    else:
                        component_status = "unknown"
                    status["components"][name] = component_status
                except Exception as e:
                    status["components"][name] = f"error: {str(e)}"
            
            return status
            
        except Exception as e:
            return {"server": "error", "error": str(e)}
    
    async def run_server(self, host: str = "0.0.0.0", port: int = 8000):
        """Ejecutar servidor MCP"""
        try:
            if not self.is_initialized:
                await self.initialize()
            
            self.logger.info(f"Iniciando servidor MCP en {host}:{port}")
            
            # Ejecutar con FastMCP
            self.mcp.run(host=host, port=port)
            
        except Exception as e:
            self.logger.error(f"Error ejecutando servidor: {e}")
            raise MCPServerError(f"Failed to run server: {e}")
    
    async def shutdown(self):
        """Apagar servidor MCP"""
        try:
            self.logger.info("Apagando servidor MCP...")
            
            # Cerrar componentes
            if hasattr(self.cache_manager, 'close'):
                await self.cache_manager.close()
            
            if hasattr(self.oauth_manager, 'close'):
                await self.oauth_manager.close()
            
            self.is_initialized = False
            self.logger.info("Servidor MCP apagado correctamente")
            
        except Exception as e:
            self.logger.error(f"Error apagando servidor: {e}")


# Instancia global del servidor
mcp_server = MCPServerManager()


async def main():
    """Función principal para ejecutar el servidor"""
    try:
        settings = get_settings()
        
        # Inicializar y ejecutar servidor
        await mcp_server.run_server(
            host=settings.mcp.server_host,
            port=settings.mcp.server_port
        )
        
    except KeyboardInterrupt:
        print("\n⏹️  Deteniendo servidor...")
        await mcp_server.shutdown()
    except Exception as e:
        print(f"❌ Error ejecutando servidor: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(asyncio.run(main()))