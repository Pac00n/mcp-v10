"""
Gestor de autenticación OAuth2 para servicios Google
"""

import os
import asyncio
import json
from typing import Dict, List, Optional, Any
from pathlib import Path

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build

from ...core.config import get_settings
from ...core.logging_config import get_logger
from ...core.exceptions import AuthenticationError, AuthorizationError


class OAuthManager:
    """
    Gestor centralizado de autenticación OAuth2 para servicios Google
    """
    
    def __init__(self):
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        # Configuración OAuth
        self.oauth_file = self.settings.google.oauth_file
        self.credentials_dir = Path(self.settings.google.credentials_dir)
        self.scopes = self.settings.google.scopes
        
        # Estado de autenticación
        self.credentials: Optional[Credentials] = None
        self.services: Dict[str, Any] = {}
        self.is_authenticated = False
        
        self.logger.info("OAuthManager inicializado")
    
    async def initialize(self) -> None:
        """
        Inicializar gestor OAuth
        """
        try:
            # Crear directorio de credenciales si no existe
            self.credentials_dir.mkdir(parents=True, exist_ok=True)
            
            # Intentar cargar credenciales existentes
            await self._load_existing_credentials()
            
            self.logger.info("OAuthManager inicializado correctamente")
            
        except Exception as e:
            self.logger.error(f"Error inicializando OAuthManager: {e}")
            raise AuthenticationError(f"Failed to initialize OAuth: {e}")
    
    async def _load_existing_credentials(self) -> None:
        """
        Cargar credenciales existentes si están disponibles
        """
        try:
            token_file = self.credentials_dir / "token.json"
            
            if token_file.exists():
                self.credentials = Credentials.from_authorized_user_file(
                    str(token_file), 
                    self.scopes
                )
                
                # Verificar y refrescar si es necesario
                if not self.credentials.valid:
                    if self.credentials.expired and self.credentials.refresh_token:
                        self.credentials.refresh(Request())
                        
                        # Guardar credenciales actualizadas
                        await self._save_credentials()
                        
                        self.is_authenticated = True
                        self.logger.info("Credenciales OAuth refrescadas correctamente")
                    else:
                        self.logger.warning("Credenciales OAuth expiradas sin refresh token")
                        self.is_authenticated = False
                else:
                    self.is_authenticated = True
                    self.logger.info("Credenciales OAuth cargadas correctamente")
            else:
                self.logger.info("No se encontraron credenciales OAuth existentes")
                
        except Exception as e:
            self.logger.error(f"Error cargando credenciales: {e}")
            self.is_authenticated = False
    
    async def _save_credentials(self) -> None:
        """
        Guardar credenciales en archivo
        """
        try:
            if not self.credentials:
                return
            
            token_file = self.credentials_dir / "token.json"
            
            with open(token_file, 'w') as f:
                f.write(self.credentials.to_json())
            
            self.logger.info("Credenciales OAuth guardadas")
            
        except Exception as e:
            self.logger.error(f"Error guardando credenciales: {e}")
    
    async def authenticate(self) -> bool:
        """
        Realizar flujo de autenticación OAuth2
        
        Returns:
            True si la autenticación fue exitosa
        """
        try:
            if not os.path.exists(self.oauth_file):
                self.logger.error(f"Archivo OAuth no encontrado: {self.oauth_file}")
                return False
            
            # Crear flujo OAuth
            flow = Flow.from_client_secrets_file(
                self.oauth_file,
                scopes=self.scopes
            )
            
            # Configurar redirect URI para desarrollo local
            flow.redirect_uri = "http://localhost:8080"
            
            # Generar URL de autorización
            auth_url, _ = flow.authorization_url(
                access_type='offline',
                include_granted_scopes='true',
                prompt='consent'
            )
            
            self.logger.info("Flujo OAuth iniciado")
            print(f"\n🔐 Para autenticar con Google services:")
            print(f"1. Visita esta URL: {auth_url}")
            print(f"2. Autoriza la aplicación")
            print(f"3. Copia el código de autorización")
            
            # En un entorno real, esto se manejaría a través de un servidor web
            # Por ahora, solicitamos el código manualmente
            auth_code = input("\nIntroduce el código de autorización: ").strip()
            
            if not auth_code:
                self.logger.error("Código de autorización no proporcionado")
                return False
            
            # Intercambiar código por token
            flow.fetch_token(code=auth_code)
            
            self.credentials = flow.credentials
            
            # Guardar credenciales
            await self._save_credentials()
            
            self.is_authenticated = True
            self.logger.info("Autenticación OAuth completada exitosamente")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error en autenticación OAuth: {e}")
            return False
    
    async def ensure_authenticated(self, service_name: str = None) -> bool:
        """
        Asegurar que estamos autenticados, y autenticar si es necesario
        
        Args:
            service_name: Nombre del servicio que requiere autenticación
            
        Returns:
            True si la autenticación está disponible
        """
        try:
            if self.is_authenticated and self.credentials and self.credentials.valid:
                return True
            
            # Intentar cargar credenciales existentes
            await self._load_existing_credentials()
            
            if self.is_authenticated:
                return True
            
            # Si no hay credenciales válidas, mostrar mensaje
            self.logger.warning(
                f"Autenticación OAuth requerida para {service_name or 'Google services'}"
            )
            
            print(f"\n⚠️ Autenticación requerida para {service_name or 'Google services'}")
            print("Ejecuta el flujo de autenticación OAuth2 manualmente")
            print("o configura las credenciales en el directorio apropiado.")
            
            return False
            
        except Exception as e:
            self.logger.error(f"Error verificando autenticación: {e}")
            return False
    
    async def get_service(self, service_name: str, version: str) -> Optional[Any]:
        """
        Obtener servicio Google API autenticado
        
        Args:
            service_name: Nombre del servicio (gmail, calendar, etc.)
            version: Versión de la API
            
        Returns:
            Objeto de servicio autenticado o None
        """
        try:
            if not await self.ensure_authenticated(service_name):
                return None
            
            # Verificar si ya tenemos el servicio en caché
            service_key = f"{service_name}_{version}"
            if service_key in self.services:
                return self.services[service_key]
            
            # Crear nuevo servicio
            service = build(service_name, version, credentials=self.credentials)
            
            # Guardar en caché
            self.services[service_key] = service
            
            self.logger.info(f"Servicio {service_name} v{version} creado")
            
            return service
            
        except Exception as e:
            self.logger.error(f"Error creando servicio {service_name}: {e}")
            raise AuthenticationError(f"Failed to create {service_name} service: {e}")
    
    async def get_gmail_service(self):
        """
        Obtener servicio Gmail autenticado
        
        Returns:
            Servicio Gmail o None
        """
        return await self.get_service("gmail", "v1")
    
    async def get_calendar_service(self):
        """
        Obtener servicio Calendar autenticado
        
        Returns:
            Servicio Calendar o None
        """
        return await self.get_service("calendar", "v3")
    
    async def get_auth_status(self) -> Dict[str, Any]:
        """
        Obtener estado de autenticación
        
        Returns:
            Diccionario con estado de autenticación
        """
        try:
            status = {
                "google_authenticated": self.is_authenticated,
                "credentials_valid": False,
                "credentials_expired": False,
                "oauth_file_exists": os.path.exists(self.oauth_file),
                "services_available": list(self.services.keys())
            }
            
            if self.credentials:
                status["credentials_valid"] = self.credentials.valid
                status["credentials_expired"] = self.credentials.expired
            
            return status
            
        except Exception as e:
            self.logger.error(f"Error obteniendo estado de autenticación: {e}")
            return {
                "error": str(e),
                "google_authenticated": False
            }
    
    async def revoke_credentials(self) -> bool:
        """
        Revocar credenciales actuales
        
        Returns:
            True si se revocaron exitosamente
        """
        try:
            if self.credentials and self.credentials.valid:
                # Revocar token
                Request().post(
                    'https://oauth2.googleapis.com/revoke',
                    params={'token': self.credentials.token},
                    headers={'content-type': 'application/x-www-form-urlencoded'}
                )
            
            # Limpiar estado
            self.credentials = None
            self.services.clear()
            self.is_authenticated = False
            
            # Eliminar archivo de token
            token_file = self.credentials_dir / "token.json"
            if token_file.exists():
                token_file.unlink()
            
            self.logger.info("Credenciales revocadas exitosamente")
            return True
            
        except Exception as e:
            self.logger.error(f"Error revocando credenciales: {e}")
            return False
    
    async def close(self) -> None:
        """
        Cerrar gestor OAuth
        """
        try:
            # Limpiar servicios en caché
            self.services.clear()
            
            self.logger.info("OAuthManager cerrado")
            
        except Exception as e:
            self.logger.error(f"Error cerrando OAuthManager: {e}")
    
    def __del__(self):
        """Destructor para limpiar recursos"""
        try:
            # Solo limpiar servicios, no hacer operaciones async
            self.services.clear()
        except:
            pass