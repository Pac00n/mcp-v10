"""
Gestor de autenticación OAuth2 para servicios Google
"""

import os
import json
import asyncio
from pathlib import Path
from typing import Optional, Dict, Any, List
import threading
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build

from ...core.config import get_settings
from ...core.logging_config import get_logger
from ...core.exceptions import AuthenticationError, ConfigurationError


class OAuthCallbackHandler(BaseHTTPRequestHandler):
    """Handler para el callback de OAuth"""
    
    def do_GET(self):
        """Manejar GET request del callback"""
        parsed_url = urlparse(self.path)
        query_params = parse_qs(parsed_url.query)
        
        # Extraer código de autorización
        if 'code' in query_params:
            self.server.auth_code = query_params['code'][0]
            
            # Respuesta HTML simple
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            
            html_response = """
            <html>
            <head><title>Autenticación Completada</title></head>
            <body>
                <h2>✅ Autenticación exitosa</h2>
                <p>Ya puedes cerrar esta ventana y volver a la aplicación.</p>
                <script>window.close();</script>
            </body>
            </html>
            """
            self.wfile.write(html_response.encode('utf-8'))
        else:
            # Error en la autenticación
            self.send_response(400)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            
            error_html = """
            <html>
            <head><title>Error de Autenticación</title></head>
            <body>
                <h2>❌ Error en la autenticación</h2>
                <p>No se pudo completar la autenticación. Intenta de nuevo.</p>
            </body>
            </html>
            """
            self.wfile.write(error_html.encode('utf-8'))
    
    def log_message(self, format, *args):
        """Suprimir logs del servidor HTTP"""
        pass


class OAuthManager:
    """Gestor de autenticación OAuth2 para Google Services"""
    
    def __init__(self):
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        self.credentials: Optional[Credentials] = None
        self.oauth_config_file = self.settings.google.oauth_file
        self.credentials_dir = self.settings.google.credentials_dir
        self.scopes = self.settings.google.scopes
        
        # Configuración del servidor local para callback
        self.callback_port = 8080
        self.redirect_uri = f"http://localhost:{self.callback_port}"
        
        self.logger.info("OAuthManager inicializado")
    
    async def initialize(self) -> None:
        """Inicializar gestor OAuth"""
        try:
            # Verificar configuración
            await self._verify_configuration()
            
            # Cargar credenciales existentes si están disponibles
            await self._load_existing_credentials()
            
            self.logger.info("OAuthManager configurado correctamente")
            
        except Exception as e:
            self.logger.error(f"Error inicializando OAuthManager: {e}")
            raise AuthenticationError(f"Failed to initialize OAuth: {e}")
    
    async def _verify_configuration(self) -> None:
        """Verificar que la configuración OAuth esté presente"""
        # Verificar archivo de configuración OAuth
        if not os.path.exists(self.oauth_config_file):
            raise ConfigurationError(
                f"OAuth config file not found: {self.oauth_config_file}. "
                f"Please create it with your Google OAuth credentials."
            )
        
        # Crear directorio de credenciales si no existe
        Path(self.credentials_dir).mkdir(parents=True, exist_ok=True)
        
        # Verificar que el archivo OAuth tiene la estructura correcta
        try:
            with open(self.oauth_config_file, 'r') as f:
                oauth_config = json.load(f)
            
            if 'installed' not in oauth_config and 'web' not in oauth_config:
                raise ConfigurationError(
                    f"Invalid OAuth config format in {self.oauth_config_file}"
                )
                
        except json.JSONDecodeError as e:
            raise ConfigurationError(f"Invalid JSON in OAuth config: {e}")
    
    async def _load_existing_credentials(self) -> None:
        """Cargar credenciales existentes si están disponibles"""
        try:
            credentials_file = os.path.join(self.credentials_dir, "credentials.json")
            
            if os.path.exists(credentials_file):
                self.credentials = Credentials.from_authorized_user_file(
                    credentials_file, self.scopes
                )
                
                # Verificar si necesitan ser actualizadas
                if self.credentials and self.credentials.expired and self.credentials.refresh_token:
                    self.credentials.refresh(Request())
                    await self._save_credentials()
                    self.logger.info("Credenciales actualizadas automáticamente")
                
                if self.credentials and self.credentials.valid:
                    self.logger.info("Credenciales válidas cargadas")
                else:
                    self.credentials = None
                    self.logger.info("Credenciales inválidas, se requerirá nueva autenticación")
            else:
                self.logger.info("No hay credenciales guardadas")
                
        except Exception as e:
            self.logger.warning(f"Error cargando credenciales existentes: {e}")
            self.credentials = None
    
    async def get_credentials(self, force_refresh: bool = False) -> Optional[Credentials]:
        """
        Obtener credenciales válidas, autenticando si es necesario
        
        Args:
            force_refresh: Forzar nueva autenticación
        
        Returns:
            Credenciales válidas o None si falla
        """
        try:
            # Si ya tenemos credenciales válidas y no se fuerza refresh
            if not force_refresh and self.credentials and self.credentials.valid:
                return self.credentials
            
            # Intentar refrescar credenciales existentes
            if not force_refresh and self.credentials and self.credentials.expired and self.credentials.refresh_token:
                try:
                    self.credentials.refresh(Request())
                    await self._save_credentials()
                    self.logger.info("Credenciales refrescadas")
                    return self.credentials
                except Exception as e:
                    self.logger.warning(f"Error refrescando credenciales: {e}")
            
            # Realizar nueva autenticación
            self.logger.info("Iniciando proceso de autenticación OAuth")
            self.credentials = await self._perform_oauth_flow()
            
            if self.credentials:
                await self._save_credentials()
                self.logger.info("Autenticación OAuth completada exitosamente")
                return self.credentials
            else:
                self.logger.error("Autenticación OAuth falló")
                return None
                
        except Exception as e:
            self.logger.error(f"Error obteniendo credenciales: {e}")
            raise AuthenticationError(f"Failed to get credentials: {e}")
    
    async def _perform_oauth_flow(self) -> Optional[Credentials]:
        """Realizar flujo OAuth completo"""
        try:
            # Crear flujo OAuth
            flow = Flow.from_client_secrets_file(
                self.oauth_config_file,
                scopes=self.scopes
            )
            flow.redirect_uri = self.redirect_uri
            
            # Generar URL de autorización
            auth_url, _ = flow.authorization_url(
                access_type='offline',
                include_granted_scopes='true',
                prompt='consent'
            )
            
            self.logger.info("Abriendo navegador para autenticación...")
            print(f"\n🔐 Proceso de autenticación OAuth iniciado")
            print(f"📱 Se abrirá tu navegador automáticamente")
            print(f"🔗 Si no se abre, visita manualmente: {auth_url}")
            print(f"⏱️  Esperando autorización...")
            
            # Abrir navegador
            webbrowser.open(auth_url)
            
            # Iniciar servidor local para callback
            auth_code = await self._start_callback_server()
            
            if not auth_code:
                raise AuthenticationError("No authorization code received")
            
            # Intercambiar código por credenciales
            flow.fetch_token(code=auth_code)
            
            return flow.credentials
            
        except Exception as e:
            self.logger.error(f"Error en flujo OAuth: {e}")
            raise AuthenticationError(f"OAuth flow failed: {e}")
    
    async def _start_callback_server(self) -> Optional[str]:
        """Iniciar servidor local para recibir callback"""
        try:
            # Crear servidor HTTP
            server = HTTPServer(('localhost', self.callback_port), OAuthCallbackHandler)
            server.auth_code = None
            server.timeout = 300  # 5 minutos timeout
            
            self.logger.info(f"Servidor callback iniciado en puerto {self.callback_port}")
            
            # Ejecutar servidor en thread separado
            def run_server():
                server.handle_request()
            
            server_thread = threading.Thread(target=run_server)
            server_thread.daemon = True
            server_thread.start()
            
            # Esperar por el código de autorización
            max_wait = 300  # 5 minutos
            wait_interval = 1
            waited = 0
            
            while waited < max_wait:
                if hasattr(server, 'auth_code') and server.auth_code:
                    auth_code = server.auth_code
                    server.server_close()
                    print(f"✅ Autorización recibida exitosamente")
                    return auth_code
                
                await asyncio.sleep(wait_interval)
                waited += wait_interval
            
            # Timeout
            server.server_close()
            print(f"⏰ Timeout: No se recibió autorización en {max_wait} segundos")
            return None
            
        except Exception as e:
            self.logger.error(f"Error en servidor callback: {e}")
            return None
    
    async def _save_credentials(self) -> None:
        """Guardar credenciales en archivo"""
        try:
            if not self.credentials:
                return
            
            credentials_file = os.path.join(self.credentials_dir, "credentials.json")
            
            # Crear datos de credenciales
            creds_data = {
                'token': self.credentials.token,
                'refresh_token': self.credentials.refresh_token,
                'token_uri': self.credentials.token_uri,
                'client_id': self.credentials.client_id,
                'client_secret': self.credentials.client_secret,
                'scopes': self.credentials.scopes
            }
            
            # Guardar en archivo
            with open(credentials_file, 'w') as f:
                json.dump(creds_data, f, indent=2)
            
            # Establecer permisos restrictivos
            os.chmod(credentials_file, 0o600)
            
            self.logger.info(f"Credenciales guardadas en {credentials_file}")
            
        except Exception as e:
            self.logger.error(f"Error guardando credenciales: {e}")
            raise AuthenticationError(f"Failed to save credentials: {e}")
    
    async def revoke_credentials(self) -> bool:
        """Revocar credenciales actuales"""
        try:
            if not self.credentials:
                return True
            
            # Revocar token
            if self.credentials.token:
                import requests
                revoke_url = 'https://oauth2.googleapis.com/revoke'
                params = {'token': self.credentials.token}
                
                response = requests.post(revoke_url, params=params)
                if response.status_code == 200:
                    self.logger.info("Token revocado exitosamente")
                else:
                    self.logger.warning(f"Error revocando token: {response.status_code}")
            
            # Eliminar archivo de credenciales
            credentials_file = os.path.join(self.credentials_dir, "credentials.json")
            if os.path.exists(credentials_file):
                os.remove(credentials_file)
                self.logger.info("Archivo de credenciales eliminado")
            
            self.credentials = None
            return True
            
        except Exception as e:
            self.logger.error(f"Error revocando credenciales: {e}")
            return False
    
    async def test_credentials(self) -> Dict[str, Any]:
        """Probar credenciales con servicios Google"""
        try:
            credentials = await self.get_credentials()
            
            if not credentials:
                return {"status": "no_credentials", "services": {}}
            
            results = {"status": "testing", "services": {}}
            
            # Probar Gmail
            try:
                gmail_service = build('gmail', 'v1', credentials=credentials)
                profile = gmail_service.users().getProfile(userId='me').execute()
                results["services"]["gmail"] = {
                    "status": "ok",
                    "email": profile.get('emailAddress'),
                    "messages_total": profile.get('messagesTotal', 0)
                }
            except Exception as e:
                results["services"]["gmail"] = {"status": "error", "error": str(e)}
            
            # Probar Calendar
            try:
                calendar_service = build('calendar', 'v3', credentials=credentials)
                calendar = calendar_service.calendars().get(calendarId='primary').execute()
                results["services"]["calendar"] = {
                    "status": "ok",
                    "calendar_name": calendar.get('summary'),
                    "timezone": calendar.get('timeZone')
                }
            except Exception as e:
                results["services"]["calendar"] = {"status": "error", "error": str(e)}
            
            # Determinar estado general
            all_services_ok = all(
                service.get("status") == "ok" 
                for service in results["services"].values()
            )
            
            results["status"] = "healthy" if all_services_ok else "partial"
            
            return results
            
        except Exception as e:
            self.logger.error(f"Error probando credenciales: {e}")
            return {"status": "error", "error": str(e), "services": {}}
    
    async def get_user_info(self) -> Optional[Dict[str, Any]]:
        """Obtener información del usuario autenticado"""
        try:
            credentials = await self.get_credentials()
            
            if not credentials:
                return None
            
            # Obtener info de Gmail (incluye email del usuario)
            gmail_service = build('gmail', 'v1', credentials=credentials)
            profile = gmail_service.users().getProfile(userId='me').execute()
            
            return {
                "email": profile.get('emailAddress'),
                "messages_total": profile.get('messagesTotal', 0),
                "threads_total": profile.get('threadsTotal', 0),
                "history_id": profile.get('historyId')
            }
            
        except Exception as e:
            self.logger.error(f"Error obteniendo info del usuario: {e}")
            return None
    
    async def health_check(self) -> str:
        """Verificar estado del OAuth Manager"""
        try:
            if not os.path.exists(self.oauth_config_file):
                return "no_oauth_config"
            
            if not self.credentials:
                return "no_credentials"
            
            if not self.credentials.valid:
                return "credentials_invalid"
            
            return "healthy"
            
        except Exception as e:
            return f"error: {str(e)}"
    
    async def close(self) -> None:
        """Cerrar OAuth Manager"""
        try:
            # No hay recursos específicos que cerrar
            self.logger.info("OAuthManager cerrado")
        except Exception as e:
            self.logger.error(f"Error cerrando OAuthManager: {e}")
