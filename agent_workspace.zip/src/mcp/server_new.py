#!/usr/bin/env python3
"""
Servidor MCP Principal - Sistema Chat OpenAI + MCP
Implementa FastMCP con Streamable HTTP y herramientas especializadas
"""

import asyncio
import os
from typing import Dict, List, Optional, Any
from contextlib import asynccontextmanager

from mcp import FastMCP
from mcp.server.stdio import stdio_server

from ..core.config import get_settings
from ..core.logging_config import get_logger, performance_logger
from ..core.exceptions import MCPServerError, MCPToolError, handle_mcp_error
from ..core.constants import SYSTEM_NAME, SYSTEM_VERSION

from .tools.serpapi_tools import SerpAPITools
from .tools.gmail_tools import GmailTools
from .tools.calendar_tools import CalendarTools
from .tools.analytics_tools import AnalyticsTools
from .tools.workflow_tools import WorkflowTools
from .auth.oauth_manager import OAuthManager


class MCPServerManager:
    """
    Gestor del servidor MCP que orquesta todas las herramientas
    """
    
    def __init__(self):
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        # Crear servidor FastMCP
        self.mcp = FastMCP(
            name=f"{SYSTEM_NAME.lower()}-server",
            version=SYSTEM_VERSION
        )
        
        # Inicializar gestores de herramientas
        self.oauth_manager = OAuthManager()
        self.serpapi_tools = SerpAPITools()
        self.gmail_tools = GmailTools()
        self.calendar_tools = CalendarTools()
        self.analytics_tools = AnalyticsTools()
        self.workflow_tools = WorkflowTools()
        
        # Estado del servidor
        self.is_running = False
        self.tool_stats = {}
        
        self.logger.info("MCPServerManager inicializado")
    
    async def initialize(self) -> None:
        """Inicializar el servidor y todas las herramientas"""
        try:
            self.logger.info("Inicializando servidor MCP...")
            
            # Configurar OAuth para Google services
            await self.oauth_manager.initialize()
            
            # Configurar servicios de Google para las herramientas
            await self._configure_google_services()
            
            # Configurar workflow tools con referencias a otras herramientas
            self.workflow_tools.set_tools(
                self.serpapi_tools,
                self.gmail_tools,
                self.calendar_tools,
                self.analytics_tools
            )
            
            # Registrar todas las herramientas
            await self._register_tools()
            
            self.logger.info("Servidor MCP inicializado correctamente")
            
        except Exception as e:
            self.logger.error(f"Error inicializando servidor MCP: {e}")
            raise MCPServerError(f"Failed to initialize MCP server: {e}")
    
    async def _configure_google_services(self) -> None:
        """Configurar servicios de Google para las herramientas"""
        try:
            # Configurar Gmail si está disponible
            gmail_service = await self.oauth_manager.get_gmail_service()
            if gmail_service:
                self.gmail_tools.set_service(gmail_service)
                self.logger.info("Servicio Gmail configurado")
            
            # Configurar Calendar si está disponible
            calendar_service = await self.oauth_manager.get_calendar_service()
            if calendar_service:
                self.calendar_tools.set_service(calendar_service)
                self.logger.info("Servicio Calendar configurado")
                
        except Exception as e:
            self.logger.warning(f"Error configurando servicios Google: {e}")
            # No es fatal, las herramientas mostrarán errores apropiados
    
    async def _register_tools(self) -> None:
        """Registrar todas las herramientas MCP"""
        
        # ====================================================================
        # HERRAMIENTAS DE BÚSQUEDA (SerpAPI)
        # ====================================================================
        
        @self.mcp.tool()
        async def buscar_informacion(
            consulta: str,
            tipo: str = "web",
            num_resultados: int = 5,
            region: str = "es"
        ) -> str:
            """
            Busca información en la web usando SerpAPI.
            
            Args:
                consulta: Términos de búsqueda
                tipo: Tipo de búsqueda (web, news, scholar, images, videos)
                num_resultados: Número de resultados (máximo 10)
                region: Región para la búsqueda (es, us, uk, etc.)
            
            Returns:
                Resultados de búsqueda formateados
            """
            try:
                result = await self.serpapi_tools.search(
                    query=consulta,
                    search_type=tipo,
                    num_results=min(num_resultados, 10),
                    region=region
                )
                
                # Registrar estadísticas
                self._update_tool_stats("buscar_informacion", success=True)
                
                return result
                
            except Exception as e:
                self._update_tool_stats("buscar_informacion", success=False)
                self.logger.error(f"Error en buscar_informacion: {e}")
                raise MCPToolError(f"Error searching: {e}", tool_name="buscar_informacion")
        
        @self.mcp.tool()
        async def buscar_noticias(
            consulta: str,
            region: str = "es",
            num_resultados: int = 5,
            periodo: str = "24h"
        ) -> str:
            """
            Busca noticias actuales usando SerpAPI.
            
            Args:
                consulta: Términos de búsqueda para noticias
                region: Región (es, us, uk, etc.)
                num_resultados: Número de noticias (máximo 10)
                periodo: Periodo de tiempo (24h, 7d, 30d)
            
            Returns:
                Noticias formateadas con fechas y fuentes
            """
            try:
                result = await self.serpapi_tools.search_news(
                    query=consulta,
                    region=region,
                    num_results=min(num_resultados, 10),
                    time_period=periodo
                )
                
                self._update_tool_stats("buscar_noticias", success=True)
                return result
                
            except Exception as e:
                self._update_tool_stats("buscar_noticias", success=False)
                self.logger.error(f"Error en buscar_noticias: {e}")
                raise MCPToolError(f"Error searching news: {e}", tool_name="buscar_noticias")
        
        # ====================================================================
        # HERRAMIENTAS DE EMAIL (Gmail)
        # ====================================================================
        
        @self.mcp.tool()
        async def gestionar_email(
            accion: str,
            destinatario: str = None,
            asunto: str = None,
            cuerpo: str = None,
            consulta_busqueda: str = None,
            email_id: str = None,
            max_resultados: int = 10
        ) -> str:
            """
            Gestiona operaciones de email usando Gmail API.
            
            Args:
                accion: Operación (enviar, buscar, leer, listar, marcar_leido)
                destinatario: Email del destinatario (para enviar)
                asunto: Asunto del email (para enviar)
                cuerpo: Contenido del email (para enviar)
                consulta_busqueda: Consulta para buscar emails
                email_id: ID del email (para leer/marcar)
                max_resultados: Máximo de resultados para buscar/listar
            
            Returns:
                Resultado de la operación de email
            """
            try:
                # Asegurar autenticación OAuth
                if not await self.oauth_manager.ensure_authenticated("gmail"):
                    return "❌ Error: No se pudo autenticar con Gmail. Configura OAuth2."
                
                result = await self.gmail_tools.execute_action(
                    action=accion,
                    recipient=destinatario,
                    subject=asunto,
                    body=cuerpo,
                    search_query=consulta_busqueda,
                    email_id=email_id,
                    max_results=min(max_resultados, 50)
                )
                
                self._update_tool_stats("gestionar_email", success=True)
                return result
                
            except Exception as e:
                self._update_tool_stats("gestionar_email", success=False)
                self.logger.error(f"Error en gestionar_email: {e}")
                raise MCPToolError(f"Error managing email: {e}", tool_name="gestionar_email")
        
        # ====================================================================
        # HERRAMIENTAS DE CALENDARIO (Google Calendar)
        # ====================================================================
        
        @self.mcp.tool()
        async def gestionar_calendario(
            accion: str,
            titulo: str = None,
            fecha_inicio: str = None,
            fecha_fin: str = None,
            descripcion: str = None,
            invitados: List[str] = None,
            evento_id: str = None,
            calendario_id: str = "primary",
            dias_adelante: int = 30
        ) -> str:
            """
            Gestiona operaciones de Google Calendar.
            
            Args:
                accion: Operación (crear, listar, eliminar, actualizar, buscar)
                titulo: Título del evento (para crear/actualizar)
                fecha_inicio: Fecha/hora inicio (ISO format o 'YYYY-MM-DD HH:MM')
                fecha_fin: Fecha/hora fin (ISO format o 'YYYY-MM-DD HH:MM')
                descripcion: Descripción del evento
                invitados: Lista de emails para invitar
                evento_id: ID del evento (para eliminar/actualizar)
                calendario_id: ID del calendario ('primary' por defecto)
                dias_adelante: Días hacia adelante para listar eventos
            
            Returns:
                Resultado de la operación de calendario
            """
            try:
                # Asegurar autenticación OAuth
                if not await self.oauth_manager.ensure_authenticated("calendar"):
                    return "❌ Error: No se pudo autenticar con Google Calendar. Configura OAuth2."
                
                result = await self.calendar_tools.execute_action(
                    action=accion,
                    title=titulo,
                    start_datetime=fecha_inicio,
                    end_datetime=fecha_fin,
                    description=descripcion,
                    attendees=invitados or [],
                    event_id=evento_id,
                    calendar_id=calendario_id,
                    days_ahead=dias_adelante
                )
                
                self._update_tool_stats("gestionar_calendario", success=True)
                return result
                
            except Exception as e:
                self._update_tool_stats("gestionar_calendario", success=False)
                self.logger.error(f"Error en gestionar_calendario: {e}")
                raise MCPToolError(f"Error managing calendar: {e}", tool_name="gestionar_calendario")
        
        # ====================================================================
        # HERRAMIENTAS DE ANÁLISIS
        # ====================================================================
        
        @self.mcp.tool()
        async def analizar_sentimiento(
            texto: str,
            idioma: str = "es",
            incluir_entidades: bool = False
        ) -> str:
            """
            Analiza el sentimiento de un texto.
            
            Args:
                texto: Texto a analizar
                idioma: Idioma del texto (es, en, fr, etc.)
                incluir_entidades: Si incluir análisis de entidades
            
            Returns:
                Análisis de sentimiento y entidades (opcional)
            """
            try:
                result = await self.analytics_tools.analyze_sentiment(
                    text=texto,
                    language=idioma,
                    include_entities=incluir_entidades
                )
                
                self._update_tool_stats("analizar_sentimiento", success=True)
                return result
                
            except Exception as e:
                self._update_tool_stats("analizar_sentimiento", success=False)
                self.logger.error(f"Error en analizar_sentimiento: {e}")
                raise MCPToolError(f"Error analyzing sentiment: {e}", tool_name="analizar_sentimiento")
        
        @self.mcp.tool()
        async def generar_resumen(
            contenido: str,
            longitud: str = "medio",
            estilo: str = "neutro",
            idioma: str = "es"
        ) -> str:
            """
            Genera un resumen del contenido proporcionado.
            
            Args:
                contenido: Texto a resumir
                longitud: Longitud del resumen (corto, medio, largo)
                estilo: Estilo del resumen (neutro, formal, casual)
                idioma: Idioma de salida
            
            Returns:
                Resumen generado del contenido
            """
            try:
                result = await self.analytics_tools.generate_summary(
                    content=contenido,
                    length=longitud,
                    style=estilo,
                    language=idioma
                )
                
                self._update_tool_stats("generar_resumen", success=True)
                return result
                
            except Exception as e:
                self._update_tool_stats("generar_resumen", success=False)
                self.logger.error(f"Error en generar_resumen: {e}")
                raise MCPToolError(f"Error generating summary: {e}", tool_name="generar_resumen")
        
        # ====================================================================
        # HERRAMIENTAS DE FLUJO DE TRABAJO
        # ====================================================================
        
        @self.mcp.tool()
        async def flujo_investigacion_completo(
            tema: str,
            profundidad: str = "normal",
            incluir_noticias: bool = True,
            incluir_academico: bool = False,
            enviar_por_email: bool = False,
            destinatario_email: str = None
        ) -> str:
            """
            Ejecuta un flujo completo de investigación sobre un tema.
            
            Args:
                tema: Tema a investigar
                profundidad: Nivel de profundidad (basico, normal, detallado)
                incluir_noticias: Si incluir noticias actuales
                incluir_academico: Si incluir búsqueda académica
                enviar_por_email: Si enviar resultado por email
                destinatario_email: Email del destinatario
            
            Returns:
                Informe completo de investigación
            """
            try:
                result = await self.workflow_tools.research_workflow(
                    topic=tema,
                    depth=profundidad,
                    include_news=incluir_noticias,
                    include_academic=incluir_academico,
                    email_report=enviar_por_email,
                    recipient_email=destinatario_email
                )
                
                self._update_tool_stats("flujo_investigacion_completo", success=True)
                return result
                
            except Exception as e:
                self._update_tool_stats("flujo_investigacion_completo", success=False)
                self.logger.error(f"Error en flujo_investigacion_completo: {e}")
                raise MCPToolError(f"Error in research workflow: {e}", tool_name="flujo_investigacion_completo")
        
        # ====================================================================
        # HERRAMIENTA DE ESTADO DEL SISTEMA
        # ====================================================================
        
        @self.mcp.tool()
        async def estado_sistema() -> str:
            """
            Obtiene el estado actual del sistema MCP y sus herramientas.
            
            Returns:
                Resumen del estado del sistema
            """
            try:
                auth_status = await self.oauth_manager.get_auth_status()
                
                status_report = f"🤖 **Estado del Sistema {SYSTEM_NAME} v{SYSTEM_VERSION}**\n\n"
                status_report += f"🟢 Servidor MCP: {'Activo' if self.is_running else 'Inactivo'}\n"
                status_report += f"🔑 Autenticación Google: {'✅ Activa' if auth_status.get('google_authenticated') else '❌ Inactiva'}\n"
                status_report += f"🔍 SerpAPI: {'✅ Configurada' if self.settings.serpapi.api_key else '❌ No configurada'}\n\n"
                
                if self.tool_stats:
                    status_report += "📊 **Estadísticas de Herramientas:**\n"
                    for tool, stats in self.tool_stats.items():
                        success_rate = (stats.get('success', 0) / max(stats.get('total', 1), 1)) * 100
                        status_report += f"• {tool}: {stats.get('total', 0)} usos ({success_rate:.1f}% éxito)\n"
                
                return status_report
                
            except Exception as e:
                self.logger.error(f"Error obteniendo estado del sistema: {e}")
                return f"❌ Error obteniendo estado: {str(e)}"
        
        self.logger.info("Todas las herramientas MCP registradas")
    
    def _update_tool_stats(self, tool_name: str, success: bool) -> None:
        """Actualizar estadísticas de uso de herramientas"""
        if tool_name not in self.tool_stats:
            self.tool_stats[tool_name] = {"total": 0, "success": 0, "errors": 0}
        
        self.tool_stats[tool_name]["total"] += 1
        if success:
            self.tool_stats[tool_name]["success"] += 1
        else:
            self.tool_stats[tool_name]["errors"] += 1
    
    async def start_server(self, use_stdio: bool = True, host: str = None, port: int = None) -> None:
        """Iniciar el servidor MCP"""
        try:
            self.is_running = True
            
            if use_stdio:
                # Modo stdio para integración directa
                self.logger.info("Iniciando servidor MCP en modo stdio...")
                async with stdio_server() as (read_stream, write_stream):
                    await self.mcp.run(read_stream, write_stream)
            else:
                # Modo HTTP para desarrollo/debug
                host = host or self.settings.mcp.server_host
                port = port or self.settings.mcp.server_port
                
                self.logger.info(f"Iniciando servidor MCP HTTP en {host}:{port}...")
                await self.mcp.run_http(host=host, port=port)
                
        except Exception as e:
            self.is_running = False
            self.logger.error(f"Error iniciando servidor MCP: {e}")
            raise MCPServerError(f"Failed to start MCP server: {e}")
    
    async def shutdown(self) -> None:
        """Apagar el servidor MCP"""
        try:
            self.logger.info("Apagando servidor MCP...")
            self.is_running = False
            
            # Cerrar conexiones OAuth
            await self.oauth_manager.close()
            
            self.logger.info("Servidor MCP apagado correctamente")
            
        except Exception as e:
            self.logger.error(f"Error apagando servidor MCP: {e}")
    
    async def health_check(self) -> Dict[str, Any]:
        """Health check del servidor"""
        try:
            auth_status = await self.oauth_manager.get_auth_status()
            
            return {
                "status": "healthy" if self.is_running else "stopped",
                "version": SYSTEM_VERSION,
                "tools_registered": len(self.tool_stats),
                "authentication": auth_status,
                "serpapi_configured": bool(self.settings.serpapi.api_key),
                "uptime": True  # TODO: implementar uptime real
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }


# Instancia global del servidor
mcp_server_manager = MCPServerManager()


async def main():
    """Función principal para ejecutar el servidor"""
    try:
        # Inicializar servidor
        await mcp_server_manager.initialize()
        
        # Determinar modo de ejecución
        use_stdio = os.getenv("MCP_STDIO_MODE", "true").lower() == "true"
        
        # Iniciar servidor
        await mcp_server_manager.start_server(use_stdio=use_stdio)
        
    except KeyboardInterrupt:
        print("\n🛑 Interrupción del usuario")
    except Exception as e:
        print(f"❌ Error fatal: {e}")
    finally:
        await mcp_server_manager.shutdown()


if __name__ == "__main__":
    asyncio.run(main())