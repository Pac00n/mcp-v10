#!/usr/bin/env python3
"""
Servidor MCP Principal - Sistema Chat OpenAI + MCP
Implementa servidor MCP estándar con herramientas especializadas
"""

import asyncio
import json
from typing import Dict, List, Optional, Any, Sequence
from contextlib import asynccontextmanager

# Imports MCP estándar
from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool, 
    TextContent, 
    ImageContent, 
    EmbeddedResource,
    CallToolRequest,
    ListToolsRequest
)

from ..core.config import get_settings
from ..core.logging_config import get_logger, performance_logger
from ..core.exceptions import MCPServerError, MCPToolError
from ..core.constants import SYSTEM_NAME, SYSTEM_VERSION

from .tools.serpapi_tools import SerpAPITools
from .tools.gmail_tools import GmailTools
from .tools.calendar_tools import CalendarTools
from .tools.analytics_tools import AnalyticsTools
from .tools.workflow_tools import WorkflowTools
from .auth.oauth_manager import OAuthManager


class MCPChatServer:
    """
    Servidor MCP para sistema de chat con herramientas múltiples
    """
    
    def __init__(self):
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        # Crear servidor MCP
        self.server = Server(f"{SYSTEM_NAME.lower()}-server")
        
        # Inicializar gestores de herramientas
        self.oauth_manager = OAuthManager()
        self.serpapi_tools = SerpAPITools()
        self.gmail_tools = GmailTools()
        self.calendar_tools = CalendarTools()
        self.analytics_tools = AnalyticsTools()
        self.workflow_tools = WorkflowTools()
        
        # Estado del servidor
        self.is_running = False
        self.tool_stats = {}
        
        # Configurar handlers del servidor
        self._setup_server_handlers()
        
        self.logger.info("MCPChatServer inicializado")
    
    def _setup_server_handlers(self):
        """Configurar handlers del servidor MCP"""
        
        @self.server.list_tools()
        async def handle_list_tools() -> List[Tool]:
            """Listar herramientas disponibles"""
            return [
                Tool(
                    name="buscar_informacion",
                    description="Busca información en la web usando SerpAPI",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "consulta": {
                                "type": "string",
                                "description": "Términos de búsqueda"
                            },
                            "tipo": {
                                "type": "string",
                                "enum": ["web", "news", "scholar", "images", "videos"],
                                "default": "web",
                                "description": "Tipo de búsqueda"
                            },
                            "num_resultados": {
                                "type": "integer",
                                "minimum": 1,
                                "maximum": 10,
                                "default": 5,
                                "description": "Número de resultados"
                            },
                            "region": {
                                "type": "string",
                                "default": "es",
                                "description": "Región para la búsqueda"
                            }
                        },
                        "required": ["consulta"]
                    }
                ),
                Tool(
                    name="buscar_noticias",
                    description="Busca noticias actuales usando SerpAPI",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "consulta": {
                                "type": "string",
                                "description": "Términos de búsqueda para noticias"
                            },
                            "region": {
                                "type": "string",
                                "default": "es",
                                "description": "Región"
                            },
                            "num_resultados": {
                                "type": "integer",
                                "minimum": 1,
                                "maximum": 10,
                                "default": 5,
                                "description": "Número de noticias"
                            },
                            "periodo": {
                                "type": "string",
                                "enum": ["24h", "7d", "30d"],
                                "default": "24h",
                                "description": "Periodo de tiempo"
                            }
                        },
                        "required": ["consulta"]
                    }
                ),
                Tool(
                    name="gestionar_email",
                    description="Gestiona operaciones de email usando Gmail API",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "accion": {
                                "type": "string",
                                "enum": ["enviar", "buscar", "leer", "listar", "marcar_leido"],
                                "description": "Operación a realizar"
                            },
                            "destinatario": {
                                "type": "string",
                                "description": "Email del destinatario (para enviar)"
                            },
                            "asunto": {
                                "type": "string",
                                "description": "Asunto del email (para enviar)"
                            },
                            "cuerpo": {
                                "type": "string",
                                "description": "Contenido del email (para enviar)"
                            },
                            "consulta_busqueda": {
                                "type": "string",
                                "description": "Consulta para buscar emails"
                            },
                            "email_id": {
                                "type": "string",
                                "description": "ID del email (para leer/marcar)"
                            },
                            "max_resultados": {
                                "type": "integer",
                                "minimum": 1,
                                "maximum": 50,
                                "default": 10,
                                "description": "Máximo de resultados"
                            }
                        },
                        "required": ["accion"]
                    }
                ),
                Tool(
                    name="gestionar_calendario",
                    description="Gestiona operaciones de Google Calendar",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "accion": {
                                "type": "string",
                                "enum": ["crear", "listar", "eliminar", "actualizar", "buscar"],
                                "description": "Operación a realizar"
                            },
                            "titulo": {
                                "type": "string",
                                "description": "Título del evento"
                            },
                            "fecha_inicio": {
                                "type": "string",
                                "description": "Fecha/hora inicio (formato ISO o 'YYYY-MM-DD HH:MM')"
                            },
                            "fecha_fin": {
                                "type": "string",
                                "description": "Fecha/hora fin"
                            },
                            "descripcion": {
                                "type": "string",
                                "description": "Descripción del evento"
                            },
                            "evento_id": {
                                "type": "string",
                                "description": "ID del evento (para eliminar/actualizar)"
                            },
                            "dias_adelante": {
                                "type": "integer",
                                "minimum": 1,
                                "maximum": 365,
                                "default": 30,
                                "description": "Días hacia adelante para listar eventos"
                            }
                        },
                        "required": ["accion"]
                    }
                ),
                Tool(
                    name="analizar_sentimiento",
                    description="Analiza el sentimiento de un texto",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "texto": {
                                "type": "string",
                                "description": "Texto a analizar"
                            },
                            "idioma": {
                                "type": "string",
                                "enum": ["es", "en"],
                                "default": "es",
                                "description": "Idioma del texto"
                            },
                            "incluir_entidades": {
                                "type": "boolean",
                                "default": False,
                                "description": "Si incluir análisis de entidades"
                            }
                        },
                        "required": ["texto"]
                    }
                ),
                Tool(
                    name="generar_resumen",
                    description="Genera un resumen del contenido proporcionado",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "contenido": {
                                "type": "string",
                                "description": "Texto a resumir"
                            },
                            "longitud": {
                                "type": "string",
                                "enum": ["corto", "medio", "largo"],
                                "default": "medio",
                                "description": "Longitud del resumen"
                            },
                            "estilo": {
                                "type": "string",
                                "enum": ["neutro", "formal", "casual"],
                                "default": "neutro",
                                "description": "Estilo del resumen"
                            },
                            "idioma": {
                                "type": "string",
                                "default": "es",
                                "description": "Idioma de salida"
                            }
                        },
                        "required": ["contenido"]
                    }
                ),
                Tool(
                    name="flujo_investigacion_completo",
                    description="Ejecuta un flujo completo de investigación sobre un tema",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "tema": {
                                "type": "string",
                                "description": "Tema a investigar"
                            },
                            "profundidad": {
                                "type": "string",
                                "enum": ["basico", "normal", "detallado"],
                                "default": "normal",
                                "description": "Nivel de profundidad"
                            },
                            "incluir_noticias": {
                                "type": "boolean",
                                "default": True,
                                "description": "Si incluir noticias actuales"
                            },
                            "incluir_academico": {
                                "type": "boolean",
                                "default": False,
                                "description": "Si incluir búsqueda académica"
                            },
                            "enviar_por_email": {
                                "type": "boolean",
                                "default": False,
                                "description": "Si enviar resultado por email"
                            },
                            "destinatario_email": {
                                "type": "string",
                                "description": "Email del destinatario"
                            }
                        },
                        "required": ["tema"]
                    }
                ),
                Tool(
                    name="estado_sistema",
                    description="Obtiene el estado actual del sistema MCP y sus herramientas",
                    inputSchema={
                        "type": "object",
                        "properties": {},
                        "additionalProperties": False
                    }
                )
            ]
        
        @self.server.call_tool()
        async def handle_call_tool(name: str, arguments: dict) -> Sequence[TextContent | ImageContent | EmbeddedResource]:
            """Manejar llamadas a herramientas"""
            try:
                if name == "buscar_informacion":
                    result = await self.serpapi_tools.search(
                        query=arguments["consulta"],
                        search_type=arguments.get("tipo", "web"),
                        num_results=arguments.get("num_resultados", 5),
                        region=arguments.get("region", "es")
                    )
                    self._update_tool_stats("buscar_informacion", success=True)
                    
                elif name == "buscar_noticias":
                    result = await self.serpapi_tools.search_news(
                        query=arguments["consulta"],
                        region=arguments.get("region", "es"),
                        num_results=arguments.get("num_resultados", 5),
                        time_period=arguments.get("periodo", "24h")
                    )
                    self._update_tool_stats("buscar_noticias", success=True)
                    
                elif name == "gestionar_email":
                    # Verificar autenticación
                    if not await self.oauth_manager.ensure_authenticated("gmail"):
                        result = "❌ Error: No se pudo autenticar con Gmail. Configura OAuth2."
                    else:
                        result = await self.gmail_tools.execute_action(
                            action=arguments["accion"],
                            recipient=arguments.get("destinatario"),
                            subject=arguments.get("asunto"),
                            body=arguments.get("cuerpo"),
                            search_query=arguments.get("consulta_busqueda"),
                            email_id=arguments.get("email_id"),
                            max_results=arguments.get("max_resultados", 10)
                        )
                    self._update_tool_stats("gestionar_email", success=True)
                    
                elif name == "gestionar_calendario":
                    # Verificar autenticación
                    if not await self.oauth_manager.ensure_authenticated("calendar"):
                        result = "❌ Error: No se pudo autenticar con Google Calendar. Configura OAuth2."
                    else:
                        result = await self.calendar_tools.execute_action(
                            action=arguments["accion"],
                            title=arguments.get("titulo"),
                            start_datetime=arguments.get("fecha_inicio"),
                            end_datetime=arguments.get("fecha_fin"),
                            description=arguments.get("descripcion"),
                            event_id=arguments.get("evento_id"),
                            days_ahead=arguments.get("dias_adelante", 30)
                        )
                    self._update_tool_stats("gestionar_calendario", success=True)
                    
                elif name == "analizar_sentimiento":
                    result = await self.analytics_tools.analyze_sentiment(
                        text=arguments["texto"],
                        language=arguments.get("idioma", "es"),
                        include_entities=arguments.get("incluir_entidades", False)
                    )
                    self._update_tool_stats("analizar_sentimiento", success=True)
                    
                elif name == "generar_resumen":
                    result = await self.analytics_tools.generate_summary(
                        content=arguments["contenido"],
                        length=arguments.get("longitud", "medio"),
                        style=arguments.get("estilo", "neutro"),
                        language=arguments.get("idioma", "es")
                    )
                    self._update_tool_stats("generar_resumen", success=True)
                    
                elif name == "flujo_investigacion_completo":
                    result = await self.workflow_tools.research_workflow(
                        topic=arguments["tema"],
                        depth=arguments.get("profundidad", "normal"),
                        include_news=arguments.get("incluir_noticias", True),
                        include_academic=arguments.get("incluir_academico", False),
                        email_report=arguments.get("enviar_por_email", False),
                        recipient_email=arguments.get("destinatario_email")
                    )
                    self._update_tool_stats("flujo_investigacion_completo", success=True)
                    
                elif name == "estado_sistema":
                    result = await self._get_system_status()
                    self._update_tool_stats("estado_sistema", success=True)
                    
                else:
                    raise MCPToolError(f"Herramienta no reconocida: {name}", tool_name=name)
                
                return [TextContent(type="text", text=result)]
                
            except Exception as e:
                self._update_tool_stats(name, success=False)
                self.logger.error(f"Error en herramienta {name}: {e}")
                error_msg = f"❌ Error ejecutando {name}: {str(e)}"
                return [TextContent(type="text", text=error_msg)]
    
    async def initialize(self) -> None:
        """Inicializar el servidor y todas las herramientas"""
        try:
            self.logger.info("Inicializando servidor MCP...")
            
            # Configurar OAuth para Google services
            await self.oauth_manager.initialize()
            
            # Configurar servicios de Google para las herramientas
            await self._configure_google_services()
            
            # Configurar workflow tools con referencias a otras herramientas
            self.workflow_tools.set_tools(
                self.serpapi_tools,
                self.gmail_tools,
                self.calendar_tools,
                self.analytics_tools
            )
            
            self.logger.info("Servidor MCP inicializado correctamente")
            
        except Exception as e:
            self.logger.error(f"Error inicializando servidor MCP: {e}")
            raise MCPServerError(f"Failed to initialize MCP server: {e}")
    
    async def _configure_google_services(self) -> None:
        """Configurar servicios de Google para las herramientas"""
        try:
            # Configurar Gmail si está disponible
            gmail_service = await self.oauth_manager.get_gmail_service()
            if gmail_service:
                self.gmail_tools.set_service(gmail_service)
                self.logger.info("Servicio Gmail configurado")
            
            # Configurar Calendar si está disponible
            calendar_service = await self.oauth_manager.get_calendar_service()
            if calendar_service:
                self.calendar_tools.set_service(calendar_service)
                self.logger.info("Servicio Calendar configurado")
                
        except Exception as e:
            self.logger.warning(f"Error configurando servicios Google: {e}")
            # No es fatal, las herramientas mostrarán errores apropiados
    
    def _update_tool_stats(self, tool_name: str, success: bool) -> None:
        """Actualizar estadísticas de uso de herramientas"""
        if tool_name not in self.tool_stats:
            self.tool_stats[tool_name] = {"total": 0, "success": 0, "errors": 0}
        
        self.tool_stats[tool_name]["total"] += 1
        if success:
            self.tool_stats[tool_name]["success"] += 1
        else:
            self.tool_stats[tool_name]["errors"] += 1
    
    async def _get_system_status(self) -> str:
        """Obtener estado del sistema"""
        try:
            auth_status = await self.oauth_manager.get_auth_status()
            
            status_report = f"🤖 **Estado del Sistema {SYSTEM_NAME} v{SYSTEM_VERSION}**\n\n"
            status_report += f"🟢 Servidor MCP: {'Activo' if self.is_running else 'Inactivo'}\n"
            status_report += f"🔑 Autenticación Google: {'✅ Activa' if auth_status.get('google_authenticated') else '❌ Inactiva'}\n"
            status_report += f"🔍 SerpAPI: {'✅ Configurada' if self.settings.serpapi.api_key else '❌ No configurada'}\n\n"
            
            if self.tool_stats:
                status_report += "📊 **Estadísticas de Herramientas:**\n"
                for tool, stats in self.tool_stats.items():
                    success_rate = (stats.get('success', 0) / max(stats.get('total', 1), 1)) * 100
                    status_report += f"• {tool}: {stats.get('total', 0)} usos ({success_rate:.1f}% éxito)\n"
            
            return status_report
            
        except Exception as e:
            self.logger.error(f"Error obteniendo estado del sistema: {e}")
            return f"❌ Error obteniendo estado: {str(e)}"
    
    async def start_server(self) -> None:
        """Iniciar el servidor MCP en modo stdio"""
        try:
            self.is_running = True
            self.logger.info("Iniciando servidor MCP en modo stdio...")
            
            async with stdio_server() as (read_stream, write_stream):
                await self.server.run(
                    read_stream, 
                    write_stream,
                    InitializationOptions(
                        server_name=f"{SYSTEM_NAME.lower()}-server",
                        server_version=SYSTEM_VERSION,
                        capabilities=self.server.get_capabilities()
                    )
                )
                
        except Exception as e:
            self.is_running = False
            self.logger.error(f"Error iniciando servidor MCP: {e}")
            raise MCPServerError(f"Failed to start MCP server: {e}")
    
    async def shutdown(self) -> None:
        """Apagar el servidor MCP"""
        try:
            self.logger.info("Apagando servidor MCP...")
            self.is_running = False
            
            # Cerrar conexiones OAuth
            await self.oauth_manager.close()
            
            self.logger.info("Servidor MCP apagado correctamente")
            
        except Exception as e:
            self.logger.error(f"Error apagando servidor MCP: {e}")


# Instancia global del servidor
mcp_chat_server = MCPChatServer()


async def main():
    """Función principal para ejecutar el servidor"""
    try:
        # Inicializar servidor
        await mcp_chat_server.initialize()
        
        # Iniciar servidor
        await mcp_chat_server.start_server()
        
    except KeyboardInterrupt:
        print("\n🛑 Interrupción del usuario")
    except Exception as e:
        print(f"❌ Error fatal: {e}")
    finally:
        await mcp_chat_server.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
