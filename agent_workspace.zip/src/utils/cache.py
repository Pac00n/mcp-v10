"""
Sistema de caché para optimización de rendimiento
Soporta Redis y caché en memoria como fallback
"""

import asyncio
import json
import hashlib
import time
from typing import Any, Dict, Optional, Union, List
from datetime import datetime, timedelta
import pickle
import threading

try:
    import aioredis
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False

from ..core.config import get_settings
from ..core.logging_config import get_logger, performance_logger
from ..core.exceptions import CacheError


class MemoryCache:
    """Caché en memoria como fallback cuando Redis no está disponible"""
    
    def __init__(self, max_size: int = 1000):
        self.cache: Dict[str, Dict[str, Any]] = {}
        self.max_size = max_size
        self.access_times: Dict[str, float] = {}
        self.lock = threading.RLock()
    
    def set(self, key: str, value: Any, ttl: int = 3600) -> bool:
        """Establecer valor en caché con TTL"""
        try:
            with self.lock:
                # Limpiar si está lleno
                if len(self.cache) >= self.max_size:
                    self._evict_expired()
                    if len(self.cache) >= self.max_size:
                        self._evict_lru()
                
                expiry = time.time() + ttl
                self.cache[key] = {
                    'value': value,
                    'expiry': expiry,
                    'created': time.time()
                }
                self.access_times[key] = time.time()
                return True
                
        except Exception:
            return False
    
    def get(self, key: str) -> Optional[Any]:
        """Obtener valor del caché"""
        try:
            with self.lock:
                if key not in self.cache:
                    return None
                
                entry = self.cache[key]
                
                # Verificar expiración
                if time.time() > entry['expiry']:
                    del self.cache[key]
                    if key in self.access_times:
                        del self.access_times[key]
                    return None
                
                # Actualizar tiempo de acceso
                self.access_times[key] = time.time()
                return entry['value']
                
        except Exception:
            return None
    
    def delete(self, key: str) -> bool:
        """Eliminar key del caché"""
        try:
            with self.lock:
                if key in self.cache:
                    del self.cache[key]
                if key in self.access_times:
                    del self.access_times[key]
                return True
        except Exception:
            return False
    
    def exists(self, key: str) -> bool:
        """Verificar si key existe y no ha expirado"""
        return self.get(key) is not None
    
    def clear(self) -> bool:
        """Limpiar todo el caché"""
        try:
            with self.lock:
                self.cache.clear()
                self.access_times.clear()
                return True
        except Exception:
            return False
    
    def _evict_expired(self):
        """Eliminar entradas expiradas"""
        current_time = time.time()
        expired_keys = [
            key for key, entry in self.cache.items()
            if current_time > entry['expiry']
        ]
        
        for key in expired_keys:
            del self.cache[key]
            if key in self.access_times:
                del self.access_times[key]
    
    def _evict_lru(self):
        """Eliminar entradas menos usadas recientemente"""
        if not self.access_times:
            return
        
        # Eliminar 20% de las entradas más antiguas
        sorted_keys = sorted(self.access_times.items(), key=lambda x: x[1])
        keys_to_remove = int(len(sorted_keys) * 0.2) or 1
        
        for key, _ in sorted_keys[:keys_to_remove]:
            if key in self.cache:
                del self.cache[key]
            del self.access_times[key]
    
    def get_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del caché"""
        with self.lock:
            current_time = time.time()
            expired_count = sum(
                1 for entry in self.cache.values()
                if current_time > entry['expiry']
            )
            
            return {
                'total_keys': len(self.cache),
                'expired_keys': expired_count,
                'max_size': self.max_size,
                'memory_usage': 'unknown'
            }


class CacheManager:
    """Gestor principal de caché con soporte Redis y fallback en memoria"""
    
    def __init__(self):
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        self.redis_client: Optional[aioredis.Redis] = None
        self.memory_cache = MemoryCache(max_size=500)
        self.use_redis = REDIS_AVAILABLE
        self.is_initialized = False
        
        # Configuración de TTL por tipo de datos
        self.ttl_config = {
            'tool_list': self.settings.cache.tool_list_ttl,
            'response': self.settings.cache.response_ttl,
            'context': self.settings.cache.context_ttl,
            'search_results': 3600,  # 1 hora
            'user_preferences': 86400,  # 24 horas
            'default': 1800  # 30 minutos
        }
        
        # Estadísticas
        self.stats = {
            'hits': 0,
            'misses': 0,
            'sets': 0,
            'errors': 0
        }
    
    async def initialize(self) -> None:
        """Inicializar sistema de caché"""
        try:
            # Intentar conectar a Redis si está disponible
            if REDIS_AVAILABLE and self.use_redis:
                await self._connect_redis()
            
            if not self.redis_client:
                self.logger.info("Usando caché en memoria (Redis no disponible)")
                self.use_redis = False
            
            self.is_initialized = True
            self.logger.info("CacheManager inicializado correctamente")
            
        except Exception as e:
            self.logger.error(f"Error inicializando caché: {e}")
            # Continuar con caché en memoria
            self.use_redis = False
            self.is_initialized = True
    
    async def _connect_redis(self) -> None:
        """Conectar a Redis"""
        try:
            self.redis_client = await aioredis.from_url(
                self.settings.cache.redis_url,
                db=self.settings.cache.redis_db,
                encoding="utf-8",
                decode_responses=True,
                socket_timeout=5,
                socket_connect_timeout=5,
                retry_on_timeout=True
            )
            
            # Probar conexión
            await self.redis_client.ping()
            self.logger.info(f"Conectado a Redis: {self.settings.cache.redis_url}")
            
        except Exception as e:
            self.logger.warning(f"No se pudo conectar a Redis: {e}")
            self.redis_client = None
    
    async def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None,
        cache_type: str = 'default'
    ) -> bool:
        """
        Establecer valor en caché
        
        Args:
            key: Clave del caché
            value: Valor a cachear
            ttl: Tiempo de vida en segundos
            cache_type: Tipo de caché para TTL automático
        
        Returns:
            True si se estableció correctamente
        """
        try:
            if not self.is_initialized:
                await self.initialize()
            
            # Determinar TTL
            if ttl is None:
                ttl = self.ttl_config.get(cache_type, self.ttl_config['default'])
            
            # Serializar valor
            serialized_value = self._serialize_value(value)
            
            success = False
            
            # Intentar Redis primero
            if self.use_redis and self.redis_client:
                try:
                    await self.redis_client.setex(key, ttl, serialized_value)
                    success = True
                except Exception as e:
                    self.logger.warning(f"Error usando Redis para set: {e}")
                    # Fallback a memoria
                    success = self.memory_cache.set(key, value, ttl)
            else:
                # Usar caché en memoria
                success = self.memory_cache.set(key, value, ttl)
            
            if success:
                self.stats['sets'] += 1
                performance_logger.log_cache_hit(key, False)  # Log como "set"
            else:
                self.stats['errors'] += 1
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error estableciendo caché {key}: {e}")
            self.stats['errors'] += 1
            return False
    
    async def get(self, key: str) -> Optional[Any]:
        """
        Obtener valor del caché
        
        Args:
            key: Clave del caché
        
        Returns:
            Valor cacheado o None si no existe
        """
        try:
            if not self.is_initialized:
                await self.initialize()
            
            value = None
            
            # Intentar Redis primero
            if self.use_redis and self.redis_client:
                try:
                    serialized_value = await self.redis_client.get(key)
                    if serialized_value:
                        value = self._deserialize_value(serialized_value)
                except Exception as e:
                    self.logger.warning(f"Error usando Redis para get: {e}")
                    # Fallback a memoria
                    value = self.memory_cache.get(key)
            else:
                # Usar caché en memoria
                value = self.memory_cache.get(key)
            
            # Actualizar estadísticas
            if value is not None:
                self.stats['hits'] += 1
                performance_logger.log_cache_hit(key, True)
            else:
                self.stats['misses'] += 1
                performance_logger.log_cache_hit(key, False)
            
            return value
            
        except Exception as e:
            self.logger.error(f"Error obteniendo caché {key}: {e}")
            self.stats['errors'] += 1
            return None
    
    async def delete(self, key: str) -> bool:
        """Eliminar clave del caché"""
        try:
            success = False
            
            # Eliminar de Redis
            if self.use_redis and self.redis_client:
                try:
                    await self.redis_client.delete(key)
                    success = True
                except Exception as e:
                    self.logger.warning(f"Error eliminando de Redis: {e}")
            
            # Eliminar de memoria también
            memory_success = self.memory_cache.delete(key)
            
            return success or memory_success
            
        except Exception as e:
            self.logger.error(f"Error eliminando caché {key}: {e}")
            return False
    
    async def exists(self, key: str) -> bool:
        """Verificar si clave existe en caché"""
        try:
            # Verificar Redis
            if self.use_redis and self.redis_client:
                try:
                    exists = await self.redis_client.exists(key)
                    if exists:
                        return True
                except Exception as e:
                    self.logger.warning(f"Error verificando Redis: {e}")
            
            # Verificar memoria
            return self.memory_cache.exists(key)
            
        except Exception as e:
            self.logger.error(f"Error verificando existencia {key}: {e}")
            return False
    
    async def clear(self, pattern: Optional[str] = None) -> bool:
        """
        Limpiar caché
        
        Args:
            pattern: Patrón de claves a eliminar (None = todas)
        
        Returns:
            True si se limpió correctamente
        """
        try:
            success = False
            
            # Limpiar Redis
            if self.use_redis and self.redis_client:
                try:
                    if pattern:
                        # Buscar claves que coincidan con el patrón
                        keys = await self.redis_client.keys(pattern)
                        if keys:
                            await self.redis_client.delete(*keys)
                    else:
                        await self.redis_client.flushdb()
                    success = True
                except Exception as e:
                    self.logger.warning(f"Error limpiando Redis: {e}")
            
            # Limpiar memoria (sin soporte de patrones por simplicidad)
            if pattern is None:
                memory_success = self.memory_cache.clear()
                success = success or memory_success
            
            return success
            
        except Exception as e:
            self.logger.error(f"Error limpiando caché: {e}")
            return False
    
    def generate_cache_key(self, *components: str) -> str:
        """
        Generar clave de caché consistente
        
        Args:
            *components: Componentes para la clave
        
        Returns:
            Clave de caché hasheada
        """
        try:
            # Crear string con componentes
            key_string = ":".join(str(comp) for comp in components)
            
            # Hash para consistencia y longitud
            key_hash = hashlib.md5(key_string.encode('utf-8')).hexdigest()
            
            # Agregar prefijo para identificación
            return f"mcp:{key_hash}"
            
        except Exception as e:
            self.logger.error(f"Error generando clave de caché: {e}")
            return f"mcp:error:{int(time.time())}"
    
    async def cache_response(
        self,
        cache_key: str,
        response: str,
        tools_used: List[str],
        tokens_used: Dict[str, int]
    ) -> bool:
        """Cachear respuesta de chat completa"""
        try:
            cache_data = {
                'content': response,
                'tools_used': tools_used,
                'tokens_used': tokens_used,
                'timestamp': time.time()
            }
            
            return await self.set(cache_key, cache_data, cache_type='response')
            
        except Exception as e:
            self.logger.error(f"Error cacheando respuesta: {e}")
            return False
    
    async def get_cached_response(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """Obtener respuesta cacheada"""
        try:
            cached_data = await self.get(cache_key)
            
            if cached_data and isinstance(cached_data, dict):
                # Verificar que tenga los campos esperados
                required_fields = ['content', 'tools_used', 'tokens_used', 'timestamp']
                if all(field in cached_data for field in required_fields):
                    return cached_data
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error obteniendo respuesta cacheada: {e}")
            return None
    
    def _serialize_value(self, value: Any) -> str:
        """Serializar valor para almacenamiento"""
        try:
            if isinstance(value, (str, int, float, bool)):
                return json.dumps({'type': 'simple', 'value': value})
            else:
                # Usar pickle para objetos complejos
                pickled = pickle.dumps(value)
                # Codificar en base64 para almacenamiento como string
                import base64
                encoded = base64.b64encode(pickled).decode('utf-8')
                return json.dumps({'type': 'pickle', 'value': encoded})
                
        except Exception as e:
            self.logger.error(f"Error serializando valor: {e}")
            return json.dumps({'type': 'error', 'value': str(value)})
    
    def _deserialize_value(self, serialized: str) -> Any:
        """Deserializar valor desde almacenamiento"""
        try:
            data = json.loads(serialized)
            
            if data.get('type') == 'simple':
                return data['value']
            elif data.get('type') == 'pickle':
                import base64
                decoded = base64.b64decode(data['value'])
                return pickle.loads(decoded)
            else:
                return data.get('value')
                
        except Exception as e:
            self.logger.error(f"Error deserializando valor: {e}")
            return None
    
    async def get_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del caché"""
        try:
            stats = {
                'cache_type': 'redis' if self.use_redis else 'memory',
                'hits': self.stats['hits'],
                'misses': self.stats['misses'],
                'sets': self.stats['sets'],
                'errors': self.stats['errors'],
                'hit_rate': 0.0
            }
            
            # Calcular hit rate
            total_requests = stats['hits'] + stats['misses']
            if total_requests > 0:
                stats['hit_rate'] = (stats['hits'] / total_requests) * 100
            
            # Estadísticas específicas por tipo de caché
            if self.use_redis and self.redis_client:
                try:
                    info = await self.redis_client.info('memory')
                    stats['redis_memory'] = info.get('used_memory_human', 'unknown')
                    stats['redis_keys'] = await self.redis_client.dbsize()
                except Exception:
                    pass
            
            # Estadísticas de memoria
            memory_stats = self.memory_cache.get_stats()
            stats['memory_cache'] = memory_stats
            
            return stats
            
        except Exception as e:
            self.logger.error(f"Error obteniendo estadísticas: {e}")
            return {'error': str(e)}
    
    async def health_check(self) -> str:
        """Verificar estado del sistema de caché"""
        try:
            if not self.is_initialized:
                return "not_initialized"
            
            # Probar operación básica
            test_key = "health_check_test"
            test_value = {"test": True, "timestamp": time.time()}
            
            # Test set/get
            set_success = await self.set(test_key, test_value, ttl=60)
            if not set_success:
                return "set_failed"
            
            retrieved_value = await self.get(test_key)
            if retrieved_value != test_value:
                return "get_failed"
            
            # Limpiar test
            await self.delete(test_key)
            
            # Verificar Redis si está en uso
            if self.use_redis and self.redis_client:
                try:
                    await self.redis_client.ping()
                    return "healthy_redis"
                except Exception:
                    return "redis_error_fallback_memory"
            
            return "healthy_memory"
            
        except Exception as e:
            return f"error: {str(e)}"
    
    async def close(self) -> None:
        """Cerrar conexiones del caché"""
        try:
            if self.redis_client:
                await self.redis_client.close()
                self.redis_client = None
            
            self.memory_cache.clear()
            self.is_initialized = False
            
            self.logger.info("CacheManager cerrado")
            
        except Exception as e:
            self.logger.error(f"Error cerrando CacheManager: {e}")
