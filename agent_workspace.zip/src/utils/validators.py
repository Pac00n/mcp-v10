"""
Validadores para entradas de usuario y datos del sistema
"""

import re
import email.utils
from datetime import datetime, date
from typing import Any, Dict, List, Optional, Union, Tuple
from urllib.parse import urlparse
import phonenumbers

from ..core.logging_config import get_logger
from ..core.exceptions import ValidationError


class MessageValidator:
    """Validador de mensajes de usuario"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        
        # Configuración de límites
        self.max_message_length = 4000
        self.min_message_length = 1
        
        # Patrones de contenido peligroso
        self.dangerous_patterns = [
            r'<script.*?>.*?</script>',  # Scripts
            r'javascript:',              # JavaScript URLs
            r'on\w+\s*=',               # Event handlers
            r'document\.',              # DOM manipulation
            r'window\.',                # Window object
            r'eval\s*\(',               # Eval function
        ]
    
    def validate_message(self, message: str) -> bool:
        """
        Validar mensaje de usuario
        
        Args:
            message: Mensaje a validar
        
        Returns:
            True si es válido
        
        Raises:
            ValidationError: Si el mensaje no es válido
        """
        try:
            # Verificar que sea string
            if not isinstance(message, str):
                raise ValidationError("Message must be a string")
            
            # Verificar longitud
            if len(message) < self.min_message_length:
                raise ValidationError("Message is too short")
            
            if len(message) > self.max_message_length:
                raise ValidationError(f"Message too long (max {self.max_message_length} characters)")
            
            # Verificar contenido peligroso
            self._check_dangerous_content(message)
            
            # Verificar que no sea solo espacios
            if not message.strip():
                raise ValidationError("Message cannot be empty or only whitespace")
            
            return True
            
        except ValidationError:
            raise
        except Exception as e:
            self.logger.error(f"Error validating message: {e}")
            raise ValidationError(f"Message validation failed: {e}")
    
    def _check_dangerous_content(self, message: str) -> None:
        """Verificar contenido potencialmente peligroso"""
        message_lower = message.lower()
        
        for pattern in self.dangerous_patterns:
            if re.search(pattern, message_lower, re.IGNORECASE):
                raise ValidationError("Message contains potentially dangerous content")


class EmailValidator:
    """Validador de direcciones de email"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        
        # Patrón básico de email
        self.email_pattern = re.compile(
            r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
        
        # Dominios bloqueados (ejemplo)
        self.blocked_domains = {
            'example.com',
            'test.com',
            'invalid.com'
        }
    
    def validate_email(self, email_address: str) -> bool:
        """
        Validar dirección de email
        
        Args:
            email_address: Email a validar
        
        Returns:
            True si es válido
        
        Raises:
            ValidationError: Si el email no es válido
        """
        try:
            if not isinstance(email_address, str):
                raise ValidationError("Email must be a string")
            
            email_address = email_address.strip().lower()
            
            # Verificar formato básico
            if not self.email_pattern.match(email_address):
                raise ValidationError("Invalid email format")
            
            # Verificar usando email.utils
            parsed = email.utils.parseaddr(email_address)
            if not parsed[1] or '@' not in parsed[1]:
                raise ValidationError("Invalid email format")
            
            # Verificar dominio
            domain = email_address.split('@')[1]
            if domain in self.blocked_domains:
                raise ValidationError("Email domain is not allowed")
            
            # Verificar longitud
            if len(email_address) > 254:  # RFC 5321 limit
                raise ValidationError("Email address too long")
            
            return True
            
        except ValidationError:
            raise
        except Exception as e:
            self.logger.error(f"Error validating email: {e}")
            raise ValidationError(f"Email validation failed: {e}")
    
    def validate_email_list(self, emails: List[str]) -> List[str]:
        """Validar lista de emails y retornar válidos"""
        valid_emails = []
        
        for email_addr in emails:
            try:
                if self.validate_email(email_addr):
                    valid_emails.append(email_addr.strip().lower())
            except ValidationError:
                self.logger.warning(f"Invalid email skipped: {email_addr}")
                continue
        
        return valid_emails


class DateTimeValidator:
    """Validador de fechas y horas"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        
        # Formatos de fecha soportados
        self.date_formats = [
            "%Y-%m-%d",
            "%d/%m/%Y",
            "%d-%m-%Y",
            "%Y/%m/%d"
        ]
        
        # Formatos de hora soportados
        self.time_formats = [
            "%H:%M",
            "%H:%M:%S",
            "%I:%M %p",
            "%I:%M:%S %p"
        ]
    
    def validate_date(self, date_str: str) -> Tuple[bool, Optional[date]]:
        """
        Validar fecha
        
        Args:
            date_str: Fecha en string
        
        Returns:
            Tuple de (es_válida, objeto_date)
        """
        try:
            if not isinstance(date_str, str):
                return False, None
            
            date_str = date_str.strip()
            
            for fmt in self.date_formats:
                try:
                    parsed_date = datetime.strptime(date_str, fmt).date()
                    
                    # Verificar que sea una fecha razonable
                    today = date.today()
                    min_date = date(1900, 1, 1)
                    max_date = date(2100, 12, 31)
                    
                    if min_date <= parsed_date <= max_date:
                        return True, parsed_date
                    
                except ValueError:
                    continue
            
            return False, None
            
        except Exception as e:
            self.logger.error(f"Error validating date: {e}")
            return False, None
    
    def validate_time(self, time_str: str) -> Tuple[bool, Optional[str]]:
        """
        Validar hora
        
        Args:
            time_str: Hora en string
        
        Returns:
            Tuple de (es_válida, hora_normalizada)
        """
        try:
            if not isinstance(time_str, str):
                return False, None
            
            time_str = time_str.strip()
            
            for fmt in self.time_formats:
                try:
                    parsed_time = datetime.strptime(time_str, fmt).time()
                    # Normalizar a formato HH:MM
                    normalized = parsed_time.strftime("%H:%M")
                    return True, normalized
                    
                except ValueError:
                    continue
            
            return False, None
            
        except Exception as e:
            self.logger.error(f"Error validating time: {e}")
            return False, None
    
    def validate_datetime(self, date_str: str, time_str: str) -> Tuple[bool, Optional[datetime]]:
        """
        Validar combinación de fecha y hora
        
        Args:
            date_str: Fecha en string
            time_str: Hora en string
        
        Returns:
            Tuple de (es_válida, objeto_datetime)
        """
        try:
            date_valid, parsed_date = self.validate_date(date_str)
            time_valid, normalized_time = self.validate_time(time_str)
            
            if not (date_valid and time_valid):
                return False, None
            
            # Combinar fecha y hora
            time_obj = datetime.strptime(normalized_time, "%H:%M").time()
            combined = datetime.combine(parsed_date, time_obj)
            
            return True, combined
            
        except Exception as e:
            self.logger.error(f"Error validating datetime: {e}")
            return False, None


class SearchQueryValidator:
    """Validador de consultas de búsqueda"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        
        # Configuración
        self.max_query_length = 500
        self.min_query_length = 2
        
        # Caracteres prohibidos en búsquedas
        self.forbidden_chars = ['<', '>', '"', "'", '`']
        
        # Palabras bloqueadas (ejemplo)
        self.blocked_words = {
            'hack', 'exploit', 'malware', 'virus'
        }
    
    def validate_search_query(self, query: str) -> bool:
        """
        Validar consulta de búsqueda
        
        Args:
            query: Consulta a validar
        
        Returns:
            True si es válida
        
        Raises:
            ValidationError: Si la consulta no es válida
        """
        try:
            if not isinstance(query, str):
                raise ValidationError("Search query must be a string")
            
            query = query.strip()
            
            # Verificar longitud
            if len(query) < self.min_query_length:
                raise ValidationError("Search query too short")
            
            if len(query) > self.max_query_length:
                raise ValidationError("Search query too long")
            
            # Verificar caracteres prohibidos
            for char in self.forbidden_chars:
                if char in query:
                    raise ValidationError(f"Search query contains forbidden character: {char}")
            
            # Verificar palabras bloqueadas
            query_words = query.lower().split()
            for word in query_words:
                if word in self.blocked_words:
                    raise ValidationError("Search query contains blocked content")
            
            return True
            
        except ValidationError:
            raise
        except Exception as e:
            self.logger.error(f"Error validating search query: {e}")
            raise ValidationError(f"Search query validation failed: {e}")


class URLValidator:
    """Validador de URLs"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        
        # Esquemas permitidos
        self.allowed_schemes = {'http', 'https', 'ftp', 'ftps'}
        
        # Dominios bloqueados
        self.blocked_domains = {
            'malicious.com',
            'spam.com'
        }
    
    def validate_url(self, url: str) -> bool:
        """
        Validar URL
        
        Args:
            url: URL a validar
        
        Returns:
            True si es válida
        
        Raises:
            ValidationError: Si la URL no es válida
        """
        try:
            if not isinstance(url, str):
                raise ValidationError("URL must be a string")
            
            url = url.strip()
            
            # Parsear URL
            parsed = urlparse(url)
            
            # Verificar esquema
            if parsed.scheme.lower() not in self.allowed_schemes:
                raise ValidationError(f"URL scheme not allowed: {parsed.scheme}")
            
            # Verificar que tenga dominio
            if not parsed.netloc:
                raise ValidationError("URL must have a domain")
            
            # Verificar dominio bloqueado
            domain = parsed.netloc.lower()
            if domain in self.blocked_domains:
                raise ValidationError("URL domain is blocked")
            
            # Verificar longitud
            if len(url) > 2048:
                raise ValidationError("URL too long")
            
            return True
            
        except ValidationError:
            raise
        except Exception as e:
            self.logger.error(f"Error validating URL: {e}")
            raise ValidationError(f"URL validation failed: {e}")


class PhoneValidator:
    """Validador de números de teléfono"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
    
    def validate_phone(self, phone: str, region: str = "ES") -> Tuple[bool, Optional[str]]:
        """
        Validar número de teléfono
        
        Args:
            phone: Número de teléfono
            region: Región/país para validación
        
        Returns:
            Tuple de (es_válido, número_formateado)
        """
        try:
            if not isinstance(phone, str):
                return False, None
            
            phone = phone.strip()
            
            # Usar phonenumbers library si está disponible
            try:
                parsed = phonenumbers.parse(phone, region)
                if phonenumbers.is_valid_number(parsed):
                    formatted = phonenumbers.format_number(
                        parsed, 
                        phonenumbers.PhoneNumberFormat.E164
                    )
                    return True, formatted
                else:
                    return False, None
                    
            except Exception:
                # Fallback a validación básica
                return self._basic_phone_validation(phone)
                
        except Exception as e:
            self.logger.error(f"Error validating phone: {e}")
            return False, None
    
    def _basic_phone_validation(self, phone: str) -> Tuple[bool, Optional[str]]:
        """Validación básica de teléfono sin librerías externas"""
        # Remover caracteres no numéricos excepto +
        cleaned = re.sub(r'[^\d+]', '', phone)
        
        # Verificar longitud básica
        if len(cleaned) < 7 or len(cleaned) > 15:
            return False, None
        
        # Verificar que sea principalmente números
        if not re.match(r'^\+?[\d\s\-\(\)\.]+$', phone):
            return False, None
        
        return True, cleaned


class ContentValidator:
    """Validador general de contenido"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        
        # Límites de contenido
        self.max_content_length = 10000
        self.min_content_length = 1
    
    def validate_content(self, content: str, content_type: str = "general") -> bool:
        """
        Validar contenido general
        
        Args:
            content: Contenido a validar
            content_type: Tipo de contenido (email_body, description, etc.)
        
        Returns:
            True si es válido
        
        Raises:
            ValidationError: Si el contenido no es válido
        """
        try:
            if not isinstance(content, str):
                raise ValidationError("Content must be a string")
            
            content = content.strip()
            
            # Verificar longitud
            if len(content) < self.min_content_length:
                raise ValidationError("Content too short")
            
            max_length = self._get_max_length_for_type(content_type)
            if len(content) > max_length:
                raise ValidationError(f"Content too long (max {max_length} characters)")
            
            # Verificar contenido malicioso básico
            self._check_malicious_content(content)
            
            return True
            
        except ValidationError:
            raise
        except Exception as e:
            self.logger.error(f"Error validating content: {e}")
            raise ValidationError(f"Content validation failed: {e}")
    
    def _get_max_length_for_type(self, content_type: str) -> int:
        """Obtener longitud máxima según tipo de contenido"""
        limits = {
            "email_subject": 200,
            "email_body": 5000,
            "description": 1000,
            "title": 100,
            "general": self.max_content_length
        }
        return limits.get(content_type, self.max_content_length)
    
    def _check_malicious_content(self, content: str) -> None:
        """Verificar contenido malicioso básico"""
        malicious_patterns = [
            r'<script.*?>.*?</script>',
            r'javascript:',
            r'vbscript:',
            r'on\w+\s*=',
        ]
        
        content_lower = content.lower()
        for pattern in malicious_patterns:
            if re.search(pattern, content_lower, re.IGNORECASE):
                raise ValidationError("Content contains potentially malicious code")


# Clase principal que combina todos los validadores
class MasterValidator:
    """Validador principal que combina todos los validadores específicos"""
    
    def __init__(self):
        self.message_validator = MessageValidator()
        self.email_validator = EmailValidator()
        self.datetime_validator = DateTimeValidator()
        self.search_validator = SearchQueryValidator()
        self.url_validator = URLValidator()
        self.phone_validator = PhoneValidator()
        self.content_validator = ContentValidator()
        
        self.logger = get_logger(__name__)
    
    def validate_input(self, input_data: Dict[str, Any], validation_rules: Dict[str, str]) -> Dict[str, Any]:
        """
        Validar datos de entrada según reglas especificadas
        
        Args:
            input_data: Datos a validar
            validation_rules: Reglas de validación por campo
        
        Returns:
            Datos validados y normalizados
        
        Raises:
            ValidationError: Si algún campo no es válido
        """
        try:
            validated_data = {}
            
            for field, rule in validation_rules.items():
                if field not in input_data:
                    if rule.endswith('_required'):
                        raise ValidationError(f"Required field missing: {field}")
                    continue
                
                value = input_data[field]
                validated_value = self._validate_field(field, value, rule)
                validated_data[field] = validated_value
            
            return validated_data
            
        except ValidationError:
            raise
        except Exception as e:
            self.logger.error(f"Error in input validation: {e}")
            raise ValidationError(f"Input validation failed: {e}")
    
    def _validate_field(self, field: str, value: Any, rule: str) -> Any:
        """Validar campo individual según regla"""
        rule_base = rule.replace('_required', '')
        
        if rule_base == 'message':
            self.message_validator.validate_message(value)
            return value
        
        elif rule_base == 'email':
            self.email_validator.validate_email(value)
            return value.strip().lower()
        
        elif rule_base == 'date':
            valid, parsed_date = self.datetime_validator.validate_date(value)
            if not valid:
                raise ValidationError(f"Invalid date format: {value}")
            return parsed_date.strftime("%Y-%m-%d")
        
        elif rule_base == 'time':
            valid, normalized_time = self.datetime_validator.validate_time(value)
            if not valid:
                raise ValidationError(f"Invalid time format: {value}")
            return normalized_time
        
        elif rule_base == 'search_query':
            self.search_validator.validate_search_query(value)
            return value.strip()
        
        elif rule_base == 'url':
            self.url_validator.validate_url(value)
            return value.strip()
        
        elif rule_base == 'phone':
            valid, formatted = self.phone_validator.validate_phone(value)
            if not valid:
                raise ValidationError(f"Invalid phone number: {value}")
            return formatted
        
        elif rule_base == 'content':
            self.content_validator.validate_content(value)
            return value.strip()
        
        else:
            # Validación básica por defecto
            if isinstance(value, str):
                return value.strip()
            return value
