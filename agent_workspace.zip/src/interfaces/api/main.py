"""
API REST principal para el sistema de chat MCP + OpenAI
Implementa endpoints RESTful usando FastAPI
"""

import asyncio
import json
import sys
from pathlib import Path
from typing import Dict, List, Optional, Any, Union
from datetime import datetime
import uuid

from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field
import uvicorn

# Agregar el directorio src al path para imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from openai_integration.responses_client import (
    OpenAIResponsesClient, 
    ChatMessage, 
    ResponseResult,
    StreamChunk
)
from core.config import get_settings
from core.logging_config import get_logger, performance_logger
from core.exceptions import OpenAIError, MCPError

# Modelos Pydantic para requests/responses
class ChatMessageRequest(BaseModel):
    """Mensaje de chat en request"""
    role: str = Field(..., description="Rol del mensaje: 'user', 'assistant', 'system'")
    content: str = Field(..., description="Contenido del mensaje")


class ChatRequest(BaseModel):
    """Request de chat completion"""
    messages: List[ChatMessageRequest] = Field(..., description="Lista de mensajes")
    model: Optional[str] = Field(None, description="Modelo OpenAI a usar")
    max_tokens: Optional[int] = Field(None, description="Máximo número de tokens")
    temperature: Optional[float] = Field(None, description="Temperatura del modelo")
    stream: bool = Field(False, description="Si hacer streaming de la respuesta")
    use_reasoning: bool = Field(False, description="Si usar modelo de razonamiento")
    reasoning_effort: str = Field("medium", description="Esfuerzo de razonamiento")
    session_id: Optional[str] = Field(None, description="ID de sesión opcional")


class ChatResponse(BaseModel):
    """Response de chat completion"""
    content: str = Field(..., description="Contenido de la respuesta")
    model_used: str = Field(..., description="Modelo utilizado")
    finish_reason: str = Field(..., description="Razón de finalización")
    tokens_used: Dict[str, int] = Field(..., description="Tokens utilizados")
    tool_calls: List[Dict[str, Any]] = Field(default_factory=list, description="Llamadas a herramientas")
    response_time: float = Field(..., description="Tiempo de respuesta en segundos")
    response_id: Optional[str] = Field(None, description="ID de la respuesta")
    reasoning: Optional[str] = Field(None, description="Razonamiento del modelo")
    session_id: Optional[str] = Field(None, description="ID de sesión")


class HealthResponse(BaseModel):
    """Response de health check"""
    status: str = Field(..., description="Estado del sistema")
    timestamp: str = Field(..., description="Timestamp del check")
    services: Dict[str, Any] = Field(..., description="Estado de servicios")
    version: str = Field(..., description="Versión del sistema")


class StatsResponse(BaseModel):
    """Response de estadísticas"""
    total_requests: int = Field(..., description="Total de requests")
    successful_requests: int = Field(..., description="Requests exitosos")
    total_tokens_used: int = Field(..., description="Total de tokens usados")
    tool_calls_made: int = Field(..., description="Llamadas a herramientas realizadas")
    streaming_requests: int = Field(..., description="Requests de streaming")
    cached_requests: int = Field(..., description="Requests cacheados")
    uptime_seconds: float = Field(..., description="Tiempo de actividad en segundos")


class ErrorResponse(BaseModel):
    """Response de error"""
    error: str = Field(..., description="Mensaje de error")
    error_type: str = Field(..., description="Tipo de error")
    timestamp: str = Field(..., description="Timestamp del error")
    request_id: Optional[str] = Field(None, description="ID de la request")


# Configurar FastAPI
app = FastAPI(
    title="🤖 MCP Chat API",
    description="API REST para sistema de chat OpenAI + MCP con herramientas especializadas",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Middleware CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # En producción, especificar dominios
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Logger y configuración
logger = get_logger(__name__)
settings = get_settings()

# Cliente OpenAI global
openai_client: Optional[OpenAIResponsesClient] = None

# Estadísticas de la API
api_stats = {
    "start_time": datetime.now(),
    "total_requests": 0,
    "successful_requests": 0,
    "error_requests": 0
}

# Autenticación simple (opcional)
security = HTTPBearer(auto_error=False)


async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Validar autenticación opcional"""
    if credentials:
        # En una implementación real, validar el token
        if credentials.credentials != settings.api.auth_token:
            raise HTTPException(status_code=401, detail="Token de autenticación inválido")
    return {"authenticated": bool(credentials)}


@app.on_event("startup")
async def startup_event():
    """Inicializar servicios al arrancar"""
    global openai_client
    
    try:
        logger.info("Iniciando MCP Chat API...")
        
        # Inicializar cliente OpenAI
        openai_client = OpenAIResponsesClient()
        openai_client.configure_default_mcp_server()
        
        logger.info("✅ MCP Chat API iniciada correctamente")
        
    except Exception as e:
        logger.error(f"❌ Error iniciando API: {e}")
        raise


@app.on_event("shutdown")
async def shutdown_event():
    """Limpiar recursos al cerrar"""
    logger.info("Cerrando MCP Chat API...")
    
    # Aquí se podrían cerrar conexiones, etc.
    logger.info("✅ MCP Chat API cerrada correctamente")


@app.middleware("http")
async def logging_middleware(request: Request, call_next):
    """Middleware para logging de requests"""
    start_time = datetime.now()
    request_id = str(uuid.uuid4())
    
    # Log de entrada
    logger.info(f"🌐 {request.method} {request.url.path} [ID: {request_id}]")
    
    # Incrementar contador
    api_stats["total_requests"] += 1
    
    try:
        response = await call_next(request)
        
        # Log de éxito
        duration = (datetime.now() - start_time).total_seconds()
        logger.info(f"✅ {request.method} {request.url.path} [{response.status_code}] {duration:.3f}s [ID: {request_id}]")
        
        if response.status_code < 400:
            api_stats["successful_requests"] += 1
        else:
            api_stats["error_requests"] += 1
        
        # Agregar headers de respuesta
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Response-Time"] = f"{duration:.3f}s"
        
        return response
        
    except Exception as e:
        # Log de error
        duration = (datetime.now() - start_time).total_seconds()
        logger.error(f"❌ {request.method} {request.url.path} ERROR {duration:.3f}s [ID: {request_id}]: {e}")
        
        api_stats["error_requests"] += 1
        
        return JSONResponse(
            status_code=500,
            content={
                "error": "Error interno del servidor",
                "error_type": "internal_server_error",
                "timestamp": datetime.now().isoformat(),
                "request_id": request_id
            }
        )


# Endpoints principales

@app.get("/", response_model=Dict[str, str])
async def root():
    """Endpoint raíz con información de la API"""
    return {
        "name": "🤖 MCP Chat API",
        "version": "1.0.0",
        "status": "operational",
        "documentation": "/docs",
        "health_check": "/health"
    }


@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check completo del sistema"""
    
    try:
        # Verificar cliente OpenAI
        openai_health = await openai_client.health_check()
        
        # Calcular uptime
        uptime = (datetime.now() - api_stats["start_time"]).total_seconds()
        
        return HealthResponse(
            status="healthy" if openai_health.get("status") == "healthy" else "degraded",
            timestamp=datetime.now().isoformat(),
            services={
                "openai": openai_health,
                "mcp_servers": openai_health.get("mcp_servers", 0),
                "api_stats": api_stats
            },
            version="1.0.0"
        )
        
    except Exception as e:
        logger.error(f"Error en health check: {e}")
        
        return HealthResponse(
            status="unhealthy",
            timestamp=datetime.now().isoformat(),
            services={"error": str(e)},
            version="1.0.0"
        )


@app.get("/stats", response_model=StatsResponse)
async def get_stats(user: dict = Depends(get_current_user)):
    """Obtener estadísticas del sistema"""
    
    try:
        # Estadísticas del cliente OpenAI
        client_stats = openai_client.get_stats()
        
        # Uptime
        uptime = (datetime.now() - api_stats["start_time"]).total_seconds()
        
        return StatsResponse(
            total_requests=client_stats.get("total_requests", 0),
            successful_requests=client_stats.get("successful_requests", 0),
            total_tokens_used=client_stats.get("total_tokens_used", 0),
            tool_calls_made=client_stats.get("tool_calls_made", 0),
            streaming_requests=client_stats.get("streaming_requests", 0),
            cached_requests=client_stats.get("cached_requests", 0),
            uptime_seconds=uptime
        )
        
    except Exception as e:
        logger.error(f"Error obteniendo estadísticas: {e}")
        raise HTTPException(status_code=500, detail="Error obteniendo estadísticas")


@app.post("/chat/completions", response_model=ChatResponse)
async def chat_completions(request: ChatRequest, user: dict = Depends(get_current_user)):
    """
    Crear chat completion (no streaming)
    """
    
    try:
        # Convertir mensajes
        messages = [
            ChatMessage(role=msg.role, content=msg.content) 
            for msg in request.messages
        ]
        
        # Realizar chat completion
        result = await openai_client.chat_completion(
            messages=messages,
            model=request.model,
            max_tokens=request.max_tokens,
            temperature=request.temperature,
            stream=False,
            use_reasoning=request.use_reasoning,
            reasoning_effort=request.reasoning_effort
        )
        
        return ChatResponse(
            content=result.content,
            model_used=result.model_used,
            finish_reason=result.finish_reason,
            tokens_used=result.tokens_used,
            tool_calls=result.tool_calls,
            response_time=result.response_time,
            response_id=result.response_id,
            reasoning=result.reasoning,
            session_id=request.session_id
        )
        
    except OpenAIError as e:
        logger.error(f"Error OpenAI: {e}")
        raise HTTPException(status_code=502, detail=f"Error de OpenAI: {str(e)}")
    
    except MCPError as e:
        logger.error(f"Error MCP: {e}")
        raise HTTPException(status_code=503, detail=f"Error de MCP: {str(e)}")
    
    except Exception as e:
        logger.error(f"Error general: {e}")
        raise HTTPException(status_code=500, detail="Error interno del servidor")


@app.post("/chat/stream")
async def chat_stream(request: ChatRequest, user: dict = Depends(get_current_user)):
    """
    Crear chat completion con streaming
    """
    
    try:
        # Convertir mensajes
        messages = [
            ChatMessage(role=msg.role, content=msg.content) 
            for msg in request.messages
        ]
        
        # Función generadora para streaming
        async def generate_stream():
            try:
                async for chunk in await openai_client.chat_completion(
                    messages=messages,
                    model=request.model,
                    max_tokens=request.max_tokens,
                    temperature=request.temperature,
                    stream=True,
                    use_reasoning=request.use_reasoning,
                    reasoning_effort=request.reasoning_effort
                ):
                    # Formato Server-Sent Events (SSE)
                    chunk_data = {
                        "content": chunk.content,
                        "is_complete": chunk.is_complete,
                        "tool_calls": chunk.tool_calls,
                        "tokens_used": chunk.tokens_used
                    }
                    
                    yield f"data: {json.dumps(chunk_data)}\n\n"
                    
                    if chunk.is_complete:
                        break
                
                # Señal de fin
                yield "data: [DONE]\n\n"
                
            except Exception as e:
                error_data = {
                    "error": str(e),
                    "error_type": type(e).__name__,
                    "timestamp": datetime.now().isoformat()
                }
                yield f"data: {json.dumps(error_data)}\n\n"
        
        return StreamingResponse(
            generate_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "Access-Control-Allow-Origin": "*",
            }
        )
        
    except Exception as e:
        logger.error(f"Error en streaming: {e}")
        raise HTTPException(status_code=500, detail="Error configurando streaming")


@app.get("/tools")
async def list_tools(user: dict = Depends(get_current_user)):
    """Listar herramientas MCP disponibles"""
    
    return {
        "tools": [
            {
                "name": "buscar_informacion",
                "description": "Búsqueda web usando SerpAPI",
                "category": "search"
            },
            {
                "name": "buscar_noticias",
                "description": "Búsqueda de noticias actuales",
                "category": "search"
            },
            {
                "name": "gestionar_email",
                "description": "Gestión de correos electrónicos con Gmail",
                "category": "productivity"
            },
            {
                "name": "gestionar_calendario",
                "description": "Gestión de eventos de Google Calendar",
                "category": "productivity"
            },
            {
                "name": "analizar_sentimiento",
                "description": "Análisis de sentimiento de texto",
                "category": "analytics"
            },
            {
                "name": "generar_resumen",
                "description": "Generación de resúmenes de texto",
                "category": "analytics"
            },
            {
                "name": "flujo_investigacion_completo",
                "description": "Flujo completo de investigación web",
                "category": "workflow"
            },
            {
                "name": "estado_sistema",
                "description": "Verificación del estado del sistema MCP",
                "category": "system"
            }
        ],
        "total_tools": 8,
        "categories": ["search", "productivity", "analytics", "workflow", "system"]
    }


@app.get("/models")
async def list_models():
    """Listar modelos OpenAI disponibles"""
    
    return {
        "models": [
            {
                "id": "gpt-4o",
                "name": "GPT-4 Omni",
                "description": "Modelo más capaz y eficiente",
                "supports_tools": True,
                "supports_reasoning": False
            },
            {
                "id": "gpt-4o-mini",
                "name": "GPT-4 Omni Mini",
                "description": "Versión más rápida y económica",
                "supports_tools": True,
                "supports_reasoning": False
            },
            {
                "id": "gpt-4-turbo",
                "name": "GPT-4 Turbo",
                "description": "GPT-4 optimizado para velocidad",
                "supports_tools": True,
                "supports_reasoning": False
            },
            {
                "id": "o1-preview",
                "name": "O1 Preview",
                "description": "Modelo de razonamiento avanzado",
                "supports_tools": True,
                "supports_reasoning": True
            },
            {
                "id": "o1-mini",
                "name": "O1 Mini",
                "description": "Modelo de razonamiento compacto",
                "supports_tools": True,
                "supports_reasoning": True
            }
        ],
        "default_model": "gpt-4o",
        "reasoning_models": ["o1-preview", "o1-mini"]
    }


# Endpoints de utilidad

@app.post("/validate-message")
async def validate_message(messages: List[ChatMessageRequest]):
    """Validar formato de mensajes"""
    
    try:
        # Validaciones básicas
        if not messages:
            raise HTTPException(status_code=400, detail="Lista de mensajes vacía")
        
        for i, msg in enumerate(messages):
            if not msg.content.strip():
                raise HTTPException(status_code=400, detail=f"Mensaje {i+1} está vacío")
            
            if msg.role not in ["user", "assistant", "system"]:
                raise HTTPException(status_code=400, detail=f"Rol inválido en mensaje {i+1}: {msg.role}")
        
        return {
            "valid": True,
            "message_count": len(messages),
            "total_characters": sum(len(msg.content) for msg in messages)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error validando mensajes: {str(e)}")


# Manejo de errores global

@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    return JSONResponse(
        status_code=404,
        content=ErrorResponse(
            error="Endpoint no encontrado",
            error_type="not_found",
            timestamp=datetime.now().isoformat()
        ).dict()
    )


@app.exception_handler(500)
async def internal_error_handler(request: Request, exc):
    logger.error(f"Error interno: {exc}")
    return JSONResponse(
        status_code=500,
        content=ErrorResponse(
            error="Error interno del servidor",
            error_type="internal_server_error",
            timestamp=datetime.now().isoformat()
        ).dict()
    )


# Script de inicio
def main():
    """Función principal para ejecutar la API"""
    
    # Configuración del servidor
    host = settings.api.host
    port = settings.api.port
    workers = settings.api.workers
    
    logger.info(f"🚀 Iniciando MCP Chat API en {host}:{port}")
    
    uvicorn.run(
        "src.interfaces.api.main:app",
        host=host,
        port=port,
        workers=workers,
        reload=settings.debug,
        log_level="info" if not settings.debug else "debug",
        access_log=True
    )


if __name__ == "__main__":
    main()
