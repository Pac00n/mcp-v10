"""
Aplicación Web UI para el sistema de chat MCP + OpenAI
Implementa interfaz moderna usando Streamlit
"""

import asyncio
import json
import sys
import time
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

import streamlit as st
from streamlit.delta_generator import DeltaGenerator

# Agregar el directorio src al path para imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from openai_integration.responses_client import (
    OpenAIResponsesClient, 
    ChatMessage, 
    ResponseResult,
    StreamChunk
)
from core.config import get_settings
from core.logging_config import get_logger

# Configuración de página
st.set_page_config(
    page_title="🤖 MCP Chat Assistant",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS personalizado
st.markdown("""
<style>
    .chat-message {
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    .user-message {
        background-color: #e3f2fd;
        border-left: 4px solid #2196f3;
    }
    .assistant-message {
        background-color: #f1f8e9;
        border-left: 4px solid #4caf50;
    }
    .tool-call {
        background-color: #fff3e0;
        border-left: 4px solid #ff9800;
        font-family: monospace;
        font-size: 0.9em;
    }
    .stats-box {
        background-color: #f5f5f5;
        padding: 1rem;
        border-radius: 0.5rem;
        border: 1px solid #ddd;
    }
</style>
""", unsafe_allow_html=True)

# Logger
logger = get_logger(__name__)


def initialize_session_state():
    """Inicializar estado de la sesión"""
    if 'conversation_history' not in st.session_state:
        st.session_state.conversation_history = []
    
    if 'client' not in st.session_state:
        st.session_state.client = None
    
    if 'client_initialized' not in st.session_state:
        st.session_state.client_initialized = False
    
    if 'session_id' not in st.session_state:
        st.session_state.session_id = f"web_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    
    if 'stats' not in st.session_state:
        st.session_state.stats = {
            'messages_sent': 0,
            'tokens_used': 0,
            'tools_called': 0,
            'session_start': datetime.now()
        }


def setup_client() -> bool:
    """Configurar cliente OpenAI"""
    try:
        if not st.session_state.client_initialized:
            client = OpenAIResponsesClient()
            client.configure_default_mcp_server()
            
            st.session_state.client = client
            st.session_state.client_initialized = True
            
            logger.info("Cliente OpenAI configurado en Streamlit")
        
        return True
        
    except Exception as e:
        st.error(f"Error configurando cliente: {e}")
        logger.error(f"Error configurando cliente: {e}")
        return False


def render_sidebar():
    """Renderizar barra lateral con configuración"""
    with st.sidebar:
        st.title("🤖 MCP Chat")
        st.markdown("---")
        
        # Configuración del modelo
        st.subheader("⚙️ Configuración")
        
        model_options = [
            "gpt-4o",
            "gpt-4o-mini", 
            "gpt-4-turbo",
            "o1-preview",
            "o1-mini"
        ]
        
        selected_model = st.selectbox(
            "Modelo OpenAI",
            model_options,
            index=0,
            help="Selecciona el modelo de OpenAI a usar"
        )
        
        use_reasoning = st.checkbox(
            "Usar razonamiento",
            value=False,
            help="Activar modelo de razonamiento (o1-series)"
        )
        
        max_tokens = st.slider(
            "Máximo de tokens",
            min_value=100,
            max_value=4000,
            value=2000,
            step=100,
            help="Máximo número de tokens en la respuesta"
        )
        
        temperature = st.slider(
            "Temperatura",
            min_value=0.0,
            max_value=2.0,
            value=0.7,
            step=0.1,
            help="Creatividad del modelo (0 = determinístico, 2 = muy creativo)"
        )
        
        stream_response = st.checkbox(
            "Streaming",
            value=True,
            help="Mostrar respuesta en tiempo real"
        )
        
        st.markdown("---")
        
        # Herramientas MCP
        st.subheader("🛠️ Herramientas MCP")
        
        tools_status = get_tools_status()
        for tool, status in tools_status.items():
            icon = "✅" if status else "❌"
            st.text(f"{icon} {tool}")
        
        st.markdown("---")
        
        # Estadísticas de sesión
        st.subheader("📊 Estadísticas")
        
        stats = st.session_state.stats
        session_duration = datetime.now() - stats['session_start']
        
        st.metric("Mensajes enviados", stats['messages_sent'])
        st.metric("Tokens usados", stats['tokens_used'])
        st.metric("Herramientas usadas", stats['tools_called'])
        st.metric("Duración sesión", f"{session_duration.seconds//60}min")
        
        st.markdown("---")
        
        # Acciones
        st.subheader("🔧 Acciones")
        
        if st.button("🗑️ Limpiar historial"):
            st.session_state.conversation_history = []
            st.session_state.stats['messages_sent'] = 0
            st.session_state.stats['tokens_used'] = 0
            st.session_state.stats['tools_called'] = 0
            st.rerun()
        
        if st.button("📥 Exportar conversación"):
            export_conversation()
        
        if st.button("🔄 Reiniciar cliente"):
            st.session_state.client_initialized = False
            st.rerun()
    
    return {
        'model': selected_model,
        'use_reasoning': use_reasoning,
        'max_tokens': max_tokens,
        'temperature': temperature,
        'stream_response': stream_response
    }


def get_tools_status() -> Dict[str, bool]:
    """Obtener estado de herramientas MCP"""
    # En una implementación real, esto verificaría el estado del servidor MCP
    return {
        "buscar_informacion": True,
        "buscar_noticias": True,
        "gestionar_email": True,
        "gestionar_calendario": True,
        "analizar_sentimiento": True,
        "generar_resumen": True,
        "flujo_investigacion_completo": True,
        "estado_sistema": True
    }


def render_chat_interface(config: Dict[str, Any]):
    """Renderizar interfaz principal de chat"""
    
    # Título principal
    st.title("🤖 Chat Assistant con MCP")
    st.markdown("Asistente inteligente con herramientas especializadas")
    
    # Verificar cliente
    if not setup_client():
        st.error("❌ Error configurando cliente OpenAI. Verifica tu configuración.")
        st.stop()
    
    # Container para mensajes
    chat_container = st.container()
    
    # Renderizar historial de conversación
    with chat_container:
        render_conversation_history()
    
    # Input del usuario
    with st.container():
        col1, col2 = st.columns([6, 1])
        
        with col1:
            user_input = st.text_area(
                "Tu mensaje:",
                placeholder="Escribe tu mensaje aquí...",
                height=100,
                key="user_input"
            )
        
        with col2:
            st.markdown("<br>", unsafe_allow_html=True)  # Espaciado
            send_button = st.button("📤 Enviar", type="primary", use_container_width=True)
            
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("🎯 Ejemplos", use_container_width=True):
                show_example_prompts()
    
    # Procesar mensaje si se envió
    if send_button and user_input.strip():
        asyncio.run(process_user_message(user_input.strip(), config))
        st.rerun()


def render_conversation_history():
    """Renderizar historial de conversación"""
    
    history = st.session_state.conversation_history
    
    if not history:
        st.info("👋 ¡Hola! Soy tu asistente con herramientas MCP. ¿En qué puedo ayudarte?")
        return
    
    for i, message in enumerate(history):
        if isinstance(message, dict):
            # Mensaje con metadatos adicionales
            role = message.get('role', 'user')
            content = message.get('content', '')
            tool_calls = message.get('tool_calls', [])
            tokens = message.get('tokens_used', {})
            timestamp = message.get('timestamp', '')
        else:
            # Mensaje simple
            role = message.role
            content = message.content
            tool_calls = []
            tokens = {}
            timestamp = ''
        
        if role == "user":
            st.markdown(f"""
            <div class="chat-message user-message">
                <strong>👤 Tú:</strong><br>
                {content}
            </div>
            """, unsafe_allow_html=True)
            
        elif role == "assistant":
            st.markdown(f"""
            <div class="chat-message assistant-message">
                <strong>🤖 Asistente:</strong><br>
                {content}
            </div>
            """, unsafe_allow_html=True)
            
            # Mostrar llamadas a herramientas si existen
            if tool_calls:
                for tool_call in tool_calls:
                    tool_name = tool_call.get('function', {}).get('name', 'unknown')
                    st.markdown(f"""
                    <div class="chat-message tool-call">
                        <strong>🛠️ Herramienta usada:</strong> {tool_name}
                    </div>
                    """, unsafe_allow_html=True)
            
            # Mostrar información de tokens si existe
            if tokens:
                with st.expander("📊 Detalles de la respuesta"):
                    col1, col2, col3 = st.columns(3)
                    with col1:
                        st.metric("Tokens totales", tokens.get('total_tokens', 0))
                    with col2:
                        st.metric("Tokens entrada", tokens.get('prompt_tokens', 0))
                    with col3:
                        st.metric("Tokens salida", tokens.get('completion_tokens', 0))


async def process_user_message(user_input: str, config: Dict[str, Any]):
    """Procesar mensaje del usuario"""
    
    client = st.session_state.client
    
    # Agregar mensaje del usuario al historial
    user_message = ChatMessage(role="user", content=user_input)
    st.session_state.conversation_history.append({
        'role': 'user',
        'content': user_input,
        'timestamp': datetime.now().isoformat()
    })
    
    # Preparar mensajes para OpenAI
    messages = []
    for msg in st.session_state.conversation_history:
        if isinstance(msg, dict):
            messages.append(ChatMessage(role=msg['role'], content=msg['content']))
        else:
            messages.append(msg)
    
    # Actualizar estadísticas
    st.session_state.stats['messages_sent'] += 1
    
    try:
        # Placeholder para respuesta en streaming
        if config['stream_response']:
            response_placeholder = st.empty()
            response_content = ""
            
            # Mostrar indicador de procesamiento
            with st.status("🤔 Pensando...", expanded=True) as status:
                st.write("Procesando tu solicitud...")
                
                # Streaming
                async for chunk in await client.chat_completion(
                    messages=messages,
                    model=config['model'],
                    max_tokens=config['max_tokens'],
                    temperature=config['temperature'],
                    stream=True,
                    use_reasoning=config['use_reasoning']
                ):
                    if chunk.content:
                        response_content += chunk.content
                        
                        # Actualizar placeholder
                        response_placeholder.markdown(f"""
                        <div class="chat-message assistant-message">
                            <strong>🤖 Asistente:</strong><br>
                            {response_content}
                        </div>
                        """, unsafe_allow_html=True)
                
                status.update(label="✅ Completado", state="complete")
            
            # Agregar respuesta completa al historial
            assistant_message = {
                'role': 'assistant',
                'content': response_content,
                'timestamp': datetime.now().isoformat()
            }
            
        else:
            # Respuesta no streaming
            with st.status("🤔 Procesando...", expanded=False):
                result = await client.chat_completion(
                    messages=messages,
                    model=config['model'],
                    max_tokens=config['max_tokens'],
                    temperature=config['temperature'],
                    stream=False,
                    use_reasoning=config['use_reasoning']
                )
            
            # Agregar respuesta al historial con metadatos
            assistant_message = {
                'role': 'assistant',
                'content': result.content,
                'tool_calls': result.tool_calls,
                'tokens_used': result.tokens_used,
                'timestamp': datetime.now().isoformat()
            }
            
            # Actualizar estadísticas
            st.session_state.stats['tokens_used'] += result.tokens_used.get('total_tokens', 0)
            st.session_state.stats['tools_called'] += len(result.tool_calls)
        
        st.session_state.conversation_history.append(assistant_message)
        
    except Exception as e:
        st.error(f"❌ Error procesando mensaje: {e}")
        logger.error(f"Error procesando mensaje: {e}")


def show_example_prompts():
    """Mostrar prompts de ejemplo"""
    
    examples = [
        "Busca las últimas noticias sobre inteligencia artificial",
        "Analiza el sentimiento de este texto: 'Estoy muy emocionado por el proyecto'",
        "Haz una investigación completa sobre energías renovables",
        "¿Cuál es el estado actual del sistema MCP?",
        "Genera un resumen de las tendencias tecnológicas de 2025",
        "Busca información sobre el protocolo MCP de OpenAI"
    ]
    
    st.subheader("🎯 Ejemplos de prompts")
    
    for example in examples:
        if st.button(f"💡 {example}", key=f"example_{hash(example)}"):
            st.session_state.user_input = example
            st.rerun()


def export_conversation():
    """Exportar conversación a JSON"""
    
    history = st.session_state.conversation_history
    
    if not history:
        st.warning("No hay conversación para exportar")
        return
    
    export_data = {
        "session_id": st.session_state.session_id,
        "exported_at": datetime.now().isoformat(),
        "message_count": len(history),
        "stats": st.session_state.stats,
        "conversation": history
    }
    
    # Convertir a JSON
    json_data = json.dumps(export_data, indent=2, ensure_ascii=False)
    
    # Crear nombre de archivo
    filename = f"mcp_chat_{st.session_state.session_id}.json"
    
    # Botón de descarga
    st.download_button(
        label="📥 Descargar conversación",
        data=json_data,
        file_name=filename,
        mime="application/json"
    )
    
    st.success(f"✅ Conversación lista para descargar: {filename}")


def render_system_status():
    """Renderizar página de estado del sistema"""
    
    st.title("🔧 Estado del Sistema")
    
    # Estado del cliente OpenAI
    with st.expander("🤖 Estado de OpenAI", expanded=True):
        if st.session_state.client:
            
            # Botón para probar conexión
            if st.button("🧪 Probar conexión"):
                with st.spinner("Probando..."):
                    health = asyncio.run(st.session_state.client.health_check())
                
                if health.get("status") == "healthy":
                    st.success("✅ Conexión OpenAI exitosa")
                    
                    # Mostrar detalles
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Endpoint", health.get("endpoint", "N/A"))
                    with col2:
                        st.metric("Servidores MCP", health.get("mcp_servers", 0))
                else:
                    st.error(f"❌ Error: {health.get('error', 'Desconocido')}")
        else:
            st.warning("⚠️ Cliente no inicializado")
    
    # Estado de herramientas MCP
    with st.expander("🛠️ Herramientas MCP", expanded=True):
        tools_status = get_tools_status()
        
        for tool, status in tools_status.items():
            icon = "✅" if status else "❌"
            status_text = "Disponible" if status else "No disponible"
            
            col1, col2 = st.columns([3, 1])
            with col1:
                st.text(f"{icon} {tool}")
            with col2:
                st.text(status_text)
    
    # Estadísticas globales
    with st.expander("📊 Estadísticas del Cliente", expanded=True):
        if st.session_state.client:
            stats = st.session_state.client.get_stats()
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Requests", stats.get('total_requests', 0))
            with col2:
                st.metric("Successful Requests", stats.get('successful_requests', 0))
            with col3:
                st.metric("Total Tokens", stats.get('total_tokens_used', 0))
            with col4:
                st.metric("Tool Calls", stats.get('tool_calls_made', 0))


def main():
    """Función principal de la aplicación"""
    
    initialize_session_state()
    
    # Navegación en sidebar
    with st.sidebar:
        st.markdown("---")
        page = st.selectbox(
            "📍 Navegación",
            ["💬 Chat", "🔧 Estado del Sistema"],
            index=0
        )
    
    if page == "💬 Chat":
        config = render_sidebar()
        render_chat_interface(config)
        
    elif page == "🔧 Estado del Sistema":
        render_sidebar()
        render_system_status()


if __name__ == "__main__":
    main()
