"""
Aplicación web Flask para el sistema de chat MCP + OpenAI
"""

import asyncio
import json
from datetime import datetime
from typing import Dict, Any, Optional
import uuid

from flask import Flask, render_template, request, jsonify, session, Response
from flask_cors import CORS
from flask_session import Session

from ...core.config import get_settings
from ...core.logging_config import get_logger
from ...orchestrator.chat_orchestrator import ChatOrchestrator, ChatRequest, ChatResult
from ...core.exceptions import ValidationError, OrchestrationError


class ChatWebApp:
    """Aplicación web para el sistema de chat"""
    
    def __init__(self):
        self.settings = get_settings()
        self.logger = get_logger(__name__)
        
        # Configurar Flask
        self.app = Flask(__name__)
        self.app.secret_key = self.settings.web.secret_key
        
        # Configurar CORS
        CORS(self.app, origins=self.settings.web.allowed_origins)
        
        # Configurar sesiones
        self.app.config['SESSION_TYPE'] = 'filesystem'
        self.app.config['SESSION_PERMANENT'] = False
        Session(self.app)
        
        # Inicializar orquestador
        self.orchestrator: Optional[ChatOrchestrator] = None
        
        # Configurar rutas
        self._setup_routes()
        
        self.logger.info("ChatWebApp inicializada")
    
    def _setup_routes(self):
        """Configurar rutas de la aplicación"""
        
        @self.app.route('/')
        def index():
            """Página principal del chat"""
            return render_template('index.html')
        
        @self.app.route('/api/chat', methods=['POST'])
        def chat():
            """Endpoint principal de chat"""
            return asyncio.run(self._handle_chat_request())
        
        @self.app.route('/api/chat/stream', methods=['POST'])
        def chat_stream():
            """Endpoint de chat con streaming"""
            return asyncio.run(self._handle_chat_stream())
        
        @self.app.route('/api/session/info', methods=['GET'])
        def session_info():
            """Obtener información de la sesión actual"""
            return asyncio.run(self._handle_session_info())
        
        @self.app.route('/api/health', methods=['GET'])
        def health():
            """Health check del sistema"""
            return asyncio.run(self._handle_health_check())
        
        @self.app.route('/api/stats', methods=['GET'])
        def stats():
            """Estadísticas del sistema"""
            return asyncio.run(self._handle_stats())
        
        @self.app.errorhandler(404)
        def not_found(error):
            return jsonify({'error': 'Endpoint not found'}), 404
        
        @self.app.errorhandler(500)
        def internal_error(error):
            self.logger.error(f"Error interno del servidor: {error}")
            return jsonify({'error': 'Internal server error'}), 500
    
    async def _handle_chat_request(self) -> tuple:
        """Manejar solicitud de chat regular"""
        try:
            # Validar entrada
            if not request.is_json:
                return jsonify({'error': 'Content-Type must be application/json'}), 400
            
            data = request.get_json()
            message = data.get('message', '').strip()
            
            if not message:
                return jsonify({'error': 'Message is required'}), 400
            
            # Obtener o crear session_id
            session_id = self._get_or_create_session_id()
            
            # Crear request
            chat_request = ChatRequest(
                message=message,
                session_id=session_id,
                user_id=self._get_user_id(),
                tools_enabled=data.get('tools_enabled', True),
                stream_response=False,
                context=data.get('context')
            )
            
            # Procesar con orquestador
            if not self.orchestrator:
                return jsonify({'error': 'Chat system not initialized'}), 503
            
            result = await self.orchestrator.process_chat_request(chat_request)
            
            # Formatear respuesta
            response_data = {
                'response': result.response,
                'session_id': result.session_id,
                'tools_used': result.tool_calls_made,
                'tokens_used': result.tokens_used,
                'response_time': result.response_time,
                'cached': result.cached,
                'timestamp': datetime.now().isoformat()
            }
            
            if result.error:
                response_data['error'] = result.error
                return jsonify(response_data), 500
            
            return jsonify(response_data), 200
            
        except ValidationError as e:
            self.logger.warning(f"Error de validación: {e}")
            return jsonify({'error': f'Validation error: {e}'}), 400
        
        except Exception as e:
            self.logger.error(f"Error procesando chat: {e}")
            return jsonify({'error': 'Failed to process chat request'}), 500
    
    async def _handle_chat_stream(self) -> Response:
        """Manejar solicitud de chat con streaming"""
        try:
            # Validar entrada
            if not request.is_json:
                return Response('Content-Type must be application/json', status=400)
            
            data = request.get_json()
            message = data.get('message', '').strip()
            
            if not message:
                return Response('Message is required', status=400)
            
            # Configurar streaming
            def generate_response():
                try:
                    # Obtener session_id
                    session_id = self._get_or_create_session_id()
                    
                    # Crear request
                    chat_request = ChatRequest(
                        message=message,
                        session_id=session_id,
                        user_id=self._get_user_id(),
                        tools_enabled=data.get('tools_enabled', True),
                        stream_response=True,
                        context=data.get('context')
                    )
                    
                    # Procesar streaming (simplificado - no implementado completamente)
                    # TODO: Implementar streaming real con OpenAI
                    
                    # Por ahora, simular streaming con respuesta completa
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    
                    result = loop.run_until_complete(
                        self.orchestrator.process_chat_request(chat_request)
                    )
                    
                    # Enviar respuesta en chunks
                    words = result.response.split()
                    for i, word in enumerate(words):
                        chunk_data = {
                            'type': 'content',
                            'data': word + ' ',
                            'index': i,
                            'total': len(words)
                        }
                        yield f"data: {json.dumps(chunk_data)}\n\n"
                        
                        # Pausa para simular streaming
                        import time
                        time.sleep(0.05)
                    
                    # Enviar datos finales
                    final_data = {
                        'type': 'complete',
                        'session_id': result.session_id,
                        'tools_used': result.tool_calls_made,
                        'tokens_used': result.tokens_used
                    }
                    yield f"data: {json.dumps(final_data)}\n\n"
                    
                except Exception as e:
                    error_data = {
                        'type': 'error',
                        'error': str(e)
                    }
                    yield f"data: {json.dumps(error_data)}\n\n"
            
            return Response(
                generate_response(),
                mimetype='text/event-stream',
                headers={
                    'Cache-Control': 'no-cache',
                    'Connection': 'keep-alive'
                }
            )
            
        except Exception as e:
            self.logger.error(f"Error en chat streaming: {e}")
            return Response(f'Error: {e}', status=500)
    
    async def _handle_session_info(self) -> tuple:
        """Manejar solicitud de información de sesión"""
        try:
            session_id = session.get('chat_session_id')
            
            if not session_id or not self.orchestrator:
                return jsonify({'session_id': None, 'info': None}), 200
            
            session_info = await self.orchestrator.get_session_info(session_id)
            
            return jsonify({
                'session_id': session_id,
                'info': session_info
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error obteniendo info de sesión: {e}")
            return jsonify({'error': 'Failed to get session info'}), 500
    
    async def _handle_health_check(self) -> tuple:
        """Manejar health check"""
        try:
            health_status = {
                'status': 'healthy',
                'timestamp': datetime.now().isoformat(),
                'components': {}
            }
            
            if self.orchestrator:
                orchestrator_status = await self.orchestrator.health_check()
                health_status['components']['orchestrator'] = orchestrator_status
                
                if 'error' in orchestrator_status:
                    health_status['status'] = 'degraded'
            else:
                health_status['status'] = 'unhealthy'
                health_status['components']['orchestrator'] = 'not_initialized'
            
            status_code = 200 if health_status['status'] == 'healthy' else 503
            
            return jsonify(health_status), status_code
            
        except Exception as e:
            self.logger.error(f"Error en health check: {e}")
            return jsonify({
                'status': 'unhealthy',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }), 503
    
    async def _handle_stats(self) -> tuple:
        """Manejar solicitud de estadísticas"""
        try:
            if not self.orchestrator:
                return jsonify({'error': 'Orchestrator not initialized'}), 503
            
            stats = await self.orchestrator.get_stats()
            
            # Agregar estadísticas de la web app
            stats['web_app'] = {
                'active_sessions': len(session.get('chat_session_id', [])) if session else 0,
                'uptime': 'unknown'  # TODO: Implementar tracking de uptime
            }
            
            return jsonify(stats), 200
            
        except Exception as e:
            self.logger.error(f"Error obteniendo estadísticas: {e}")
            return jsonify({'error': 'Failed to get stats'}), 500
    
    def _get_or_create_session_id(self) -> str:
        """Obtener o crear session_id"""
        if 'chat_session_id' not in session:
            session['chat_session_id'] = str(uuid.uuid4())
        return session['chat_session_id']
    
    def _get_user_id(self) -> str:
        """Obtener user_id (por ahora anónimo)"""
        if 'user_id' not in session:
            session['user_id'] = f"web_user_{uuid.uuid4().hex[:8]}"
        return session['user_id']
    
    async def initialize(self) -> None:
        """Inicializar la aplicación web"""
        try:
            self.logger.info("Inicializando ChatWebApp...")
            
            # Inicializar orquestador
            self.orchestrator = ChatOrchestrator()
            await self.orchestrator.initialize()
            
            self.logger.info("ChatWebApp inicializada correctamente")
            
        except Exception as e:
            self.logger.error(f"Error inicializando web app: {e}")
            raise OrchestrationError(f"Failed to initialize web app: {e}")
    
    def run(self, host: str = None, port: int = None, debug: bool = False):
        """Ejecutar la aplicación web"""
        host = host or self.settings.web.host
        port = port or self.settings.web.port
        
        self.logger.info(f"Iniciando servidor web en {host}:{port}")
        
        self.app.run(
            host=host,
            port=port,
            debug=debug,
            threaded=True
        )
    
    async def close(self) -> None:
        """Cerrar la aplicación web"""
        try:
            if self.orchestrator:
                await self.orchestrator.close()
            
            self.logger.info("ChatWebApp cerrada")
            
        except Exception as e:
            self.logger.error(f"Error cerrando web app: {e}")


# Función para crear la aplicación
def create_app() -> Flask:
    """Factory function para crear la aplicación Flask"""
    web_app = ChatWebApp()
    
    # Inicializar en un event loop
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(web_app.initialize())
    
    return web_app.app


# Para desarrollo
if __name__ == '__main__':
    import asyncio
    
    async def main():
        web_app = ChatWebApp()
        await web_app.initialize()
        web_app.run(debug=True)
    
    asyncio.run(main())
