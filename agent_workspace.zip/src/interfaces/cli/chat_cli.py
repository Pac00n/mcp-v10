"""
Interfaz CLI para el sistema de chat MCP + OpenAI
Implementa comandos interactivos usando Typer y Rich
"""

import asyncio
import json
import os
import sys
from pathlib import Path
from typing import List, Optional, Dict, Any
from datetime import datetime

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt, Confirm
from rich.markdown import Markdown
from rich.syntax import Syntax
from rich.live import Live
from rich.layout import Layout

# Agregar el directorio src al path para imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from openai_integration.responses_client import (
    OpenAIResponsesClient, 
    ChatMessage, 
    MCPServerConfig,
    ResponseResult,
    StreamChunk
)
from core.config import get_settings
from core.logging_config import get_logger

# Crear aplicación Typer
app = typer.Typer(
    name="mcp-chat",
    help="🤖 Sistema de Chat MCP + OpenAI - Interfaz de línea de comandos",
    add_completion=False
)

# Console para output mejorado
console = Console()
logger = get_logger(__name__)

# Estado global de la sesión
session_state = {
    "conversation_history": [],
    "client": None,
    "current_model": None,
    "session_id": None,
    "config_loaded": False
}


@app.command()
def chat(
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Modelo OpenAI a usar"),
    reasoning: bool = typer.Option(False, "--reasoning", "-r", help="Usar modelo de razonamiento"),
    stream: bool = typer.Option(True, "--stream/--no-stream", help="Streaming de respuestas"),
    max_tokens: Optional[int] = typer.Option(None, "--max-tokens", help="Máximo de tokens"),
    temperature: Optional[float] = typer.Option(None, "--temperature", "-t", help="Temperatura del modelo"),
    interactive: bool = typer.Option(True, "--interactive/--single", help="Modo interactivo"),
    message: Optional[str] = typer.Option(None, "--message", help="Mensaje único (modo no interactivo)")
):
    """
    💬 Iniciar sesión de chat interactiva con OpenAI + MCP
    """
    try:
        # Mostrar banner
        _show_banner()
        
        # Configurar cliente
        if not _setup_client():
            typer.echo("❌ Error configurando cliente. Verifica tu configuración.")
            raise typer.Exit(1)
        
        # Configurar parámetros de la sesión
        session_state["current_model"] = model
        session_state["session_id"] = f"cli_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        console.print(f"[green]✅ Cliente configurado correctamente[/green]")
        
        if not interactive and message:
            # Modo mensaje único
            asyncio.run(_handle_single_message(
                message, model, reasoning, stream, max_tokens, temperature
            ))
        else:
            # Modo interactivo
            asyncio.run(_interactive_chat_loop(
                model, reasoning, stream, max_tokens, temperature
            ))
            
    except KeyboardInterrupt:
        console.print("\n[yellow]👋 Chat finalizado por el usuario[/yellow]")
    except Exception as e:
        console.print(f"[red]❌ Error: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def config(
    show: bool = typer.Option(False, "--show", help="Mostrar configuración actual"),
    test: bool = typer.Option(False, "--test", help="Probar conexión"),
    setup: bool = typer.Option(False, "--setup", help="Configurar interactivamente")
):
    """
    ⚙️ Gestionar configuración del sistema
    """
    if show:
        _show_config()
    elif test:
        asyncio.run(_test_connection())
    elif setup:
        _interactive_setup()
    else:
        typer.echo("Usa --show, --test o --setup")


@app.command()
def tools(
    list_tools: bool = typer.Option(False, "--list", help="Listar herramientas disponibles"),
    server_status: bool = typer.Option(False, "--status", help="Estado del servidor MCP"),
    test_tool: Optional[str] = typer.Option(None, "--test", help="Probar una herramienta específica")
):
    """
    🛠️ Gestionar herramientas MCP
    """
    if list_tools:
        _list_available_tools()
    elif server_status:
        asyncio.run(_check_mcp_server_status())
    elif test_tool:
        asyncio.run(_test_mcp_tool(test_tool))
    else:
        typer.echo("Usa --list, --status o --test <herramienta>")


@app.command()
def history(
    show: bool = typer.Option(False, "--show", help="Mostrar historial de la sesión"),
    export: Optional[str] = typer.Option(None, "--export", help="Exportar a archivo"),
    clear: bool = typer.Option(False, "--clear", help="Limpiar historial")
):
    """
    📜 Gestionar historial de conversación
    """
    if show:
        _show_conversation_history()
    elif export:
        _export_history(export)
    elif clear:
        if Confirm.ask("¿Limpiar historial de conversación?"):
            session_state["conversation_history"] = []
            console.print("[green]✅ Historial limpiado[/green]")
    else:
        typer.echo("Usa --show, --export <archivo> o --clear")


def _show_banner():
    """Mostrar banner de bienvenida"""
    banner = """
    🤖 Sistema de Chat MCP + OpenAI
    ===============================
    
    Características:
    • Integración nativa con MCP
    • 8 herramientas especializadas
    • Streaming de respuestas
    • Modelos de razonamiento
    • Historial de conversación
    """
    
    console.print(Panel(banner, style="blue"))


def _setup_client() -> bool:
    """Configurar cliente OpenAI"""
    try:
        session_state["client"] = OpenAIResponsesClient()
        
        # Configurar servidor MCP por defecto
        session_state["client"].configure_default_mcp_server()
        
        session_state["config_loaded"] = True
        return True
        
    except Exception as e:
        console.print(f"[red]Error configurando cliente: {e}[/red]")
        return False


async def _handle_single_message(
    message: str,
    model: Optional[str],
    reasoning: bool,
    stream: bool,
    max_tokens: Optional[int],
    temperature: Optional[float]
) -> None:
    """Manejar mensaje único (no interactivo)"""
    
    client = session_state["client"]
    
    # Crear mensaje
    chat_message = ChatMessage(role="user", content=message)
    
    console.print(f"[blue]Usuario:[/blue] {message}\n")
    
    with console.status("[bold green]Procesando..."):
        try:
            if stream:
                console.print("[green]Asistente:[/green] ", end="")
                
                # Streaming
                async for chunk in await client.chat_completion(
                    messages=[chat_message],
                    model=model,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    stream=True,
                    use_reasoning=reasoning
                ):
                    if chunk.content:
                        console.print(chunk.content, end="")
                
                console.print()  # Nueva línea al final
                
            else:
                # Respuesta completa
                result = await client.chat_completion(
                    messages=[chat_message],
                    model=model,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    stream=False,
                    use_reasoning=reasoning
                )
                
                console.print(f"[green]Asistente:[/green] {result.content}")
                
                # Mostrar información adicional
                _show_response_info(result)
                
        except Exception as e:
            console.print(f"[red]❌ Error: {e}[/red]")


async def _interactive_chat_loop(
    model: Optional[str],
    reasoning: bool,
    stream: bool,
    max_tokens: Optional[int],
    temperature: Optional[float]
) -> None:
    """Loop de chat interactivo"""
    
    client = session_state["client"]
    conversation_history = session_state["conversation_history"]
    
    console.print("[green]💬 Chat iniciado. Escribe 'salir', 'quit' o 'exit' para terminar.[/green]")
    console.print("[dim]Comandos especiales: /help, /clear, /config, /tools[/dim]\n")
    
    while True:
        try:
            # Obtener input del usuario
            user_input = Prompt.ask("\n[blue]Tú")
            
            if not user_input.strip():
                continue
            
            # Comandos especiales
            if user_input.lower() in ['salir', 'quit', 'exit']:
                break
            
            if user_input.startswith('/'):
                if await _handle_special_command(user_input):
                    continue
                else:
                    break
            
            # Agregar mensaje del usuario al historial
            user_message = ChatMessage(role="user", content=user_input)
            conversation_history.append(user_message)
            
            # Preparar mensajes para OpenAI
            messages = conversation_history.copy()
            
            with console.status("[bold green]Pensando..."):
                try:
                    if stream:
                        # Streaming
                        console.print("[green]Asistente:[/green] ", end="")
                        response_content = ""
                        
                        async for chunk in await client.chat_completion(
                            messages=messages,
                            model=model,
                            max_tokens=max_tokens,
                            temperature=temperature,
                            stream=True,
                            use_reasoning=reasoning
                        ):
                            if chunk.content:
                                console.print(chunk.content, end="")
                                response_content += chunk.content
                        
                        console.print()  # Nueva línea
                        
                        # Agregar respuesta al historial
                        assistant_message = ChatMessage(role="assistant", content=response_content)
                        conversation_history.append(assistant_message)
                        
                    else:
                        # Respuesta completa
                        result = await client.chat_completion(
                            messages=messages,
                            model=model,
                            max_tokens=max_tokens,
                            temperature=temperature,
                            stream=False,
                            use_reasoning=reasoning
                        )
                        
                        console.print(f"[green]Asistente:[/green] {result.content}")
                        
                        # Agregar al historial
                        assistant_message = ChatMessage(role="assistant", content=result.content)
                        conversation_history.append(assistant_message)
                        
                        # Mostrar info adicional en modo verbose
                        if reasoning or len(result.tool_calls) > 0:
                            _show_response_info(result)
                        
                except Exception as e:
                    console.print(f"[red]❌ Error: {e}[/red]")
                    
        except KeyboardInterrupt:
            break
        except EOFError:
            break


async def _handle_special_command(command: str) -> bool:
    """Manejar comandos especiales. Returns True para continuar, False para salir"""
    
    if command == "/help":
        _show_help_commands()
        
    elif command == "/clear":
        session_state["conversation_history"] = []
        console.print("[green]✅ Historial limpiado[/green]")
        
    elif command == "/config":
        _show_config()
        
    elif command == "/tools":
        await _check_mcp_server_status()
        
    elif command == "/stats":
        if session_state["client"]:
            stats = session_state["client"].get_stats()
            _show_stats(stats)
        
    elif command == "/quit" or command == "/exit":
        return False
        
    else:
        console.print(f"[red]Comando desconocido: {command}[/red]")
        console.print("Usa /help para ver comandos disponibles")
    
    return True


def _show_help_commands():
    """Mostrar comandos disponibles"""
    help_text = """
[bold]Comandos disponibles:[/bold]

[blue]/help[/blue]     - Mostrar esta ayuda
[blue]/clear[/blue]    - Limpiar historial de conversación
[blue]/config[/blue]   - Mostrar configuración actual
[blue]/tools[/blue]    - Estado de herramientas MCP
[blue]/stats[/blue]    - Estadísticas del cliente
[blue]/quit[/blue]     - Salir del chat

[dim]También puedes usar: salir, quit, exit[/dim]
"""
    console.print(Panel(help_text, title="Ayuda"))


def _show_response_info(result: ResponseResult):
    """Mostrar información adicional de la respuesta"""
    
    info_table = Table(title="Información de Respuesta")
    info_table.add_column("Campo", style="cyan")
    info_table.add_column("Valor", style="green")
    
    info_table.add_row("Modelo", result.model_used)
    info_table.add_row("Tokens", str(result.tokens_used.get('total_tokens', 'N/A')))
    info_table.add_row("Tiempo", f"{result.response_time:.2f}s")
    info_table.add_row("Razón", result.finish_reason)
    
    if result.tool_calls:
        info_table.add_row("Herramientas", f"{len(result.tool_calls)} llamadas")
    
    console.print(info_table)


def _show_config():
    """Mostrar configuración actual"""
    try:
        settings = get_settings()
        
        config_table = Table(title="Configuración Actual")
        config_table.add_column("Parámetro", style="cyan")
        config_table.add_column("Valor", style="green")
        
        config_table.add_row("OpenAI Model", settings.openai.default_model)
        config_table.add_row("Max Tokens", str(settings.openai.max_tokens))
        config_table.add_row("Temperature", str(settings.openai.temperature))
        config_table.add_row("MCP Server", settings.mcp.server_url)
        config_table.add_row("MCP Label", settings.mcp.server_label)
        
        console.print(config_table)
        
    except Exception as e:
        console.print(f"[red]Error mostrando configuración: {e}[/red]")


async def _test_connection():
    """Probar conexión con OpenAI y MCP"""
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        
        # Test OpenAI
        task1 = progress.add_task("Probando OpenAI...", total=1)
        
        try:
            client = OpenAIResponsesClient()
            health = await client.health_check()
            
            if health["status"] == "healthy":
                console.print("[green]✅ OpenAI: Conexión exitosa[/green]")
            else:
                console.print(f"[red]❌ OpenAI: {health.get('error', 'Error desconocido')}[/red]")
            
            progress.update(task1, completed=1)
            
        except Exception as e:
            console.print(f"[red]❌ OpenAI: Error - {e}[/red]")
            progress.update(task1, completed=1)


async def _check_mcp_server_status():
    """Verificar estado del servidor MCP"""
    console.print("[blue]🔧 Estado de herramientas MCP:[/blue]\n")
    
    # Lista de herramientas esperadas
    expected_tools = [
        "buscar_informacion",
        "buscar_noticias", 
        "gestionar_email",
        "gestionar_calendario",
        "analizar_sentimiento",
        "generar_resumen",
        "flujo_investigacion_completo",
        "estado_sistema"
    ]
    
    tools_table = Table(title="Herramientas MCP Disponibles")
    tools_table.add_column("Herramienta", style="cyan")
    tools_table.add_column("Descripción", style="white")
    tools_table.add_column("Estado", style="green")
    
    for tool in expected_tools:
        # Mapear nombres a descripciones
        descriptions = {
            "buscar_informacion": "Búsqueda web con SerpAPI",
            "buscar_noticias": "Búsqueda de noticias actuales",
            "gestionar_email": "Gestión de Gmail",
            "gestionar_calendario": "Gestión de Google Calendar",
            "analizar_sentimiento": "Análisis de sentimiento de texto",
            "generar_resumen": "Generación de resúmenes",
            "flujo_investigacion_completo": "Flujo de investigación completa",
            "estado_sistema": "Estado del sistema MCP"
        }
        
        tools_table.add_row(
            tool,
            descriptions.get(tool, "Herramienta MCP"),
            "✅ Disponible"
        )
    
    console.print(tools_table)


async def _test_mcp_tool(tool_name: str):
    """Probar una herramienta MCP específica"""
    console.print(f"[blue]🧪 Probando herramienta: {tool_name}[/blue]")
    
    # Ejemplos de prueba según la herramienta
    test_cases = {
        "estado_sistema": "Obtener estado del sistema",
        "analizar_sentimiento": "Analizar: 'Este es un texto muy positivo'",
        "generar_resumen": "Resumir: 'Texto de ejemplo para probar la funcionalidad'"
    }
    
    if tool_name in test_cases:
        console.print(f"Caso de prueba: {test_cases[tool_name]}")
        console.print("[green]✅ Herramienta disponible para prueba[/green]")
    else:
        console.print("[yellow]⚠️ Herramienta válida, pero sin caso de prueba automático[/yellow]")


def _list_available_tools():
    """Listar herramientas disponibles"""
    await _check_mcp_server_status()


def _show_conversation_history():
    """Mostrar historial de conversación"""
    history = session_state["conversation_history"]
    
    if not history:
        console.print("[yellow]📭 No hay historial de conversación[/yellow]")
        return
    
    console.print(f"[blue]📜 Historial de Conversación ({len(history)} mensajes):[/blue]\n")
    
    for i, message in enumerate(history, 1):
        role_color = "blue" if message.role == "user" else "green"
        role_name = "Tú" if message.role == "user" else "Asistente"
        
        console.print(f"[{role_color}]{i}. {role_name}:[/{role_color}] {message.content[:100]}...")


def _export_history(filename: str):
    """Exportar historial a archivo"""
    history = session_state["conversation_history"]
    
    if not history:
        console.print("[yellow]📭 No hay historial para exportar[/yellow]")
        return
    
    try:
        # Convertir a formato exportable
        export_data = {
            "session_id": session_state["session_id"],
            "exported_at": datetime.now().isoformat(),
            "message_count": len(history),
            "conversation": [
                {
                    "role": msg.role,
                    "content": msg.content,
                    "timestamp": getattr(msg, 'timestamp', None)
                }
                for msg in history
            ]
        }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)
        
        console.print(f"[green]✅ Historial exportado a: {filename}[/green]")
        
    except Exception as e:
        console.print(f"[red]❌ Error exportando historial: {e}[/red]")


def _show_stats(stats: Dict[str, Any]):
    """Mostrar estadísticas del cliente"""
    stats_table = Table(title="Estadísticas del Cliente")
    stats_table.add_column("Métrica", style="cyan")
    stats_table.add_column("Valor", style="green")
    
    for key, value in stats.items():
        stats_table.add_row(key.replace('_', ' ').title(), str(value))
    
    console.print(stats_table)


def _interactive_setup():
    """Configuración interactiva"""
    console.print("[blue]🔧 Configuración Interactiva[/blue]\n")
    
    console.print("Esta funcionalidad requiere editar variables de entorno.")
    console.print("Por favor, configura tu archivo .env con:")
    console.print("")
    console.print("OPENAI_API_KEY=tu_clave_openai")
    console.print("MCP_SERVER_URL=http://localhost:8000/mcp")
    console.print("MCP_API_KEY=tu_clave_mcp")
    console.print("")
    console.print("Ver .env.example para referencia completa.")


if __name__ == "__main__":
    app()
