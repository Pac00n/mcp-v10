#!/usr/bin/env python3
"""
Prueba simple y real del sistema - sin necesidad de API keys reales
"""

import os
import sys
from pathlib import Path

# Agregar el directorio src al path
sys.path.insert(0, str(Path(__file__).parent / "src"))

def test_openai_client_basic():
    """Probar que el cliente OpenAI se puede inicializar (sin llamadas reales)"""
    print("🧪 Probando inicialización del cliente OpenAI...")
    
    try:
        from openai import OpenAI
        
        # Crear cliente con API key falsa (no haremos llamadas reales)
        client = OpenAI(api_key="test-key-fake")
        print("✅ Cliente OpenAI se puede inicializar")
        return True
    except Exception as e:
        print(f"❌ Error inicializando OpenAI: {e}")
        return False

def test_mcp_tools_config():
    """Probar configuración MCP básica"""
    print("🧪 Probando configuración MCP...")
    
    try:
        # Verificar que podemos definir herramientas MCP como especifica OpenAI
        mcp_config = {
            "type": "mcp",
            "server_url": "http://localhost:8080/mcp",
            "server_label": "test_tools",
            "allowed_tools": ["buscar_informacion", "gestionar_email"],
            "require_approval": "never",
            "headers": {"X-API-KEY": "test-key"}
        }
        
        print(f"✅ Configuración MCP válida: {mcp_config['server_label']}")
        return True
    except Exception as e:
        print(f"❌ Error configurando MCP: {e}")
        return False

def test_file_structure():
    """Verificar que los archivos principales existen"""
    print("🧪 Verificando estructura de archivos...")
    
    required_files = [
        "src/core/config.py",
        "src/mcp/server.py", 
        "scripts/start_mcp_chat.py",
        ".env.example",
        "requirements.txt"
    ]
    
    missing_files = []
    for file_path in required_files:
        if not Path(file_path).exists():
            missing_files.append(file_path)
    
    if missing_files:
        print(f"❌ Archivos faltantes: {missing_files}")
        return False
    else:
        print("✅ Estructura de archivos correcta")
        return True

def main():
    """Ejecutar todas las pruebas simples"""
    print("🚀 Iniciando pruebas reales simples del sistema MCP\n")
    
    tests = [
        ("Inicialización OpenAI", test_openai_client_basic),
        ("Configuración MCP", test_mcp_tools_config),
        ("Estructura de archivos", test_file_structure)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"📋 Ejecutando: {test_name}")
        result = test_func()
        results.append((test_name, result))
        print()
    
    # Resumen
    print("📊 RESUMEN DE PRUEBAS REALES:")
    passed = 0
    for test_name, passed_test in results:
        status = "✅ PASÓ" if passed_test else "❌ FALLÓ"
        print(f"  {status} - {test_name}")
        if passed_test:
            passed += 1
    
    print(f"\n🎯 Resultado final: {passed}/{len(tests)} pruebas pasaron")
    
    if passed == len(tests):
        print("🎉 ¡Todas las pruebas reales pasaron!")
        return True
    else:
        print(f"⚠️ {len(tests) - passed} pruebas fallaron.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
