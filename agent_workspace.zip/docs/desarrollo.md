# 💻 Guía de Desarrollo - Sistema MCP Chat

## Arquitectura del Sistema

### Componentes Principales

```
Sistema MCP Chat
├── 🧠 Cliente OpenAI (Responses API + MCP)
├── 🔗 Servidor MCP (Model Context Protocol)
├── 🛠️ Herramientas Especializadas
├── 🖥️ Interfaces de Usuario (CLI, Web, API)
└── ⚙️ Configuración y Utilidades
```

### Flujo de Datos

```
Usuario → Interface → Cliente OpenAI → MCP Server → Herramientas → APIs Externas
   ↓                                                                        ↓
Respuesta ← Interface ← Cliente OpenAI ← MCP Server ← Herramientas ← APIs Externas
```

## Estructura del Proyecto

```
/workspace/
├── src/                          # Código fuente principal
│   ├── core/                     # Componentes centrales
│   │   ├── config.py            # Configuración del sistema
│   │   ├── constants.py         # Constantes globales
│   │   ├── exceptions.py        # Excepciones personalizadas
│   │   └── logging_config.py    # Configuración de logging
│   ├── mcp/                      # Servidor MCP
│   │   ├── server.py            # Servidor principal MCP
│   │   ├── tools/               # Herramientas especializadas
│   │   └── auth/                # Autenticación OAuth
│   ├── openai_integration/       # Integración OpenAI
│   │   ├── responses_client_v2.py # Cliente Responses API
│   │   └── responses_client.py   # Cliente alternativo
│   ├── interfaces/               # Interfaces de usuario
│   │   ├── cli/                 # Interfaz CLI
│   │   ├── web/                 # Interfaz Web (Streamlit)
│   │   └── api/                 # API REST (FastAPI)
│   └── utils/                    # Utilidades
├── scripts/                      # Scripts de ejecución
├── docs/                         # Documentación
├── config/                       # Archivos de configuración
├── tests/                        # Pruebas unitarias
└── deployment/                   # Archivos de despliegue
```

## Tecnologías Utilizadas

### Backend Core
- **Python 3.9+**: Lenguaje principal
- **AsyncIO**: Programación asíncrona
- **Pydantic**: Validación de datos
- **aiohttp**: Cliente HTTP asíncrono

### Integración OpenAI
- **openai**: SDK oficial de OpenAI
- **Responses API**: API de respuestas estructuradas
- **MCP (Model Context Protocol)**: Protocolo de contexto

### Servidor MCP
- **mcp**: Librería oficial MCP
- **FastAPI**: Framework web para endpoints
- **uvicorn**: Servidor ASGI

### APIs Externas
- **serpapi**: Búsquedas web y noticias
- **google-api-python-client**: APIs de Google
- **google-auth**: Autenticación Google

### Interfaces
- **Typer**: CLI moderna con Rich
- **Streamlit**: Interfaz web interactiva
- **FastAPI**: API REST con documentación automática

### Utilidades
- **python-dotenv**: Gestión de variables de entorno
- **loguru**: Logging avanzado
- **pytest**: Framework de testing

## Configuración de Desarrollo

### 1. Entorno de Desarrollo

```bash
# Clonar repositorio
git clone <repo-url>
cd mcp-chat-system

# Crear entorno virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# o venv\Scriptsctivate  # Windows

# Instalar dependencias de desarrollo
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

### 2. Variables de Entorno

```bash
# Copiar template
cp .env.template .env

# Configurar para desarrollo
cat >> .env << EOF
ENVIRONMENT=development
DEBUG=true
LOG_LEVEL=DEBUG
RELOAD=true
EOF
```

### 3. Estructura de Testing

```bash
# Ejecutar tests unitarios
pytest tests/unit/

# Ejecutar tests de integración
pytest tests/integration/

# Ejecutar todos los tests
pytest

# Con cobertura
pytest --cov=src tests/
```

## Desarrollo de Componentes

### 1. Agregar Nueva Herramienta MCP

```python
# src/mcp/tools/mi_nueva_tool.py
from .base_tool import BaseTool
from typing import Dict, Any

class MiNuevaTool(BaseTool):
    """Nueva herramienta personalizada"""
    
    def __init__(self):
        super().__init__()
        self.name = "mi_nueva_herramienta"
        self.description = "Descripción de la herramienta"
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Ejecutar la herramienta"""
        # Implementar lógica aquí
        return {
            "result": "Resultado de la herramienta",
            "status": "success"
        }
```

### 2. Registrar Herramienta en el Servidor

```python
# src/mcp/server.py
from .tools.mi_nueva_tool import MiNuevaTool

class MCPChatServer:
    def __init__(self):
        # ... código existente ...
        self.tools["mi_nueva_herramienta"] = MiNuevaTool()
```

### 3. Agregar Nueva Interface

```python
# src/interfaces/mi_interface/app.py
from fastapi import FastAPI
from ...openai_integration.responses_client_v2 import OpenAIResponsesClientV2

app = FastAPI()
client = OpenAIResponsesClientV2()

@app.post("/chat")
async def chat(message: str):
    """Endpoint de chat"""
    response = await client.chat([
        {"role": "user", "content": message}
    ])
    return {"response": response.content}
```

## Patrones de Desarrollo

### 1. Manejo de Errores

```python
from core.exceptions import OpenAIError, MCPError

try:
    result = await some_api_call()
except OpenAIError as e:
    logger.error(f"Error de OpenAI: {e}")
    raise
except MCPError as e:
    logger.error(f"Error de MCP: {e}")
    raise
```

### 2. Logging Estructurado

```python
from core.logging_config import get_logger

logger = get_logger(__name__)

logger.info("Operación exitosa", extra={
    "user_id": user_id,
    "operation": "search",
    "duration": duration
})
```

### 3. Configuración

```python
from core.config import get_settings

settings = get_settings()
api_key = settings.openai_api_key
debug_mode = settings.debug
```

### 4. Validación de Datos

```python
from pydantic import BaseModel, validator

class ChatRequest(BaseModel):
    message: str
    user_id: str
    
    @validator('message')
    def message_not_empty(cls, v):
        if not v.strip():
            raise ValueError('Message cannot be empty')
        return v
```

## Testing

### 1. Test Unitario

```python
# tests/unit/test_openai_client.py
import pytest
from src.openai_integration.responses_client_v2 import OpenAIResponsesClientV2

class TestOpenAIClient:
    def test_client_initialization(self):
        client = OpenAIResponsesClientV2()
        assert client is not None
    
    def test_mcp_configuration(self):
        client = OpenAIResponsesClientV2()
        client.configure_mcp_tool(
            server_url="http://test:8080/mcp",
            server_label="test"
        )
        assert len(client.mcp_tools) == 1
```

### 2. Test de Integración

```python
# tests/integration/test_full_flow.py
import pytest
from src.openai_integration.responses_client_v2 import OpenAIResponsesClientV2

@pytest.mark.asyncio
async def test_complete_chat_flow():
    client = OpenAIResponsesClientV2()
    client.configure_default_mcp_tool()
    
    # Mock de APIs externas
    with patch('openai.AsyncOpenAI') as mock_openai:
        mock_openai.return_value.chat.completions.create.return_value = mock_response
        
        response = await client.chat([
            {"role": "user", "content": "Test message"}
        ])
        
        assert response.content is not None
```

## Deployment

### 1. Docker

```dockerfile
# Dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY src/ ./src/
COPY scripts/ ./scripts/
COPY config/ ./config/

CMD ["python", "scripts/start_api.py"]
```

### 2. Docker Compose

```yaml
# docker-compose.yml
version: '3.8'
services:
  mcp-chat:
    build: .
    ports:
      - "8000:8000"
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - SERPAPI_KEY=${SERPAPI_KEY}
    volumes:
      - ./config:/app/config
```

### 3. Kubernetes

```yaml
# deployment/kubernetes/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mcp-chat
spec:
  replicas: 3
  selector:
    matchLabels:
      app: mcp-chat
  template:
    metadata:
      labels:
        app: mcp-chat
    spec:
      containers:
      - name: mcp-chat
        image: mcp-chat:latest
        ports:
        - containerPort: 8000
        env:
        - name: OPENAI_API_KEY
          valueFrom:
            secretKeyRef:
              name: api-keys
              key: openai-key
```

## Mejores Prácticas

### 1. Código
- Usar type hints en todas las funciones
- Documentar funciones con docstrings
- Seguir PEP 8 para estilo de código
- Usar async/await para operaciones I/O

### 2. Git
- Commits atómicos y descriptivos
- Branches para features (`feature/nueva-herramienta`)
- Pull requests con revisión de código
- Tags para releases (`v1.0.0`)

### 3. Seguridad
- Nunca hardcodear API keys
- Usar variables de entorno para configuración
- Validar inputs de usuario
- Implementar rate limiting

### 4. Performance
- Usar connection pooling para APIs
- Implementar caching donde sea apropiado
- Optimizar queries de base de datos
- Monitorear métricas de rendimiento

## Contribución

### 1. Fork y Clone
```bash
# Fork el repositorio en GitHub
git clone https://github.com/tu-usuario/mcp-chat-system.git
```

### 2. Crear Branch
```bash
git checkout -b feature/mi-nueva-feature
```

### 3. Desarrollar y Testear
```bash
# Hacer cambios
# Ejecutar tests
pytest

# Verificar calidad de código
flake8 src/
black src/
```

### 4. Pull Request
- Describir los cambios claramente
- Incluir tests para nuevas funcionalidades
- Verificar que todos los tests pasen
- Seguir el template de PR

## Recursos

- **Documentación OpenAI**: https://platform.openai.com/docs
- **Documentación MCP**: https://github.com/modelcontextprotocol/python-sdk
- **FastAPI Docs**: https://fastapi.tiangolo.com/
- **Streamlit Docs**: https://docs.streamlit.io/
- **Python AsyncIO**: https://docs.python.org/3/library/asyncio.html
