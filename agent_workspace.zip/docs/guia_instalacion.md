# 🚀 Guía de Instalación - Sistema MCP Chat

## Información General

**Sistema**: OpenAI MCP Chat Assistant  
**Versión**: 1.0.0  
**Fecha**: Junio 2025  
**Autor**: Desarrollado con MiniMax  

## Descripción

Sistema de chat inteligente que integra OpenAI Responses API con servidor MCP (Model Context Protocol) para proporcionar capacidades avanzadas de:

- 🔍 Búsqueda web y noticias (SerpAPI)
- 📧 Gestión de Gmail 
- 📅 Gestión de Google Calendar
- 📊 Análisis de sentimiento
- 📝 Generación de resúmenes
- 🔄 Flujos de trabajo complejos
- 🧠 Selección automática de herramientas

## Prerrequisitos

### Software Requerido

- **Python**: 3.9+ (recomendado 3.11+)
- **Node.js**: 18+ (para desarrollo web opcional)
- **Git**: Para clonación del repositorio
- **Docker**: Opcional, para deployment containerizado

### APIs y Servicios Externos

1. **OpenAI API Key** (REQUERIDO)
   - Visita: https://platform.openai.com/api-keys
   - Crea una API key nueva
   - Verifica billing y límites

2. **SerpAPI Key** (REQUERIDO para búsquedas)
   - Visita: https://serpapi.com/
   - Regístrate y obtén API key
   - Plan gratuito incluye 100 búsquedas/mes

3. **Google Cloud APIs** (REQUERIDO para Gmail/Calendar)
   - Visita: https://console.cloud.google.com/
   - Crea nuevo proyecto
   - Habilita Gmail API y Calendar API
   - Crea Service Account y descarga credentials JSON

## Instalación Paso a Paso

### 1. Clonar Repositorio

```bash
git clone <repository-url>
cd mcp-chat-system
```

### 2. Configurar Entorno Python

```bash
# Crear entorno virtual
python -m venv venv

# Activar entorno (Linux/Mac)
source venv/bin/activate

# Activar entorno (Windows)
venv\Scripts\activate

# Instalar dependencias
pip install -r requirements.txt
```

### 3. Configurar Variables de Entorno

```bash
# Copiar template de configuración
cp .env.template .env

# Editar .env con tus API keys
nano .env
```

### 4. Configurar APIs

#### OpenAI
```bash
# En .env
OPENAI_API_KEY=sk-proj-tu-clave-aqui
OPENAI_DEFAULT_MODEL=gpt-4o
```

#### SerpAPI
```bash
# En .env
SERPAPI_KEY=tu-clave-serpapi-aqui
```

#### Google APIs
```bash
# En .env
GOOGLE_PROJECT_ID=tu-proyecto-google-cloud
GOOGLE_CREDENTIALS_PATH=config/credentials/google-service-account.json

# Copiar tu archivo de credenciales
cp path/to/your/credentials.json config/credentials/google-service-account.json
```

### 5. Verificar Instalación

```bash
# Test básico del sistema
python scripts/test_basic.py

# Test de OpenAI
python scripts/test_openai_simple.py

# Test completo del sistema
python scripts/test_complete_system.py
```

## Iniciar el Sistema

### Opción 1: CLI Interactivo

```bash
python scripts/start_cli.py
```

### Opción 2: Interfaz Web (Streamlit)

```bash
python scripts/start_web.py
```

### Opción 3: API REST (FastAPI)

```bash
python scripts/start_api.py
```

### Opción 4: Chat Completo

```bash
python scripts/start_mcp_chat.py
```

## Solución de Problemas

### Error: API Key inválida
- Verifica que la API key esté correcta en .env
- Verifica que no haya espacios extra
- Verifica billing en el dashboard de OpenAI

### Error: Import modules
- Asegúrate de que el entorno virtual esté activado
- Ejecuta: `pip install -r requirements.txt`
- Verifica que estés en el directorio correcto

### Error: Google credentials
- Verifica que el archivo JSON exista en la ruta especificada
- Verifica que las APIs estén habilitadas en Google Cloud
- Verifica que el Service Account tenga permisos

### Error: Puerto en uso
- Cambia el puerto en el archivo de configuración
- O mata el proceso: `lsof -ti:8080 | xargs kill -9`

## Próximos Pasos

1. ✅ Familiarízate con la interfaz de chat
2. ✅ Prueba diferentes tipos de consultas
3. ✅ Revisa el manual de usuario para casos de uso
4. ✅ Personaliza la configuración según tus necesidades

## Soporte

- 📖 Documentación completa: `docs/`
- 🔧 Ejemplos de uso: `docs/manual_usuario.md`
- 🐛 Solución de problemas: `docs/troubleshooting.md`
- 💡 Contribuciones: `docs/desarrollo.md`
