# 👤 Manual de Usuario - Sistema MCP Chat

## Introducción

Bienvenido al Sistema MCP Chat, tu asistente inteligente que combina la potencia de OpenAI con herramientas especializadas para ayudarte en tareas cotidianas y profesionales.

## Interfaces Disponibles

### 1. CLI (Línea de Comandos)
**Inicio**: `python scripts/start_cli.py`

**Características**:
- Interfaz de texto interactiva
- Historial de conversaciones
- Comandos especiales
- Ideal para usuarios técnicos

**Comandos Especiales**:
```bash
/help          # Mostrar ayuda
/history       # Ver historial
/clear         # Limpiar pantalla
/config        # Ver configuración
/exit          # Salir
```

### 2. Interfaz Web (Streamlit)
**Inicio**: `python scripts/start_web.py`  
**URL**: http://localhost:8501

**Características**:
- Interfaz gráfica moderna
- Chat en tiempo real
- Configuración visual
- Historial persistente
- Ideal para todos los usuarios

### 3. API REST (FastAPI)
**Inicio**: `python scripts/start_api.py`  
**URL**: http://localhost:8000  
**Docs**: http://localhost:8000/docs

**Características**:
- API RESTful completa
- Documentación automática
- Integración con otras aplicaciones
- Ideal para desarrolladores

## Herramientas Disponibles

### 🔍 Búsqueda de Información
**Comando**: "Busca información sobre [tema]"

**Ejemplos**:
```
• "Busca información sobre inteligencia artificial"
• "Necesito datos sobre el mercado de criptomonedas"
• "Investiga las últimas tendencias en tecnología"
```

**Uso**:
- Búsquedas web generales
- Información técnica
- Datos de mercado
- Investigación académica

### 📰 Búsqueda de Noticias
**Comando**: "Busca noticias sobre [tema]"

**Ejemplos**:
```
• "Busca noticias recientes sobre Tesla"
• "¿Qué noticias hay sobre el Mundial de Fútbol?"
• "Últimas noticias de tecnología en España"
```

**Uso**:
- Noticias actuales
- Eventos recientes
- Tendencias en medios
- Actualizaciones específicas

### 📧 Gestión de Email
**Comando**: "Revisa mis emails [filtro]"

**Ejemplos**:
```
• "Revisa mis emails de hoy"
• "¿Hay emails importantes?"
• "Busca emails sobre el proyecto X"
• "Muestra emails de la semana pasada"
```

**Capacidades**:
- Leer emails recientes
- Filtrar por fecha/remitente
- Identificar emails importantes
- Búsqueda en el contenido

### 📅 Gestión de Calendario
**Comando**: "¿Qué tengo programado [cuándo]?"

**Ejemplos**:
```
• "¿Qué tengo programado para mañana?"
• "Muestra mi agenda de esta semana"
• "¿Tengo reuniones el viernes?"
• "Agenda una reunión con [persona]"
```

**Capacidades**:
- Ver eventos programados
- Crear nuevos eventos
- Buscar disponibilidad
- Gestionar reuniones

### 💭 Análisis de Sentimiento
**Comando**: "Analiza el sentimiento de [texto]"

**Ejemplos**:
```
• "Analiza el tono de este email: [contenido]"
• "¿Qué sentimiento expresa este texto?"
• "Evalúa la opinión en estos comentarios"
```

**Uso**:
- Análisis de comunicaciones
- Evaluación de feedback
- Monitoreo de opiniones
- Análisis de textos

### 📝 Generación de Resúmenes
**Comando**: "Haz un resumen de [contenido]"

**Ejemplos**:
```
• "Resume la información que encontraste"
• "Haz un resumen ejecutivo de estos datos"
• "Crea un resumen de mis emails importantes"
```

**Uso**:
- Síntesis de información
- Resúmenes ejecutivos
- Consolidación de datos
- Reportes concisos

### 🔄 Flujo de Investigación Completo
**Comando**: "Haz una investigación completa sobre [tema]"

**Ejemplos**:
```
• "Investiga completamente el mercado de vehículos eléctricos"
• "Análisis completo de las tendencias en IA para 2024"
• "Investigación exhaustiva sobre [empresa/tecnología]"
```

**Proceso**:
1. Búsqueda de información general
2. Búsqueda de noticias recientes
3. Análisis de sentimiento
4. Generación de resumen consolidado

### ⚙️ Estado del Sistema
**Comando**: "¿Cómo está el sistema?"

**Información**:
- Estado de conexiones
- Rendimiento del servidor
- Disponibilidad de herramientas
- Estadísticas de uso

## Ejemplos de Uso Completos

### Ejemplo 1: Investigación de Mercado
```
Usuario: "Necesito investigar el mercado de inteligencia artificial en salud"

Sistema:
1. 🔍 Busca información general sobre IA en salud
2. 📰 Busca noticias recientes del sector
3. 💭 Analiza el sentimiento de las noticias
4. 📝 Genera un resumen ejecutivo completo
```

### Ejemplo 2: Gestión de Productividad
```
Usuario: "¿Qué emails importantes tengo y qué tengo programado hoy?"

Sistema:
1. 📧 Revisa emails del día
2. 💭 Identifica emails importantes por sentimiento
3. 📅 Muestra agenda del día
4. 📝 Resume prioridades del día
```

### Ejemplo 3: Seguimiento de Proyecto
```
Usuario: "Busca información sobre GraphQL, revisa emails relacionados y programa una reunión para discutirlo"

Sistema:
1. 🔍 Busca información técnica sobre GraphQL
2. 📧 Busca emails que mencionen GraphQL
3. 📅 Programa reunión en calendario
4. 📝 Prepara agenda de la reunión
```

## Consejos de Uso

### Para Mejores Resultados
1. **Sé específico**: Usa términos claros y específicos
2. **Combina herramientas**: Aprovecha múltiples capacidades
3. **Usa contexto**: Proporciona contexto relevante
4. **Verifica resultados**: Siempre revisa la información obtenida

### Comandos Naturales
El sistema entiende lenguaje natural. Puedes usar:
- Preguntas directas
- Solicitudes específicas
- Comandos informales
- Combinaciones complejas

### Manejo de Errores
Si algo no funciona:
1. Verifica tu conexión a internet
2. Confirma que las APIs estén configuradas
3. Revisa los logs del sistema
4. Reintenta con una formulación diferente

## Limitaciones y Consideraciones

### Límites de APIs
- **OpenAI**: Límites por minuto según tu plan
- **SerpAPI**: Límites de búsquedas según plan
- **Google APIs**: Cuotas diarias de uso

### Privacidad
- Las consultas se procesan a través de APIs externas
- No se almacenan datos sensibles localmente
- Configura permisos apropiados en Google

### Rendimiento
- Las respuestas dependen de la velocidad de las APIs
- Consultas complejas pueden tomar más tiempo
- El sistema optimiza automáticamente las llamadas

## Soporte y Ayuda

- **Documentación técnica**: `docs/desarrollo.md`
- **Solución de problemas**: `docs/troubleshooting.md`
- **Ejemplos adicionales**: `docs/ejemplos/`
- **Configuración avanzada**: `docs/configuracion_avanzada.md`
