# 🔌 Documentación de APIs - Sistema MCP Chat

## API REST Principal

### Base URL
- **Desarrollo**: `http://localhost:8000`
- **Producción**: `https://your-domain.com`

### Autenticación
```http
Authorization: Bearer YOUR_API_TOKEN
Content-Type: application/json
```

### Endpoints Principales

#### 1. Chat Básico
```http
POST /chat
```

**Request Body**:
```json
{
  "message": "¿Cuáles son las últimas noticias sobre IA?",
  "user_id": "user123",
  "conversation_id": "conv456"
}
```

**Response**:
```json
{
  "response": "Aquí están las últimas noticias sobre IA...",
  "conversation_id": "conv456",
  "tool_calls": [
    {
      "tool": "buscar_noticias",
      "status": "success",
      "execution_time": 2.5
    }
  ],
  "usage": {
    "total_tokens": 1250,
    "prompt_tokens": 100,
    "completion_tokens": 1150
  }
}
```

#### 2. Chat con Streaming
```http
POST /chat/stream
```

**Response**: Server-Sent Events (SSE)
```
data: {"type": "thinking", "content": "Buscando información..."}
data: {"type": "tool_call", "tool": "buscar_noticias", "status": "executing"}
data: {"type": "content", "content": "He encontrado las siguientes noticias..."}
data: {"type": "done", "conversation_id": "conv456"}
```

#### 3. Historial de Conversaciones
```http
GET /conversations/{user_id}
```

**Response**:
```json
{
  "conversations": [
    {
      "id": "conv456",
      "title": "Consulta sobre IA",
      "created_at": "2025-06-06T10:30:00Z",
      "last_message_at": "2025-06-06T10:35:00Z",
      "message_count": 5
    }
  ]
}
```

#### 4. Configuración MCP
```http
GET /mcp/config
POST /mcp/config
```

**GET Response**:
```json
{
  "server_url": "http://localhost:8080/mcp",
  "server_label": "chat_assistant",
  "tools": [
    "buscar_informacion",
    "buscar_noticias",
    "gestionar_email",
    "gestionar_calendario",
    "analizar_sentimiento",
    "generar_resumen",
    "flujo_investigacion_completo",
    "estado_sistema"
  ],
  "require_approval": "never"
}
```

**POST Request**:
```json
{
  "server_url": "http://localhost:8080/mcp",
  "server_label": "mi_asistente",
  "allowed_tools": ["buscar_informacion", "analizar_sentimiento"],
  "require_approval": "never"
}
```

#### 5. Estado del Sistema
```http
GET /health
GET /metrics
```

**Health Response**:
```json
{
  "status": "healthy",
  "timestamp": "2025-06-06T10:30:00Z",
  "services": {
    "openai": "connected",
    "mcp_server": "running",
    "database": "connected"
  },
  "version": "1.0.0"
}
```

## API del Servidor MCP

### Base URL
- **Local**: `http://localhost:8080/mcp`

### Endpoints MCP

#### 1. Listar Herramientas
```http
GET /tools/list
```

**Response**:
```json
{
  "tools": [
    {
      "name": "buscar_informacion",
      "description": "Busca información general en la web",
      "parameters": {
        "query": {"type": "string", "required": true},
        "num_results": {"type": "integer", "default": 10}
      }
    },
    {
      "name": "gestionar_email",
      "description": "Gestiona emails de Gmail",
      "parameters": {
        "action": {"type": "string", "required": true},
        "query": {"type": "string", "required": false}
      }
    }
  ]
}
```

#### 2. Ejecutar Herramienta
```http
POST /tools/execute
```

**Request**:
```json
{
  "tool": "buscar_informacion",
  "parameters": {
    "query": "inteligencia artificial 2024",
    "num_results": 5
  }
}
```

**Response**:
```json
{
  "result": {
    "results": [
      {
        "title": "AI Trends 2024",
        "url": "https://example.com/ai-trends",
        "snippet": "Las principales tendencias en IA para 2024...",
        "source": "TechNews"
      }
    ],
    "search_metadata": {
      "total_results": 1250000,
      "time_taken": 0.8
    }
  },
  "status": "success",
  "execution_time": 2.1
}
```

## Códigos de Error

### HTTP Status Codes
- `200`: Operación exitosa
- `400`: Request inválido
- `401`: No autorizado
- `403`: Acceso denegado
- `404`: Recurso no encontrado
- `429`: Rate limit excedido
- `500`: Error interno del servidor
- `503`: Servicio no disponible

### Códigos de Error Personalizados

#### OpenAI Errors
```json
{
  "error": {
    "code": "OPENAI_API_ERROR",
    "message": "OpenAI API request failed",
    "details": {
      "status_code": 429,
      "openai_error": "Rate limit exceeded"
    }
  }
}
```

#### MCP Errors
```json
{
  "error": {
    "code": "MCP_TOOL_ERROR",
    "message": "Tool execution failed",
    "details": {
      "tool": "buscar_informacion",
      "reason": "API key invalid"
    }
  }
}
```

#### Validation Errors
```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid request parameters",
    "details": {
      "field": "message",
      "issue": "Message cannot be empty"
    }
  }
}
```

## Rate Limiting

### Límites por Defecto
- **Chat requests**: 60 por minuto por usuario
- **Tool executions**: 100 por minuto por usuario
- **Configuration changes**: 10 por minuto por usuario

### Headers de Rate Limiting
```http
X-RateLimit-Limit: 60
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1672531200
```

## Webhooks (Opcional)

### Configuración
```http
POST /webhooks/configure
```

**Request**:
```json
{
  "url": "https://your-app.com/webhook",
  "events": ["conversation.completed", "tool.executed"],
  "secret": "webhook_secret_key"
}
```

### Eventos

#### Conversación Completada
```json
{
  "event": "conversation.completed",
  "timestamp": "2025-06-06T10:30:00Z",
  "data": {
    "conversation_id": "conv456",
    "user_id": "user123",
    "message_count": 5,
    "total_tokens": 2500
  }
}
```

#### Herramienta Ejecutada
```json
{
  "event": "tool.executed",
  "timestamp": "2025-06-06T10:30:00Z",
  "data": {
    "tool": "buscar_informacion",
    "status": "success",
    "execution_time": 2.1,
    "user_id": "user123"
  }
}
```

## SDKs y Librerías

### Python SDK
```python
from mcp_chat_client import MCPChatClient

client = MCPChatClient(
    api_key="your_api_key",
    base_url="http://localhost:8000"
)

response = await client.chat(
    message="¿Qué noticias hay sobre IA?",
    user_id="user123"
)
print(response.content)
```

### JavaScript SDK
```javascript
import { MCPChatClient } from 'mcp-chat-client';

const client = new MCPChatClient({
  apiKey: 'your_api_key',
  baseUrl: 'http://localhost:8000'
});

const response = await client.chat({
  message: '¿Qué noticias hay sobre IA?',
  userId: 'user123'
});
console.log(response.content);
```

## Ejemplos de Integración

### cURL
```bash
# Chat básico
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "message": "Busca información sobre Python",
    "user_id": "user123"
  }'

# Streaming
curl -X POST http://localhost:8000/chat/stream \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"message": "¿Qué tiempo hace?", "user_id": "user123"}' \
  --no-buffer
```

### Postman Collection
Disponible en: `docs/postman/MCP-Chat-API.postman_collection.json`

## Monitoreo y Métricas

### Métricas Disponibles
- **Requests por minuto**: Total de requests
- **Tiempo de respuesta**: Latencia promedio
- **Tool executions**: Ejecuciones de herramientas
- **Error rate**: Tasa de errores
- **Token usage**: Uso de tokens OpenAI

### Prometheus Metrics
```
# http://localhost:9090/metrics
mcp_chat_requests_total{method="POST", endpoint="/chat"} 1250
mcp_chat_response_time_seconds{endpoint="/chat"} 2.1
mcp_chat_tool_executions_total{tool="buscar_informacion"} 450
mcp_chat_errors_total{error_type="openai_api_error"} 12
```

## Documentación Interactiva

### OpenAPI/Swagger
- **URL**: `http://localhost:8000/docs`
- **ReDoc**: `http://localhost:8000/redoc`

### Postman
- **Collection**: `docs/postman/`
- **Environment**: `docs/postman/environment.json`

### Insomnia
- **Workspace**: `docs/insomnia/workspace.json`
