# Estructura de Archivos Definitiva - Chat OpenAI + MCP

## Estructura del Proyecto

```
openai-mcp-chat-system/
├── README.md                          # Documentación principal
├── pyproject.toml                     # Configuración moderna de Python
├── requirements.txt                   # Dependencias
├── docker-compose.yml                # Orquestación de servicios
├── Dockerfile                        # Imagen del contenedor
├── .env.example                      # Plantilla de variables de entorno
├── .gitignore                        # Archivos ignorados por Git
│
├── src/                              # Código fuente principal
│   ├── __init__.py
│   │
│   ├── core/                         # Núcleo del sistema
│   │   ├── __init__.py
│   │   ├── config.py                 # Configuración centralizada
│   │   ├── exceptions.py             # Excepciones customizadas
│   │   ├── logging_config.py         # Configuración de logging
│   │   └── constants.py              # Constantes del sistema
│   │
│   ├── orchestrator/                 # Orquestador principal
│   │   ├── __init__.py
│   │   ├── chat_orchestrator.py      # Lógica principal de chat
│   │   ├── tool_selector.py          # Selección inteligente de herramientas
│   │   ├── context_manager.py        # Gestión de contexto
│   │   └── optimization.py           # Optimizaciones de rendimiento
│   │
│   ├── mcp/                          # Servidor y herramientas MCP
│   │   ├── __init__.py
│   │   ├── server.py                 # Servidor MCP principal
│   │   ├── base_tool.py              # Clase base para herramientas
│   │   │
│   │   ├── tools/                    # Herramientas MCP específicas
│   │   │   ├── __init__.py
│   │   │   ├── serpapi_tools.py      # Herramientas de búsqueda
│   │   │   ├── gmail_tools.py        # Herramientas de Gmail
│   │   │   ├── calendar_tools.py     # Herramientas de Calendar
│   │   │   ├── analytics_tools.py    # Herramientas de análisis
│   │   │   └── workflow_tools.py     # Herramientas de flujo de trabajo
│   │   │
│   │   └── auth/                     # Autenticación
│   │       ├── __init__.py
│   │       ├── oauth_manager.py      # Gestión OAuth2
│   │       └── token_manager.py      # Gestión de tokens
│   │
│   ├── openai_integration/           # Integración con OpenAI
│   │   ├── __init__.py
│   │   ├── client.py                 # Cliente OpenAI con MCP
│   │   ├── responses_handler.py      # Manejo de Responses API
│   │   └── model_selector.py         # Selección de modelos
│   │
│   ├── interfaces/                   # Interfaces de usuario
│   │   ├── __init__.py
│   │   ├── cli/                      # Interfaz de línea de comandos
│   │   │   ├── __init__.py
│   │   │   ├── main.py               # CLI principal con Typer
│   │   │   └── commands.py           # Comandos específicos
│   │   │
│   │   ├── web/                      # Interfaz web
│   │   │   ├── __init__.py
│   │   │   ├── streamlit_app.py      # Aplicación Streamlit
│   │   │   └── components.py         # Componentes reutilizables
│   │   │
│   │   └── api/                      # API REST
│   │       ├── __init__.py
│   │       ├── main.py               # FastAPI app
│   │       ├── routes/               # Rutas de la API
│   │       │   ├── __init__.py
│   │       │   ├── chat.py           # Endpoints de chat
│   │       │   └── health.py         # Health checks
│   │       └── models.py             # Modelos Pydantic
│   │
│   ├── utils/                        # Utilidades
│   │   ├── __init__.py
│   │   ├── cache.py                  # Sistema de caché
│   │   ├── retry.py                  # Lógica de retry
│   │   ├── validators.py             # Validaciones
│   │   └── formatters.py             # Formateadores de datos
│   │
│   └── monitoring/                   # Monitoreo y observabilidad
│       ├── __init__.py
│       ├── metrics.py                # Métricas de rendimiento
│       ├── health_checker.py         # Health checks
│       └── alerts.py                 # Sistema de alertas
│
├── tests/                            # Tests del proyecto
│   ├── __init__.py
│   ├── conftest.py                   # Configuración de pytest
│   ├── unit/                         # Tests unitarios
│   │   ├── test_orchestrator.py
│   │   ├── test_mcp_tools.py
│   │   └── test_openai_integration.py
│   ├── integration/                  # Tests de integración
│   │   ├── test_full_workflow.py
│   │   └── test_api_endpoints.py
│   └── fixtures/                     # Datos de prueba
│       ├── sample_responses.json
│       └── mock_configs.py
│
├── config/                           # Archivos de configuración
│   ├── development.yaml              # Configuración desarrollo
│   ├── production.yaml               # Configuración producción
│   ├── logging.yaml                  # Configuración de logging
│   └── oauth/                        # Configuraciones OAuth
│       ├── google_oauth.json.example
│       └── credentials/              # Directorio para credenciales
│
├── scripts/                          # Scripts de utilidad
│   ├── setup_environment.py          # Configuración inicial
│   ├── run_development.py            # Ejecutar en desarrollo
│   ├── deploy.py                     # Script de despliegue
│   └── migrations/                   # Scripts de migración
│       └── initial_setup.py
│
├── docs/                             # Documentación
│   ├── api/                          # Documentación de API
│   │   ├── openapi.yaml
│   │   └── endpoints.md
│   ├── guides/                       # Guías de usuario
│   │   ├── installation.md
│   │   ├── configuration.md
│   │   ├── usage.md
│   │   └── troubleshooting.md
│   ├── development/                  # Documentación para desarrolladores
│   │   ├── architecture.md
│   │   ├── contributing.md
│   │   └── testing.md
│   └── examples/                     # Ejemplos de uso
│       ├── basic_chat.py
│       ├── advanced_workflows.py
│       └── api_usage.py
│
├── monitoring/                       # Configuración de monitoreo
│   ├── prometheus/
│   │   └── prometheus.yml
│   ├── grafana/
│   │   ├── dashboards/
│   │   └── datasources/
│   └── alerts/
│       └── alertmanager.yml
│
├── deployment/                       # Archivos de despliegue
│   ├── kubernetes/                   # Manifests de K8s
│   │   ├── deployment.yaml
│   │   ├── service.yaml
│   │   └── configmap.yaml
│   ├── helm/                         # Charts de Helm
│   │   ├── Chart.yaml
│   │   ├── values.yaml
│   │   └── templates/
│   └── docker/                       # Configuraciones Docker
│       ├── Dockerfile.prod
│       └── docker-compose.prod.yml
│
└── logs/                             # Directorio de logs (git-ignored)
    ├── app.log
    ├── mcp.log
    └── error.log
```

## Descripción de Componentes Clave

### Core (/src/core/)
- **config.py**: Configuración centralizada usando Pydantic Settings
- **exceptions.py**: Excepciones específicas del dominio
- **logging_config.py**: Configuración estructurada de logging

### Orchestrator (/src/orchestrator/)
- **chat_orchestrator.py**: Componente principal que coordina toda la lógica
- **tool_selector.py**: Lógica inteligente para selección de herramientas MCP
- **context_manager.py**: Gestión de contexto de conversación y estado

### MCP (/src/mcp/)
- **server.py**: Servidor FastMCP con Streamable HTTP
- **tools/**: Implementaciones específicas de cada herramienta MCP
- **auth/**: Sistema de autenticación OAuth2 para servicios externos

### OpenAI Integration (/src/openai_integration/)
- **client.py**: Cliente optimizado para Responses API con MCP
- **responses_handler.py**: Manejo especializado de respuestas OpenAI
- **model_selector.py**: Selección inteligente entre modelos (GPT-4.1, O4-mini)

### Interfaces (/src/interfaces/)
- **cli/**: Interfaz de línea de comandos con Typer
- **web/**: Aplicación web con Streamlit
- **api/**: API REST con FastAPI para integración externa

### Utils (/src/utils/)
- **cache.py**: Sistema de caché Redis/memoria para optimización
- **retry.py**: Lógica de reintentos con backoff exponencial
- **validators.py**: Validaciones de entrada usando Pydantic

## Configuraciones Clave

### pyproject.toml
```toml
[project]
name = "openai-mcp-chat"
version = "1.0.0"
description = "Sistema de chat inteligente con OpenAI y MCP"
authors = [{name = "Tu Nombre", email = "tu@email.com"}]
requires-python = ">=3.11"
dependencies = [
    "mcp>=1.9.3",
    "openai>=1.0.0",
    "fastapi>=0.104.0",
    "streamlit>=1.28.0",
    "typer>=0.9.0",
    "pydantic>=2.5.0",
    "redis>=5.0.0",
    "aiohttp>=3.9.0",
    "google-auth>=2.25.0",
    "google-auth-oauthlib>=1.1.0",
    "google-api-python-client>=2.110.0"
]

[project.optional-dependencies]
dev = [
    "pytest>=7.4.0",
    "pytest-asyncio>=0.21.0",
    "black>=23.0.0",
    "ruff>=0.1.0",
    "mypy>=1.7.0"
]

[project.scripts]
mcp-chat = "src.interfaces.cli.main:app"
mcp-web = "src.interfaces.web.streamlit_app:main"
mcp-server = "src.mcp.server:main"
```

### docker-compose.yml
```yaml
version: '3.8'

services:
  mcp-server:
    build: .
    ports:
      - "8000:8000"
    environment:
      - ENVIRONMENT=development
    volumes:
      - ./config:/app/config
      - ./logs:/app/logs
    depends_on:
      - redis

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data

  prometheus:
    image: prom/prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus:/etc/prometheus

volumes:
  redis_data:
```

## Ventajas de Esta Estructura

1. **Modularidad**: Separación clara de responsabilidades
2. **Escalabilidad**: Fácil adición de nuevas herramientas MCP
3. **Mantenibilidad**: Código organizado y bien documentado
4. **Testing**: Estructura que facilita pruebas unitarias e integración
5. **Despliegue**: Configuración lista para múltiples entornos
6. **Monitoreo**: Observabilidad integrada desde el diseño

## Próximo Paso

Con esta estructura definida, procederemos a:
1. Configurar el entorno de desarrollo
2. Implementar el código base actualizado
3. Integrar las mejores prácticas identificadas en la investigación
