# 🤖 Sistema MCP Chat - Asistente Inteligente OpenAI + MCP

[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://github.com/your-repo/mcp-chat-system)
[![Python](https://img.shields.io/badge/python-3.9+-green.svg)](https://python.org)
[![OpenAI](https://img.shields.io/badge/OpenAI-Responses%20API-orange.svg)](https://platform.openai.com)
[![MCP](https://img.shields.io/badge/MCP-Compatible-purple.svg)](https://github.com/modelcontextprotocol)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

## 🌟 Descripción

Sistema de chat inteligente que combina la potencia de **OpenAI Responses API** con **Model Context Protocol (MCP)** para proporcionar un asistente con capacidades especializadas avanzadas.

### ✨ Características Principales

- 🧠 **Integración OpenAI + MCP**: Selección automática e inteligente de herramientas
- 🔍 **Búsqueda Web**: SerpAPI para información y noticias actualizadas
- 📧 **Gmail Integration**: Gestión completa de emails
- 📅 **Google Calendar**: Programación y gestión de eventos
- 💭 **Análisis de Sentimiento**: Evaluación automática de tono y emociones
- 📝 **Generación de Resúmenes**: Síntesis inteligente de información
- 🔄 **Flujos de Trabajo**: Investigación completa automatizada
- 🖥️ **Múltiples Interfaces**: CLI, Web UI y API REST

### 🏗️ Arquitectura

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Interfaces    │───▶│  Cliente OpenAI  │───▶│ Servidor MCP    │
│ CLI/Web/API     │    │ (Responses API)  │    │ (8 herramientas)│
└─────────────────┘    └──────────────────┘    └─────────────────┘
                                │                        │
                                ▼                        ▼
                       ┌──────────────────┐    ┌─────────────────┐
                       │   OpenAI API     │    │  APIs Externas  │
                       │  (gpt-4o, o1)    │    │ SerpAPI, Google │
                       └──────────────────┘    └─────────────────┘
```

## 🚀 Inicio Rápido

### 1. Instalación

```bash
# Clonar repositorio
git clone <repository-url>
cd mcp-chat-system

# Crear entorno virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate  # Windows

# Instalar dependencias
pip install -r requirements.txt
```

### 2. Configuración

```bash
# Copiar template de configuración
cp .env.template .env

# Editar .env con tus API keys
# OPENAI_API_KEY=sk-proj-tu-clave-aqui
# SERPAPI_KEY=tu-clave-serpapi
# GOOGLE_CREDENTIALS_PATH=config/credentials/google-service-account.json
```

### 3. Ejecución

```bash
# CLI Interactivo
python scripts/start_cli.py

# Interfaz Web (Streamlit)
python scripts/start_web.py

# API REST (FastAPI)
python scripts/start_api.py
```

## 📖 Documentación

### 📚 Guías Principales
- [📋 Guía de Instalación](docs/guia_instalacion.md)
- [👤 Manual de Usuario](docs/manual_usuario.md)
- [💻 Guía de Desarrollo](docs/desarrollo.md)
- [🔌 Documentación API](docs/api_documentation.md)

### 💡 Ejemplos y Casos de Uso
- [📝 Casos de Uso Básicos](docs/ejemplos/casos_uso_basicos.md)
- [🏢 Integración Empresarial](docs/ejemplos/integracion_empresarial.md)
- [⚡ Ejemplos Avanzados](docs/ejemplos/)

### 🔧 Configuración y Deployment
- [⚙️ Configuración APIs](docs/paso6_guia_configuracion_apis.json)
- [🐳 Docker Deployment](deployment/docker/)
- [☸️ Kubernetes Deployment](deployment/kubernetes/)

## 🛠️ Herramientas Disponibles

| Herramienta | Descripción | API Requerida |
|-------------|-------------|---------------|
| 🔍 `buscar_informacion` | Búsqueda web general | SerpAPI |
| 📰 `buscar_noticias` | Noticias actualizadas | SerpAPI |
| 📧 `gestionar_email` | Gestión de Gmail | Google APIs |
| 📅 `gestionar_calendario` | Gestión de Calendar | Google APIs |
| 💭 `analizar_sentimiento` | Análisis de emociones | Integrado |
| 📝 `generar_resumen` | Síntesis de información | Integrado |
| 🔄 `flujo_investigacion_completo` | Workflow automatizado | Múltiples |
| ⚙️ `estado_sistema` | Monitoreo del sistema | Integrado |

## 💬 Ejemplos de Uso

### Búsqueda e Investigación
```
Usuario: "Investiga las tendencias de IA en 2024 y haz un análisis completo"
Sistema: 🔍 Busca información → 📰 Obtiene noticias → 💭 Analiza sentimiento → 📝 Genera reporte
```

### Productividad Personal
```
Usuario: "¿Qué emails importantes tengo y qué está programado para hoy?"
Sistema: 📧 Revisa Gmail → 💭 Identifica prioridades → 📅 Muestra calendario → 📝 Resume el día
```

### Análisis de Mercado
```
Usuario: "Analiza el sentimiento del mercado sobre Tesla esta semana"
Sistema: 📰 Busca noticias de Tesla → 💭 Analiza sentimiento → 📝 Genera insights
```

## 🔧 APIs y Configuración

### APIs Requeridas

#### 🤖 OpenAI API (OBLIGATORIO)
- **Obtener**: https://platform.openai.com/api-keys
- **Modelos**: gpt-4o, o1-preview
- **Variable**: `OPENAI_API_KEY`

#### 🔍 SerpAPI (Para búsquedas)
- **Obtener**: https://serpapi.com/manage-api-key
- **Plan gratuito**: 100 búsquedas/mes
- **Variable**: `SERPAPI_KEY`

#### 📧 Google APIs (Para Gmail/Calendar)
- **Setup**: Google Cloud Console
- **APIs**: Gmail API, Calendar API
- **Credenciales**: Service Account JSON
- **Variable**: `GOOGLE_CREDENTIALS_PATH`

### Configuración Mínima (.env)
```bash
# Configuración mínima para funcionamiento básico
OPENAI_API_KEY=sk-proj-tu-clave-aqui
SERPAPI_KEY=tu-clave-serpapi
GOOGLE_PROJECT_ID=tu-proyecto-google
GOOGLE_CREDENTIALS_PATH=config/credentials/google-service-account.json
```

## 🧪 Testing y Validación

### Tests Básicos
```bash
# Test de configuración
python scripts/test_basic.py

# Test de OpenAI
python scripts/test_openai_simple.py

# Test del sistema completo
python scripts/test_complete_system.py
```

### Suite Completa
```bash
# Todos los tests
python scripts/paso7_pruebas_end_to_end.py

# Tests específicos
pytest tests/unit/
pytest tests/integration/
```

## 📊 Rendimiento y Métricas

### Benchmarks
- **Tiempo de respuesta promedio**: < 3 segundos
- **Precisión de selección de herramientas**: > 95%
- **Disponibilidad del sistema**: > 99.9%
- **Throughput**: > 100 requests/minuto

### Monitoreo
- **Health Check**: `/health`
- **Métricas**: `/metrics` (Prometheus)
- **Logs**: Structured JSON logging
- **Alertas**: Configurables por umbral

## 🐳 Deployment

### Docker (Recomendado)
```bash
# Deployment simple
./deployment/docker/deploy_docker.sh

# Docker Compose (con monitoreo)
./deployment/docker/deploy_compose.sh
```

### Kubernetes
```bash
# Deployment en cluster K8s
./deployment/kubernetes/deploy_k8s.sh production
```

### Manual
```bash
# Desarrollo local
python scripts/start_mcp_chat.py
```

## 🤝 Contribución

1. **Fork** el repositorio
2. **Crear** branch para tu feature (`git checkout -b feature/nueva-funcionalidad`)
3. **Commit** tus cambios (`git commit -am 'Agregar nueva funcionalidad'`)
4. **Push** al branch (`git push origin feature/nueva-funcionalidad`)
5. **Crear** Pull Request

### Desarrollo Local
```bash
# Setup de desarrollo
pip install -r requirements-dev.txt
pre-commit install

# Tests antes de PR
pytest
flake8 src/
black src/
```

## 📋 Roadmap

### ✅ v1.0.0 (Actual)
- [x] Integración OpenAI + MCP
- [x] 8 herramientas especializadas
- [x] 3 interfaces (CLI, Web, API)
- [x] Documentación completa

### 🔄 v1.1.0 (Q3 2025)
- [ ] Plugin system para herramientas custom
- [ ] Multi-tenancy support
- [ ] Advanced analytics dashboard
- [ ] Mobile app (React Native)

### 🚀 v2.0.0 (Q4 2025)
- [ ] Multi-model support (Claude, Gemini)
- [ ] Voice interface
- [ ] Advanced workflow builder
- [ ] Enterprise features (SSO, audit logs)

## ❓ FAQ

### ¿Necesito todas las APIs para usar el sistema?
- **OpenAI API**: Obligatoria
- **SerpAPI**: Opcional (sin búsquedas web)
- **Google APIs**: Opcional (sin Gmail/Calendar)

### ¿Funciona con otros modelos además de OpenAI?
Actualmente solo OpenAI, pero v2.0 incluirá soporte multi-modelo.

### ¿Puedo agregar mis propias herramientas?
Sí, consulta la [Guía de Desarrollo](docs/desarrollo.md) para crear herramientas personalizadas.

### ¿Es seguro para uso empresarial?
Sí, implementa mejores prácticas de seguridad. Para enterprise, considera el roadmap v2.0.

## 📞 Soporte

- **Documentación**: [docs/](docs/)
- **Issues**: GitHub Issues
- **Discussions**: GitHub Discussions
- **Email**: support@your-domain.com

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver [LICENSE](LICENSE) para más detalles.

---

<div align="center">

**🚀 ¡Construido con OpenAI + MCP para el futuro de la asistencia inteligente! 🤖**

[⭐ Star en GitHub](https://github.com/your-repo/mcp-chat-system) • [📖 Documentación](docs/) • [🐛 Reportar Bug](https://github.com/your-repo/mcp-chat-system/issues)

</div>
