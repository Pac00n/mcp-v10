# Sistema de Chat Inteligente OpenAI + MCP

> Sistema avanzado de chat que integra OpenAI Responses API con Model Context Protocol (MCP) para proporcionar un asistente inteligente con herramientas especializadas.

## 🚀 Características Principales

- **Integración OpenAI + MCP**: Utiliza la última Responses API de OpenAI con soporte nativo para MCP
- **Herramientas Especializadas**: SerpAPI, Gmail, Google Calendar, análisis de sentimientos, flujos de trabajo
- **Selección Inteligente**: Algoritmo avanzado para seleccionar automáticamente las herramientas apropiadas
- **Optimización de Rendimiento**: Caché inteligente, gestión de tokens, selección adaptiva de modelos
- **Interfaces Múltiples**: CLI, Web UI (Streamlit), API REST
- **Arquitectura Escalable**: Diseño modular y componentes desacoplados

## 📋 Requisitos

- Python 3.11+
- Redis (para caché)
- Claves API:
  - OpenAI API Key
  - SerpAPI Key
  - Google OAuth credentials

## 🛠️ Instalación

### 1. Clonar y Configurar Entorno

```bash
# Clonar repositorio
git clone <repository-url>
cd openai-mcp-chat

# Crear entorno virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# o
venv\Scripts\activate     # Windows

# Instalar dependencias
pip install -r requirements.txt
```

### 2. Configurar Variables de Entorno

```bash
# Copiar archivo de ejemplo
cp .env.example .env

# Editar .env con tus claves API
OPENAI_API_KEY=sk-...
SERPAPI_API_KEY=...
GOOGLE_OAUTH_FILE=config/oauth/google_oauth.json
```

### 3. Configurar Google OAuth

```bash
# Crear directorio para credenciales
mkdir -p config/oauth/credentials

# Copiar tu archivo de credenciales OAuth de Google
cp path/to/your/google_oauth.json config/oauth/

# El sistema guiará el proceso de autenticación en el primer uso
```

### 4. Iniciar Redis (si es necesario)

```bash
# Docker
docker run -d -p 6379:6379 redis:7-alpine

# O instalar localmente según tu OS
```

## 🚀 Uso Rápido

### CLI (Interfaz de Línea de Comandos)

```bash
# Ejecutar chat interactivo
python -m src.interfaces.cli.main

# Comando directo
python -m src.interfaces.cli.main "Busca las últimas noticias sobre IA"
```

### Web UI (Streamlit)

```bash
# Iniciar interfaz web
streamlit run src/interfaces/web/streamlit_app.py

# Abrir http://localhost:8501
```

### API REST

```bash
# Iniciar servidor API
python -m src.interfaces.api.main

# Ejemplo de uso
curl -X POST "http://localhost:8000/chat" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Busca información sobre Python MCP",
    "conversation_id": "conv_123"
  }'
```

### Servidor MCP Standalone

```bash
# Ejecutar servidor MCP independiente
python -m src.mcp.server

# El servidor estará disponible en http://localhost:8000/mcp/v1
```

## 🏗️ Arquitectura del Sistema

```
┌─────────────────────────────────────────────────────────────┐
│                    CAPA DE APLICACIÓN                       │
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   Chat Web UI   │  │   Chat CLI      │  │   Chat API   │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                  CAPA DE ORQUESTACIÓN                       │
│  ┌───────────────────────────────────────────────────────┐  │
│  │            ChatOrchestrator                           │  │
│  │  • Gestión de conversaciones                         │  │
│  │  • Selección inteligente de herramientas             │  │
│  │  • Optimización de tokens                            │  │
│  └───────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    CAPA DE SERVICIOS MCP                    │
│  ┌─────────────────────────────────────────────────────┐    │
│  │              Servidor MCP Unificado                │    │
│  │  ┌─────────────┐  ┌──────────────┐  ┌────────────┐ │    │
│  │  │  SerpAPI    │  │   Gmail      │  │  Calendar  │ │    │
│  │  └─────────────┘  └──────────────┘  └────────────┘ │    │
│  └─────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

## 🔧 Herramientas Disponibles

### 🔍 Búsqueda e Información
- **buscar_informacion**: Búsqueda web general usando SerpAPI
- **buscar_noticias**: Búsqueda de noticias actuales
- **buscar_academico**: Búsqueda en Google Scholar
- **analizar_tendencias**: Análisis de tendencias de búsqueda

### 📧 Comunicación
- **gestionar_email**: Operaciones completas de Gmail (leer, enviar, buscar)
- **gestionar_calendario**: Gestión de Google Calendar (crear, listar, eliminar eventos)

### 🧠 Análisis Avanzado
- **analizar_sentimiento**: Análisis de sentimientos de texto
- **generar_resumen**: Generación de resúmenes inteligentes
- **traducir_contenido**: Traducción entre idiomas

### 🔄 Flujos de Trabajo
- **flujo_investigacion**: Investigación completa automatizada
- **flujo_comunicacion**: Comunicación automatizada
- **flujo_analisis_competencia**: Análisis de competencia integral

## ⚙️ Configuración Avanzada

### Variables de Entorno

```bash
# OpenAI
OPENAI_API_KEY=sk-...
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_DEFAULT_MODEL=gpt-4.1
OPENAI_REASONING_MODEL=o4-mini

# MCP
MCP_SERVER_HOST=0.0.0.0
MCP_SERVER_PORT=8000
MCP_ENABLE_STREAMABLE_HTTP=true

# SerpAPI
SERPAPI_API_KEY=...
SERPAPI_TIMEOUT=30

# Google
GOOGLE_OAUTH_FILE=config/oauth/google_oauth.json
GOOGLE_CREDENTIALS_DIR=config/oauth/credentials

# Cache (Redis)
CACHE_REDIS_URL=redis://localhost:6379
CACHE_TOOL_LIST_TTL=3600
CACHE_RESPONSE_TTL=1800

# Logging
LOGGING_LEVEL=INFO
LOGGING_FILE_PATH=logs/mcp_chat.log
```

### Archivos de Configuración

```yaml
# config/development.yaml
environment: development
debug: true

google:
  oauth_file: "config/oauth/google_oauth.json"
  credentials_dir: "config/oauth/credentials"

mcp:
  server_port: 8000
  max_tools_per_request: 5

optimization_config:
  tool_selection:
    dynamic_filtering: true
    context_aware: true
  caching:
    enabled: true
    strategy: "intelligent"
```

## 📊 Monitoreo y Observabilidad

### Métricas Disponibles

- Latencia de respuesta por herramienta
- Uso de tokens por conversación
- Tasa de éxito de llamadas MCP
- Métricas de caché (hit rate)

### Health Checks

```bash
# Verificar estado del sistema
curl http://localhost:8000/health

# Métricas de Prometheus
curl http://localhost:9090/metrics
```

### Logs Estructurados

```bash
# Ver logs en tiempo real
tail -f logs/mcp_chat.log

# Logs por componente
grep "ChatOrchestrator" logs/mcp_chat.log
grep "performance" logs/mcp_chat.log
```

## 🧪 Testing

```bash
# Ejecutar tests unitarios
pytest tests/unit/

# Tests de integración
pytest tests/integration/

# Coverage report
pytest --cov=src --cov-report=html
```

## 🔐 Seguridad

- Autenticación OAuth2 para servicios Google
- Gestión segura de tokens y API keys
- Rate limiting configurable
- Validación estricta de entrada
- Logs de auditoría para eventos de seguridad

## 🚀 Despliegue

### Docker

```bash
# Build imagen
docker build -t openai-mcp-chat .

# Ejecutar con docker-compose
docker-compose up -d
```

### Kubernetes

```bash
# Aplicar manifests
kubectl apply -f deployment/kubernetes/
```

## 📈 Optimizaciones de Rendimiento

### Gestión de Tokens
- Selección dinámica de herramientas basada en contexto
- Caché inteligente de respuestas similares
- Compresión automática de contexto largo

### Selección de Modelos
- GPT-4.1 para tareas generales
- O4-mini para razonamiento complejo
- Selección automática basada en intención

### Caché Estratégico
- Caché de listas de herramientas (1 hora)
- Caché de respuestas similares (30 minutos)
- Caché de contexto de usuario (2 horas)

## 🛣️ Roadmap

- [ ] **v1.1**: Integración con más servicios (Slack, Discord)
- [ ] **v1.2**: Soporte para archivos y documentos
- [ ] **v1.3**: API de plugins para herramientas custom
- [ ] **v1.4**: Interfaz de administración web
- [ ] **v2.0**: Soporte para múltiples modelos LLM

## 🤝 Contribuir

1. Fork el proyecto
2. Crear rama feature (`git checkout -b feature/AmazingFeature`)
3. Commit cambios (`git commit -m 'Add AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abrir Pull Request

## 📝 Licencia

Este proyecto está bajo la licencia MIT. Ver `LICENSE` para más detalles.

## 🆘 Soporte

- **Documentación**: [docs/](docs/)
- **Issues**: [GitHub Issues](https://github.com/tu-usuario/openai-mcp-chat/issues)
- **Discusiones**: [GitHub Discussions](https://github.com/tu-usuario/openai-mcp-chat/discussions)

## 🙏 Agradecimientos

- [Anthropic](https://anthropic.com) por el protocolo MCP
- [OpenAI](https://openai.com) por la integración nativa MCP
- Comunidad open source por las librerías utilizadas

---

**Desarrollado con ❤️ usando OpenAI Responses API y Model Context Protocol**