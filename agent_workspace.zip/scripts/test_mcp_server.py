#!/usr/bin/env python3
"""
Script de prueba para el servidor MCP
"""

import asyncio
import sys
import os
from pathlib import Path

# Agregar el directorio src al path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from mcp.server import MCPChatServer
from core.config import get_settings
from core.logging_config import get_logger


async def test_server_initialization():
    """Probar inicialización del servidor"""
    logger = get_logger("test")
    
    try:
        logger.info("🧪 Iniciando pruebas del servidor MCP...")
        
        # Crear instancia del servidor
        server = MCPChatServer()
        
        # Probar inicialización
        logger.info("📋 Probando inicialización...")
        await server.initialize()
        
        # Probar estadísticas de herramientas
        logger.info("📊 Probando estadísticas de herramientas...")
        
        # SerpAPI
        serpapi_health = await server.serpapi_tools.health_check()
        logger.info(f"SerpAPI: {serpapi_health}")
        
        # Analytics
        analytics_health = await server.analytics_tools.health_check()
        logger.info(f"Analytics: {analytics_health}")
        
        # Workflow
        workflow_health = await server.workflow_tools.health_check()
        logger.info(f"Workflow: {workflow_health}")
        
        # Gmail (puede fallar si no hay OAuth)
        try:
            gmail_health = await server.gmail_tools.health_check()
            logger.info(f"Gmail: {gmail_health}")
        except Exception as e:
            logger.warning(f"Gmail (esperado si no hay OAuth): {e}")
        
        # Calendar (puede fallar si no hay OAuth)
        try:
            calendar_health = await server.calendar_tools.health_check()
            logger.info(f"Calendar: {calendar_health}")
        except Exception as e:
            logger.warning(f"Calendar (esperado si no hay OAuth): {e}")
        
        # Probar estado del sistema
        logger.info("🏥 Probando estado del sistema...")
        system_status = await server._get_system_status()
        logger.info(f"Estado del sistema:\n{system_status}")
        
        logger.info("✅ Todas las pruebas básicas completadas")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Error en las pruebas: {e}")
        return False


async def test_analytics_tools():
    """Probar herramientas de análisis"""
    logger = get_logger("test_analytics")
    
    try:
        logger.info("🧪 Probando herramientas de análisis...")
        
        server = MCPChatServer()
        await server.initialize()
        
        # Probar análisis de sentimiento
        test_text = "¡Estoy muy feliz con este excelente producto! Es fantástico y funciona perfectamente."
        
        sentiment_result = await server.analytics_tools.analyze_sentiment(
            text=test_text,
            language="es",
            include_entities=True
        )
        
        logger.info("Resultado del análisis de sentimiento:")
        print(sentiment_result)
        
        # Probar generación de resumen
        long_text = """
        El protocolo de comunicación de modelos (MCP) es una especificación abierta que permite
        a las aplicaciones de inteligencia artificial integrar herramientas, datos y prompts
        de manera segura. Desarrollado por Anthropic, MCP ofrece un estándar universal para
        conectar sistemas de IA con diversas fuentes de datos y funcionalidades. El protocolo
        utiliza comunicación bidireccional para permitir que los servidores notifiquen a los
        clientes sobre cambios en tiempo real. Las aplicaciones pueden implementar MCP para
        acceder a herramientas como APIs de servicios web, bases de datos locales y sistemas
        de archivos de manera consistente y segura.
        """
        
        summary_result = await server.analytics_tools.generate_summary(
            content=long_text,
            length="medio",
            style="formal",
            language="es"
        )
        
        logger.info("Resultado del resumen:")
        print(summary_result)
        
        logger.info("✅ Pruebas de análisis completadas")
        return True
        
    except Exception as e:
        logger.error(f"❌ Error en pruebas de análisis: {e}")
        return False


async def test_serpapi_tools():
    """Probar herramientas de SerpAPI (solo si hay API key)"""
    logger = get_logger("test_serpapi")
    
    try:
        settings = get_settings()
        
        if not settings.serpapi.api_key:
            logger.warning("⚠️ No hay API key de SerpAPI configurada, saltando pruebas")
            return True
        
        logger.info("🧪 Probando herramientas de SerpAPI...")
        
        server = MCPChatServer()
        await server.initialize()
        
        # Probar búsqueda web básica
        search_result = await server.serpapi_tools.search(
            query="Python programming",
            search_type="web",
            num_results=3,
            region="es"
        )
        
        logger.info("Resultado de búsqueda web:")
        print(search_result[:500] + "..." if len(search_result) > 500 else search_result)
        
        logger.info("✅ Pruebas de SerpAPI completadas")
        return True
        
    except Exception as e:
        logger.error(f"❌ Error en pruebas de SerpAPI: {e}")
        return False


async def main():
    """Función principal de pruebas"""
    logger = get_logger("main_test")
    
    logger.info("🚀 Iniciando suite de pruebas del servidor MCP")
    
    tests = [
        ("Inicialización del servidor", test_server_initialization),
        ("Herramientas de análisis", test_analytics_tools),
        ("Herramientas de SerpAPI", test_serpapi_tools),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        logger.info(f"\n📋 Ejecutando: {test_name}")
        try:
            result = await test_func()
            results.append((test_name, result))
            if result:
                logger.info(f"✅ {test_name}: PASÓ")
            else:
                logger.error(f"❌ {test_name}: FALLÓ")
        except Exception as e:
            logger.error(f"💥 {test_name}: ERROR - {e}")
            results.append((test_name, False))
    
    # Resumen final
    logger.info("\n📊 RESUMEN DE PRUEBAS:")
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASÓ" if result else "❌ FALLÓ"
        logger.info(f"  {status} - {test_name}")
    
    logger.info(f"\n🎯 Resultado final: {passed}/{total} pruebas pasaron")
    
    if passed == total:
        logger.info("🎉 ¡Todas las pruebas pasaron! El servidor MCP está funcionando correctamente.")
        return True
    else:
        logger.warning(f"⚠️ {total - passed} pruebas fallaron. Revisa la configuración.")
        return False


if __name__ == "__main__":
    asyncio.run(main())
