#!/usr/bin/env python3
"""
Validación Final del PASO 4 - Cliente OpenAI + Interfaces MCP
Verifica que todos los componentes estén implementados y funcionando
"""

import asyncio
import json
import os
import sys
from pathlib import Path
from datetime import datetime


def print_header():
    """Header de la validación"""
    print("🔍 VALIDACIÓN FINAL - PASO 4 COMPLETADO")
    print("=" * 60)
    print("Verificando implementación del cliente OpenAI con sintaxis MCP exacta")
    print("y las 3 interfaces requeridas: CLI, Web UI y API REST")
    print(f"Timestamp: {datetime.now().isoformat()}")
    print("")


def check_file_exists(file_path: str, description: str) -> bool:
    """Verificar que un archivo existe"""
    full_path = Path(__file__).parent.parent / file_path
    exists = full_path.exists()
    status = "✅" if exists else "❌"
    print(f"   {status} {description}")
    if exists:
        print(f"      📁 {file_path}")
    else:
        print(f"      ❌ FALTANTE: {file_path}")
    return exists


def validate_client_implementation():
    """Validar implementación del cliente OpenAI"""
    print("1. 🤖 CLIENTE OPENAI CON SINTAXIS MCP EXACTA")
    print("-" * 50)
    
    files_to_check = [
        ("src/openai_integration/responses_client_v2.py", "Cliente OpenAI V2 con sintaxis MCP exacta"),
        ("src/openai_integration/responses_client.py", "Cliente OpenAI base original"),
        ("src/openai_integration/__init__.py", "Módulo de integración OpenAI"),
    ]
    
    all_files_exist = True
    for file_path, description in files_to_check:
        if not check_file_exists(file_path, description):
            all_files_exist = False
    
    print("")
    if all_files_exist:
        print("✅ Cliente OpenAI implementado correctamente")
    else:
        print("❌ Faltan archivos del cliente OpenAI")
    
    return all_files_exist


def validate_interfaces():
    """Validar las 3 interfaces implementadas"""
    print("2. 🖥️ INTERFACES IMPLEMENTADAS")
    print("-" * 50)
    
    interfaces = [
        {
            "name": "CLI Interactivo (Typer)",
            "files": [
                ("src/interfaces/cli/chat_cli.py", "CLI principal con Typer"),
                ("src/interfaces/cli/__init__.py", "Módulo CLI"),
            ]
        },
        {
            "name": "Web UI (Streamlit)",
            "files": [
                ("src/interfaces/web/streamlit_app.py", "Aplicación Streamlit"),
                ("src/interfaces/web/__init__.py", "Módulo Web"),
                ("src/interfaces/web/app.py", "Aplicación web alternativa"),
            ]
        },
        {
            "name": "API REST (FastAPI)",
            "files": [
                ("src/interfaces/api/main.py", "API principal FastAPI"),
                ("src/interfaces/api/__init__.py", "Módulo API"),
                ("src/interfaces/api/routes/__init__.py", "Rutas API"),
            ]
        }
    ]
    
    all_interfaces_ok = True
    
    for interface in interfaces:
        print(f"\n📱 {interface['name']}:")
        interface_ok = True
        
        for file_path, description in interface['files']:
            if not check_file_exists(file_path, description):
                interface_ok = False
                all_interfaces_ok = False
        
        if interface_ok:
            print(f"   ✅ {interface['name']} implementada correctamente")
        else:
            print(f"   ❌ Problemas en {interface['name']}")
    
    print("")
    if all_interfaces_ok:
        print("✅ Todas las 3 interfaces implementadas correctamente")
    else:
        print("❌ Faltan archivos en algunas interfaces")
    
    return all_interfaces_ok


def validate_mcp_integration():
    """Validar integración MCP"""
    print("3. 🔗 INTEGRACIÓN MCP")
    print("-" * 50)
    
    mcp_files = [
        ("src/mcp/server.py", "Servidor MCP principal"),
        ("src/mcp/tools/serpapi_tools.py", "Herramientas SerpAPI"),
        ("src/mcp/tools/gmail_tools.py", "Herramientas Gmail"),
        ("src/mcp/tools/calendar_tools.py", "Herramientas Calendar"),
        ("src/mcp/tools/analytics_tools.py", "Herramientas Analytics"),
        ("src/mcp/tools/workflow_tools.py", "Herramientas Workflow"),
    ]
    
    all_mcp_ok = True
    for file_path, description in mcp_files:
        if not check_file_exists(file_path, description):
            all_mcp_ok = False
    
    print("")
    if all_mcp_ok:
        print("✅ Integración MCP completa")
    else:
        print("❌ Faltan archivos de integración MCP")
    
    return all_mcp_ok


def validate_testing_scripts():
    """Validar scripts de testing"""
    print("4. 🧪 SCRIPTS DE TESTING Y VALIDACIÓN")
    print("-" * 50)
    
    test_scripts = [
        ("scripts/test_mcp_syntax_exacta.py", "Test de sintaxis MCP exacta"),
        ("scripts/demo_cliente_mcp_exacto.py", "Demo del cliente MCP"),
        ("scripts/demo_interfaces_paso4.py", "Demo de las 3 interfaces"),
        ("scripts/test_basic.py", "Tests básicos del sistema"),
        ("scripts/test_openai_simple.py", "Test de conectividad OpenAI"),
        ("scripts/start_mcp_chat.py", "Script maestro de inicio"),
    ]
    
    all_tests_ok = True
    for file_path, description in test_scripts:
        if not check_file_exists(file_path, description):
            all_tests_ok = False
    
    print("")
    if all_tests_ok:
        print("✅ Todos los scripts de testing implementados")
    else:
        print("❌ Faltan scripts de testing")
    
    return all_tests_ok


def validate_configuration():
    """Validar configuración del sistema"""
    print("5. ⚙️ CONFIGURACIÓN DEL SISTEMA")
    print("-" * 50)
    
    config_files = [
        ("src/core/config.py", "Configuración principal"),
        ("src/core/logging_config.py", "Configuración de logging"),
        ("src/core/exceptions.py", "Excepciones personalizadas"),
        ("src/core/constants.py", "Constantes del sistema"),
        (".env.example", "Archivo de configuración ejemplo"),
        ("requirements.txt", "Dependencias del proyecto"),
    ]
    
    all_config_ok = True
    for file_path, description in config_files:
        if not check_file_exists(file_path, description):
            all_config_ok = False
    
    print("")
    if all_config_ok:
        print("✅ Configuración del sistema completa")
    else:
        print("❌ Faltan archivos de configuración")
    
    return all_config_ok


def validate_documentation():
    """Validar documentación"""
    print("6. 📚 DOCUMENTACIÓN")
    print("-" * 50)
    
    doc_files = [
        ("docs/paso4_cliente_openai_implementacion_completa.md", "Documentación completa PASO 4"),
        ("sub_tasks/task_summary_paso4_cliente_openai_completado.md", "Resumen PASO 4"),
        ("docs/arquitectura_sistema_final.md", "Arquitectura del sistema"),
        ("README_new.md", "README principal"),
    ]
    
    all_docs_ok = True
    for file_path, description in doc_files:
        if not check_file_exists(file_path, description):
            all_docs_ok = False
    
    print("")
    if all_docs_ok:
        print("✅ Documentación completa")
    else:
        print("❌ Falta documentación")
    
    return all_docs_ok


def validate_sintaxis_mcp():
    """Validar que la sintaxis MCP esté correctamente implementada"""
    print("7. 🔧 VALIDACIÓN DE SINTAXIS MCP EXACTA")
    print("-" * 50)
    
    print("Verificando sintaxis MCP según especificaciones del PASO 4:")
    
    # Ejemplo de la sintaxis exacta requerida
    expected_syntax = {
        "type": "mcp",
        "server_url": "http://localhost:8080/mcp",
        "server_label": "chat_assistant",
        "allowed_tools": ["buscar_informacion", "gestionar_email"],
        "require_approval": "never",
        "headers": {"X-API-KEY": "MI_CLAVE_SECRETA"}
    }
    
    print("✅ Sintaxis MCP esperada:")
    print(json.dumps(expected_syntax, indent=2, ensure_ascii=False))
    
    # Verificar que el archivo del cliente existe y contiene la implementación
    client_file = Path(__file__).parent.parent / "src/openai_integration/responses_client_v2.py"
    
    if client_file.exists():
        print("✅ Cliente V2 encontrado")
        
        # Leer contenido del archivo para verificar elementos clave
        content = client_file.read_text()
        
        syntax_checks = [
            ('MCPToolConfig', 'Clase de configuración MCP'),
            ('to_dict', 'Método de conversión a diccionario'),
            ('configure_mcp_tool', 'Método de configuración MCP'),
            ('"type": "mcp"', 'Tipo MCP'),
            ('server_url', 'URL del servidor'),
            ('server_label', 'Label del servidor'),
            ('allowed_tools', 'Lista de herramientas permitidas'),
            ('require_approval', 'Política de aprobación'),
            ('headers', 'Headers de autenticación'),
        ]
        
        all_syntax_ok = True
        for check, description in syntax_checks:
            if check in content:
                print(f"   ✅ {description}")
            else:
                print(f"   ❌ FALTANTE: {description}")
                all_syntax_ok = False
        
        if all_syntax_ok:
            print("✅ Sintaxis MCP correctamente implementada")
        else:
            print("❌ Faltan elementos de sintaxis MCP")
        
        return all_syntax_ok
    else:
        print("❌ Cliente V2 no encontrado")
        return False


def run_actual_tests():
    """Ejecutar tests reales para verificar funcionalidad"""
    print("8. 🚀 EJECUCIÓN DE TESTS REALES")
    print("-" * 50)
    
    print("Ejecutando test de sintaxis MCP exacta...")
    
    try:
        # Importar y ejecutar el test de sintaxis MCP
        os.chdir(Path(__file__).parent.parent)
        result = os.system("python scripts/test_mcp_syntax_exacta.py > /dev/null 2>&1")
        
        if result == 0:
            print("✅ Test de sintaxis MCP: PASÓ")
            test_mcp_ok = True
        else:
            print("❌ Test de sintaxis MCP: FALLÓ")
            test_mcp_ok = False
    except Exception as e:
        print(f"❌ Error ejecutando test MCP: {e}")
        test_mcp_ok = False
    
    print("\nEjecutando test básico del sistema...")
    
    try:
        result = os.system("python scripts/test_basic.py > /dev/null 2>&1")
        
        if result == 0:
            print("✅ Test básico del sistema: PASÓ")
            test_basic_ok = True
        else:
            print("❌ Test básico del sistema: FALLÓ")
            test_basic_ok = False
    except Exception as e:
        print(f"❌ Error ejecutando test básico: {e}")
        test_basic_ok = False
    
    print("")
    all_tests_passed = test_mcp_ok and test_basic_ok
    
    if all_tests_passed:
        print("✅ Todos los tests ejecutados exitosamente")
    else:
        print("❌ Algunos tests fallaron")
    
    return all_tests_passed


def generate_final_report(results: dict):
    """Generar reporte final de validación"""
    print("🎯 REPORTE FINAL DE VALIDACIÓN - PASO 4")
    print("=" * 60)
    
    print("\n📊 Resumen de Validaciones:")
    total_checks = len(results)
    passed_checks = sum(1 for result in results.values() if result)
    success_rate = (passed_checks / total_checks) * 100
    
    for check_name, result in results.items():
        status = "✅ PASÓ" if result else "❌ FALLÓ"
        print(f"   {status} {check_name}")
    
    print(f"\n📈 Tasa de Éxito: {passed_checks}/{total_checks} ({success_rate:.1f}%)")
    
    if success_rate == 100:
        print("\n🎉 RESULTADO FINAL: ✅ PASO 4 COMPLETAMENTE IMPLEMENTADO")
        print("✅ Todos los componentes están presentes y funcionando")
        print("✅ Cliente OpenAI con sintaxis MCP exacta")
        print("✅ 3 interfaces implementadas (CLI/Web/API)")
        print("✅ Integración MCP completa")
        print("✅ Testing y validación exitosos")
        print("✅ Configuración y documentación completas")
        print("")
        print("🚀 SISTEMA LISTO PARA USO EN PRODUCCIÓN")
        
    elif success_rate >= 80:
        print("\n⚠️ RESULTADO FINAL: PASO 4 MAYORMENTE COMPLETADO")
        print("✅ La mayoría de componentes están implementados")
        print("⚠️ Algunos elementos menores pueden necesitar atención")
        print("")
        print("🔧 SISTEMA FUNCIONAL CON MEJORAS MENORES NECESARIAS")
        
    else:
        print("\n❌ RESULTADO FINAL: PASO 4 INCOMPLETO")
        print("❌ Faltan componentes críticos")
        print("❌ Se requiere más trabajo para completar el PASO 4")
        print("")
        print("🚧 SISTEMA NO LISTO PARA USO")
    
    print("\n" + "=" * 60)
    print("📅 Validación completada:", datetime.now().isoformat())
    
    return success_rate == 100


def main():
    """Función principal de validación"""
    print_header()
    
    # Ejecutar todas las validaciones
    results = {
        "Cliente OpenAI": validate_client_implementation(),
        "Interfaces (CLI/Web/API)": validate_interfaces(),
        "Integración MCP": validate_mcp_integration(),
        "Scripts de Testing": validate_testing_scripts(),
        "Configuración": validate_configuration(),
        "Documentación": validate_documentation(),
        "Sintaxis MCP Exacta": validate_sintaxis_mcp(),
        "Tests Funcionales": run_actual_tests(),
    }
    
    # Generar reporte final
    print("")
    success = generate_final_report(results)
    
    return success


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
