#!/usr/bin/env python3
"""
Script de configuración inicial para el sistema OpenAI + MCP
"""

import os
import sys
import shutil
import subprocess
from pathlib import Path
from typing import Dict, List, Optional
import json

# Colores para la salida de terminal
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


def print_colored(message: str, color: str = Colors.OKGREEN):
    """Imprimir mensaje con color"""
    print(f"{color}{message}{Colors.ENDC}")


def print_header(message: str):
    """Imprimir encabezado"""
    print_colored(f"\n{'='*60}", Colors.HEADER)
    print_colored(f" {message}", Colors.HEADER)
    print_colored(f"{'='*60}", Colors.HEADER)


def check_python_version():
    """Verificar versión de Python"""
    print_header("Verificando versión de Python")
    
    version = sys.version_info
    if version.major != 3 or version.minor < 11:
        print_colored(
            f"❌ Python 3.11+ requerido. Tienes Python {version.major}.{version.minor}",
            Colors.FAIL
        )
        return False
    
    print_colored(f"✅ Python {version.major}.{version.minor}.{version.micro} - OK", Colors.OKGREEN)
    return True


def check_commands() -> Dict[str, bool]:
    """Verificar comandos necesarios"""
    print_header("Verificando comandos del sistema")
    
    commands = {
        "git": "git --version",
        "redis-cli": "redis-cli --version",
        "docker": "docker --version"
    }
    
    results = {}
    for cmd, check_cmd in commands.items():
        try:
            subprocess.run(check_cmd.split(), capture_output=True, check=True)
            print_colored(f"✅ {cmd} - Disponible", Colors.OKGREEN)
            results[cmd] = True
        except (subprocess.CalledProcessError, FileNotFoundError):
            print_colored(f"❌ {cmd} - No disponible", Colors.WARNING)
            results[cmd] = False
    
    return results


def create_directories():
    """Crear directorios necesarios"""
    print_header("Creando estructura de directorios")
    
    directories = [
        "logs",
        "config/oauth",
        "config/oauth/credentials", 
        "temp",
        "data/cache",
        "monitoring/prometheus",
        "monitoring/grafana/dashboards",
        "monitoring/grafana/datasources"
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print_colored(f"✅ Creado: {directory}", Colors.OKGREEN)


def setup_environment_file():
    """Configurar archivo .env"""
    print_header("Configurando archivo .env")
    
    if Path(".env").exists():
        response = input("❓ El archivo .env ya existe. ¿Sobrescribir? (y/N): ")
        if response.lower() != 'y':
            print_colored("⏭️  Saltando configuración de .env", Colors.WARNING)
            return
    
    # Copiar archivo de ejemplo
    if Path(".env.example").exists():
        shutil.copy(".env.example", ".env")
        print_colored("✅ Archivo .env creado desde .env.example", Colors.OKGREEN)
    else:
        print_colored("❌ Archivo .env.example no encontrado", Colors.FAIL)
        return
    
    # Solicitar claves API básicas
    print_colored("\n🔑 Configuración de claves API (opcional, puedes hacerlo después):", Colors.OKCYAN)
    
    openai_key = input("OpenAI API Key (presiona Enter para saltar): ").strip()
    if openai_key:
        update_env_file("OPENAI_API_KEY", openai_key)
    
    serpapi_key = input("SerpAPI Key (presiona Enter para saltar): ").strip()
    if serpapi_key:
        update_env_file("SERPAPI_API_KEY", serpapi_key)
    
    print_colored("✅ Archivo .env configurado", Colors.OKGREEN)


def update_env_file(key: str, value: str):
    """Actualizar valor en archivo .env"""
    with open(".env", "r") as f:
        lines = f.readlines()
    
    with open(".env", "w") as f:
        updated = False
        for line in lines:
            if line.startswith(f"{key}="):
                f.write(f"{key}={value}\n")
                updated = True
            else:
                f.write(line)
        
        if not updated:
            f.write(f"{key}={value}\n")


def install_dependencies():
    """Instalar dependencias de Python"""
    print_header("Instalando dependencias de Python")
    
    try:
        # Verificar si estamos en un entorno virtual
        in_venv = hasattr(sys, 'real_prefix') or (
            hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix
        )
        
        if not in_venv:
            print_colored("⚠️  No estás en un entorno virtual.", Colors.WARNING)
            response = input("¿Continuar instalando en el entorno global? (y/N): ")
            if response.lower() != 'y':
                print_colored("⏭️  Saltando instalación de dependencias", Colors.WARNING)
                return False
        
        print_colored("📦 Instalando dependencias...", Colors.OKCYAN)
        
        # Actualizar pip
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pip"], check=True)
        
        # Instalar dependencias
        subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"], check=True)
        
        print_colored("✅ Dependencias instaladas correctamente", Colors.OKGREEN)
        return True
        
    except subprocess.CalledProcessError as e:
        print_colored(f"❌ Error instalando dependencias: {e}", Colors.FAIL)
        return False


def setup_redis():
    """Configurar Redis"""
    print_header("Configurando Redis")
    
    commands = check_commands()
    
    if commands.get("redis-cli"):
        try:
            # Verificar si Redis está funcionando
            subprocess.run(["redis-cli", "ping"], capture_output=True, check=True)
            print_colored("✅ Redis está funcionando", Colors.OKGREEN)
            return True
        except subprocess.CalledProcessError:
            print_colored("❌ Redis no está funcionando", Colors.WARNING)
    
    if commands.get("docker"):
        response = input("❓ ¿Quieres iniciar Redis con Docker? (y/N): ")
        if response.lower() == 'y':
            try:
                print_colored("🐳 Iniciando Redis con Docker...", Colors.OKCYAN)
                subprocess.run([
                    "docker", "run", "-d", "--name", "mcp-redis", 
                    "-p", "6379:6379", "redis:7-alpine"
                ], check=True)
                print_colored("✅ Redis iniciado con Docker", Colors.OKGREEN)
                return True
            except subprocess.CalledProcessError:
                print_colored("❌ Error iniciando Redis con Docker", Colors.FAIL)
    
    print_colored("⚠️  Redis no configurado. Instálalo manualmente o usa Docker.", Colors.WARNING)
    return False


def create_google_oauth_example():
    """Crear archivo de ejemplo para Google OAuth"""
    print_header("Configurando Google OAuth")
    
    oauth_example = {
        "installed": {
            "client_id": "your-client-id.googleusercontent.com",
            "project_id": "your-project-id",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_secret": "your-client-secret",
            "redirect_uris": ["http://localhost"]
        }
    }
    
    oauth_path = Path("config/oauth/google_oauth.json.example")
    with open(oauth_path, "w") as f:
        json.dump(oauth_example, f, indent=2)
    
    print_colored("✅ Archivo de ejemplo Google OAuth creado", Colors.OKGREEN)
    print_colored(f"📍 Ubicación: {oauth_path}", Colors.OKCYAN)
    print_colored("🔧 Edita este archivo con tus credenciales reales y renómbralo a google_oauth.json", Colors.WARNING)


def run_basic_tests():
    """Ejecutar tests básicos"""
    print_header("Ejecutando tests básicos")
    
    try:
        # Test de importación de módulos principales
        print_colored("🧪 Probando importaciones...", Colors.OKCYAN)
        
        test_imports = [
            "import mcp",
            "import openai", 
            "import fastapi",
            "import streamlit",
            "import pydantic",
            "import redis"
        ]
        
        for import_test in test_imports:
            try:
                exec(import_test)
                module_name = import_test.split()[1]
                print_colored(f"✅ {module_name} - OK", Colors.OKGREEN)
            except ImportError as e:
                module_name = import_test.split()[1]
                print_colored(f"❌ {module_name} - Error: {e}", Colors.FAIL)
        
        print_colored("✅ Tests básicos completados", Colors.OKGREEN)
        return True
        
    except Exception as e:
        print_colored(f"❌ Error en tests: {e}", Colors.FAIL)
        return False


def print_next_steps():
    """Imprimir próximos pasos"""
    print_header("🎉 Configuración completada!")
    
    next_steps = [
        "1. Configura tus claves API en el archivo .env",
        "2. Obtén credenciales de Google OAuth y colócalas en config/oauth/google_oauth.json",
        "3. Inicia Redis si no está funcionando",
        "4. Ejecuta el sistema con uno de estos comandos:",
        "   • CLI: python -m src.interfaces.cli.main",
        "   • Web: streamlit run src/interfaces/web/streamlit_app.py", 
        "   • API: python -m src.interfaces.api.main",
        "5. Lee la documentación en docs/ para más información"
    ]
    
    for step in next_steps:
        print_colored(f"  {step}", Colors.OKCYAN)
    
    print_colored("\n🆘 Si tienes problemas, revisa:", Colors.WARNING)
    print_colored("  • README.md para documentación completa", Colors.WARNING)
    print_colored("  • logs/ para archivos de log", Colors.WARNING)
    print_colored("  • .env.example para todas las configuraciones disponibles", Colors.WARNING)


def main():
    """Función principal"""
    print_colored("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                   🤖 SISTEMA CHAT OPENAI + MCP                              ║
║                        Script de Configuración                              ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
    """, Colors.HEADER)
    
    # Verificaciones iniciales
    if not check_python_version():
        return 1
    
    # Verificar comandos del sistema
    commands = check_commands()
    
    # Crear directorios
    create_directories()
    
    # Configurar archivo .env
    setup_environment_file()
    
    # Instalar dependencias
    if not install_dependencies():
        print_colored("⚠️  Puedes instalar las dependencias manualmente con: pip install -r requirements.txt", Colors.WARNING)
    
    # Configurar Redis
    setup_redis()
    
    # Crear archivo de ejemplo OAuth
    create_google_oauth_example()
    
    # Ejecutar tests básicos
    run_basic_tests()
    
    # Mostrar próximos pasos
    print_next_steps()
    
    return 0


if __name__ == "__main__":
    sys.exit(main())