#!/usr/bin/env python3
"""
Script de pruebas completas para el sistema MCP Chat
Valida la integración completa de todos los componentes
"""

import asyncio
import sys
import os
import json
import time
from pathlib import Path
from typing import Dict, List, Any, Optional

# Agregar el directorio src al path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

# Import with error handling to avoid relative import issues
try:
    from openai_integration.responses_client import (
        OpenAIResponsesClient, 
        ChatMessage, 
        MCPServerConfig
    )
    OPENAI_CLIENT_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ OpenAI integration not available: {e}")
    OPENAI_CLIENT_AVAILABLE = False

try:
    from orchestrator.responses_orchestrator import (
        ResponsesOrchestrator,
        OrchestrationRequest
    )
    ORCHESTRATOR_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ Orchestrator not available: {e}")
    ORCHESTRATOR_AVAILABLE = False

try:
    from core.config import get_settings
    from core.logging_config import get_logger
    CORE_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ Core modules not available: {e}")
    CORE_AVAILABLE = False
    
    # Create dummy logger and settings
    class DummyLogger:
        def info(self, msg): print(f"INFO: {msg}")
        def error(self, msg): print(f"ERROR: {msg}")
        def warning(self, msg): print(f"WARNING: {msg}")
    
    def get_logger(name):
        return DummyLogger()
    
    def get_settings():
        return None


class SystemTester:
    """Tester completo del sistema"""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.test_results = {
            "total_tests": 0,
            "passed": 0,
            "failed": 0,
            "skipped": 0,
            "details": []
        }
        
        # Componentes a probar
        self.openai_client: Optional[OpenAIResponsesClient] = None
        self.orchestrator: Optional[ResponsesOrchestrator] = None
        
    async def run_all_tests(self) -> Dict[str, Any]:
        """Ejecutar todas las pruebas del sistema"""
        
        print("🧪 Iniciando pruebas completas del sistema MCP Chat")
        print("=" * 60)
        
        # Pruebas de configuración
        await self.test_configuration()
        
        # Pruebas del cliente OpenAI
        await self.test_openai_client()
        
        # Pruebas del orquestrador
        await self.test_orchestrator()
        
        # Pruebas de integración
        await self.test_integration()
        
        # Pruebas de rendimiento básicas
        await self.test_basic_performance()
        
        # Resumen final
        self.print_final_summary()
        
        return self.test_results
    
    async def test_configuration(self):
        """Probar configuración del sistema"""
        
        print("\n🔧 Probando configuración...")
        
        try:
            # Test 1: Cargar configuración
            self.add_test("Cargar configuración")
            settings = get_settings()
            self.pass_test("Configuración cargada correctamente")
            
            # Test 2: Variables de entorno
            self.add_test("Variables de entorno críticas")
            
            required_vars = ["OPENAI_API_KEY"]
            missing_vars = []
            
            for var in required_vars:
                if not os.getenv(var):
                    missing_vars.append(var)
            
            if missing_vars:
                self.fail_test(f"Variables faltantes: {missing_vars}")
            else:
                self.pass_test("Variables de entorno configuradas")
            
            # Test 3: Estructura de archivos
            self.add_test("Estructura de archivos")
            
            project_root = Path(__file__).parent.parent
            critical_files = [
                "src/openai_integration/responses_client.py",
                "src/orchestrator/responses_orchestrator.py",
                "src/mcp/server.py",
                "src/interfaces/cli/chat_cli.py",
                "src/interfaces/web/streamlit_app.py",
                "src/interfaces/api/main.py"
            ]
            
            missing_files = []
            for file_path in critical_files:
                if not (project_root / file_path).exists():
                    missing_files.append(file_path)
            
            if missing_files:
                self.fail_test(f"Archivos faltantes: {missing_files}")
            else:
                self.pass_test("Estructura de archivos correcta")
                
        except Exception as e:
            self.fail_test(f"Error en configuración: {e}")
    
    async def test_openai_client(self):
        """Probar cliente OpenAI"""
        
        print("\n🤖 Probando cliente OpenAI...")
        
        if not OPENAI_CLIENT_AVAILABLE:
            self.add_test("Cliente OpenAI disponible")
            self.skip_test("Módulo OpenAI client no disponible (imports relativos)")
            return
        
        try:
            # Test 1: Inicialización
            self.add_test("Inicializar cliente OpenAI")
            self.openai_client = OpenAIResponsesClient()
            self.pass_test("Cliente OpenAI inicializado")
            
            # Test 2: Configuración MCP
            self.add_test("Configurar servidor MCP")
            self.openai_client.configure_default_mcp_server()
            
            if len(self.openai_client.mcp_servers) > 0:
                self.pass_test("Servidor MCP configurado")
            else:
                self.fail_test("No se configuró servidor MCP")
            
            # Test 3: Health check
            self.add_test("Health check OpenAI")
            
            try:
                health = await self.openai_client.health_check()
                
                if health.get("status") == "healthy":
                    self.pass_test("OpenAI healthy")
                else:
                    self.fail_test(f"OpenAI unhealthy: {health.get('error', 'Unknown')}")
                    
            except Exception as e:
                self.fail_test(f"Health check falló: {e}")
            
            # Test 4: Chat completion simple
            self.add_test("Chat completion simple")
            
            try:
                simple_message = ChatMessage(role="user", content="Hello, test message")
                
                result = await self.openai_client.chat_completion(
                    messages=[simple_message],
                    max_tokens=50,
                    stream=False
                )
                
                if result.content and len(result.content) > 0:
                    self.pass_test(f"Chat completion exitoso: {len(result.content)} chars")
                else:
                    self.fail_test("Chat completion sin contenido")
                    
            except Exception as e:
                self.fail_test(f"Chat completion falló: {e}")
                
        except Exception as e:
            self.fail_test(f"Error general en cliente OpenAI: {e}")
    
    async def test_orchestrator(self):
        """Probar orquestador"""
        
        print("\n🎼 Probando orquestrador...")
        
        if not ORCHESTRATOR_AVAILABLE:
            self.add_test("Orquestrador disponible")
            self.skip_test("Módulo orquestrador no disponible (imports relativos)")
            return
        
        try:
            # Test 1: Inicialización
            self.add_test("Inicializar orquestrador")
            self.orchestrator = ResponsesOrchestrator()
            
            # Solo inicializamos si el cliente OpenAI funcionó
            if self.openai_client:
                await self.orchestrator.initialize()
                self.pass_test("Orquestrador inicializado")
            else:
                self.skip_test("Cliente OpenAI no disponible")
                return
            
            # Test 2: Crear sesión
            self.add_test("Crear sesión de chat")
            
            request = OrchestrationRequest(
                message="Test message",
                user_id="test_user"
            )
            
            result = await self.orchestrator.process_chat_request(request)
            
            if result.session_id and not result.error:
                self.pass_test(f"Sesión creada: {result.session_id}")
            else:
                self.fail_test(f"Error creando sesión: {result.error}")
            
            # Test 3: Estadísticas
            self.add_test("Obtener estadísticas")
            
            stats = self.orchestrator.get_orchestrator_stats()
            
            if isinstance(stats, dict) and "total_requests" in stats:
                self.pass_test(f"Estadísticas: {stats['total_requests']} requests")
            else:
                self.fail_test("Estadísticas inválidas")
                
        except Exception as e:
            self.fail_test(f"Error general en orquestrador: {e}")
    
    async def test_integration(self):
        """Probar integración completa"""
        
        print("\n🔗 Probando integración completa...")
        
        if not self.orchestrator:
            self.skip_test("Orquestador no disponible")
            return
        
        try:
            # Test 1: Flujo completo de chat
            self.add_test("Flujo completo de chat")
            
            request = OrchestrationRequest(
                message="¿Cuál es el estado del sistema?",
                user_id="test_integration",
                model="gpt-4o-mini",
                max_tokens=100
            )
            
            result = await self.orchestrator.process_chat_request(request)
            
            if result.response and not result.error:
                self.pass_test(f"Flujo completo exitoso: {len(result.response)} chars")
            else:
                self.fail_test(f"Flujo completo falló: {result.error}")
            
            # Test 2: Múltiples mensajes en sesión
            self.add_test("Múltiples mensajes en sesión")
            
            request2 = OrchestrationRequest(
                message="¿Puedes darme más detalles?",
                session_id=result.session_id,
                user_id="test_integration",
                max_tokens=50
            )
            
            result2 = await self.orchestrator.process_chat_request(request2)
            
            if result2.response and result2.session_id == result.session_id:
                self.pass_test("Múltiples mensajes exitoso")
            else:
                self.fail_test("Múltiples mensajes falló")
                
        except Exception as e:
            self.fail_test(f"Error en integración: {e}")
    
    async def test_basic_performance(self):
        """Probar rendimiento básico"""
        
        print("\n⚡ Probando rendimiento básico...")
        
        if not self.orchestrator:
            self.skip_test("Orquestador no disponible")
            return
        
        try:
            # Test 1: Tiempo de respuesta
            self.add_test("Tiempo de respuesta")
            
            start_time = time.time()
            
            request = OrchestrationRequest(
                message="Test de velocidad",
                user_id="test_performance",
                max_tokens=20
            )
            
            result = await self.orchestrator.process_chat_request(request)
            
            response_time = time.time() - start_time
            
            if response_time < 10.0:  # Menos de 10 segundos
                self.pass_test(f"Tiempo de respuesta: {response_time:.2f}s")
            else:
                self.fail_test(f"Tiempo de respuesta lento: {response_time:.2f}s")
            
            # Test 2: Múltiples requests concurrentes
            self.add_test("Requests concurrentes")
            
            async def single_request(i):
                req = OrchestrationRequest(
                    message=f"Test concurrente {i}",
                    user_id=f"test_concurrent_{i}",
                    max_tokens=10
                )
                return await self.orchestrator.process_chat_request(req)
            
            start_time = time.time()
            
            # 3 requests concurrentes
            results = await asyncio.gather(
                single_request(1),
                single_request(2),
                single_request(3),
                return_exceptions=True
            )
            
            concurrent_time = time.time() - start_time
            
            successful = sum(1 for r in results if not isinstance(r, Exception) and not r.error)
            
            if successful >= 2:  # Al menos 2 de 3 exitosos
                self.pass_test(f"Concurrencia: {successful}/3 exitosos en {concurrent_time:.2f}s")
            else:
                self.fail_test(f"Concurrencia falló: {successful}/3 exitosos")
                
        except Exception as e:
            self.fail_test(f"Error en performance: {e}")
    
    def add_test(self, test_name: str):
        """Agregar test a la suite"""
        self.test_results["total_tests"] += 1
        print(f"  🧪 {test_name}...", end=" ", flush=True)
    
    def pass_test(self, message: str):
        """Marcar test como exitoso"""
        self.test_results["passed"] += 1
        self.test_results["details"].append({
            "status": "PASS",
            "message": message,
            "timestamp": time.time()
        })
        print(f"✅ {message}")
    
    def fail_test(self, message: str):
        """Marcar test como fallido"""
        self.test_results["failed"] += 1
        self.test_results["details"].append({
            "status": "FAIL",
            "message": message,
            "timestamp": time.time()
        })
        print(f"❌ {message}")
    
    def skip_test(self, reason: str):
        """Marcar test como omitido"""
        self.test_results["skipped"] += 1
        self.test_results["details"].append({
            "status": "SKIP",
            "message": reason,
            "timestamp": time.time()
        })
        print(f"⏭️ SKIP: {reason}")
    
    def print_final_summary(self):
        """Imprimir resumen final"""
        
        print("\n" + "=" * 60)
        print("📊 RESUMEN DE PRUEBAS")
        print("=" * 60)
        
        total = self.test_results["total_tests"]
        passed = self.test_results["passed"]
        failed = self.test_results["failed"]
        skipped = self.test_results["skipped"]
        
        print(f"Total de pruebas: {total}")
        print(f"✅ Exitosas: {passed}")
        print(f"❌ Fallidas: {failed}")
        print(f"⏭️ Omitidas: {skipped}")
        
        if total > 0:
            success_rate = (passed / total) * 100
            print(f"📈 Tasa de éxito: {success_rate:.1f}%")
        
        print("\n🎯 ESTADO DEL SISTEMA:")
        
        if failed == 0:
            print("✅ Sistema completamente funcional")
        elif failed <= 2:
            print("⚠️ Sistema mayormente funcional con problemas menores")
        else:
            print("❌ Sistema con problemas significativos")
        
        # Detalles de fallos
        if failed > 0:
            print("\n❌ DETALLES DE FALLOS:")
            for detail in self.test_results["details"]:
                if detail["status"] == "FAIL":
                    print(f"  • {detail['message']}")
        
        print("\n" + "=" * 60)
    
    async def cleanup(self):
        """Limpiar recursos"""
        
        if self.orchestrator:
            try:
                await self.orchestrator.shutdown()
            except Exception as e:
                print(f"Warning: Error cerrando orquestrador: {e}")


async def main():
    """Función principal"""
    
    tester = SystemTester()
    
    try:
        results = await tester.run_all_tests()
        
        # Guardar resultados
        results_file = Path(__file__).parent.parent / "test_results.json"
        with open(results_file, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"📁 Resultados guardados en: {results_file}")
        
        # Código de salida basado en resultados
        if results["failed"] == 0:
            return 0  # Éxito
        elif results["failed"] <= 2:
            return 1  # Problemas menores
        else:
            return 2  # Problemas significativos
            
    except KeyboardInterrupt:
        print("\n👋 Pruebas canceladas por el usuario")
        return 3
    except Exception as e:
        print(f"\n❌ Error ejecutando pruebas: {e}")
        return 4
    finally:
        await tester.cleanup()


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
