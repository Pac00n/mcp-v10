#!/usr/bin/env python3
"""
Demo de las 3 interfaces del PASO 4:
1. CLI interactivo con Typer
2. Web UI con Streamlit  
3. API REST con FastAPI

Cada interfaz usa el cliente OpenAI con sintaxis MCP exacta
"""

import asyncio
import json
import subprocess
import sys
from pathlib import Path
from datetime import datetime


def print_banner():
    """Banner informativo"""
    print("🚀 DEMO: Interfaces del Sistema MCP Chat - PASO 4")
    print("=" * 60)
    print("Demostrando 3 interfaces con cliente OpenAI + MCP:")
    print("1. 💻 CLI interactivo (Typer)")
    print("2. 🌐 Web UI (Streamlit)")
    print("3. 🔌 API REST (FastAPI)")
    print(f"Timestamp: {datetime.now().isoformat()}")
    print("")


def demo_cli_interface():
    """Demo de interfaz CLI"""
    print("1. 💻 INTERFAZ CLI (Typer)")
    print("-" * 40)
    print("Características implementadas:")
    print("✅ Comandos interactivos con Typer")
    print("✅ Output formateado con Rich")
    print("✅ Historial de conversaciones")
    print("✅ Streaming de respuestas en tiempo real")
    print("✅ Configuración MCP integrada")
    print("")
    
    print("📋 Estructura de la CLI:")
    print("• mcp-chat start           - Iniciar chat interactivo")
    print("• mcp-chat history         - Ver historial")
    print("• mcp-chat config          - Configurar MCP servers")
    print("• mcp-chat tools           - Listar herramientas disponibles")
    print("• mcp-chat status          - Estado del sistema")
    print("")
    
    print("🔧 Configuración MCP en CLI:")
    cli_mcp_config = {
        "server_url": "http://localhost:8080/mcp",
        "server_label": "cli_assistant",
        "allowed_tools": [
            "buscar_informacion",
            "gestionar_email", 
            "analizar_sentimiento"
        ],
        "require_approval": "never",
        "headers": {"X-API-KEY": "cli-demo-key"}
    }
    print(json.dumps(cli_mcp_config, indent=2, ensure_ascii=False))
    print("")
    
    print("💬 Ejemplo de uso CLI:")
    print("$ python scripts/start_cli.py")
    print("🤖 MCP Chat Assistant iniciado...")
    print("💬 Usuario: Busca información sobre Python asyncio")
    print("🔍 [Usando buscar_informacion via MCP...]")
    print("✅ Respuesta: Aquí tienes información sobre Python asyncio...")
    print("")


def demo_web_interface():
    """Demo de interfaz Web"""
    print("2. 🌐 INTERFAZ WEB (Streamlit)")
    print("-" * 40)
    print("Características implementadas:")
    print("✅ UI moderna con Streamlit")
    print("✅ Chat en tiempo real con streaming")
    print("✅ Sidebar con configuración MCP")
    print("✅ Visualización de tool calls")
    print("✅ Historial persistente")
    print("✅ Configuración visual de herramientas")
    print("")
    
    print("🎨 Componentes de la Web UI:")
    print("• Chat principal con markdown rendering")
    print("• Sidebar con configuración MCP")
    print("• Panel de estadísticas")
    print("• Visualizador de tool calls")
    print("• Selector de modelos OpenAI")
    print("")
    
    print("🔧 Configuración MCP en Web UI:")
    web_mcp_config = {
        "server_url": "http://localhost:8080/mcp",
        "server_label": "web_assistant", 
        "allowed_tools": [
            "buscar_informacion",
            "buscar_noticias",
            "gestionar_calendario",
            "flujo_investigacion_completo"
        ],
        "require_approval": "never",
        "headers": {"X-API-KEY": "web-demo-key"}
    }
    print(json.dumps(web_mcp_config, indent=2, ensure_ascii=False))
    print("")
    
    print("🌐 Ejemplo de uso Web:")
    print("$ streamlit run src/interfaces/web/streamlit_app.py")
    print("Local URL: http://localhost:8501")
    print("🎯 Interfaz cargada con:")
    print("   • Chat principal")
    print("   • Configuración MCP en sidebar")
    print("   • Streaming habilitado")
    print("   • Tool calls visibles")
    print("")


def demo_api_interface():
    """Demo de interfaz API REST"""
    print("3. 🔌 INTERFAZ API REST (FastAPI)")
    print("-" * 40)
    print("Características implementadas:")
    print("✅ Endpoints RESTful con FastAPI")
    print("✅ Documentación automática (Swagger)")
    print("✅ Streaming via Server-Sent Events")
    print("✅ Autenticación y rate limiting")
    print("✅ Configuración MCP via API")
    print("✅ WebSocket support para chat real-time")
    print("")
    
    print("🔗 Endpoints principales:")
    print("• POST /chat/completion    - Chat completion")
    print("• POST /chat/stream        - Chat con streaming")
    print("• GET  /chat/history       - Obtener historial")
    print("• POST /mcp/configure      - Configurar servidor MCP")
    print("• GET  /mcp/tools          - Listar herramientas MCP")
    print("• GET  /status             - Estado del sistema")
    print("")
    
    print("🔧 Configuración MCP en API:")
    api_mcp_config = {
        "server_url": "http://localhost:8080/mcp",
        "server_label": "api_assistant",
        "allowed_tools": [
            "buscar_informacion",
            "gestionar_email",
            "analizar_sentimiento",
            "generar_resumen"
        ],
        "require_approval": "never",
        "headers": {
            "X-API-KEY": "api-demo-key",
            "User-Agent": "MCP-Chat-API/1.0"
        }
    }
    print(json.dumps(api_mcp_config, indent=2, ensure_ascii=False))
    print("")
    
    print("📡 Ejemplo de uso API:")
    print("$ uvicorn src.interfaces.api.main:app --host 0.0.0.0 --port 8000")
    print("API URL: http://localhost:8000")
    print("Docs: http://localhost:8000/docs")
    print("")
    
    print("📨 Request ejemplo:")
    api_request = {
        "messages": [
            {"role": "user", "content": "Busca noticias sobre inteligencia artificial"}
        ],
        "model": "gpt-4o",
        "stream": False,
        "use_reasoning": False
    }
    print(json.dumps(api_request, indent=2, ensure_ascii=False))
    print("")


def demo_integracion_completa():
    """Demo de integración completa del sistema"""
    print("🔗 INTEGRACIÓN COMPLETA DEL SISTEMA")
    print("=" * 60)
    print("")
    
    print("🏗️ Arquitectura integrada:")
    print("┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐")
    print("│   CLI/Web/API   │───▶│  OpenAI Client   │───▶│  Responses API  │")
    print("│   Interfaces    │    │  (Sintaxis MCP)  │    │  + MCP Tools    │")
    print("└─────────────────┘    └──────────────────┘    └─────────────────┘")
    print("                                │")
    print("                                ▼")
    print("                       ┌─────────────────┐")
    print("                       │   MCP Server    │")
    print("                       │  localhost:8080 │")
    print("                       └─────────────────┘")
    print("                                │")
    print("                                ▼")
    print("                       ┌─────────────────┐")
    print("                       │ Tools: SerpAPI  │")
    print("                       │ Gmail, Calendar │") 
    print("                       │ Analytics, etc. │")
    print("                       └─────────────────┘")
    print("")
    
    print("⚙️ Configuración unificada:")
    unified_config = {
        "openai": {
            "api_key": "sk-your-openai-key",
            "model": "gpt-4o",
            "base_url": "https://api.openai.com/v1"
        },
        "mcp": {
            "server_url": "http://localhost:8080/mcp",
            "server_label": "chat_assistant",
            "allowed_tools": [
                "buscar_informacion",      # SerpAPI
                "buscar_noticias",         # SerpAPI News
                "gestionar_email",         # Gmail
                "gestionar_calendario",    # Google Calendar
                "analizar_sentimiento",    # Analytics
                "generar_resumen",         # Analytics
                "flujo_investigacion_completo",  # Workflow
                "estado_sistema"           # System
            ],
            "require_approval": "never",
            "headers": {
                "X-API-KEY": "mcp-server-key"
            }
        }
    }
    print(json.dumps(unified_config, indent=2, ensure_ascii=False))
    print("")
    
    print("🚀 Scripts de inicio unificados:")
    startup_scripts = [
        {
            "script": "scripts/start_mcp_chat.py cli",
            "descripcion": "Inicia CLI interactiva",
            "url": "Terminal local"
        },
        {
            "script": "scripts/start_mcp_chat.py web", 
            "descripcion": "Inicia Web UI",
            "url": "http://localhost:8501"
        },
        {
            "script": "scripts/start_mcp_chat.py api",
            "descripcion": "Inicia API REST", 
            "url": "http://localhost:8000"
        },
        {
            "script": "scripts/start_mcp_chat.py all",
            "descripcion": "Inicia todas las interfaces",
            "url": "Múltiples puertos"
        }
    ]
    
    for script in startup_scripts:
        print(f"• {script['script']}")
        print(f"  📝 {script['descripcion']}")
        print(f"  🌐 {script['url']}")
        print("")


def demo_ejemplos_funcionais():
    """Demo de ejemplos funcionales específicos"""
    print("📋 EJEMPLOS FUNCIONALES - PASO 4")
    print("=" * 60)
    print("")
    
    ejemplos = [
        {
            "titulo": "Búsqueda e Investigación",
            "descripcion": "Buscar información web y generar resumen",
            "interface": "CLI/Web/API",
            "mcp_tools": ["buscar_informacion", "generar_resumen"],
            "example_query": "Busca información sobre 'OpenAI MCP Protocol' y haz un resumen ejecutivo",
            "expected_flow": [
                "1. Usuario envía query",
                "2. OpenAI identifica necesidad de buscar_informacion", 
                "3. Se llama al MCP tool buscar_informacion",
                "4. Se obtienen resultados de SerpAPI",
                "5. OpenAI identifica necesidad de generar_resumen",
                "6. Se llama al MCP tool generar_resumen",
                "7. Se genera resumen ejecutivo"
            ]
        },
        {
            "titulo": "Gestión de Email Inteligente",
            "descripcion": "Gestionar emails con análisis de sentimiento",
            "interface": "Web/API",
            "mcp_tools": ["gestionar_email", "analizar_sentimiento"],
            "example_query": "Revisa emails de la última semana sobre 'proyecto AI' y analiza el sentimiento",
            "expected_flow": [
                "1. Usuario solicita análisis de emails",
                "2. OpenAI llama gestionar_email para buscar emails",
                "3. Se obtienen emails relevantes vía Gmail API",
                "4. OpenAI llama analizar_sentimiento",
                "5. Se analiza el tono de los emails",
                "6. Se presenta resumen con sentimiento"
            ]
        },
        {
            "titulo": "Flujo de Investigación Completo",
            "descripcion": "Investigación multi-step con herramientas combinadas",
            "interface": "Todas",
            "mcp_tools": ["flujo_investigacion_completo", "buscar_noticias", "analizar_sentimiento"],
            "example_query": "Investiga el mercado de AI, busca noticias recientes y analiza el sentimiento del mercado",
            "expected_flow": [
                "1. OpenAI inicia flujo_investigacion_completo",
                "2. Se ejecuta búsqueda estructurada",
                "3. Se llama buscar_noticias para info reciente",
                "4. Se recopilan múltiples fuentes",
                "5. Se llama analizar_sentimiento en conjunto",
                "6. Se genera reporte completo"
            ]
        }
    ]
    
    for i, ejemplo in enumerate(ejemplos, 1):
        print(f"{i}. 📖 {ejemplo['titulo']}")
        print(f"   📝 {ejemplo['descripcion']}")
        print(f"   🖥️  Interfaces: {ejemplo['interface']}")
        print(f"   🔧 MCP Tools: {ejemplo['mcp_tools']}")
        print(f"   💬 Query: {ejemplo['example_query']}")
        print(f"   🔄 Flujo esperado:")
        for step in ejemplo['expected_flow']:
            print(f"      {step}")
        print("")


def demo_testing_validacion():
    """Demo de testing y validación"""
    print("🧪 TESTING Y VALIDACIÓN")
    print("=" * 60)
    print("")
    
    print("✅ Tests implementados:")
    tests = [
        "scripts/test_mcp_syntax_exacta.py - Validación sintaxis MCP",
        "scripts/test_openai_simple.py - Conectividad OpenAI",
        "scripts/test_basic.py - Funcionalidad core",
        "scripts/test_complete_system.py - Integración completa"
    ]
    
    for test in tests:
        print(f"• {test}")
    print("")
    
    print("🎯 Validaciones específicas del PASO 4:")
    validaciones = [
        "✅ Sintaxis MCP exacta según documentación",
        "✅ ChatCompletion.create() con tools=[{'type': 'mcp', ...}]",
        "✅ Configuración servidor MCP local",
        "✅ Headers de autenticación",
        "✅ allowed_tools específicas", 
        "✅ require_approval='never'",
        "✅ Múltiples servidores MCP",
        "✅ Compatibilidad con herramientas OpenAI adicionales",
        "✅ 3 interfaces funcionales (CLI/Web/API)",
        "✅ Integración con servidor MCP existente"
    ]
    
    for validacion in validaciones:
        print(f"   {validacion}")
    print("")


def main():
    """Función principal del demo"""
    print_banner()
    
    # Demo de cada interfaz
    demo_cli_interface()
    demo_web_interface() 
    demo_api_interface()
    
    # Demo de integración
    demo_integracion_completa()
    
    # Ejemplos funcionales
    demo_ejemplos_funcionais()
    
    # Testing
    demo_testing_validacion()
    
    # Resumen final
    print("🎉 RESUMEN FINAL - PASO 4 COMPLETADO")
    print("=" * 60)
    print("")
    
    resultados = [
        "✅ Cliente OpenAI con sintaxis MCP exacta implementado",
        "✅ 3 interfaces desarrolladas: CLI (Typer) + Web (Streamlit) + API (FastAPI)",
        "✅ Configuración para servidor MCP local (localhost:8080)",
        "✅ Integración con herramientas múltiples del servidor MCP",
        "✅ Headers de autenticación configurados",
        "✅ Streaming y historial implementados",
        "✅ Ejemplos funcionales y testing completos",
        "✅ Compatible con OpenAI Responses API + MCP tools",
        "✅ Arquitectura lista para producción"
    ]
    
    for resultado in resultados:
        print(f"   {resultado}")
    
    print("")
    print("🚀 EL SISTEMA ESTÁ LISTO PARA USO:")
    print("   • Desarrollo: Todas las interfaces funcionan")
    print("   • Testing: Scripts de validación completos")
    print("   • Producción: Configuración escalable")
    print("")
    print("📚 PRÓXIMOS PASOS:")
    print("   1. Configurar API keys reales")
    print("   2. Iniciar servidor MCP")
    print("   3. Ejecutar interfaces según necesidad")
    print("   4. Monitorear y optimizar rendimiento")


if __name__ == "__main__":
    main()
