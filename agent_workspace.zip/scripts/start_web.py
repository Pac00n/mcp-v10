#!/usr/bin/env python3
"""
Script de inicio para la interfaz Web (Streamlit) del sistema MCP Chat
"""

import sys
import os
import subprocess
from pathlib import Path

def main():
    """Función principal"""
    
    print("🌐 Iniciando MCP Chat Web UI...")
    print("=" * 50)
    
    # Verificar que estamos en el directorio correcto
    project_root = Path(__file__).parent.parent
    web_script = project_root / "src" / "interfaces" / "web" / "streamlit_app.py"
    
    if not web_script.exists():
        print(f"❌ Error: No se encuentra el script Web en {web_script}")
        sys.exit(1)
    
    try:
        # Cambiar al directorio del proyecto
        os.chdir(project_root)
        
        # Configurar variables de entorno para Streamlit
        env = os.environ.copy()
        env["PYTHONPATH"] = str(project_root / "src")
        
        # Comando para ejecutar Streamlit
        cmd = [
            "streamlit", 
            "run", 
            str(web_script),
            "--server.port=8501",
            "--server.address=0.0.0.0",
            "--server.headless=false",
            "--browser.gatherUsageStats=false",
            "--theme.base=light"
        ]
        
        # Agregar argumentos adicionales si los hay
        if len(sys.argv) > 1:
            for arg in sys.argv[1:]:
                if arg.startswith("--port="):
                    port = arg.split("=")[1]
                    cmd[3] = f"--server.port={port}"
                elif arg.startswith("--host="):
                    host = arg.split("=")[1]
                    cmd[4] = f"--server.address={host}"
                else:
                    cmd.append(arg)
        
        print(f"Ejecutando: {' '.join(cmd)}")
        print("🚀 La aplicación web estará disponible en:")
        print("   http://localhost:8501")
        print("=" * 50)
        
        # Ejecutar Streamlit
        subprocess.run(cmd, env=env, cwd=project_root)
        
    except KeyboardInterrupt:
        print("\n👋 Web UI finalizada por el usuario")
    except FileNotFoundError:
        print("❌ Error: Streamlit no está instalado")
        print("Instálalo con: pip install streamlit")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error ejecutando Web UI: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
