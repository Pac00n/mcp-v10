#!/usr/bin/env python3
"""
Script de inicio para la interfaz CLI del sistema MCP Chat
"""

import sys
import os
import subprocess
from pathlib import Path

# Agregar el directorio src al path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

def main():
    """Función principal"""
    
    print("🤖 Iniciando MCP Chat CLI...")
    print("=" * 50)
    
    # Verificar que estamos en el directorio correcto
    project_root = Path(__file__).parent.parent
    cli_script = project_root / "src" / "interfaces" / "cli" / "chat_cli.py"
    
    if not cli_script.exists():
        print(f"❌ Error: No se encuentra el script CLI en {cli_script}")
        sys.exit(1)
    
    try:
        # Ejecutar la CLI usando el módulo
        os.chdir(project_root)
        
        # Comando para ejecutar la CLI
        cmd = [
            sys.executable, 
            "-m", 
            "src.interfaces.cli.chat_cli",
            "chat"
        ]
        
        # Agregar argumentos de línea de comandos si los hay
        if len(sys.argv) > 1:
            cmd.extend(sys.argv[1:])
        
        print(f"Ejecutando: {' '.join(cmd)}")
        print("=" * 50)
        
        # Ejecutar
        subprocess.run(cmd, cwd=project_root)
        
    except KeyboardInterrupt:
        print("\n👋 CLI finalizada por el usuario")
    except Exception as e:
        print(f"❌ Error ejecutando CLI: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
