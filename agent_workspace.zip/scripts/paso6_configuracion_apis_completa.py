#!/usr/bin/env python3
"""
PASO 6: Configuración Completa de APIs
Asegura que todas las APIs estén correctamente configuradas y documentadas
"""

import os
import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional

# Agregar src al path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


def print_header():
    """Header del PASO 6"""
    print("🔧 PASO 6: CONFIGURACIÓN COMPLETA DE APIs")
    print("=" * 60)
    print("Verificando y asegurando configuración completa de todas las APIs:")
    print("• OpenAI API (Responses API + MCP)")
    print("• SerpAPI (Búsqueda web y noticias)")
    print("• Google APIs (Gmail + Calendar)")
    print(f"Timestamp: {datetime.now().isoformat()}")
    print("")


def check_openai_configuration():
    """Verificar configuración de OpenAI"""
    print("1. 🤖 CONFIGURACIÓN OPENAI API")
    print("-" * 40)
    
    config_items = [
        {
            "variable": "OPENAI_API_KEY",
            "descripcion": "Clave API de OpenAI",
            "formato": "sk-proj-...",
            "requerido": True,
            "documentacion": "https://platform.openai.com/api-keys"
        },
        {
            "variable": "OPENAI_DEFAULT_MODEL",
            "descripcion": "Modelo por defecto",
            "formato": "gpt-4o",
            "requerido": False,
            "valor_default": "gpt-4o"
        },
        {
            "variable": "OPENAI_REASONING_MODEL",
            "descripcion": "Modelo de razonamiento",
            "formato": "o1-preview",
            "requerido": False,
            "valor_default": "o1-preview"
        },
        {
            "variable": "OPENAI_BASE_URL",
            "descripcion": "URL base de la API",
            "formato": "https://api.openai.com/v1",
            "requerido": False,
            "valor_default": "https://api.openai.com/v1"
        },
        {
            "variable": "OPENAI_MAX_TOKENS",
            "descripcion": "Máximo tokens por respuesta",
            "formato": "4000",
            "requerido": False,
            "valor_default": "4000"
        },
        {
            "variable": "OPENAI_TEMPERATURE",
            "descripcion": "Temperatura del modelo",
            "formato": "0.7",
            "requerido": False,
            "valor_default": "0.7"
        }
    ]
    
    print("Elementos de configuración OpenAI:")
    print("")
    
    status_openai = True
    for item in config_items:
        current_value = os.getenv(item["variable"])
        
        if item["requerido"] and not current_value:
            status = "❌ FALTANTE"
            status_openai = False
        elif current_value:
            status = "✅ CONFIGURADO"
        else:
            status = f"⚙️ DEFAULT ({item.get('valor_default', 'N/A')})"
        
        print(f"   {status} {item['variable']}")
        print(f"      📝 {item['descripcion']}")
        print(f"      📋 Formato: {item['formato']}")
        if item.get('documentacion'):
            print(f"      🔗 Docs: {item['documentacion']}")
        print("")
    
    if status_openai:
        print("✅ Configuración OpenAI: COMPLETA")
    else:
        print("⚠️ Configuración OpenAI: REQUIERE ATENCIÓN")
    
    return status_openai, config_items


def check_serpapi_configuration():
    """Verificar configuración de SerpAPI"""
    print("2. 🔍 CONFIGURACIÓN SERPAPI")
    print("-" * 40)
    
    config_items = [
        {
            "variable": "SERPAPI_KEY",
            "descripcion": "Clave API de SerpAPI",
            "formato": "a1b2c3d4e5f6...",
            "requerido": True,
            "documentacion": "https://serpapi.com/manage-api-key"
        },
        {
            "variable": "SERPAPI_ENGINE",
            "descripcion": "Motor de búsqueda por defecto",
            "formato": "google",
            "requerido": False,
            "valor_default": "google"
        },
        {
            "variable": "SERPAPI_GL",
            "descripcion": "Localización geográfica",
            "formato": "us",
            "requerido": False,
            "valor_default": "us"
        },
        {
            "variable": "SERPAPI_HL",
            "descripcion": "Idioma de resultados",
            "formato": "es",
            "requerido": False,
            "valor_default": "en"
        },
        {
            "variable": "SERPAPI_NUM_RESULTS",
            "descripcion": "Número de resultados",
            "formato": "10",
            "requerido": False,
            "valor_default": "10"
        }
    ]
    
    print("Elementos de configuración SerpAPI:")
    print("")
    
    status_serpapi = True
    for item in config_items:
        current_value = os.getenv(item["variable"])
        
        if item["requerido"] and not current_value:
            status = "❌ FALTANTE"
            status_serpapi = False
        elif current_value:
            status = "✅ CONFIGURADO"
        else:
            status = f"⚙️ DEFAULT ({item.get('valor_default', 'N/A')})"
        
        print(f"   {status} {item['variable']}")
        print(f"      📝 {item['descripcion']}")
        print(f"      📋 Formato: {item['formato']}")
        if item.get('documentacion'):
            print(f"      🔗 Docs: {item['documentacion']}")
        print("")
    
    if status_serpapi:
        print("✅ Configuración SerpAPI: COMPLETA")
    else:
        print("⚠️ Configuración SerpAPI: REQUIERE ATENCIÓN")
    
    return status_serpapi, config_items


def check_google_configuration():
    """Verificar configuración de Google APIs"""
    print("3. 📧 CONFIGURACIÓN GOOGLE APIS")
    print("-" * 40)
    
    config_items = [
        {
            "variable": "GOOGLE_CREDENTIALS_PATH",
            "descripcion": "Ruta a credenciales de servicio",
            "formato": "config/credentials/google-service-account.json",
            "requerido": True,
            "documentacion": "https://console.cloud.google.com/apis/credentials"
        },
        {
            "variable": "GOOGLE_PROJECT_ID",
            "descripcion": "ID del proyecto Google Cloud",
            "formato": "mi-proyecto-123456",
            "requerido": True,
            "documentacion": "https://console.cloud.google.com/"
        },
        {
            "variable": "GOOGLE_CLIENT_ID",
            "descripcion": "Client ID OAuth2",
            "formato": "123456789-abcdef.apps.googleusercontent.com",
            "requerido": False,
            "uso": "Para autenticación OAuth2 de usuarios"
        },
        {
            "variable": "GOOGLE_CLIENT_SECRET",
            "descripcion": "Client Secret OAuth2",
            "formato": "GOCSPX-...",
            "requerido": False,
            "uso": "Para autenticación OAuth2 de usuarios"
        },
        {
            "variable": "GMAIL_SCOPES",
            "descripcion": "Permisos Gmail",
            "formato": "https://www.googleapis.com/auth/gmail.readonly",
            "requerido": False,
            "valor_default": "gmail.readonly,gmail.compose"
        },
        {
            "variable": "CALENDAR_SCOPES",
            "descripcion": "Permisos Calendar",
            "formato": "https://www.googleapis.com/auth/calendar",
            "requerido": False,
            "valor_default": "calendar.readonly,calendar.events"
        }
    ]
    
    print("Elementos de configuración Google APIs:")
    print("")
    
    status_google = True
    for item in config_items:
        current_value = os.getenv(item["variable"])
        
        if item["requerido"] and not current_value:
            status = "❌ FALTANTE"
            status_google = False
        elif current_value:
            # Verificar si es un archivo y existe
            if "path" in item["variable"].lower() and current_value:
                file_path = Path(current_value)
                if file_path.exists():
                    status = "✅ CONFIGURADO (archivo existe)"
                else:
                    status = "⚠️ CONFIGURADO (archivo no encontrado)"
                    status_google = False
            else:
                status = "✅ CONFIGURADO"
        else:
            status = f"⚙️ DEFAULT ({item.get('valor_default', 'N/A')})"
        
        print(f"   {status} {item['variable']}")
        print(f"      📝 {item['descripcion']}")
        print(f"      📋 Formato: {item['formato']}")
        if item.get('uso'):
            print(f"      🎯 Uso: {item['uso']}")
        if item.get('documentacion'):
            print(f"      🔗 Docs: {item['documentacion']}")
        print("")
    
    if status_google:
        print("✅ Configuración Google APIs: COMPLETA")
    else:
        print("⚠️ Configuración Google APIs: REQUIERE ATENCIÓN")
    
    return status_google, config_items


def check_mcp_configuration():
    """Verificar configuración del servidor MCP"""
    print("4. 🔗 CONFIGURACIÓN SERVIDOR MCP")
    print("-" * 40)
    
    config_items = [
        {
            "variable": "MCP_SERVER_URL",
            "descripcion": "URL del servidor MCP",
            "formato": "http://localhost:8080/mcp",
            "requerido": True,
            "valor_default": "http://localhost:8080/mcp"
        },
        {
            "variable": "MCP_SERVER_LABEL",
            "descripcion": "Etiqueta del servidor MCP",
            "formato": "chat_assistant",
            "requerido": True,
            "valor_default": "chat_assistant"
        },
        {
            "variable": "MCP_API_KEY",
            "descripcion": "Clave API del servidor MCP",
            "formato": "mcp-secret-key-123",
            "requerido": False,
            "uso": "Para autenticación con servidor MCP"
        },
        {
            "variable": "MCP_TIMEOUT",
            "descripcion": "Timeout para llamadas MCP",
            "formato": "30",
            "requerido": False,
            "valor_default": "30"
        },
        {
            "variable": "MCP_MAX_RETRIES",
            "descripcion": "Máximo reintentos MCP",
            "formato": "3",
            "requerido": False,
            "valor_default": "3"
        }
    ]
    
    print("Elementos de configuración MCP:")
    print("")
    
    status_mcp = True
    for item in config_items:
        current_value = os.getenv(item["variable"])
        
        if item["requerido"] and not current_value:
            status = "❌ FALTANTE"
            status_mcp = False
        elif current_value:
            status = "✅ CONFIGURADO"
        else:
            status = f"⚙️ DEFAULT ({item.get('valor_default', 'N/A')})"
        
        print(f"   {status} {item['variable']}")
        print(f"      📝 {item['descripcion']}")
        print(f"      📋 Formato: {item['formato']}")
        if item.get('uso'):
            print(f"      🎯 Uso: {item['uso']}")
        print("")
    
    if status_mcp:
        print("✅ Configuración MCP: COMPLETA")
    else:
        print("⚠️ Configuración MCP: REQUIERE ATENCIÓN")
    
    return status_mcp, config_items


def generate_configuration_guide():
    """Generar guía completa de configuración"""
    print("5. 📚 GUÍA DE CONFIGURACIÓN COMPLETA")
    print("-" * 40)
    
    guide = {
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat(),
        "titulo": "Guía Completa de Configuración - Sistema MCP Chat",
        "seccion_openai": {
            "descripcion": "Configuración de OpenAI Responses API",
            "pasos": [
                "1. Visitar https://platform.openai.com/api-keys",
                "2. Crear nueva API key",
                "3. Configurar OPENAI_API_KEY en .env",
                "4. Verificar límites y billing en dashboard",
                "5. Configurar modelos preferidos (gpt-4o, o1-preview)"
            ],
            "verificacion": "Ejecutar: python scripts/test_openai_simple.py"
        },
        "seccion_serpapi": {
            "descripcion": "Configuración de SerpAPI para búsquedas",
            "pasos": [
                "1. Registrarse en https://serpapi.com/",
                "2. Obtener API key desde dashboard",
                "3. Configurar SERPAPI_KEY en .env",
                "4. Configurar localización (SERPAPI_GL=us, SERPAPI_HL=en)",
                "5. Verificar límites de uso en plan seleccionado"
            ],
            "verificacion": "Ejecutar herramienta buscar_informacion via MCP"
        },
        "seccion_google": {
            "descripcion": "Configuración de Google APIs (Gmail + Calendar)",
            "pasos": [
                "1. Crear proyecto en Google Cloud Console",
                "2. Habilitar Gmail API y Calendar API",
                "3. Crear Service Account",
                "4. Descargar JSON de credenciales",
                "5. Configurar GOOGLE_CREDENTIALS_PATH en .env",
                "6. Para OAuth2: crear Client ID/Secret",
                "7. Configurar scopes necesarios"
            ],
            "verificacion": "Ejecutar herramientas gestionar_email y gestionar_calendario"
        },
        "seccion_mcp": {
            "descripcion": "Configuración del servidor MCP local",
            "pasos": [
                "1. Configurar MCP_SERVER_URL (localhost:8080/mcp)",
                "2. Configurar MCP_SERVER_LABEL (chat_assistant)",
                "3. Configurar MCP_API_KEY para autenticación",
                "4. Ajustar timeouts según necesidad",
                "5. Verificar que puerto 8080 esté disponible"
            ],
            "verificacion": "Ejecutar: python scripts/test_mcp_server.py"
        }
    }
    
    print("📋 Guía de configuración generada:")
    print("")
    
    for seccion, contenido in guide.items():
        if seccion.startswith("seccion_"):
            nombre_seccion = seccion.replace("seccion_", "").upper()
            print(f"🔧 {nombre_seccion}:")
            print(f"   📝 {contenido['descripcion']}")
            print(f"   📋 Pasos:")
            for paso in contenido['pasos']:
                print(f"      {paso}")
            print(f"   ✅ Verificación: {contenido['verificacion']}")
            print("")
    
    # Guardar guía
    guide_path = Path(__file__).parent.parent / "docs" / "paso6_guia_configuracion_apis.json"
    with open(guide_path, "w", encoding="utf-8") as f:
        json.dump(guide, f, indent=2, ensure_ascii=False)
    
    print(f"✅ Guía guardada en: {guide_path}")
    return guide


def create_env_template_complete():
    """Crear template completo de .env"""
    print("6. 📄 TEMPLATE .ENV COMPLETO")
    print("-" * 40)
    
    env_template = """# =============================================================================
# CONFIGURACIÓN COMPLETA - SISTEMA MCP CHAT
# =============================================================================
# Copia este archivo como .env y configura las variables necesarias

# =============================================================================
# OPENAI API CONFIGURATION (REQUERIDO)
# =============================================================================
OPENAI_API_KEY=sk-proj-tu-clave-openai-aqui
OPENAI_DEFAULT_MODEL=gpt-4o
OPENAI_REASONING_MODEL=o1-preview
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MAX_TOKENS=4000
OPENAI_TEMPERATURE=0.7
OPENAI_TIMEOUT=60
OPENAI_MAX_RETRIES=3

# =============================================================================
# SERPAPI CONFIGURATION (REQUERIDO PARA BÚSQUEDAS)
# =============================================================================
SERPAPI_KEY=tu-clave-serpapi-aqui
SERPAPI_ENGINE=google
SERPAPI_GL=us
SERPAPI_HL=en
SERPAPI_NUM_RESULTS=10
SERPAPI_SAFE=off

# =============================================================================
# GOOGLE APIS CONFIGURATION (REQUERIDO PARA GMAIL/CALENDAR)
# =============================================================================
GOOGLE_PROJECT_ID=tu-proyecto-google-cloud
GOOGLE_CREDENTIALS_PATH=config/credentials/google-service-account.json

# OAuth2 (Opcional - para autenticación de usuarios)
GOOGLE_CLIENT_ID=tu-client-id.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-tu-client-secret

# Scopes (Permisos)
GMAIL_SCOPES=https://www.googleapis.com/auth/gmail.readonly,https://www.googleapis.com/auth/gmail.compose
CALENDAR_SCOPES=https://www.googleapis.com/auth/calendar.readonly,https://www.googleapis.com/auth/calendar.events

# =============================================================================
# MCP SERVER CONFIGURATION
# =============================================================================
MCP_SERVER_URL=http://localhost:8080/mcp
MCP_SERVER_LABEL=chat_assistant
MCP_API_KEY=mcp-secret-key-change-this
MCP_TIMEOUT=30
MCP_MAX_RETRIES=3

# =============================================================================
# SYSTEM CONFIGURATION
# =============================================================================
ENVIRONMENT=development
LOG_LEVEL=INFO
DEBUG=true

# =============================================================================
# CACHE CONFIGURATION (OPCIONAL)
# =============================================================================
REDIS_URL=redis://localhost:6379/0
CACHE_TTL=3600

# =============================================================================
# API LIMITS CONFIGURATION
# =============================================================================
RATE_LIMIT_REQUESTS_PER_MINUTE=60
RATE_LIMIT_BURST=10

# =============================================================================
# SECURITY CONFIGURATION
# =============================================================================
SECRET_KEY=change-this-secret-key-in-production
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=24

# =============================================================================
# MONITORING CONFIGURATION (OPCIONAL)
# =============================================================================
PROMETHEUS_PORT=9090
GRAFANA_PORT=3000
ENABLE_METRICS=true

# =============================================================================
# DEPLOYMENT CONFIGURATION
# =============================================================================
HOST=0.0.0.0
PORT=8000
WORKERS=1
RELOAD=true

# =============================================================================
# INTERFACES CONFIGURATION
# =============================================================================
STREAMLIT_PORT=8501
STREAMLIT_HOST=0.0.0.0
CLI_HISTORY_SIZE=1000
"""
    
    # Guardar template
    template_path = Path(__file__).parent.parent / ".env.template"
    with open(template_path, "w", encoding="utf-8") as f:
        f.write(env_template)
    
    print(f"📄 Template completo creado en: {template_path}")
    print("")
    print("📋 Contenido del template:")
    print("   • Configuración OpenAI (API key, modelos, parámetros)")
    print("   • Configuración SerpAPI (clave, motor, localización)")
    print("   • Configuración Google APIs (credenciales, OAuth2, scopes)")
    print("   • Configuración MCP (servidor, autenticación)")
    print("   • Configuración sistema (logs, cache, seguridad)")
    print("   • Configuración deployment (puertos, workers)")
    print("")
    print("✅ Template .env completo creado")
    
    return template_path


def test_api_connectivity():
    """Test básico de conectividad a APIs"""
    print("7. 🌐 TEST DE CONECTIVIDAD A APIS")
    print("-" * 40)
    
    connectivity_tests = [
        {
            "api": "OpenAI",
            "endpoint": "https://api.openai.com/v1/models",
            "requires_key": True,
            "test_description": "Listar modelos disponibles"
        },
        {
            "api": "SerpAPI",
            "endpoint": "https://serpapi.com/account",
            "requires_key": True,
            "test_description": "Verificar información de cuenta"
        },
        {
            "api": "Google Gmail",
            "endpoint": "https://www.googleapis.com/gmail/v1/users/me/profile",
            "requires_key": True,
            "test_description": "Obtener perfil de usuario"
        },
        {
            "api": "Google Calendar",
            "endpoint": "https://www.googleapis.com/calendar/v3/calendars/primary",
            "requires_key": True,
            "test_description": "Obtener calendario principal"
        },
        {
            "api": "MCP Server",
            "endpoint": "http://localhost:8080/mcp/tools/list",
            "requires_key": False,
            "test_description": "Listar herramientas disponibles"
        }
    ]
    
    print("Tests de conectividad configurados:")
    print("")
    
    for test in connectivity_tests:
        print(f"🌐 {test['api']}:")
        print(f"   📍 Endpoint: {test['endpoint']}")
        print(f"   🔐 Requiere clave: {'Sí' if test['requires_key'] else 'No'}")
        print(f"   📋 Test: {test['test_description']}")
        print("")
    
    print("💡 Para ejecutar tests reales:")
    print("   python scripts/test_openai_simple.py         # OpenAI")
    print("   python scripts/test_mcp_server.py            # MCP Server")
    print("   python scripts/test_complete_system.py       # Sistema completo")
    print("")
    print("✅ Tests de conectividad definidos")
    
    return connectivity_tests


def generate_configuration_report():
    """Generar reporte final de configuración"""
    print("8. 📊 REPORTE FINAL DE CONFIGURACIÓN")
    print("-" * 40)
    
    # Ejecutar verificaciones
    status_openai, _ = check_openai_configuration()
    status_serpapi, _ = check_serpapi_configuration()
    status_google, _ = check_google_configuration()
    status_mcp, _ = check_mcp_configuration()
    
    report = {
        "timestamp": datetime.now().isoformat(),
        "version": "1.0.0",
        "sistema": "MCP Chat - Configuración APIs",
        "resumen": {
            "apis_total": 4,
            "apis_configuradas": sum([status_openai, status_serpapi, status_google, status_mcp]),
            "porcentaje_completado": (sum([status_openai, status_serpapi, status_google, status_mcp]) / 4) * 100
        },
        "estado_apis": {
            "openai": "✅ Configurada" if status_openai else "⚠️ Requiere atención",
            "serpapi": "✅ Configurada" if status_serpapi else "⚠️ Requiere atención",
            "google": "✅ Configurada" if status_google else "⚠️ Requiere atención",
            "mcp": "✅ Configurada" if status_mcp else "⚠️ Requiere atención"
        },
        "archivos_generados": [
            "docs/paso6_guia_configuracion_apis.json",
            ".env.template",
            "docs/paso6_configuracion_apis_reporte.json"
        ],
        "proximos_pasos": [
            "1. Configurar API keys reales en .env",
            "2. Verificar credenciales Google Cloud",
            "3. Ejecutar tests de conectividad",
            "4. Validar herramientas MCP funcionando"
        ]
    }
    
    print("📋 Reporte final generado:")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    
    # Guardar reporte
    report_path = Path(__file__).parent.parent / "docs" / "paso6_configuracion_apis_reporte.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ Reporte guardado en: {report_path}")
    
    return report


def main():
    """Función principal del PASO 6"""
    print_header()
    
    # Ejecutar todas las verificaciones
    status_openai, _ = check_openai_configuration()
    status_serpapi, _ = check_serpapi_configuration()
    status_google, _ = check_google_configuration()
    status_mcp, _ = check_mcp_configuration()
    
    guide = generate_configuration_guide()
    template_path = create_env_template_complete()
    connectivity_tests = test_api_connectivity()
    report = generate_configuration_report()
    
    # Resumen final
    print("\n🎯 RESUMEN PASO 6 - CONFIGURACIÓN APIS")
    print("=" * 60)
    print("")
    
    apis_configuradas = sum([status_openai, status_serpapi, status_google, status_mcp])
    porcentaje = (apis_configuradas / 4) * 100
    
    print(f"📊 Estado de Configuración:")
    print(f"   📈 APIs configuradas: {apis_configuradas}/4 ({porcentaje:.1f}%)")
    print(f"   🤖 OpenAI: {'✅' if status_openai else '⚠️'}")
    print(f"   🔍 SerpAPI: {'✅' if status_serpapi else '⚠️'}")
    print(f"   📧 Google APIs: {'✅' if status_google else '⚠️'}")
    print(f"   🔗 MCP Server: {'✅' if status_mcp else '⚠️'}")
    print("")
    
    print("📚 Documentación generada:")
    print("   ✅ Guía completa de configuración")
    print("   ✅ Template .env completo")
    print("   ✅ Tests de conectividad definidos")
    print("   ✅ Reporte de estado")
    print("")
    
    print("🔧 Próximos pasos:")
    if porcentaje < 100:
        print("   1. ⚠️ Completar configuración de APIs faltantes")
        print("   2. 🔑 Configurar API keys reales")
        print("   3. 🧪 Ejecutar tests de conectividad")
    else:
        print("   1. ✅ Todas las APIs configuradas")
        print("   2. 🧪 Ejecutar tests de conectividad")
        print("   3. 🚀 Proceder con pruebas end-to-end")
    print("")
    
    if porcentaje >= 75:
        print("🎉 RESULTADO PASO 6:")
        print("✅ CONFIGURACIÓN DE APIS COMPLETA")
        print("✅ Sistema listo para pruebas funcionales")
        success = True
    else:
        print("⚠️ RESULTADO PASO 6:")
        print("⚠️ Configuración parcial completada")
        print("🔧 Requiere configuración adicional")
        success = False
    
    return success


if __name__ == "__main__":
    success = main()
    print(f"\nPASO 6 completado: {'✅ ÉXITO' if success else '⚠️ PARCIAL'}")
    exit(0)
