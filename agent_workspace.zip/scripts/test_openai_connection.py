#!/usr/bin/env python3
"""
Prueba de conectividad real con OpenAI
"""

import sys
import os
import asyncio
from pathlib import Path

# Agregar el directorio src al path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

async def test_openai_connectivity():
    """Probar conectividad real con OpenAI"""
    
    print("🔗 Probando conectividad con OpenAI...")
    
    # Verificar que existe la API key
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("❌ OPENAI_API_KEY no está configurada")
        print("   Configura tu API key en el archivo .env")
        return False
    
    if api_key.startswith("sk-your-"):
        print("❌ OPENAI_API_KEY usa valor de ejemplo")
        print("   Reemplaza con tu API key real de OpenAI")
        return False
    
    print(f"✅ API key configurada: {api_key[:10]}...")
    
    try:
        # Import with error handling
        try:
            from openai_integration.responses_client import OpenAIResponsesClient, ChatMessage
        except ImportError as e:
            print(f"❌ Error importando cliente OpenAI: {e}")
            print("   Verifica que el módulo esté correctamente instalado")
            return False
        
        # Crear cliente
        print("🤖 Creando cliente OpenAI...")
        client = OpenAIResponsesClient()
        
        # Configurar MCP por defecto
        client.configure_default_mcp_server()
        print("✅ Cliente OpenAI creado")
        
        # Health check
        print("🔍 Realizando health check...")
        health = await client.health_check()
        
        if health.get("status") == "healthy":
            print("✅ Health check exitoso")
            print(f"   Endpoint: {health.get('endpoint', 'N/A')}")
        else:
            print(f"❌ Health check falló: {health.get('error', 'Unknown')}")
            return False
        
        # Prueba de chat simple
        print("💬 Probando chat completion...")
        
        test_message = ChatMessage(
            role="user", 
            content="Di 'Hola, sistema MCP funcionando correctamente' en una sola línea."
        )
        
        result = await client.chat_completion(
            messages=[test_message],
            max_tokens=50,
            stream=False
        )
        
        if result.content:
            print("✅ Chat completion exitoso")
            print(f"   Respuesta: {result.content[:100]}...")
            print(f"   Modelo: {result.model_used}")
            print(f"   Tokens: {result.tokens_used.get('total_tokens', 'N/A')}")
            print(f"   Tiempo: {result.response_time:.2f}s")
        else:
            print("❌ Chat completion sin respuesta")
            return False
        
        # Prueba de streaming
        print("📡 Probando streaming...")
        
        stream_content = ""
        async for chunk in await client.chat_completion(
            messages=[test_message],
            max_tokens=30,
            stream=True
        ):
            if chunk.content:
                stream_content += chunk.content
            
            if chunk.is_complete:
                break
        
        if stream_content:
            print("✅ Streaming exitoso")
            print(f"   Contenido: {stream_content[:100]}...")
        else:
            print("❌ Streaming sin contenido")
            return False
        
        # Estadísticas
        stats = client.get_stats()
        print("📊 Estadísticas del cliente:")
        print(f"   Total requests: {stats.get('total_requests', 0)}")
        print(f"   Successful requests: {stats.get('successful_requests', 0)}")
        print(f"   Tokens usados: {stats.get('total_tokens_used', 0)}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error en prueba de conectividad: {e}")
        return False

async def main():
    """Función principal"""
    
    print("🧪 Test de Conectividad OpenAI")
    print("=" * 50)
    
    success = await test_openai_connectivity()
    
    print("\n" + "=" * 50)
    if success:
        print("🎉 ¡Conectividad OpenAI exitosa!")
        print("   El sistema está listo para usar con OpenAI")
    else:
        print("❌ Conectividad OpenAI falló")
        print("   Revisa la configuración antes de continuar")
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
