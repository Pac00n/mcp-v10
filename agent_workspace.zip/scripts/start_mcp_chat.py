#!/usr/bin/env python3
"""
Script maestro de inicio para el sistema MCP Chat
Permite ejecutar cualquier interfaz del sistema
"""

import sys
import os
import subprocess
from pathlib import Path
import argparse

def print_banner():
    """Mostrar banner del sistema"""
    banner = """
╔══════════════════════════════════════════════════════════════╗
║                    🤖 MCP CHAT SYSTEM                       ║
║              OpenAI Responses API + MCP Tools               ║
╚══════════════════════════════════════════════════════════════╝

Sistema de chat inteligente con herramientas especializadas:
• 🔍 Búsqueda web y noticias (SerpAPI)
• 📧 Gestión de Gmail
• 📅 Gestión de Google Calendar  
• 📊 Análisis de texto y sentimientos
• 🔄 Flujos de trabajo complejos
• 🌐 Múltiples interfaces (CLI, Web, API)
"""
    print(banner)

def print_help():
    """Mostrar ayuda completa"""
    help_text = """
🚀 Uso del sistema MCP Chat:

Interfaces disponibles:
    cli        Interfaz de línea de comandos interactiva
    web        Interfaz web con Streamlit
    api        API REST con FastAPI
    server     Servidor MCP independiente
    all        Iniciar todas las interfaces

Ejemplos:
    python start_mcp_chat.py cli
    python start_mcp_chat.py web --port=8501
    python start_mcp_chat.py api --host=localhost --port=8000
    python start_mcp_chat.py server
    python start_mcp_chat.py all

Opciones por interfaz:

CLI:
    --model=MODEL              Modelo OpenAI a usar
    --reasoning                Usar modelo de razonamiento
    --stream/--no-stream       Streaming de respuestas
    --interactive/--single     Modo interactivo o mensaje único
    --message="texto"          Mensaje único (modo no interactivo)

Web:
    --port=PORT               Puerto para Streamlit (default: 8501)
    --host=HOST               Host para Streamlit (default: 0.0.0.0)

API:
    --host=HOST               Host para API (default: 0.0.0.0)
    --port=PORT               Puerto para API (default: 8000)
    --workers=N               Número de workers (default: 1)
    --reload                  Auto-reload para desarrollo

Server:
    --port=PORT               Puerto para servidor MCP (default: 8080)
    --host=HOST               Host para servidor MCP (default: localhost)

Configuración:
    Asegúrate de tener configuradas las variables de entorno:
    - OPENAI_API_KEY
    - SERPAPI_KEY (opcional)
    - Google OAuth credentials (opcional)
"""
    print(help_text)

def start_cli(args):
    """Iniciar interfaz CLI"""
    script_path = Path(__file__).parent / "start_cli.py"
    cmd = [sys.executable, str(script_path)] + args
    return subprocess.run(cmd)

def start_web(args):
    """Iniciar interfaz Web"""
    script_path = Path(__file__).parent / "start_web.py"
    cmd = [sys.executable, str(script_path)] + args
    return subprocess.run(cmd)

def start_api(args):
    """Iniciar API REST"""
    script_path = Path(__file__).parent / "start_api.py"
    cmd = [sys.executable, str(script_path)] + args
    return subprocess.run(cmd)

def start_server(args):
    """Iniciar servidor MCP"""
    project_root = Path(__file__).parent.parent
    server_script = project_root / "src" / "mcp" / "server.py"
    
    if not server_script.exists():
        print(f"❌ Error: No se encuentra el servidor MCP en {server_script}")
        return 1
    
    os.chdir(project_root)
    env = os.environ.copy()
    env["PYTHONPATH"] = str(project_root / "src")
    
    cmd = [sys.executable, str(server_script)] + args
    return subprocess.run(cmd, env=env, cwd=project_root)

def start_all(args):
    """Iniciar todas las interfaces"""
    print("🚀 Iniciando todas las interfaces del sistema...")
    print("=" * 60)
    
    import threading
    import time
    
    def run_interface(name, func, args):
        try:
            print(f"🔄 Iniciando {name}...")
            func(args)
        except Exception as e:
            print(f"❌ Error en {name}: {e}")
    
    # Iniciar servidor MCP primero
    mcp_thread = threading.Thread(
        target=run_interface,
        args=("Servidor MCP", start_server, ["--port=8080"])
    )
    mcp_thread.daemon = True
    mcp_thread.start()
    
    time.sleep(2)  # Esperar a que el servidor MCP inicie
    
    # Iniciar API REST
    api_thread = threading.Thread(
        target=run_interface,
        args=("API REST", start_api, ["--port=8000"])
    )
    api_thread.daemon = True
    api_thread.start()
    
    time.sleep(2)  # Esperar a que la API inicie
    
    # Iniciar Web UI
    web_thread = threading.Thread(
        target=run_interface,
        args=("Web UI", start_web, ["--port=8501"])
    )
    web_thread.daemon = True
    web_thread.start()
    
    print("✅ Todas las interfaces iniciadas:")
    print("   🖥️  Servidor MCP: http://localhost:8080")
    print("   🚀 API REST: http://localhost:8000 (docs: /docs)")
    print("   🌐 Web UI: http://localhost:8501")
    print("\nPresiona Ctrl+C para detener todas las interfaces")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n👋 Deteniendo todas las interfaces...")

def check_environment():
    """Verificar configuración del entorno"""
    print("🔍 Verificando configuración del entorno...")
    
    issues = []
    
    # Verificar Python
    if sys.version_info < (3, 8):
        issues.append("❌ Python 3.8+ requerido")
    else:
        print(f"✅ Python {sys.version_info.major}.{sys.version_info.minor}")
    
    # Verificar variables de entorno críticas
    openai_key = os.getenv("OPENAI_API_KEY")
    if not openai_key:
        issues.append("⚠️  OPENAI_API_KEY no configurada")
    else:
        print("✅ OPENAI_API_KEY configurada")
    
    # Verificar dependencias críticas
    try:
        import openai
        print("✅ openai library disponible")
    except ImportError:
        issues.append("❌ openai library no instalada")
    
    try:
        import fastapi
        print("✅ FastAPI disponible")
    except ImportError:
        issues.append("❌ FastAPI no instalada")
    
    try:
        import streamlit
        print("✅ Streamlit disponible")
    except ImportError:
        issues.append("❌ Streamlit no instalada")
    
    # Verificar estructura de archivos
    project_root = Path(__file__).parent.parent
    critical_files = [
        "src/openai_integration/responses_client.py",
        "src/interfaces/cli/chat_cli.py",
        "src/interfaces/web/streamlit_app.py",
        "src/interfaces/api/main.py",
        "src/mcp/server.py"
    ]
    
    for file_path in critical_files:
        full_path = project_root / file_path
        if full_path.exists():
            print(f"✅ {file_path}")
        else:
            issues.append(f"❌ Archivo faltante: {file_path}")
    
    if issues:
        print("\n⚠️  Problemas encontrados:")
        for issue in issues:
            print(f"   {issue}")
        print("\nRevisa la documentación para resolver estos problemas.")
        return False
    else:
        print("\n✅ Entorno configurado correctamente")
        return True

def main():
    """Función principal"""
    print_banner()
    
    # Parser de argumentos
    parser = argparse.ArgumentParser(
        description="Sistema MCP Chat - Interfaz unificada de inicio",
        add_help=False
    )
    
    parser.add_argument(
        "interface",
        nargs="?",
        choices=["cli", "web", "api", "server", "all", "check"],
        help="Interfaz a iniciar"
    )
    
    parser.add_argument(
        "--help", "-h",
        action="store_true",
        help="Mostrar ayuda completa"
    )
    
    # Parsear argumentos conocidos
    args, unknown = parser.parse_known_args()
    
    if args.help or not args.interface:
        print_help()
        return
    
    if args.interface == "check":
        check_environment()
        return
    
    # Verificar entorno antes de iniciar
    if not check_environment():
        print("\n❌ Por favor, resuelve los problemas de configuración antes de continuar.")
        return 1
    
    print("\n" + "=" * 60)
    
    try:
        if args.interface == "cli":
            return start_cli(unknown)
        elif args.interface == "web":
            return start_web(unknown)
        elif args.interface == "api":
            return start_api(unknown)
        elif args.interface == "server":
            return start_server(unknown)
        elif args.interface == "all":
            return start_all(unknown)
        else:
            print(f"❌ Interfaz desconocida: {args.interface}")
            return 1
            
    except KeyboardInterrupt:
        print("\n👋 Operación cancelada por el usuario")
        return 0
    except Exception as e:
        print(f"❌ Error ejecutando {args.interface}: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main() or 0)
