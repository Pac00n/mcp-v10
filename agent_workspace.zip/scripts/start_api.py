#!/usr/bin/env python3
"""
Script de inicio para la API REST del sistema MCP Chat
"""

import sys
import os
import subprocess
from pathlib import Path

def main():
    """Función principal"""
    
    print("🚀 Iniciando MCP Chat API REST...")
    print("=" * 50)
    
    # Verificar que estamos en el directorio correcto
    project_root = Path(__file__).parent.parent
    api_script = project_root / "src" / "interfaces" / "api" / "main.py"
    
    if not api_script.exists():
        print(f"❌ Error: No se encuentra el script API en {api_script}")
        sys.exit(1)
    
    # Configuración por defecto
    host = "0.0.0.0"
    port = "8000"
    workers = "1"
    reload = False
    
    # Procesar argumentos de línea de comandos
    if len(sys.argv) > 1:
        for arg in sys.argv[1:]:
            if arg.startswith("--host="):
                host = arg.split("=")[1]
            elif arg.startswith("--port="):
                port = arg.split("=")[1]
            elif arg.startswith("--workers="):
                workers = arg.split("=")[1]
            elif arg == "--reload":
                reload = True
            elif arg == "--help":
                print_help()
                return
    
    try:
        # Cambiar al directorio del proyecto
        os.chdir(project_root)
        
        # Configurar variables de entorno
        env = os.environ.copy()
        env["PYTHONPATH"] = str(project_root / "src")
        
        # Comando para ejecutar uvicorn
        cmd = [
            "uvicorn",
            "src.interfaces.api.main:app",
            f"--host={host}",
            f"--port={port}",
            f"--workers={workers}",
            "--log-level=info",
            "--access-log"
        ]
        
        if reload:
            cmd.append("--reload")
        
        print(f"Ejecutando: {' '.join(cmd)}")
        print("🔗 La API estará disponible en:")
        print(f"   http://{host}:{port}")
        print(f"   Documentación: http://{host}:{port}/docs")
        print(f"   ReDoc: http://{host}:{port}/redoc")
        print("=" * 50)
        
        # Ejecutar uvicorn
        subprocess.run(cmd, env=env, cwd=project_root)
        
    except KeyboardInterrupt:
        print("\n👋 API finalizada por el usuario")
    except FileNotFoundError:
        print("❌ Error: uvicorn no está instalado")
        print("Instálalo con: pip install uvicorn[standard]")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error ejecutando API: {e}")
        sys.exit(1)

def print_help():
    """Mostrar ayuda"""
    help_text = """
🚀 MCP Chat API - Script de inicio

Uso:
    python start_api.py [opciones]

Opciones:
    --host=HOST        Host para bind (default: 0.0.0.0)
    --port=PORT        Puerto para bind (default: 8000)
    --workers=N        Número de workers (default: 1)
    --reload           Activar auto-reload para desarrollo
    --help             Mostrar esta ayuda

Ejemplos:
    python start_api.py
    python start_api.py --port=8080 --reload
    python start_api.py --host=localhost --workers=4
"""
    print(help_text)

if __name__ == "__main__":
    main()
