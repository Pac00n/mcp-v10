#!/usr/bin/env python3
"""
Test específico para validar sintaxis MCP exacta según PASO 4
Verifica que el cliente use la sintaxis MCP exacta de la documentación
"""

import asyncio
import json
import sys
import os
from pathlib import Path

# Agregar src al path
src_path = str(Path(__file__).parent.parent / "src")
sys.path.insert(0, src_path)

# Agregar workspace al path para imports relativos
workspace_path = str(Path(__file__).parent.parent)
sys.path.insert(0, workspace_path)

# También configurar PYTHONPATH para imports
os.environ['PYTHONPATH'] = f"{workspace_path}:{src_path}"

# Test de sintaxis MCP exacta sin imports relativos
from dataclasses import dataclass
from typing import Dict, List, Optional, Any


@dataclass
class MCPToolConfig:
    """Configuración exacta de herramienta MCP según documentación OpenAI"""
    type: str = "mcp"
    server_url: str = ""
    server_label: str = ""
    allowed_tools: Optional[List[str]] = None
    require_approval: str = "never"
    headers: Optional[Dict[str, str]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convertir a diccionario para OpenAI API"""
        tool_dict = {
            "type": self.type,
            "server_url": self.server_url,
            "server_label": self.server_label,
            "require_approval": self.require_approval
        }
        
        if self.allowed_tools:
            tool_dict["allowed_tools"] = self.allowed_tools
        
        if self.headers:
            tool_dict["headers"] = self.headers
            
        return tool_dict


@dataclass
class ChatMessageV2:
    """Mensaje de chat para Responses API v2"""
    role: str  # 'user', 'assistant', 'system'
    content: str
    name: Optional[str] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    
    def to_openai_format(self) -> Dict[str, Any]:
        """Convertir a formato OpenAI"""
        message = {
            "role": self.role,
            "content": self.content
        }
        
        if self.name:
            message["name"] = self.name
            
        if self.tool_calls:
            message["tool_calls"] = self.tool_calls
            
        return message


class MockOpenAIResponsesClientV2:
    """Mock del cliente para testing sin dependencias"""
    
    def __init__(self):
        self.mcp_tools: List[MCPToolConfig] = []
    
    def configure_mcp_tool(
        self,
        server_url: str,
        server_label: str,
        allowed_tools: Optional[List[str]] = None,
        require_approval: str = "never",
        headers: Optional[Dict[str, str]] = None
    ) -> None:
        """Configurar herramienta MCP exacta según documentación OpenAI"""
        mcp_tool = MCPToolConfig(
            server_url=server_url,
            server_label=server_label,
            allowed_tools=allowed_tools,
            require_approval=require_approval,
            headers=headers
        )
        
        # Reemplazar si ya existe
        self.mcp_tools = [t for t in self.mcp_tools if t.server_label != server_label]
        self.mcp_tools.append(mcp_tool)
    
    def configure_default_mcp_tool(self) -> None:
        """Configurar herramienta MCP por defecto"""
        allowed_tools = [
            "buscar_informacion",
            "buscar_noticias", 
            "gestionar_email",
            "gestionar_calendario",
            "analizar_sentimiento",
            "generar_resumen",
            "flujo_investigacion_completo",
            "estado_sistema"
        ]
        
        self.configure_mcp_tool(
            server_url="http://localhost:8080/mcp",
            server_label="chat_assistant",
            allowed_tools=allowed_tools,
            require_approval="never",
            headers={"X-API-KEY": "test-api-key"}
        )
    
    async def _prepare_request_params(
        self,
        messages: List[ChatMessageV2],
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        additional_tools: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        """Preparar parámetros de request con sintaxis MCP exacta"""
        
        request_params = {
            "model": model or "gpt-4o",
            "messages": [msg.to_openai_format() for msg in messages],
            "max_tokens": max_tokens or 1000,
            "temperature": temperature or 0.7
        }
        
        # Preparar herramientas usando sintaxis MCP exacta
        tools = []
        
        # Agregar herramientas MCP con sintaxis exacta según documentación
        for mcp_tool in self.mcp_tools:
            tools.append(mcp_tool.to_dict())
        
        # Agregar herramientas adicionales de OpenAI
        if additional_tools:
            tools.extend(additional_tools)
        
        if tools:
            request_params["tools"] = tools
        
        return request_params


async def test_sintaxis_mcp_exacta():
    """
    Test de sintaxis MCP exacta según especificaciones del PASO 4
    """
    print("🧪 Probando sintaxis MCP exacta...")
    print("=" * 60)
    
    # Test 1: Crear configuración MCP con sintaxis exacta
    print("\n1. ✅ Creando configuración MCP exacta...")
    
    mcp_config = MCPToolConfig(
        type="mcp",
        server_url="http://localhost:8080/mcp",
        server_label="chat_assistant",
        allowed_tools=["buscar_informacion", "gestionar_email"],
        require_approval="never",
        headers={"X-API-KEY": "mi_clave_secreta"}
    )
    
    # Verificar que la configuración se convierte al formato exacto
    tool_dict = mcp_config.to_dict()
    
    expected_format = {
        "type": "mcp",
        "server_url": "http://localhost:8080/mcp",
        "server_label": "chat_assistant",
        "allowed_tools": ["buscar_informacion", "gestionar_email"],
        "require_approval": "never",
        "headers": {"X-API-KEY": "mi_clave_secreta"}
    }
    
    print(f"Configuración generada:")
    print(json.dumps(tool_dict, indent=2, ensure_ascii=False))
    
    assert tool_dict == expected_format, "❌ Formato MCP no coincide con especificación"
    print("✅ Formato MCP correcto!")
    
    # Test 2: Crear cliente y configurar herramienta MCP
    print("\n2. ✅ Configurando cliente con herramienta MCP...")
    
    client = MockOpenAIResponsesClientV2()
    
    # Configurar con sintaxis exacta
    client.configure_mcp_tool(
        server_url="http://localhost:8080/mcp",
        server_label="chat_assistant", 
        allowed_tools=["buscar_informacion", "gestionar_email"],
        require_approval="never",
        headers={"X-API-KEY": "mi_clave_secreta"}
    )
    
    assert len(client.mcp_tools) == 1, "❌ Herramienta MCP no configurada"
    
    tool_config = client.mcp_tools[0]
    assert tool_config.server_url == "http://localhost:8080/mcp", "❌ URL incorrecta"
    assert tool_config.server_label == "chat_assistant", "❌ Label incorrecto"
    assert tool_config.allowed_tools == ["buscar_informacion", "gestionar_email"], "❌ Tools incorrectas"
    assert tool_config.require_approval == "never", "❌ Approval incorrecto"
    assert tool_config.headers == {"X-API-KEY": "mi_clave_secreta"}, "❌ Headers incorrectos"
    
    print("✅ Cliente configurado correctamente!")
    
    # Test 3: Verificar preparación de parámetros de request
    print("\n3. ✅ Verificando parámetros de request...")
    
    messages = [
        ChatMessageV2(role="user", content="Busca información sobre OpenAI")
    ]
    
    request_params = await client._prepare_request_params(
        messages=messages,
        model="gpt-4o",
        max_tokens=1000,
        temperature=0.7
    )
    
    # Verificar que incluye herramientas MCP en formato exacto
    assert "tools" in request_params, "❌ No se incluyen herramientas"
    assert len(request_params["tools"]) == 1, "❌ Número incorrecto de herramientas"
    
    mcp_tool = request_params["tools"][0]
    assert mcp_tool["type"] == "mcp", "❌ Tipo incorrecto"
    assert mcp_tool["server_url"] == "http://localhost:8080/mcp", "❌ URL incorrecta en request"
    assert mcp_tool["server_label"] == "chat_assistant", "❌ Label incorrecto en request"
    assert mcp_tool["allowed_tools"] == ["buscar_informacion", "gestionar_email"], "❌ Tools incorrectas en request"
    assert mcp_tool["require_approval"] == "never", "❌ Approval incorrecto en request"
    assert mcp_tool["headers"] == {"X-API-KEY": "mi_clave_secreta"}, "❌ Headers incorrectos en request"
    
    print("Request params generados:")
    print(json.dumps(request_params, indent=2, ensure_ascii=False))
    print("✅ Parámetros de request correctos!")
    
    # Test 4: Verificar múltiples herramientas MCP
    print("\n4. ✅ Probando múltiples herramientas MCP...")
    
    # Agregar segunda herramienta MCP
    client.configure_mcp_tool(
        server_url="https://api.ejemplo.com/mcp",
        server_label="herramientas_externas",
        allowed_tools=["buscar_web", "enviar_email"],
        require_approval="never"
    )
    
    assert len(client.mcp_tools) == 2, "❌ Segunda herramienta no agregada"
    
    # Verificar que se incluyen ambas en request
    request_params_multi = await client._prepare_request_params(
        messages=messages,
        model="gpt-4o"
    )
    
    assert len(request_params_multi["tools"]) == 2, "❌ No se incluyen todas las herramientas"
    
    # Verificar primera herramienta
    tool1 = request_params_multi["tools"][0]
    assert tool1["server_label"] == "chat_assistant", "❌ Primera herramienta incorrecta"
    
    # Verificar segunda herramienta
    tool2 = request_params_multi["tools"][1]
    assert tool2["server_label"] == "herramientas_externas", "❌ Segunda herramienta incorrecta"
    assert tool2["server_url"] == "https://api.ejemplo.com/mcp", "❌ URL segunda herramienta incorrecta"
    assert "headers" not in tool2, "❌ Headers no debería estar presente sin configurar"
    
    print("✅ Múltiples herramientas MCP configuradas correctamente!")
    
    # Test 5: Verificar herramientas adicionales combinadas
    print("\n5. ✅ Probando combinación con herramientas adicionales...")
    
    additional_tools = [
        {
            "type": "web_search_preview",
            "user_location": {
                "type": "approximate",
                "country": "US"
            }
        },
        {
            "type": "code_interpreter"
        }
    ]
    
    request_params_combined = await client._prepare_request_params(
        messages=messages,
        model="gpt-4o",
        additional_tools=additional_tools
    )
    
    # Debe tener 2 MCP + 2 adicionales = 4 herramientas
    assert len(request_params_combined["tools"]) == 4, "❌ Número incorrecto de herramientas combinadas"
    
    # Verificar que las primeras 2 son MCP
    assert request_params_combined["tools"][0]["type"] == "mcp", "❌ Primera no es MCP"
    assert request_params_combined["tools"][1]["type"] == "mcp", "❌ Segunda no es MCP"
    
    # Verificar que las siguientes son adicionales
    assert request_params_combined["tools"][2]["type"] == "web_search_preview", "❌ Tercera no es web_search"
    assert request_params_combined["tools"][3]["type"] == "code_interpreter", "❌ Cuarta no es code_interpreter"
    
    print("✅ Combinación con herramientas adicionales correcta!")
    
    # Test 6: Configuración por defecto
    print("\n6. ✅ Probando configuración por defecto...")
    
    client_default = MockOpenAIResponsesClientV2()
    client_default.configure_default_mcp_tool()
    
    assert len(client_default.mcp_tools) == 1, "❌ Configuración por defecto no aplicada"
    
    default_tool = client_default.mcp_tools[0]
    assert default_tool.server_label == "chat_assistant", "❌ Label por defecto incorrecto"
    assert default_tool.server_url == "http://localhost:8080/mcp", "❌ URL por defecto incorrecta"
    assert default_tool.allowed_tools is not None, "❌ Tools por defecto no configuradas"
    assert len(default_tool.allowed_tools) > 0, "❌ Lista de tools por defecto vacía"
    
    print(f"Herramientas por defecto configuradas: {default_tool.allowed_tools}")
    print("✅ Configuración por defecto correcta!")
    
    print("\n" + "=" * 60)
    print("🎉 ¡Todos los tests de sintaxis MCP exacta PASARON!")
    print("✅ El cliente implementa correctamente la sintaxis MCP especificada")
    print("✅ Compatible con herramientas adicionales de OpenAI")
    print("✅ Configuración por defecto funcional")
    print("✅ Múltiples servidores MCP soportados")


async def test_configuracion_servidor_local():
    """
    Test específico para servidor MCP local según nuestro servidor en src/mcp/server.py
    """
    print("\n🏠 Probando configuración para servidor MCP local...")
    print("=" * 60)
    
    client = MockOpenAIResponsesClientV2()
    
    # Configurar para nuestro servidor local con herramientas específicas
    client.configure_mcp_tool(
        server_url="http://localhost:8080/mcp",
        server_label="chat_assistant",
        allowed_tools=[
            "buscar_informacion",      # SerpAPI tools
            "buscar_noticias",
            "gestionar_email",         # Gmail tools  
            "gestionar_calendario",    # Calendar tools
            "analizar_sentimiento",    # Analytics tools
            "generar_resumen",
            "flujo_investigacion_completo",  # Workflow tools
            "estado_sistema"           # System status
        ],
        require_approval="never",
        headers={"X-API-KEY": "test-api-key"}
    )
    
    # Crear mensaje de prueba
    messages = [
        ChatMessageV2(
            role="user", 
            content="Busca información sobre inteligencia artificial y analiza el sentimiento"
        )
    ]
    
    # Preparar request para servidor local
    request_params = await client._prepare_request_params(
        messages=messages,
        model="gpt-4o",
        max_tokens=1500,
        temperature=0.7
    )
    
    print("Configuración para servidor MCP local:")
    print(json.dumps(request_params["tools"][0], indent=2, ensure_ascii=False))
    
    # Verificar que está configurado para nuestro servidor
    mcp_tool = request_params["tools"][0]
    assert mcp_tool["server_url"] == "http://localhost:8080/mcp"
    assert mcp_tool["server_label"] == "chat_assistant"
    assert "buscar_informacion" in mcp_tool["allowed_tools"]
    assert "gestionar_email" in mcp_tool["allowed_tools"]
    assert "flujo_investigacion_completo" in mcp_tool["allowed_tools"]
    
    print("✅ Configuración para servidor local correcta!")
    print(f"✅ Herramientas configuradas: {len(mcp_tool['allowed_tools'])}")


if __name__ == "__main__":
    async def main():
        try:
            await test_sintaxis_mcp_exacta()
            await test_configuracion_servidor_local()
            
            print("\n🎯 RESULTADO FINAL:")
            print("✅ TODOS LOS TESTS PASARON")
            print("✅ Sintaxis MCP exacta implementada correctamente")
            print("✅ Compatible con especificaciones del PASO 4")
            print("✅ Listo para usar con servidor MCP local")
            
        except Exception as e:
            print(f"\n❌ ERROR: {e}")
            print("💥 Algún test falló")
            return False
        
        return True
    
    # Ejecutar tests
    result = asyncio.run(main())
    exit(0 if result else 1)
