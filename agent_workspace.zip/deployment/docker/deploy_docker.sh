#!/bin/bash
# deploy_docker.sh - Deployment con Docker

set -e

echo "🚀 Iniciando deployment Docker del Sistema MCP Chat"

# Variables
IMAGE_NAME="mcp-chat-system"
CONTAINER_NAME="mcp-chat"
VERSION=${1:-"latest"}
PORT=${2:-"8000"}

echo "📦 Construyendo imagen Docker..."
docker build -t $IMAGE_NAME:$VERSION .

echo "🛑 Deteniendo contenedor existente (si existe)..."
docker stop $CONTAINER_NAME 2>/dev/null || true
docker rm $CONTAINER_NAME 2>/dev/null || true

echo "🏃 Iniciando nuevo contenedor..."
docker run -d \
  --name $CONTAINER_NAME \
  --restart unless-stopped \
  -p $PORT:8000 \
  --env-file .env \
  -v $(pwd)/config:/app/config \
  -v $(pwd)/logs:/app/logs \
  $IMAGE_NAME:$VERSION

echo "✅ Deployment completado!"
echo "🌐 Sistema disponible en: http://localhost:$PORT"
echo "📊 Health check: http://localhost:$PORT/health"

# Verificar que el contenedor esté ejecutándose
sleep 5
if docker ps | grep -q $CONTAINER_NAME; then
    echo "✅ Contenedor ejecutándose correctamente"
else
    echo "❌ Error: Contenedor no está ejecutándose"
    echo "📋 Logs del contenedor:"
    docker logs $CONTAINER_NAME
    exit 1
fi

echo "🎉 Deployment exitoso!"
