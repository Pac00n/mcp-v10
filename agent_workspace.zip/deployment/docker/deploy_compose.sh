#!/bin/bash
# deploy_compose.sh - Deployment con Docker Compose

set -e

echo "🚀 Iniciando deployment con Docker Compose"

# Variables
COMPOSE_FILE=${1:-"docker-compose.yml"}
ENVIRONMENT=${2:-"production"}

echo "📁 Verificando archivos necesarios..."
if [[ ! -f $COMPOSE_FILE ]]; then
    echo "❌ Error: $COMPOSE_FILE no encontrado"
    exit 1
fi

if [[ ! -f .env ]]; then
    echo "❌ Error: Archivo .env no encontrado"
    echo "💡 Copia .env.template a .env y configura las variables"
    exit 1
fi

echo "🔧 Configurando entorno: $ENVIRONMENT"
export ENVIRONMENT=$ENVIRONMENT

echo "🛑 Deteniendo servicios existentes..."
docker-compose -f $COMPOSE_FILE down

echo "📦 Construyendo imágenes..."
docker-compose -f $COMPOSE_FILE build

echo "🏃 Iniciando servicios..."
docker-compose -f $COMPOSE_FILE up -d

echo "⏳ Esperando que los servicios estén listos..."
sleep 10

echo "🔍 Verificando estado de servicios..."
docker-compose -f $COMPOSE_FILE ps

# Health checks
echo "🩺 Ejecutando health checks..."
for service in mcp-chat mcp-server; do
    if docker-compose -f $COMPOSE_FILE ps $service | grep -q "Up"; then
        echo "✅ $service: OK"
    else
        echo "❌ $service: ERROR"
        echo "📋 Logs de $service:"
        docker-compose -f $COMPOSE_FILE logs $service
    fi
done

echo "📊 URLs disponibles:"
echo "   🌐 Chat Web UI: http://localhost:8501"
echo "   🔌 API REST: http://localhost:8000"
echo "   📚 API Docs: http://localhost:8000/docs"
echo "   📈 Metrics: http://localhost:9090"

echo "🎉 Deployment con Docker Compose completado!"
