#!/bin/bash
# deploy_kubernetes.sh - Deployment en Kubernetes

set -e

echo "🚀 Iniciando deployment en Kubernetes"

# Variables
NAMESPACE=${1:-"mcp-chat"}
ENVIRONMENT=${2:-"production"}
KUBECTL_CONTEXT=${3:-""}

echo "🔧 Configurando entorno..."
if [[ ! -z "$KUBECTL_CONTEXT" ]]; then
    kubectl config use-context $KUBECTL_CONTEXT
fi

echo "📁 Creando namespace (si no existe)..."
kubectl create namespace $NAMESPACE --dry-run=client -o yaml | kubectl apply -f -

echo "🔐 Configurando secrets..."
kubectl create secret generic api-keys \
  --namespace=$NAMESPACE \
  --from-env-file=.env \
  --dry-run=client -o yaml | kubectl apply -f -

echo "📦 Aplicando manifests..."
kubectl apply -f deployment/kubernetes/ -n $NAMESPACE

echo "⏳ Esperando que los pods estén listos..."
kubectl wait --for=condition=ready pod -l app=mcp-chat -n $NAMESPACE --timeout=300s

echo "🔍 Verificando deployment..."
kubectl get pods -n $NAMESPACE
kubectl get services -n $NAMESPACE

# Obtener URLs de acceso
echo "📊 URLs de acceso:"
if kubectl get service mcp-chat-service -n $NAMESPACE -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null; then
    EXTERNAL_IP=$(kubectl get service mcp-chat-service -n $NAMESPACE -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
    echo "   🌐 External IP: http://$EXTERNAL_IP"
else
    echo "   🔗 Port Forward: kubectl port-forward service/mcp-chat-service 8000:80 -n $NAMESPACE"
fi

echo "📋 Para monitorear:"
echo "   kubectl logs -f deployment/mcp-chat -n $NAMESPACE"
echo "   kubectl get events -n $NAMESPACE --sort-by=.metadata.creationTimestamp"

echo "🎉 Deployment en Kubernetes completado!"
