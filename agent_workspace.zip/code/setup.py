#!/usr/bin/env python3
"""
Script de configuración automática para MCP Chat Assistant
Configura el entorno, dependencias y archivos necesarios
"""

import os
import sys
import subprocess
import json
import shutil
from pathlib import Path
from typing import Dict, Any

def print_banner():
    """Imprime banner de bienvenida"""
    banner = """
    ╔══════════════════════════════════════╗
    ║     MCP CHAT ASSISTANT SETUP        ║
    ║                                      ║
    ║  Configuración automática para       ║
    ║  OpenAI + MCP + SerpAPI + Google     ║
    ╚══════════════════════════════════════╝
    """
    print(banner)

def check_python_version():
    """Verifica versión de Python"""
    if sys.version_info < (3, 8):
        print("❌ Error: Python 3.8+ es requerido")
        sys.exit(1)
    print(f"✅ Python {sys.version.split()[0]} detectado")

def create_directories():
    """Crea directorios necesarios"""
    directories = [
        "credentials",
        "logs", 
        "data",
        "conversations",
        "reports"
    ]
    
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
        print(f"📁 Directorio creado: {directory}")

def install_dependencies():
    """Instala dependencias de Python"""
    print("📦 Instalando dependencias...")
    
    try:
        subprocess.check_call([
            sys.executable, "-m", "pip", "install", "-r", "requirements.txt"
        ])
        print("✅ Dependencias instaladas correctamente")
    except subprocess.CalledProcessError:
        print("❌ Error instalando dependencias")
        sys.exit(1)

def setup_environment_file():
    """Configura archivo .env"""
    if os.path.exists(".env"):
        print("⚠️  Archivo .env ya existe")
        overwrite = input("¿Sobrescribir? (s/n): ").lower().startswith('s')
        if not overwrite:
            print("📄 Manteniendo archivo .env existente")
            return
    
    # Copiar desde ejemplo
    if os.path.exists(".env.example"):
        shutil.copy(".env.example", ".env")
        print("✅ Archivo .env creado desde plantilla")
        print("⚠️  IMPORTANTE: Edita .env con tus claves API")
    else:
        print("❌ No se encontró .env.example")

def setup_google_oauth():
    """Configura Google OAuth"""
    if os.path.exists(".gauth.json"):
        print("⚠️  Archivo .gauth.json ya existe")
        return
    
    print("\n🔧 Configuración Google OAuth:")
    print("1. Ve a https://console.cloud.google.com/")
    print("2. Crea un proyecto o selecciona uno existente")
    print("3. Habilita Gmail API y Calendar API")
    print("4. Crea credenciales OAuth 2.0")
    print("5. Descarga el archivo JSON de credenciales")
    
    create_oauth = input("\n¿Crear archivo .gauth.json desde plantilla? (s/n): ").lower().startswith('s')
    
    if create_oauth:
        if os.path.exists(".gauth.json.example"):
            shutil.copy(".gauth.json.example", ".gauth.json")
            print("✅ Archivo .gauth.json creado desde plantilla")
            print("⚠️  IMPORTANTE: Edita .gauth.json con tus credenciales Google")
        else:
            print("❌ No se encontró .gauth.json.example")

def collect_api_keys() -> Dict[str, str]:
    """Recolecta claves API del usuario"""
    print("\n🔑 Configuración de claves API:")
    print("(Presiona Enter para omitir cualquier clave)")
    
    keys = {}
    
    # OpenAI API Key
    openai_key = input("OpenAI API Key: ").strip()
    if openai_key:
        keys["OPENAI_API_KEY"] = openai_key
    
    # SerpAPI Key
    serpapi_key = input("SerpAPI Key: ").strip()
    if serpapi_key:
        keys["SERPAPI_API_KEY"] = serpapi_key
    
    return keys

def update_env_file(api_keys: Dict[str, str]):
    """Actualiza archivo .env con claves API"""
    if not api_keys:
        return
    
    env_content = []
    
    # Leer archivo .env existente
    if os.path.exists(".env"):
        with open(".env", "r") as f:
            env_content = f.readlines()
    
    # Actualizar claves
    for key, value in api_keys.items():
        updated = False
        for i, line in enumerate(env_content):
            if line.startswith(f"{key}="):
                env_content[i] = f"{key}={value}\n"
                updated = True
                break
        
        if not updated:
            env_content.append(f"{key}={value}\n")
    
    # Escribir archivo actualizado
    with open(".env", "w") as f:
        f.writelines(env_content)
    
    print("✅ Archivo .env actualizado con claves API")

def setup_claude_desktop():
    """Configura Claude Desktop"""
    print("\n🖥️  Configuración Claude Desktop:")
    
    # Detectar sistema operativo
    if sys.platform == "darwin":  # macOS
        config_path = Path.home() / "Library/Application Support/Claude/claude_desktop_config.json"
    elif sys.platform == "win32":  # Windows
        config_path = Path.home() / "AppData/Roaming/Claude/claude_desktop_config.json"
    else:
        print("⚠️  Claude Desktop no soportado en Linux")
        return
    
    print(f"📍 Ruta de configuración: {config_path}")
    
    if config_path.exists():
        backup = input("¿Crear backup del archivo existente? (s/n): ").lower().startswith('s')
        if backup:
            backup_path = config_path.with_suffix(".json.backup")
            shutil.copy(config_path, backup_path)
            print(f"💾 Backup creado: {backup_path}")
    
    # Crear directorio si no existe
    config_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Copiar configuración
    if os.path.exists("claude_desktop_config.json"):
        # Actualizar rutas en la configuración
        with open("claude_desktop_config.json", "r") as f:
            config = json.load(f)
        
        # Actualizar rutas absolutas
        current_dir = os.getcwd()
        for server_name, server_config in config.get("mcpServers", {}).items():
            if "args" in server_config:
                # Convertir rutas relativas a absolutas
                args = server_config["args"]
                for i, arg in enumerate(args):
                    if arg.startswith("./"):
                        args[i] = os.path.join(current_dir, arg[2:])
        
        # Escribir configuración actualizada
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
        
        print("✅ Configuración Claude Desktop actualizada")
    else:
        print("❌ No se encontró claude_desktop_config.json")

def run_tests():
    """Ejecuta tests básicos"""
    print("\n🧪 Ejecutando tests básicos...")
    
    try:
        # Test importaciones
        import mcp
        import openai
        import aiohttp
        print("✅ Importaciones principales OK")
        
        # Test archivo .env
        from dotenv import load_dotenv
        load_dotenv()
        
        openai_key = os.getenv("OPENAI_API_KEY")
        serpapi_key = os.getenv("SERPAPI_API_KEY")
        
        if openai_key:
            print("✅ OpenAI API Key cargada")
        else:
            print("⚠️  OpenAI API Key no encontrada")
        
        if serpapi_key:
            print("✅ SerpAPI Key cargada")
        else:
            print("⚠️  SerpAPI Key no encontrada")
        
        # Test Google OAuth
        if os.path.exists(".gauth.json"):
            print("✅ Archivo Google OAuth encontrado")
        else:
            print("⚠️  Archivo Google OAuth no encontrado")
        
        print("✅ Tests básicos completados")
        
    except ImportError as e:
        print(f"❌ Error de importación: {e}")
    except Exception as e:
        print(f"❌ Error en tests: {e}")

def main():
    """Función principal de setup"""
    print_banner()
    
    print("🚀 Iniciando configuración automática...\n")
    
    # 1. Verificar Python
    check_python_version()
    
    # 2. Crear directorios
    create_directories()
    
    # 3. Instalar dependencias
    install_dependencies()
    
    # 4. Configurar archivos de entorno
    setup_environment_file()
    
    # 5. Configurar Google OAuth
    setup_google_oauth()
    
    # 6. Recolectar claves API
    api_keys = collect_api_keys()
    if api_keys:
        update_env_file(api_keys)
    
    # 7. Configurar Claude Desktop
    setup_claude_desktop()
    
    # 8. Ejecutar tests
    run_tests()
    
    # Resumen final
    print("\n" + "="*50)
    print("🎉 CONFIGURACIÓN COMPLETADA")
    print("="*50)
    print("\n📋 Próximos pasos:")
    print("1. Edita .env con tus claves API si no lo hiciste")
    print("2. Edita .gauth.json con credenciales Google")
    print("3. Ejecuta: python mcp_chat_server.py")
    print("4. En otra terminal: python openai_mcp_client.py interactive")
    print("\n📚 Documentación:")
    print("- README.md para instrucciones detalladas")
    print("- docs/ para documentación completa")
    print("\n🆘 Soporte:")
    print("- Revisa logs/ si hay errores")
    print("- Verifica configuración en .env y .gauth.json")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n❌ Setup interrumpido por el usuario")
    except Exception as e:
        print(f"\n❌ Error durante setup: {e}")
        sys.exit(1)
