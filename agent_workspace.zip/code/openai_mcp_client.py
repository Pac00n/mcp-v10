#!/usr/bin/env python3
"""
Cliente OpenAI con integración MCP
Conecta con el servidor MCP para chat inteligente
"""

import os
import json
import asyncio
from typing import Dict, List, Optional
import openai
from openai import OpenAI
import logging

# Configuración de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MCPChatClient:
    """Cliente de chat que usa OpenAI con MCP"""
    
    def __init__(
        self,
        openai_api_key: str = None,
        mcp_server_url: str = "http://localhost:8000/mcp",
        model: str = "gpt-4.1"
    ):
        self.client = OpenAI(api_key=openai_api_key or os.getenv("OPENAI_API_KEY"))
        self.mcp_server_url = mcp_server_url
        self.model = model
        
        # Configuración de herramientas MCP
        self.mcp_tools_config = {
            "type": "mcp",
            "server_url": self.mcp_server_url,
            "server_label": "chat-assistant",
            "allowed_tools": [
                "buscar_informacion",
                "gestionar_email",
                "gestionar_calendario", 
                "flujo_investigacion_completo",
                "analizar_sentimiento_noticias"
            ],
            "require_approval": "never"
        }
        
        # Historial de conversación
        self.conversation_history = []
    
    def chat(self, message: str, **kwargs) -> str:
        """
        Envía mensaje al chat y obtiene respuesta usando MCP
        
        Args:
            message: Mensaje del usuario
            **kwargs: Parámetros adicionales para OpenAI
        
        Returns:
            Respuesta del asistente
        """
        try:
            # Agregar mensaje del usuario al historial
            self.conversation_history.append({
                "role": "user",
                "content": message
            })
            
            # Configuración de la llamada
            call_config = {
                "model": self.model,
                "input": self.conversation_history,
                "tools": [self.mcp_tools_config],
                "temperature": kwargs.get("temperature", 0.7),
                "max_output_tokens": kwargs.get("max_tokens", 2048)
            }
            
            # Realizar llamada a OpenAI Responses API
            response = self.client.responses.create(**call_config)
            
            # Extraer respuesta
            assistant_message = response.output.content
            
            # Agregar respuesta al historial
            self.conversation_history.append({
                "role": "assistant", 
                "content": assistant_message
            })
            
            # Log para debugging
            logger.info(f"Usuario: {message}")
            logger.info(f"Asistente: {assistant_message}")
            
            return assistant_message
            
        except Exception as e:
            logger.error(f"Error en chat: {e}")
            return f"Lo siento, ocurrió un error: {str(e)}"
    
    def chat_stream(self, message: str, **kwargs):
        """
        Chat con streaming de respuesta
        
        Args:
            message: Mensaje del usuario
            **kwargs: Parámetros adicionales
        
        Yields:
            Chunks de respuesta en tiempo real
        """
        try:
            self.conversation_history.append({
                "role": "user",
                "content": message
            })
            
            call_config = {
                "model": self.model,
                "input": self.conversation_history,
                "tools": [self.mcp_tools_config],
                "temperature": kwargs.get("temperature", 0.7),
                "max_output_tokens": kwargs.get("max_tokens", 2048),
                "stream": True
            }
            
            full_response = ""
            
            for chunk in self.client.responses.create(**call_config):
                if hasattr(chunk, 'output') and hasattr(chunk.output, 'content'):
                    content = chunk.output.content
                    full_response += content
                    yield content
            
            # Agregar respuesta completa al historial
            self.conversation_history.append({
                "role": "assistant",
                "content": full_response
            })
            
        except Exception as e:
            logger.error(f"Error en chat stream: {e}")
            yield f"Error: {str(e)}"
    
    def clear_history(self):
        """Limpiar historial de conversación"""
        self.conversation_history = []
        logger.info("Historial de conversación limpiado")
    
    def save_conversation(self, filename: str):
        """
        Guardar conversación en archivo JSON
        
        Args:
            filename: Nombre del archivo donde guardar
        """
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump({
                    "timestamp": asyncio.get_event_loop().time(),
                    "model": self.model,
                    "mcp_server": self.mcp_server_url,
                    "conversation": self.conversation_history
                }, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Conversación guardada en {filename}")
            
        except Exception as e:
            logger.error(f"Error guardando conversación: {e}")
    
    def load_conversation(self, filename: str):
        """
        Cargar conversación desde archivo JSON
        
        Args:
            filename: Nombre del archivo a cargar
        """
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.conversation_history = data.get("conversation", [])
            
            logger.info(f"Conversación cargada desde {filename}")
            
        except Exception as e:
            logger.error(f"Error cargando conversación: {e}")

def demo_conversation():
    """Demostración de uso del cliente MCP"""
    
    print("🤖 Iniciando demo de Chat Inteligente con MCP...")
    
    # Crear cliente
    client = MCPChatClient()
    
    # Ejemplos de conversación
    ejemplos = [
        "Hola, ¿qué puedes hacer?",
        "Busca información sobre inteligencia artificial en medicina",
        "Analiza el sentimiento de noticias recientes sobre Tesla",
        "Envía un email a test@ejemplo.com con un resumen de IA en medicina",
        "Crea un evento en mi calendario para mañana: 'Revisión proyecto IA'",
        "Realiza una investigación completa sobre 'energías renovables' y envía el informe a director@empresa.com"
    ]
    
    print("\n🔥 Ejecutando ejemplos de conversación...\n")
    
    for i, mensaje in enumerate(ejemplos, 1):
        print(f"👤 Usuario {i}: {mensaje}")
        
        respuesta = client.chat(mensaje)
        print(f"🤖 Asistente: {respuesta}")
        print("-" * 80)
    
    # Guardar conversación
    client.save_conversation("demo_conversation.json")
    print("\n✅ Demo completado. Conversación guardada en 'demo_conversation.json'")

def interactive_chat():
    """Chat interactivo en terminal"""
    
    print("🤖 Chat Inteligente con MCP")
    print("Escribe 'salir' para terminar, 'limpiar' para limpiar historial")
    print("=" * 60)
    
    client = MCPChatClient()
    
    while True:
        try:
            user_input = input("\n👤 Tú: ").strip()
            
            if user_input.lower() in ['salir', 'exit', 'quit']:
                # Ofrecer guardar conversación
                save = input("¿Guardar conversación? (s/n): ").lower().startswith('s')
                if save:
                    filename = input("Nombre del archivo (sin extensión): ").strip()
                    if not filename:
                        filename = "conversacion"
                    client.save_conversation(f"{filename}.json")
                break
            
            elif user_input.lower() in ['limpiar', 'clear']:
                client.clear_history()
                print("🗑️ Historial limpiado")
                continue
            
            elif user_input.lower().startswith('cargar '):
                filename = user_input[7:].strip()
                client.load_conversation(filename)
                continue
            
            elif not user_input:
                continue
            
            # Respuesta con streaming
            print("🤖 Asistente: ", end="", flush=True)
            
            for chunk in client.chat_stream(user_input):
                print(chunk, end="", flush=True)
            
            print()  # Nueva línea después del streaming
            
        except KeyboardInterrupt:
            print("\n\n👋 Chat interrumpido. ¡Hasta luego!")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}")

def batch_process_requests():
    """Procesamiento en lote de solicitudes predefinidas"""
    
    print("📋 Procesamiento en lote de solicitudes...")
    
    # Solicitudes predefinidas
    requests = [
        {
            "id": "research_ai", 
            "message": "Investiga sobre 'inteligencia artificial en salud' y envía informe a investigacion@hospital.com",
            "save_as": "ai_health_research.json"
        },
        {
            "id": "market_analysis",
            "message": "Analiza el sentimiento de noticias sobre 'mercado de criptomonedas' en los últimos 7 días",
            "save_as": "crypto_sentiment.json"
        },
        {
            "id": "schedule_meeting",
            "message": "Crea una reunión para el viernes a las 14:00 sobre 'Revisión Q1 2025'",
            "save_as": "meeting_scheduled.json"
        }
    ]
    
    client = MCPChatClient()
    results = []
    
    for request in requests:
        print(f"\n🔄 Procesando: {request['id']}")
        print(f"📝 Solicitud: {request['message']}")
        
        response = client.chat(request['message'])
        
        result = {
            "request_id": request['id'],
            "message": request['message'],
            "response": response,
            "timestamp": asyncio.get_event_loop().time()
        }
        
        results.append(result)
        
        # Guardar resultado individual
        with open(request['save_as'], 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        
        print(f"✅ Completado y guardado en {request['save_as']}")
    
    # Guardar resumen completo
    with open("batch_results_summary.json", 'w', encoding='utf-8') as f:
        json.dump({
            "batch_id": f"batch_{int(asyncio.get_event_loop().time())}",
            "total_requests": len(requests),
            "results": results
        }, f, indent=2, ensure_ascii=False)
    
    print(f"\n🎯 Procesamiento en lote completado. {len(results)} solicitudes procesadas.")
    print("📊 Resumen guardado en 'batch_results_summary.json'")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        mode = sys.argv[1].lower()
        
        if mode == "demo":
            demo_conversation()
        elif mode == "interactive":
            interactive_chat()
        elif mode == "batch":
            batch_process_requests()
        else:
            print("Modos disponibles: demo, interactive, batch")
    else:
        # Modo interactivo por defecto
        interactive_chat()
