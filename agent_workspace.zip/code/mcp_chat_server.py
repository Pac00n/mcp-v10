#!/usr/bin/env python3
"""
Servidor MCP Integrado para Chat Inteligente
Combina SerpAPI, Gmail, Google Calendar y OpenAI
"""

import asyncio
import os
import json
from typing import Dict, List, Optional, Any
from mcp import FastMCP
import aiohttp
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
import logging

# Configuración de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Crear servidor MCP
mcp = FastMCP("chat-assistant-pro")

# Configuración global
CONFIG = {
    "serpapi": {
        "api_key": os.getenv("SERPAPI_API_KEY"),
        "base_url": "https://serpapi.com/search"
    },
    "google": {
        "oauth_file": os.getenv("GOOGLE_OAUTH_FILE", ".gauth.json"),
        "credentials_dir": os.getenv("GOOGLE_CREDENTIALS_DIR", "./credentials"),
        "scopes": [
            "https://mail.google.com/",
            "https://www.googleapis.com/auth/calendar",
            "https://www.googleapis.com/auth/userinfo.email"
        ]
    }
}

class GoogleServiceManager:
    """Gestor de servicios de Google (Gmail, Calendar)"""
    
    def __init__(self):
        self.credentials = None
        self.gmail_service = None
        self.calendar_service = None
    
    async def authenticate(self):
        """Autenticar con Google OAuth2"""
        try:
            # Cargar credenciales existentes
            creds_file = os.path.join(CONFIG["google"]["credentials_dir"], "token.json")
            if os.path.exists(creds_file):
                self.credentials = Credentials.from_authorized_user_file(
                    creds_file, CONFIG["google"]["scopes"]
                )
            
            # Refrescar si es necesario
            if not self.credentials or not self.credentials.valid:
                if self.credentials and self.credentials.expired and self.credentials.refresh_token:
                    self.credentials.refresh(Request())
                else:
                    # Nuevo flujo de autenticación
                    flow = Flow.from_client_secrets_file(
                        CONFIG["google"]["oauth_file"],
                        scopes=CONFIG["google"]["scopes"]
                    )
                    flow.redirect_uri = "http://localhost:4100/callback"
                    
                    logger.info("Inicia autenticación OAuth2...")
                    # En producción, esto se manejaría diferente
                    auth_url, _ = flow.authorization_url(prompt='consent')
                    print(f"Visita esta URL para autenticar: {auth_url}")
                    
                    # Aquí se implementaría el flujo completo
                    return False
            
            # Crear servicios
            self.gmail_service = build('gmail', 'v1', credentials=self.credentials)
            self.calendar_service = build('calendar', 'v3', credentials=self.credentials)
            
            logger.info("Servicios Google autenticados correctamente")
            return True
            
        except Exception as e:
            logger.error(f"Error en autenticación Google: {e}")
            return False

class SerpAPIClient:
    """Cliente para SerpAPI"""
    
    def __init__(self):
        self.api_key = CONFIG["serpapi"]["api_key"]
        self.base_url = CONFIG["serpapi"]["base_url"]
    
    async def search(self, query: str, engine: str = "google", **params) -> Dict:
        """Realizar búsqueda usando SerpAPI"""
        if not self.api_key:
            raise ValueError("SERPAPI_API_KEY no configurada")
        
        params.update({
            "api_key": self.api_key,
            "q": query,
            "engine": engine
        })
        
        async with aiohttp.ClientSession() as session:
            async with session.get(self.base_url, params=params) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    raise Exception(f"Error SerpAPI: {response.status}")

# Instancias globales
google_manager = GoogleServiceManager()
serpapi_client = SerpAPIClient()

@mcp.tool()
async def buscar_informacion(
    consulta: str, 
    tipo: str = "web", 
    num_resultados: int = 5,
    ubicacion: str = "Spain"
) -> str:
    """
    Busca información usando SerpAPI.
    
    Args:
        consulta: Términos de búsqueda
        tipo: Tipo de búsqueda (web, news, scholar, images)
        num_resultados: Número de resultados a devolver
        ubicacion: Ubicación para la búsqueda
    
    Returns:
        Resultados de búsqueda formateados
    """
    try:
        engine_map = {
            "web": "google",
            "news": "google_news", 
            "scholar": "google_scholar",
            "images": "google_images"
        }
        
        engine = engine_map.get(tipo, "google")
        params = {
            "num": num_resultados,
            "location": ubicacion
        }
        
        if tipo == "news":
            params["gl"] = "es"
            params["hl"] = "es"
        
        resultado = await serpapi_client.search(consulta, engine=engine, **params)
        
        # Formatear resultados
        if "organic_results" in resultado:
            results = resultado["organic_results"][:num_resultados]
            formatted = f"🔍 **Resultados para '{consulta}'** ({tipo}):\n\n"
            
            for i, item in enumerate(results, 1):
                title = item.get("title", "Sin título")
                snippet = item.get("snippet", "Sin descripción")
                link = item.get("link", "")
                
                formatted += f"**{i}. {title}**\n"
                formatted += f"📝 {snippet}\n"
                formatted += f"🔗 {link}\n\n"
            
            return formatted
        
        elif "news_results" in resultado:
            results = resultado["news_results"][:num_resultados]
            formatted = f"📰 **Noticias para '{consulta}'**:\n\n"
            
            for i, item in enumerate(results, 1):
                title = item.get("title", "Sin título")
                snippet = item.get("snippet", "Sin descripción")
                source = item.get("source", "Fuente desconocida")
                date = item.get("date", "")
                
                formatted += f"**{i}. {title}**\n"
                formatted += f"📰 {source} - {date}\n"
                formatted += f"📝 {snippet}\n\n"
            
            return formatted
        
        else:
            return f"No se encontraron resultados para '{consulta}'"
            
    except Exception as e:
        logger.error(f"Error en búsqueda: {e}")
        return f"Error al buscar '{consulta}': {str(e)}"

@mcp.tool()
async def gestionar_email(
    accion: str,
    destinatario: str = None,
    asunto: str = None,
    cuerpo: str = None,
    consulta_busqueda: str = None,
    email_id: str = None,
    max_resultados: int = 10
) -> str:
    """
    Gestiona operaciones de email usando Gmail API.
    
    Args:
        accion: Tipo de operación (enviar, buscar, leer, listar)
        destinatario: Email del destinatario (para enviar)
        asunto: Asunto del email (para enviar)
        cuerpo: Cuerpo del email (para enviar)
        consulta_busqueda: Consulta de búsqueda (para buscar)
        email_id: ID del email (para leer)
        max_resultados: Número máximo de resultados (para buscar/listar)
    
    Returns:
        Resultado de la operación
    """
    try:
        if not google_manager.gmail_service:
            if not await google_manager.authenticate():
                return "❌ Error: No se pudo autenticar con Gmail"
        
        service = google_manager.gmail_service
        
        if accion == "enviar":
            if not all([destinatario, asunto, cuerpo]):
                return "❌ Error: destinatario, asunto y cuerpo son requeridos para enviar"
            
            # Crear mensaje
            import base64
            from email.mime.text import MIMEText
            
            message = MIMEText(cuerpo)
            message['to'] = destinatario
            message['subject'] = asunto
            
            raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
            
            # Enviar
            resultado = service.users().messages().send(
                userId='me',
                body={'raw': raw_message}
            ).execute()
            
            return f"✅ Email enviado correctamente a {destinatario} (ID: {resultado['id']})"
        
        elif accion == "buscar":
            if not consulta_busqueda:
                return "❌ Error: consulta_busqueda es requerida para buscar"
            
            # Buscar emails
            resultado = service.users().messages().list(
                userId='me',
                q=consulta_busqueda,
                maxResults=max_resultados
            ).execute()
            
            if 'messages' not in resultado:
                return f"📭 No se encontraron emails para: {consulta_busqueda}"
            
            messages = resultado['messages']
            formatted = f"📧 **Emails encontrados ({len(messages)}):**\n\n"
            
            for i, msg in enumerate(messages, 1):
                # Obtener detalles del mensaje
                msg_detail = service.users().messages().get(
                    userId='me', 
                    id=msg['id'],
                    format='metadata'
                ).execute()
                
                headers = msg_detail['payload']['headers']
                subject = next((h['value'] for h in headers if h['name'] == 'Subject'), 'Sin asunto')
                sender = next((h['value'] for h in headers if h['name'] == 'From'), 'Desconocido')
                date = next((h['value'] for h in headers if h['name'] == 'Date'), 'Sin fecha')
                
                formatted += f"**{i}. {subject}**\n"
                formatted += f"👤 De: {sender}\n"
                formatted += f"📅 Fecha: {date}\n"
                formatted += f"🆔 ID: {msg['id']}\n\n"
            
            return formatted
        
        elif accion == "leer":
            if not email_id:
                return "❌ Error: email_id es requerido para leer"
            
            # Obtener email completo
            message = service.users().messages().get(
                userId='me',
                id=email_id,
                format='full'
            ).execute()
            
            headers = message['payload']['headers']
            subject = next((h['value'] for h in headers if h['name'] == 'Subject'), 'Sin asunto')
            sender = next((h['value'] for h in headers if h['name'] == 'From'), 'Desconocido')
            date = next((h['value'] for h in headers if h['name'] == 'Date'), 'Sin fecha')
            
            # Extraer cuerpo
            body = ""
            if 'parts' in message['payload']:
                for part in message['payload']['parts']:
                    if part['mimeType'] == 'text/plain':
                        data = part['body']['data']
                        body = base64.urlsafe_b64decode(data).decode('utf-8')
                        break
            else:
                if message['payload']['body'].get('data'):
                    data = message['payload']['body']['data']
                    body = base64.urlsafe_b64decode(data).decode('utf-8')
            
            formatted = f"📧 **Email Details**\n\n"
            formatted += f"**Asunto:** {subject}\n"
            formatted += f"**De:** {sender}\n"
            formatted += f"**Fecha:** {date}\n\n"
            formatted += f"**Contenido:**\n{body}"
            
            return formatted
        
        elif accion == "listar":
            # Listar emails recientes
            resultado = service.users().messages().list(
                userId='me',
                maxResults=max_resultados
            ).execute()
            
            if 'messages' not in resultado:
                return "📭 No se encontraron emails"
            
            messages = resultado['messages']
            formatted = f"📬 **Emails recientes ({len(messages)}):**\n\n"
            
            for i, msg in enumerate(messages, 1):
                msg_detail = service.users().messages().get(
                    userId='me',
                    id=msg['id'],
                    format='metadata'
                ).execute()
                
                headers = msg_detail['payload']['headers']
                subject = next((h['value'] for h in headers if h['name'] == 'Subject'), 'Sin asunto')
                sender = next((h['value'] for h in headers if h['name'] == 'From'), 'Desconocido')
                
                formatted += f"**{i}. {subject}**\n"
                formatted += f"👤 {sender}\n"
                formatted += f"🆔 {msg['id']}\n\n"
            
            return formatted
        
        else:
            return f"❌ Error: Acción '{accion}' no reconocida. Acciones válidas: enviar, buscar, leer, listar"
            
    except Exception as e:
        logger.error(f"Error en gestión de email: {e}")
        return f"❌ Error al gestionar email: {str(e)}"

@mcp.tool()
async def gestionar_calendario(
    accion: str,
    titulo: str = None,
    fecha_inicio: str = None,
    fecha_fin: str = None,
    descripcion: str = None,
    asistentes: List[str] = None,
    calendario_id: str = "primary",
    event_id: str = None,
    max_resultados: int = 10
) -> str:
    """
    Gestiona operaciones de calendario usando Calendar API.
    
    Args:
        accion: Tipo de operación (crear, listar, eliminar, buscar)
        titulo: Título del evento (para crear)
        fecha_inicio: Fecha/hora inicio formato ISO (para crear)
        fecha_fin: Fecha/hora fin formato ISO (para crear)  
        descripcion: Descripción del evento (para crear)
        asistentes: Lista de emails de asistentes (para crear)
        calendario_id: ID del calendario (default: primary)
        event_id: ID del evento (para eliminar)
        max_resultados: Número máximo de resultados
    
    Returns:
        Resultado de la operación
    """
    try:
        if not google_manager.calendar_service:
            if not await google_manager.authenticate():
                return "❌ Error: No se pudo autenticar con Calendar"
        
        service = google_manager.calendar_service
        
        if accion == "crear":
            if not all([titulo, fecha_inicio, fecha_fin]):
                return "❌ Error: titulo, fecha_inicio y fecha_fin son requeridos"
            
            # Crear evento
            evento = {
                'summary': titulo,
                'description': descripcion or '',
                'start': {
                    'dateTime': fecha_inicio,
                    'timeZone': 'Europe/Madrid',
                },
                'end': {
                    'dateTime': fecha_fin,
                    'timeZone': 'Europe/Madrid',
                }
            }
            
            if asistentes:
                evento['attendees'] = [{'email': email} for email in asistentes]
            
            resultado = service.events().insert(
                calendarId=calendario_id,
                body=evento
            ).execute()
            
            return f"✅ Evento creado: {titulo} (ID: {resultado['id']})"
        
        elif accion == "listar":
            from datetime import datetime, timedelta
            
            # Listar eventos próximos
            now = datetime.utcnow().isoformat() + 'Z'
            max_time = (datetime.utcnow() + timedelta(days=30)).isoformat() + 'Z'
            
            resultado = service.events().list(
                calendarId=calendario_id,
                timeMin=now,
                timeMax=max_time,
                maxResults=max_resultados,
                singleEvents=True,
                orderBy='startTime'
            ).execute()
            
            events = resultado.get('items', [])
            
            if not events:
                return "📅 No hay eventos próximos"
            
            formatted = f"📅 **Próximos eventos ({len(events)}):**\n\n"
            
            for i, event in enumerate(events, 1):
                start = event['start'].get('dateTime', event['start'].get('date'))
                title = event.get('summary', 'Sin título')
                description = event.get('description', '')
                
                formatted += f"**{i}. {title}**\n"
                formatted += f"🕐 {start}\n"
                if description:
                    formatted += f"📝 {description}\n"
                formatted += f"🆔 {event['id']}\n\n"
            
            return formatted
        
        elif accion == "eliminar":
            if not event_id:
                return "❌ Error: event_id es requerido para eliminar"
            
            service.events().delete(
                calendarId=calendario_id,
                eventId=event_id
            ).execute()
            
            return f"✅ Evento eliminado (ID: {event_id})"
        
        elif accion == "buscar":
            if not titulo:
                return "❌ Error: titulo es requerido para buscar"
            
            resultado = service.events().list(
                calendarId=calendario_id,
                q=titulo,
                maxResults=max_resultados,
                singleEvents=True,
                orderBy='startTime'
            ).execute()
            
            events = resultado.get('items', [])
            
            if not events:
                return f"📅 No se encontraron eventos para: {titulo}"
            
            formatted = f"🔍 **Eventos encontrados para '{titulo}' ({len(events)}):**\n\n"
            
            for i, event in enumerate(events, 1):
                start = event['start'].get('dateTime', event['start'].get('date'))
                summary = event.get('summary', 'Sin título')
                
                formatted += f"**{i}. {summary}**\n"
                formatted += f"🕐 {start}\n"
                formatted += f"🆔 {event['id']}\n\n"
            
            return formatted
        
        else:
            return f"❌ Error: Acción '{accion}' no reconocida. Acciones válidas: crear, listar, eliminar, buscar"
            
    except Exception as e:
        logger.error(f"Error en gestión de calendario: {e}")
        return f"❌ Error al gestionar calendario: {str(e)}"

@mcp.tool()
async def flujo_investigacion_completo(
    tema: str, 
    destinatario_email: str,
    incluir_noticias: bool = True,
    incluir_academico: bool = True,
    crear_evento_calendario: bool = False
) -> str:
    """
    Flujo completo de investigación: buscar información, crear informe y enviarlo.
    
    Args:
        tema: Tema a investigar
        destinatario_email: Email donde enviar el informe
        incluir_noticias: Si incluir búsqueda de noticias
        incluir_academico: Si incluir búsqueda académica
        crear_evento_calendario: Si crear evento de seguimiento
    
    Returns:
        Resumen del flujo ejecutado
    """
    try:
        logger.info(f"Iniciando investigación completa sobre: {tema}")
        
        # 1. Buscar información general
        info_web = await buscar_informacion(tema, "web", 3)
        
        informe_sections = [
            f"# INFORME DE INVESTIGACIÓN: {tema.upper()}",
            f"*Generado automáticamente el {asyncio.get_event_loop().time()}*",
            "",
            "## 1. INFORMACIÓN GENERAL",
            info_web,
            ""
        ]
        
        # 2. Buscar noticias si se solicita
        if incluir_noticias:
            noticias = await buscar_informacion(f"{tema} noticias recientes", "news", 3)
            informe_sections.extend([
                "## 2. NOTICIAS RECIENTES",
                noticias,
                ""
            ])
        
        # 3. Buscar investigación académica si se solicita
        if incluir_academico:
            academico = await buscar_informacion(f"{tema} research papers", "scholar", 3)
            informe_sections.extend([
                "## 3. INVESTIGACIÓN ACADÉMICA",
                academico,
                ""
            ])
        
        # 4. Añadir conclusión
        informe_sections.extend([
            "## CONCLUSIÓN",
            f"Este informe proporciona una visión completa sobre '{tema}' basada en fuentes web actuales, noticias recientes y literatura académica disponible.",
            "",
            "---",
            "*Informe generado por Asistente IA con MCP*"
        ])
        
        informe_completo = "\n".join(informe_sections)
        
        # 5. Enviar por email
        resultado_email = await gestionar_email(
            accion="enviar",
            destinatario=destinatario_email,
            asunto=f"📊 Informe de Investigación: {tema}",
            cuerpo=informe_completo
        )
        
        resultados = [
            f"✅ Investigación completada sobre '{tema}'",
            f"📧 {resultado_email}"
        ]
        
        # 6. Crear evento de calendario si se solicita
        if crear_evento_calendario:
            from datetime import datetime, timedelta
            
            ahora = datetime.now()
            inicio_evento = (ahora + timedelta(days=7)).isoformat()
            fin_evento = (ahora + timedelta(days=7, hours=1)).isoformat()
            
            resultado_calendario = await gestionar_calendario(
                accion="crear",
                titulo=f"Seguimiento: {tema}",
                fecha_inicio=inicio_evento,
                fecha_fin=fin_evento,
                descripcion=f"Revisión y seguimiento del informe de investigación sobre {tema}",
                asistentes=[destinatario_email]
            )
            
            resultados.append(f"📅 {resultado_calendario}")
        
        return "\n".join(resultados)
        
    except Exception as e:
        logger.error(f"Error en flujo de investigación: {e}")
        return f"❌ Error en investigación sobre '{tema}': {str(e)}"

@mcp.tool()
async def analizar_sentimiento_noticias(tema: str, dias_atras: int = 7) -> str:
    """
    Analiza el sentimiento de noticias recientes sobre un tema.
    
    Args:
        tema: Tema a analizar
        dias_atras: Días hacia atrás para buscar noticias
    
    Returns:
        Análisis de sentimiento de noticias
    """
    try:
        # Buscar noticias recientes
        noticias = await buscar_informacion(f"{tema} últimas noticias", "news", 10)
        
        # Análisis básico de sentimiento (en producción usarías un modelo más sofisticado)
        palabras_positivas = ["éxito", "crecimiento", "mejora", "avance", "positivo", "bueno", "excelente", "incremento"]
        palabras_negativas = ["crisis", "caída", "problema", "fallo", "negativo", "malo", "disminución", "pérdida"]
        
        texto_lower = noticias.lower()
        
        count_positivas = sum(1 for palabra in palabras_positivas if palabra in texto_lower)
        count_negativas = sum(1 for palabra in palabras_negativas if palabra in texto_lower)
        
        if count_positivas > count_negativas:
            sentimiento = "POSITIVO"
            emoji = "😊"
        elif count_negativas > count_positivas:
            sentimiento = "NEGATIVO"
            emoji = "😟"
        else:
            sentimiento = "NEUTRAL"
            emoji = "😐"
        
        analisis = f"""
{emoji} **ANÁLISIS DE SENTIMIENTO: {tema.upper()}**

**Sentimiento General:** {sentimiento}
**Indicadores Positivos:** {count_positivas}
**Indicadores Negativos:** {count_negativas}

**Noticias Analizadas:**
{noticias}

**Resumen:** 
El análisis de noticias recientes sobre '{tema}' muestra un sentimiento {sentimiento.lower()} basado en el contenido encontrado.
        """
        
        return analisis
        
    except Exception as e:
        logger.error(f"Error en análisis de sentimiento: {e}")
        return f"❌ Error al analizar sentimiento para '{tema}': {str(e)}"

# Recursos MCP
@mcp.resource("config://server")
def get_server_config() -> str:
    """Proporciona la configuración actual del servidor"""
    config_info = {
        "servidor": "chat-assistant-pro",
        "herramientas_disponibles": [
            "buscar_informacion",
            "gestionar_email", 
            "gestionar_calendario",
            "flujo_investigacion_completo",
            "analizar_sentimiento_noticias"
        ],
        "integraciones": {
            "serpapi": bool(CONFIG["serpapi"]["api_key"]),
            "google_oauth": os.path.exists(CONFIG["google"]["oauth_file"])
        },
        "version": "1.0.0"
    }
    
    return json.dumps(config_info, indent=2)

@mcp.resource("help://usage")
def get_usage_help() -> str:
    """Proporciona ayuda sobre cómo usar el servidor"""
    return """
# 🤖 Asistente de Chat Inteligente - Guía de Uso

## Herramientas Disponibles:

### 🔍 buscar_informacion
- **Propósito:** Buscar información en web, noticias, académica
- **Ejemplo:** "Busca información sobre inteligencia artificial"

### 📧 gestionar_email  
- **Propósito:** Enviar, buscar, leer emails
- **Ejemplo:** "Envía un email a juan@ejemplo.com con el informe"

### 📅 gestionar_calendario
- **Propósito:** Crear, listar, eliminar eventos
- **Ejemplo:** "Crea una reunión para mañana a las 15:00"

### 🔄 flujo_investigacion_completo
- **Propósito:** Investigación completa con informe por email
- **Ejemplo:** "Investiga sobre blockchain y envía informe a director@empresa.com"

### 📊 analizar_sentimiento_noticias
- **Propósito:** Analizar sentimiento de noticias sobre un tema
- **Ejemplo:** "Analiza el sentimiento de noticias sobre Tesla"

## Configuración Requerida:
- SERPAPI_API_KEY: Clave API de SerpAPI
- Archivo OAuth Google: .gauth.json
- Credenciales Google: directorio ./credentials

## Flujos Típicos:
1. Investigación + Email: Buscar → Compilar → Enviar
2. Seguimiento: Investigación → Email → Evento Calendario  
3. Monitoreo: Búsqueda → Análisis Sentimiento → Alerta Email
    """

# Función principal
async def main():
    """Función principal para iniciar el servidor"""
    logger.info("🚀 Iniciando servidor MCP Chat Assistant Pro...")
    
    # Verificar configuración
    if not CONFIG["serpapi"]["api_key"]:
        logger.warning("⚠️  SERPAPI_API_KEY no configurada")
    
    if not os.path.exists(CONFIG["google"]["oauth_file"]):
        logger.warning(f"⚠️  Archivo OAuth Google no encontrado: {CONFIG['google']['oauth_file']}")
    
    # Crear directorio de credenciales si no existe
    os.makedirs(CONFIG["google"]["credentials_dir"], exist_ok=True)
    
    logger.info("✅ Servidor MCP listo para recibir conexiones")
    
    # Ejecutar servidor MCP
    mcp.run()

if __name__ == "__main__":
    asyncio.run(main())
