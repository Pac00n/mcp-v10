# 🤖 MCP Chat Assistant Pro

Sistema de chat inteligente que integra OpenAI con Model Context Protocol (MCP) para acceder a herramientas de búsqueda web (SerpAPI), gestión de email (Gmail) y calendario (Google Calendar) con selección automática de herramientas.

## ✨ Características

- **🔍 Búsqueda Web Avanzada**: SerpAPI para Google Search, News, Scholar, Images
- **📧 Gestión Inteligente de Email**: Gmail API con OAuth2
- **📅 Administración de Calendario**: Google Calendar con eventos automáticos
- **🤖 Selección Automática de Herramientas**: IA decide qué herramienta usar
- **🔄 Flujos de Trabajo Complejos**: Investigación + Informe + Email + Calendario
- **📊 Análisis de Sentimiento**: Análisis automático de noticias
- **⚡ Integración Directa OpenAI**: Usando Responses API con MCP

## 🏗️ Arquitectura

```
┌─────────────────┐
│   Chat Client   │ ← Interface de usuario
└─────────┬───────┘
          │
┌─────────▼───────┐
│  OpenAI API     │ ← GPT-4 con Responses API
│  (Responses)    │
└─────────┬───────┘
          │
┌─────────▼───────┐
│   MCP Server    │ ← Servidor MCP centralizado
│ (FastMCP)       │
└─────┬───┬───┬───┘
      │   │   │
   ┌──▼┐ ┌▼─┐ ┌▼──┐
   │SE│ │GM│ │GC │ ← Herramientas especializadas
   │RP│ │AI│ │AL │
   └──┘ └──┘ └───┘
   SerpAPI Gmail Calendar
```

## 🚀 Instalación Rápida

### 1. Setup Automático
```bash
# Clonar repositorio
git clone https://github.com/tu-usuario/mcp-chat-assistant.git
cd mcp-chat-assistant

# Ejecutar setup automático
python setup.py
```

### 2. Instalación Manual

#### Requisitos Previos
- Python 3.8+
- Node.js 18+ (para algunos servidores MCP)
- Cuentas en: OpenAI, SerpAPI, Google Cloud

#### Dependencias
```bash
pip install -r requirements.txt
```

#### Configuración de APIs

**OpenAI API**:
1. Obtén tu API key en https://platform.openai.com/
2. Añade a `.env`: `OPENAI_API_KEY=sk-tu-clave`

**SerpAPI**:
1. Regístrate en https://serpapi.com/
2. Añade a `.env`: `SERPAPI_API_KEY=tu-clave`

**Google APIs**:
1. Ve a [Google Cloud Console](https://console.cloud.google.com/)
2. Crea proyecto y habilita Gmail API + Calendar API
3. Crea credenciales OAuth 2.0 para aplicación desktop
4. Descarga JSON y guarda como `.gauth.json`

## ⚙️ Configuración

### Archivo .env
```bash
# APIs
OPENAI_API_KEY=sk-tu-openai-key
SERPAPI_API_KEY=tu-serpapi-key

# Google OAuth
GOOGLE_OAUTH_FILE=.gauth.json
GOOGLE_CREDENTIALS_DIR=./credentials

# Servidor
MCP_SERVER_HOST=localhost
MCP_SERVER_PORT=8000
```

### Google OAuth (.gauth.json)
```json
{
  "installed": {
    "client_id": "tu-client-id.apps.googleusercontent.com",
    "project_id": "tu-project-id",
    "client_secret": "tu-client-secret",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "redirect_uris": ["http://localhost:4100/code"]
  }
}
```

## 🎯 Uso

### 1. Iniciar Servidor MCP
```bash
python mcp_chat_server.py
```

### 2. Chat Interactivo
```bash
# Modo interactivo
python openai_mcp_client.py interactive

# Demo automático
python openai_mcp_client.py demo

# Procesamiento en lote
python openai_mcp_client.py batch
```

### 3. Integración con Claude Desktop

Copia `claude_desktop_config.json` a:
- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows**: `%APPDATA%/Claude/claude_desktop_config.json`

## 💬 Ejemplos de Uso

### Búsqueda Simple
```
Usuario: "Busca información sobre inteligencia artificial en medicina"
Sistema: 🔍 Busca usando SerpAPI → Formatea resultados
```

### Flujo de Investigación Completo
```
Usuario: "Investiga sobre 'energías renovables' y envía informe a director@empresa.com"
Sistema: 
1. 🔍 Busca información web
2. 📰 Busca noticias recientes  
3. 🎓 Busca papers académicos
4. 📝 Compila informe
5. 📧 Envía por email
6. 📅 Crea evento seguimiento (opcional)
```

### Gestión de Email
```
Usuario: "Busca emails del jefe de la última semana y resume los importantes"
Sistema: 
1. 📧 Busca emails con filtros
2. 🤖 Analiza contenido
3. 📋 Crea resumen ejecutivo
```

### Análisis de Sentimiento
```
Usuario: "Analiza el sentimiento de noticias sobre Tesla en los últimos 5 días"
Sistema:
1. 📰 Busca noticias recientes
2. 🧠 Analiza sentimiento
3. 📊 Genera reporte con métricas
```

## 🛠️ Herramientas Disponibles

### 🔍 buscar_informacion
- **Propósito**: Búsqueda en web, noticias, académica, imágenes
- **Parámetros**: consulta, tipo, num_resultados, ubicación
- **Ejemplos**: 
  - `buscar_informacion("IA medicina", "web", 5)`
  - `buscar_informacion("Bitcoin noticias", "news", 3)`

### 📧 gestionar_email
- **Propósito**: Enviar, buscar, leer, listar emails
- **Acciones**: enviar, buscar, leer, listar
- **Ejemplos**:
  - `gestionar_email("enviar", destinatario="test@email.com", asunto="Hola", cuerpo="Mensaje")`
  - `gestionar_email("buscar", consulta_busqueda="from:jefe@empresa.com")`

### 📅 gestionar_calendario
- **Propósito**: Crear, listar, eliminar eventos
- **Acciones**: crear, listar, eliminar, buscar
- **Ejemplos**:
  - `gestionar_calendario("crear", titulo="Reunión", fecha_inicio="2025-06-07T15:00:00")`
  - `gestionar_calendario("listar", max_resultados=10)`

### 🔄 flujo_investigacion_completo
- **Propósito**: Investigación automatizada con informe por email
- **Características**: Multi-fuente, compilación automática, distribución
- **Ejemplo**: `flujo_investigacion_completo("blockchain", "director@empresa.com")`

### 📊 analizar_sentimiento_noticias
- **Propósito**: Análisis de sentimiento de noticias
- **Métricas**: Positivo/Negativo/Neutral con indicadores
- **Ejemplo**: `analizar_sentimiento_noticias("Tesla stock", 7)`

## 🔧 Desarrollo y Personalización

### Agregar Nueva Herramienta
```python
@mcp.tool()
async def mi_nueva_herramienta(parametro: str) -> str:
    """
    Descripción de la herramienta para el LLM.
    
    Args:
        parametro: Descripción del parámetro
    
    Returns:
        Resultado de la operación
    """
    # Tu lógica aquí
    return f"Resultado para {parametro}"
```

### Integrar Nueva API
```python
class MiAPIClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
    
    async def hacer_consulta(self, query: str):
        # Implementación de API
        pass

# Integrar en herramientas MCP
mi_api = MiAPIClient(os.getenv("MI_API_KEY"))
```

## 📊 Monitoreo y Logs

### Estructura de Logs
```
logs/
├── server.log          # Logs del servidor MCP
├── client.log          # Logs del cliente OpenAI
├── api_calls.log       # Logs de llamadas a APIs
└── errors.log          # Logs de errores
```

### Métricas Clave
- Latencia de respuesta por herramienta
- Rate de éxito/error por API
- Uso de tokens OpenAI
- Throughput de requests

## 🔐 Seguridad

### Mejores Prácticas Implementadas
- **OAuth 2.0** para Google APIs
- **API Keys** en variables de entorno
- **Rate limiting** por defecto
- **Validación de entrada** en todas las herramientas
- **Logging de auditoría** para acciones sensibles

### Configuración de Seguridad
```python
# Rate limiting
MAX_REQUESTS_PER_MINUTE = 60

# Validación de emails
ALLOWED_EMAIL_DOMAINS = ["empresa.com", "cliente.com"]

# Scope mínimo Google
GOOGLE_SCOPES = [
    "https://mail.google.com/",
    "https://www.googleapis.com/auth/calendar"
]
```

## 🚀 Deployment en Producción

### Docker
```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 8000

CMD ["uvicorn", "mcp_chat_server:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Variables de Entorno Producción
```bash
# Escalabilidad
MCP_WORKERS=4
MCP_MAX_CONNECTIONS=100

# Cache
REDIS_URL=redis://localhost:6379/0
CACHE_TTL=3600

# Monitoreo
PROMETHEUS_PORT=9090
LOG_LEVEL=INFO
```

### Load Balancer (nginx)
```nginx
upstream mcp_servers {
    server localhost:8000;
    server localhost:8001;
    server localhost:8002;
}

server {
    listen 80;
    location /mcp {
        proxy_pass http://mcp_servers;
        proxy_set_header Host $host;
    }
}
```

## 🧪 Testing

### Tests Unitarios
```bash
pytest tests/ -v
```

### Tests de Integración
```bash
pytest tests/integration/ -v --env=test
```

### Tests de Carga
```bash
locust -f tests/load_test.py --host=http://localhost:8000
```

## 📈 Performance

### Benchmarks Típicos
- **Búsqueda web**: ~2-3 segundos
- **Envío email**: ~1-2 segundos  
- **Creación evento**: ~1-2 segundos
- **Flujo completo**: ~10-15 segundos

### Optimizaciones
- **Cache Redis** para búsquedas frecuentes
- **Connection pooling** para APIs
- **Async/await** en toda la stack
- **Compression** en responses HTTP

## 🆘 Troubleshooting

### Problemas Comunes

**Error de autenticación Google**:
```bash
# Verificar archivo OAuth
ls -la .gauth.json

# Regenerar token
rm credentials/token.json
python mcp_chat_server.py
```

**Error SerpAPI rate limit**:
```bash
# Verificar límites
curl "https://serpapi.com/account" -H "Authorization: Bearer TU_API_KEY"

# Configurar rate limiting
export MAX_SERPAPI_REQUESTS=100
```

**Error OpenAI**:
```bash
# Verificar quota
curl https://api.openai.com/v1/usage \
  -H "Authorization: Bearer $OPENAI_API_KEY"
```

### Logs de Debug
```bash
# Modo debug
LOG_LEVEL=DEBUG python mcp_chat_server.py

# Logs específicos
tail -f logs/api_calls.log
tail -f logs/errors.log
```

## 🤝 Contribuir

1. Fork el repositorio
2. Crea branch: `git checkout -b feature/nueva-funcionalidad`
3. Commit: `git commit -am 'Agrega nueva funcionalidad'`
4. Push: `git push origin feature/nueva-funcionalidad`
5. Crea Pull Request

## 📄 Licencia

MIT License - ver [LICENSE](LICENSE) para detalles.

## 🙏 Reconocimientos

- [Anthropic](https://anthropic.com) por el Model Context Protocol
- [OpenAI](https://openai.com) por la integración MCP en Responses API
- [SerpAPI](https://serpapi.com) por la API de búsqueda
- [Google](https://developers.google.com) por Gmail y Calendar APIs

## 📚 Documentación Adicional

- [MCP Specification](https://modelcontextprotocol.io/specification)
- [OpenAI MCP Guide](https://cookbook.openai.com/examples/mcp/mcp_tool_guide)
- [Google APIs Python](https://github.com/googleapis/google-api-python-client)
- [SerpAPI Documentation](https://serpapi.com/docs)

---

**¿Preguntas o problemas?** Abre un [issue](https://github.com/tu-usuario/mcp-chat-assistant/issues) o contacta al equipo de desarrollo.
